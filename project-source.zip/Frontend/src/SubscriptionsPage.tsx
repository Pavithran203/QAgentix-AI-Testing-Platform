import { useState, useMemo } from 'react'
import {
  Search,
  Grid,
  List,
  Plus,
  MoreVertical,
  Clock,
  Folder,
  ChevronDown,
  ArrowRight,
  Moon,
  SunMedium,
  Bell,
  Sparkles,
  CheckCircle2,
  X,
  Building2,
  Trash2,
  SlidersHorizontal,
  Check,
  TrendingUp,
  FolderOpen,
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'

export type Subscription = {
  id: string
  code: string
  name: string
  category: 'General' | 'Enterprise' | 'Production' | 'AI Automation' | 'QA Lab'
  status: 'Ongoing' | 'Active' | 'Trial' | 'Expiring Soon'
  plan: string
  description: string
  projectsCount: number
  activeAgents: number
  totalRuns: number
  createdAt: string
  accentGradient: string
}

export const initialSubscriptions: Subscription[] = [
  {
    id: 'sub-mdg',
    code: 'SUB-8821',
    name: 'MDG',
    category: 'General',
    status: 'Ongoing',
    plan: 'Enterprise Pro',
    description: 'No subscription description provided.',
    projectsCount: 4,
    activeAgents: 8,
    totalRuns: 1420,
    createdAt: '3 Sep 2026 @06:43',
    accentGradient: 'from-amber-400 via-amber-500 to-teal-500',
  },
  {
    id: 'sub-prompts',
    code: 'SUB-7409',
    name: 'prompts',
    category: 'General',
    status: 'Ongoing',
    plan: 'AI Synthesis Hub',
    description: 'No subscription description provided.',
    projectsCount: 2,
    activeAgents: 5,
    totalRuns: 890,
    createdAt: '28 Aug 2026 @17:21',
    accentGradient: 'from-amber-400 via-teal-400 to-cyan-500',
  },
  {
    id: 'sub-dna',
    code: 'SUB-5502',
    name: 'AI First Test DNA',
    category: 'AI Automation',
    status: 'Active',
    plan: 'Enterprise AI Suite',
    description: 'Autonomous Playwright test generation, self-healing locators, and LLM verification pipelines.',
    projectsCount: 6,
    activeAgents: 12,
    totalRuns: 3240,
    createdAt: '12 Jul 2026 @14:10',
    accentGradient: 'from-teal-400 via-emerald-500 to-indigo-500',
  },
  {
    id: 'sub-rammas',
    code: 'SUB-3190',
    name: 'Rammas Operations',
    category: 'Production',
    status: 'Ongoing',
    plan: 'High-Availability Cluster',
    description: 'Production customer portal regression suites and multi-tenant live health checks.',
    projectsCount: 3,
    activeAgents: 6,
    totalRuns: 2150,
    createdAt: '19 Jun 2026 @10:05',
    accentGradient: 'from-cyan-400 via-blue-500 to-teal-500',
  },
]

type SubscriptionsPageProps = {
  subscriptions: Subscription[]
  onSelectSubscription: (subscription: Subscription) => void
  onAddSubscription: (newSub: Omit<Subscription, 'id' | 'code' | 'createdAt' | 'projectsCount' | 'activeAgents' | 'totalRuns' | 'accentGradient'>) => void
  onDeleteSubscription: (id: string) => void
  theme: 'light' | 'dark'
  toggleTheme: () => void
  user: { name: string; role: string; email: string; avatar: string } | null
  onLogout: () => void
}

export function SubscriptionsPage({
  subscriptions,
  onSelectSubscription,
  onAddSubscription,
  onDeleteSubscription,
  theme,
  toggleTheme,
  user,
  onLogout,
}: SubscriptionsPageProps) {
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')
  const [filterCategory, setFilterCategory] = useState<string>('All')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null)
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false)

  // Form State for Add Modal
  const [newSubName, setNewSubName] = useState('')
  const [newSubCategory, setNewSubCategory] = useState<'General' | 'Enterprise' | 'Production' | 'AI Automation' | 'QA Lab'>('General')
  const [newSubPlan, setNewSubPlan] = useState('Enterprise Pro')
  const [newSubDescription, setNewSubDescription] = useState('')
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  const showToast = (msg: string) => {
    setToastMessage(msg)
    setTimeout(() => setToastMessage(null), 3500)
  }

  const filteredSubscriptions = useMemo(() => {
    return subscriptions.filter((sub) => {
      const matchesSearch =
        sub.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sub.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sub.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sub.description.toLowerCase().includes(searchQuery.toLowerCase())

      const matchesFilter =
        filterCategory === 'All'
          ? true
          : filterCategory === 'Ongoing'
          ? sub.status === 'Ongoing'
          : filterCategory === 'Active'
          ? sub.status === 'Active'
          : filterCategory === 'Trial'
          ? sub.status === 'Trial'
          : sub.category === filterCategory

      return matchesSearch && matchesFilter
    })
  }, [subscriptions, searchQuery, filterCategory])

  const handleCreateSubscription = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newSubName.trim()) return

    onAddSubscription({
      name: newSubName.trim(),
      category: newSubCategory,
      plan: newSubPlan,
      status: 'Ongoing',
      description: newSubDescription.trim() || 'No subscription description provided.',
    })

    setNewSubName('')
    setNewSubDescription('')
    setIsAddModalOpen(false)
    showToast(`Subscription "${newSubName.trim()}" created successfully!`)
  }

  const handleCardClick = (sub: Subscription) => {
    onSelectSubscription(sub)
    navigate('/subprojects')
  }

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 rounded-2xl border border-teal-500/30 bg-teal-900/90 px-4 py-3 text-sm font-medium text-white shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-5">
          <CheckCircle2 className="h-5 w-5 text-teal-400" />
          <span>{toastMessage}</span>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            className="ml-2 rounded-lg p-1 text-teal-300 hover:bg-teal-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Top Navbar */}
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/90 shadow-xs">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          {/* Left: Brand Heading */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-600 text-base font-bold text-white shadow-md shadow-teal-600/20">
              Q
            </div>
            <div>
              <div className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                Q-Agentix
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                AI QA & Testing Platform
              </div>
            </div>
          </div>

          {/* Right: Theme Toggle, Notifications, User Profile */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={toggleTheme}
              className="rounded-xl border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 transition"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <Moon className="h-4 w-4" /> : <SunMedium className="h-4 w-4" />}
            </button>

            <button
              type="button"
              className="relative rounded-xl border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 transition"
              aria-label="Notifications"
            >
              <Bell className="h-4 w-4" />
              <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-teal-500 ring-2 ring-white dark:ring-slate-900" />
            </button>

            {/* User Profile Pill matching screenshot Ada w / Manager */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                className="group flex items-center gap-2.5 rounded-full border border-slate-200 bg-slate-50/80 py-1 pl-1.5 pr-3 text-left transition hover:border-teal-500 hover:bg-white dark:border-slate-800 dark:bg-slate-800/80 dark:hover:border-teal-500"
              >
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-teal-500 text-xs font-bold text-white shadow-sm">
                  {user?.avatar || 'AW'}
                </div>
                <div className="text-left leading-tight hidden sm:block">
                  <div className="text-xs font-bold text-slate-900 dark:text-white">
                    {user?.name || 'Ada w'}
                  </div>
                  <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400">
                    {user?.role || 'Manager'}
                  </div>
                </div>
                <ChevronDown className="h-3 w-3 text-slate-400 group-hover:text-teal-600 transition" />
              </button>

              {/* User Dropdown Menu */}
              {isUserDropdownOpen && (
                <div className="absolute right-0 top-full mt-2 w-56 rounded-2xl border border-slate-200 bg-white p-2 shadow-xl dark:border-slate-800 dark:bg-slate-900 z-50 animate-in fade-in zoom-in-95">
                  <div className="border-b border-slate-100 px-3 py-2 dark:border-slate-800">
                    <div className="text-xs font-bold text-slate-900 dark:text-white">
                      {user?.name || 'Ada w'}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      {user?.email || 'ada.w@qagentix.io'}
                    </div>
                  </div>
                  <div className="mt-1 space-y-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserDropdownOpen(false)
                        navigate('/settings')
                      }}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                    >
                      <Building2 className="h-3.5 w-3.5 text-slate-400" />
                      Workspace Settings
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserDropdownOpen(false)
                        onLogout()
                        navigate('/login')
                      }}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Page Body */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Welcome / Header Title Section */}
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-teal-200 bg-teal-50 px-3 py-1 text-xs font-semibold text-teal-700 dark:border-teal-900 dark:bg-teal-950/40 dark:text-teal-300">
              <Sparkles className="h-3.5 w-3.5 text-teal-500" />
              <span>QAgentix Multi-Tenant Workspace Portal</span>
            </div>
            <h1 className="mt-2 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-white">
              Subscriptions & Workspaces
            </h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Select an active subscription to access automated test suites, locator harvesting, and AI agents.
            </p>
          </div>

          {/* Quick Metrics Bar */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2 shadow-xs dark:border-slate-800 dark:bg-slate-900">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-50 text-teal-600 dark:bg-teal-950/50 dark:text-teal-400">
                <FolderOpen className="h-3.5 w-3.5" />
              </div>
              <div>
                <div className="text-[10px] font-semibold uppercase text-slate-400">Subscriptions</div>
                <div className="text-xs font-bold text-slate-800 dark:text-slate-100">{subscriptions.length} Active</div>
              </div>
            </div>

            <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2 shadow-xs dark:border-slate-800 dark:bg-slate-900">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-400">
                <TrendingUp className="h-3.5 w-3.5" />
              </div>
              <div>
                <div className="text-[10px] font-semibold uppercase text-slate-400">Monthly Runs</div>
                <div className="text-xs font-bold text-slate-800 dark:text-slate-100">7.7k Executed</div>
              </div>
            </div>
          </div>
        </div>

        {/* Search, Filter & Action Toolbar (Matches Screenshot Layout) */}
        <div className="mb-6 flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-xs dark:border-slate-800 dark:bg-slate-900 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by Subscription ID or Name..."
                className="w-full rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-10 pr-9 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-teal-500 focus:bg-white focus:ring-2 focus:ring-teal-500/20 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100 dark:focus:border-teal-400 dark:focus:bg-slate-800"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-0.5 text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {/* Filter Dropdown */}
            <div className="relative shrink-0">
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="w-full sm:w-auto appearance-none rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-9 pr-8 text-sm font-semibold text-slate-700 outline-none transition hover:border-slate-300 focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200 dark:hover:border-slate-600"
              >
                <option value="All">All Subscriptions</option>
                <option value="Ongoing">Ongoing Status</option>
                <option value="Active">Active Status</option>
                <option value="Trial">Trial Tier</option>
                <option value="General">General</option>
                <option value="AI Automation">AI Automation</option>
                <option value="Production">Production</option>
                <option value="QA Lab">QA Lab</option>
              </select>
              <SlidersHorizontal className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            </div>
          </div>

          {/* Right Toolbar Actions: Grid/List switch & Add New Subscription Button */}
          <div className="flex items-center justify-between sm:justify-end gap-2.5">
            {/* View Switcher */}
            <div className="flex items-center rounded-xl border border-slate-200 bg-slate-100/80 p-1 dark:border-slate-700 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`rounded-lg p-1.5 transition ${
                  viewMode === 'grid'
                    ? 'bg-white text-teal-600 shadow-xs dark:bg-slate-700 dark:text-teal-300'
                    : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
                title="Grid View"
              >
                <Grid className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`rounded-lg p-1.5 transition ${
                  viewMode === 'list'
                    ? 'bg-white text-teal-600 shadow-xs dark:bg-slate-700 dark:text-teal-300'
                    : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
                title="List View"
              >
                <List className="h-4 w-4" />
              </button>
            </div>

            {/* + Add New Subscription Button */}
            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="flex items-center gap-2 rounded-xl bg-teal-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-teal-600/20 transition hover:bg-teal-700 hover:shadow-lg active:scale-95"
            >
              <Plus className="h-4 w-4 stroke-[2.5]" />
              <span>Add new subscription</span>
            </button>
          </div>
        </div>

        {/* Subscriptions Grid View */}
        {viewMode === 'grid' && (
          <>
            {filteredSubscriptions.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-200 bg-white/50 p-12 text-center dark:border-slate-800 dark:bg-slate-900/40">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500">
                  <Search className="h-6 w-6" />
                </div>
                <h3 className="mt-3 text-base font-bold text-slate-800 dark:text-slate-200">
                  No subscriptions found
                </h3>
                <p className="mt-1 max-w-sm text-xs text-slate-500 dark:text-slate-400">
                  No subscriptions match "{searchQuery}" with the selected filter. Try adjusting your query.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('')
                    setFilterCategory('All')
                  }}
                  className="mt-4 rounded-xl border border-slate-200 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  Reset filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3">
                {filteredSubscriptions.map((sub) => (
                  <div
                    key={sub.id}
                    onClick={() => handleCardClick(sub)}
                    className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-xs transition-all duration-200 hover:-translate-y-1 hover:border-teal-500/50 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900 cursor-pointer"
                  >
                    {/* Top Colored Accent Stripe */}
                    <div className={`h-1.5 w-full bg-gradient-to-r ${sub.accentGradient}`} />

                    <div className="p-5 flex-1 flex flex-col justify-between">
                      <div>
                        {/* Card Header: Folder Icon + Title + 3-Dots Menu */}
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/10 text-amber-600 transition group-hover:bg-amber-500/20 group-hover:scale-105 dark:bg-amber-500/20 dark:text-amber-400">
                              <Folder className="h-5 w-5" />
                            </div>
                            <div>
                              <h3 className="text-base font-bold text-slate-900 group-hover:text-teal-600 transition dark:text-white dark:group-hover:text-teal-400">
                                {sub.name}
                              </h3>
                              <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500">
                                {sub.code}
                              </span>
                            </div>
                          </div>

                          {/* 3-Dots Menu */}
                          <div
                            className="relative"
                            onClick={(e) => {
                              e.stopPropagation()
                            }}
                          >
                            <button
                              type="button"
                              onClick={() =>
                                setActiveMenuId(activeMenuId === sub.id ? null : sub.id)
                              }
                              className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition"
                            >
                              <MoreVertical className="h-4 w-4" />
                            </button>

                            {activeMenuId === sub.id && (
                              <div className="absolute right-0 top-full mt-1.5 w-44 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl dark:border-slate-800 dark:bg-slate-900 z-30">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setActiveMenuId(null)
                                    handleCardClick(sub)
                                  }}
                                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-teal-50 hover:text-teal-700 dark:text-slate-200 dark:hover:bg-teal-950/40 dark:hover:text-teal-300"
                                >
                                  <ArrowRight className="h-3.5 w-3.5" />
                                  Enter Workspace
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setActiveMenuId(null)
                                    navigator.clipboard?.writeText(sub.code)
                                    showToast(`Copied ${sub.code} to clipboard`)
                                  }}
                                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                                >
                                  <Check className="h-3.5 w-3.5" />
                                  Copy ID ({sub.code})
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setActiveMenuId(null)
                                    onDeleteSubscription(sub.id)
                                    showToast(`Subscription "${sub.name}" removed`)
                                  }}
                                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                  Delete
                                </button>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Category Tag + Status Badge (Matching Screenshot) */}
                        <div className="mt-3.5 flex items-center justify-between">
                          <span className="inline-flex items-center rounded-lg bg-teal-50/80 px-2.5 py-0.5 text-xs font-semibold text-teal-700 dark:bg-teal-950/50 dark:text-teal-300">
                            {sub.category}
                          </span>

                          {/* Ongoing / Active status pill */}
                          <span
                            className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                              sub.status === 'Ongoing'
                                ? 'border border-amber-300/80 bg-amber-50 text-amber-700 dark:border-amber-800 dark:bg-amber-950/50 dark:text-amber-300'
                                : sub.status === 'Active'
                                ? 'border border-emerald-300/80 bg-emerald-50 text-emerald-700 dark:border-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300'
                                : 'border border-sky-300/80 bg-sky-50 text-sky-700 dark:border-sky-800 dark:bg-sky-950/50 dark:text-sky-300'
                            }`}
                          >
                            <span
                              className={`h-1.5 w-1.5 rounded-full ${
                                sub.status === 'Ongoing'
                                  ? 'bg-amber-500 animate-pulse'
                                  : sub.status === 'Active'
                                  ? 'bg-emerald-500'
                                  : 'bg-sky-500'
                              }`}
                            />
                            {sub.status}
                          </span>
                        </div>

                        {/* Description */}
                        <p className="mt-3 text-xs leading-relaxed text-slate-500 dark:text-slate-400 line-clamp-2">
                          {sub.description}
                        </p>

                        {/* Stats Row */}
                        <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-slate-50/80 p-2.5 text-center dark:bg-slate-800/60">
                          <div>
                            <div className="text-[10px] uppercase font-semibold text-slate-400">Projects</div>
                            <div className="text-xs font-bold text-slate-800 dark:text-slate-100">{sub.projectsCount}</div>
                          </div>
                          <div>
                            <div className="text-[10px] uppercase font-semibold text-slate-400">Agents</div>
                            <div className="text-xs font-bold text-slate-800 dark:text-slate-100">{sub.activeAgents}</div>
                          </div>
                          <div>
                            <div className="text-[10px] uppercase font-semibold text-slate-400">Runs</div>
                            <div className="text-xs font-bold text-slate-800 dark:text-slate-100">{sub.totalRuns}</div>
                          </div>
                        </div>
                      </div>

                      {/* Footer: Created timestamp with Clock icon */}
                      <div>
                        <div className="mt-4 border-t border-dashed border-slate-200 pt-3 dark:border-slate-800">
                          <div className="flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500">
                            <div className="flex items-center gap-1.5">
                              <Clock className="h-3.5 w-3.5 text-slate-400" />
                              <span>Created {sub.createdAt}</span>
                            </div>
                            <div className="flex items-center gap-1 font-semibold text-teal-600 group-hover:translate-x-0.5 transition dark:text-teal-400">
                              <span>Enter</span>
                              <ArrowRight className="h-3 w-3" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Subscriptions List / Table View */}
        {viewMode === 'list' && (
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 bg-slate-50/70 uppercase tracking-wider text-slate-400 dark:border-slate-800 dark:bg-slate-800/50 font-bold">
                  <tr>
                    <th className="px-5 py-3.5">Subscription Name</th>
                    <th className="px-4 py-3.5">Category</th>
                    <th className="px-4 py-3.5">Plan Tier</th>
                    <th className="px-4 py-3.5">Status</th>
                    <th className="px-4 py-3.5">Projects / Agents</th>
                    <th className="px-4 py-3.5">Total Runs</th>
                    <th className="px-4 py-3.5">Created At</th>
                    <th className="px-5 py-3.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredSubscriptions.map((sub) => (
                    <tr
                      key={sub.id}
                      onClick={() => handleCardClick(sub)}
                      className="group hover:bg-teal-50/40 dark:hover:bg-slate-800/60 cursor-pointer transition"
                    >
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/10 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400">
                            <Folder className="h-4 w-4" />
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 group-hover:text-teal-600 transition dark:text-white dark:group-hover:text-teal-400">
                              {sub.name}
                            </div>
                            <div className="font-mono text-[10px] text-slate-400">{sub.code}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="inline-flex rounded-lg bg-teal-50 px-2 py-0.5 font-semibold text-teal-700 dark:bg-teal-950/50 dark:text-teal-300">
                          {sub.category}
                        </span>
                      </td>
                      <td className="px-4 py-4 font-medium text-slate-600 dark:text-slate-300">
                        {sub.plan}
                      </td>
                      <td className="px-4 py-4">
                        <span
                          className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                            sub.status === 'Ongoing'
                              ? 'border border-amber-300/80 bg-amber-50 text-amber-700 dark:border-amber-800 dark:bg-amber-950/50 dark:text-amber-300'
                              : 'border border-emerald-300/80 bg-emerald-50 text-emerald-700 dark:border-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300'
                          }`}
                        >
                          <span
                            className={`h-1.5 w-1.5 rounded-full ${
                              sub.status === 'Ongoing' ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'
                            }`}
                          />
                          {sub.status}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-slate-600 dark:text-slate-300 font-medium">
                        {sub.projectsCount} projects • {sub.activeAgents} agents
                      </td>
                      <td className="px-4 py-4 font-bold text-slate-700 dark:text-slate-200">
                        {sub.totalRuns}
                      </td>
                      <td className="px-4 py-4 text-slate-400">
                        {sub.createdAt}
                      </td>
                      <td className="px-5 py-4 text-right">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleCardClick(sub)
                          }}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-teal-50 px-3 py-1.5 text-xs font-bold text-teal-700 transition hover:bg-teal-600 hover:text-white dark:bg-teal-950/50 dark:text-teal-300 dark:hover:bg-teal-600 dark:hover:text-white"
                        >
                          <span>Launch</span>
                          <ArrowRight className="h-3 w-3" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Add New Subscription Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900 animate-in zoom-in-95">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-600 text-white shadow-sm shadow-teal-600/30">
                  <Plus className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Add New Subscription
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Create a new workspace environment for your testing team
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="rounded-xl p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleCreateSubscription} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
                  Subscription Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newSubName}
                  onChange={(e) => setNewSubName(e.target.value)}
                  placeholder="e.g. Mobile E-Commerce Suite, Billing Core QA..."
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-teal-500 focus:bg-white focus:ring-2 focus:ring-teal-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
                    Category
                  </label>
                  <select
                    value={newSubCategory}
                    onChange={(e) => setNewSubCategory(e.target.value as any)}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm font-semibold text-slate-800 outline-none transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                  >
                    <option value="General">General</option>
                    <option value="AI Automation">AI Automation</option>
                    <option value="Production">Production</option>
                    <option value="QA Lab">QA Lab</option>
                    <option value="Enterprise">Enterprise</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
                    Plan Tier
                  </label>
                  <select
                    value={newSubPlan}
                    onChange={(e) => setNewSubPlan(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm font-semibold text-slate-800 outline-none transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                  >
                    <option value="Enterprise Pro">Enterprise Pro</option>
                    <option value="Standard AI">Standard AI</option>
                    <option value="Enterprise AI Suite">Enterprise AI Suite</option>
                    <option value="Starter Lab">Starter Lab</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
                  Description <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <textarea
                  value={newSubDescription}
                  onChange={(e) => setNewSubDescription(e.target.value)}
                  placeholder="Describe the scope, test targets, or workflows for this subscription..."
                  rows={3}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-teal-500 focus:bg-white focus:ring-2 focus:ring-teal-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md shadow-teal-600/20 hover:bg-teal-700 active:scale-95 transition"
                >
                  Create Subscription
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
