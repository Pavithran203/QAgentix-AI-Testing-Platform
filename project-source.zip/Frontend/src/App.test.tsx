import { render, screen, fireEvent } from '@testing-library/react'
import App from './App'

describe('App', () => {
  it('renders the login screen by default', () => {
    render(<App />)
    expect(screen.getByText(/Sign in to QAgentix/i)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /^sign in$/i })).toBeInTheDocument()
  })

  it('allows toggling to the sign up screen', () => {
    render(<App />)
    const signUpLink = screen.getByRole('button', { name: /^sign up$/i })
    fireEvent.click(signUpLink)

    expect(screen.getByText(/Create an account/i)).toBeInTheDocument()
    expect(screen.getByPlaceholderText(/e\.g\. Alicia Morgan/i)).toBeInTheDocument()
    expect(screen.getByPlaceholderText(/alicia@company\.com/i)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /create account/i })).toBeInTheDocument()
  })
  it('renders chat with upload option only in the chat box, and sends prompts and files', async () => {
    const { container } = render(<App />)
    // 1. Fill credentials and sign in
    fireEvent.change(screen.getByPlaceholderText(/e\.g\. alicia or alicia@qagentix\.io/i), {
      target: { value: 'alicia' },
    })
    const passwordInput = container.querySelector('input[name="password"]') as HTMLInputElement
    fireEvent.change(passwordInput, {
      target: { value: 'password123' },
    })
    const signInBtn = screen.getByRole('button', { name: /^sign in$/i })
    fireEvent.click(signInBtn)

    // 2. Select subscription and navigate to projects and workspace
    const subCard = await screen.findByText(/Rammas Operations/i)
    fireEvent.click(subCard)

    const projectCard = await screen.findByText(/Rammas Validation/i)
    fireEvent.click(projectCard)

    const openAgentBtn = await screen.findByRole('link', { name: /agent workspace/i })
    fireEvent.click(openAgentBtn)

    // 3. No standalone upload dropzone and no Active Target banner in the chat box
    expect(screen.queryByText(/Click to upload specification files/i)).not.toBeInTheDocument()
    expect(screen.queryByText(/Upload Spec File/i)).not.toBeInTheDocument()
    expect(screen.queryByText(/Active Target/i)).not.toBeInTheDocument()

    // 4. Upload option is present exclusively inside the chat box
    const uploadBtn = screen.getByRole('button', { name: /upload specification file/i })
    expect(uploadBtn).toBeInTheDocument()
    const fileInput = screen.getByLabelText(/file upload input/i) as HTMLInputElement
    expect(fileInput).toBeInTheDocument()

    // 5. Test uploading a file inside the chat box
    const testFile = new File(['{"openapi":"3.0.0"}'], 'spec-auth.json', { type: 'application/json' })
    fireEvent.change(fileInput, { target: { files: [testFile] } })

    // 6. Attachment chip and file-tailored suggestion prompts appear
    expect(screen.getAllByText(/spec-auth\.json/i).length).toBeGreaterThan(0)
    const sugPrompt = screen.getByRole('button', { name: /Playwright API Test Suite/i })
    expect(sugPrompt).toBeInTheDocument()

    // 7. Click suggestion prompt to immediately generate things
    fireEvent.click(sugPrompt)

    // 8. User message with prompt and AI generation state are triggered
    expect(await screen.findByText(/Generate a complete Playwright TypeScript API test project for spec-auth\.json/i)).toBeInTheDocument()
    expect(screen.getByText(/Analyzing uploaded specifications/i)).toBeInTheDocument()
  })
})
