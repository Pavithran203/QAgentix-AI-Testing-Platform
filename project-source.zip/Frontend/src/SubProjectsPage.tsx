import { useState, useMemo } from 'react'
import {
  Search,
  Grid,
  List,
  Plus,
  MoreVertical,
  Clock,
  ChevronDown,
  ArrowRight,
  ArrowLeft,
  Moon,
  SunMedium,
  Bell,
  CheckCircle2,
  X,
  Trash2,
  SlidersHorizontal,
  BookOpen,
  ClipboardList,
  Code2,
  Globe,
  Layers,
  Sparkles,
  Link2,
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import type { Subscription } from './SubscriptionsPage'

export type SubProject = {
  id: string
  subscriptionId: string
  name: string
  type: 'Web Application' | 'Mobile App' | 'REST API' | 'Microservice'
  endpointsCount: number
  endpoints: string[]
  description: string
  storiesCount: number
  testCasesCount: number
  scriptsCount: number
  createdAt: string
  accentGradient: string
}

export const initialProjects: SubProject[] = [
  // Under 'prompts'
  {
    id: 'proj-prompt-1',
    subscriptionId: 'sub-prompts',
    name: 'prompt',
    type: 'Web Application',
    endpointsCount: 0,
    endpoints: [],
    description: 'No project description provided.',
    storiesCount: 41,
    testCasesCount: 314,
    scriptsCount: 0,
    createdAt: '28 Aug 2026 @17:21',
    accentGradient: 'from-teal-400 via-cyan-500 to-blue-500',
  },
  {
    id: 'proj-prompt-2',
    subscriptionId: 'sub-prompts',
    name: 'prompts',
    type: 'Web Application',
    endpointsCount: 0,
    endpoints: [],
    description: 'No project description provided.',
    storiesCount: 16,
    testCasesCount: 44,
    scriptsCount: 0,
    createdAt: '28 Aug 2026 @17:21',
    accentGradient: 'from-blue-400 via-indigo-500 to-teal-500',
  },
  {
    id: 'proj-prompt-3',
    subscriptionId: 'sub-prompts',
    name: 'Model',
    type: 'Web Application',
    endpointsCount: 0,
    endpoints: [],
    description: 'No project description provided.',
    storiesCount: 16,
    testCasesCount: 53,
    scriptsCount: 0,
    createdAt: '3 Sep 2026 @05:52',
    accentGradient: 'from-emerald-400 via-teal-500 to-cyan-500',
  },
  {
    id: 'proj-prompt-4',
    subscriptionId: 'sub-prompts',
    name: 'checking',
    type: 'Web Application',
    endpointsCount: 0,
    endpoints: [],
    description: 'No project description provided.',
    storiesCount: 12,
    testCasesCount: 4,
    scriptsCount: 0,
    createdAt: '8 Oct 2026 @15:32',
    accentGradient: 'from-amber-400 via-amber-500 to-teal-500',
  },

  // Under 'MDG'
  {
    id: 'proj-mdg-1',
    subscriptionId: 'sub-mdg',
    name: 'MDG Core Portal',
    type: 'Web Application',
    endpointsCount: 2,
    endpoints: ['https://mdg-portal.internal.net', 'https://api.mdg.io/v2'],
    description: 'MDG master admin portal with autonomous locator healing and session tracking.',
    storiesCount: 24,
    testCasesCount: 180,
    scriptsCount: 15,
    createdAt: '3 Sep 2026 @06:43',
    accentGradient: 'from-amber-400 via-teal-500 to-emerald-500',
  },
  {
    id: 'proj-mdg-2',
    subscriptionId: 'sub-mdg',
    name: 'MDG Payments & Billing',
    type: 'REST API',
    endpointsCount: 3,
    endpoints: ['https://billing.mdg.io'],
    description: 'Card tokenization, gateway routing, and invoice generation validation suites.',
    storiesCount: 18,
    testCasesCount: 120,
    scriptsCount: 8,
    createdAt: '10 Sep 2026 @11:20',
    accentGradient: 'from-teal-400 via-emerald-500 to-cyan-600',
  },

  // Under 'AI First Test DNA'
  {
    id: 'proj-dna-1',
    subscriptionId: 'sub-dna',
    name: 'Autonomous Synthesizer',
    type: 'Web Application',
    endpointsCount: 1,
    endpoints: ['https://synth.qagentix.ai'],
    description: 'AI-driven test generator with LLM verification and self-healing locators.',
    storiesCount: 35,
    testCasesCount: 240,
    scriptsCount: 22,
    createdAt: '12 Jul 2026 @14:10',
    accentGradient: 'from-emerald-400 via-teal-500 to-indigo-500',
  },

  // Under 'Rammas Operations'
  {
    id: 'rammas',
    subscriptionId: 'sub-rammas',
    name: 'Rammas Validation',
    type: 'Web Application',
    endpointsCount: 1,
    endpoints: ['https://demo.rammas.ai'],
    description: 'Customer communications and operations portal with multi-tenant health monitoring.',
    storiesCount: 28,
    testCasesCount: 195,
    scriptsCount: 18,
    createdAt: '19 Jun 2026 @10:05',
    accentGradient: 'from-cyan-400 via-blue-500 to-teal-500',
  },
]

type SubProjectsPageProps = {
  subscription: Subscription | null
  projects: SubProject[]
  onSelectProject: (project: SubProject) => void
  onCreateProject: (newProject: Omit<SubProject, 'id' | 'createdAt' | 'storiesCount' | 'testCasesCount' | 'scriptsCount' | 'accentGradient'>) => void
  onDeleteProject: (id: string) => void
  theme: 'light' | 'dark'
  toggleTheme: () => void
  user: { name: string; role: string; email: string; avatar: string } | null
  onLogout: () => void
}

export function SubProjectsPage({
  subscription,
  projects,
  onSelectProject,
  onCreateProject,
  onDeleteProject,
  theme,
  toggleTheme,
  user,
  onLogout,
}: SubProjectsPageProps) {
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')
  const [filterType, setFilterType] = useState<string>('All')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null)
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false)
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  // Create Project Form State
  const [creationMethod, setCreationMethod] = useState<'direct' | 'jira'>('direct')
  const [projectName, setProjectName] = useState('')
  const [projectType, setProjectType] = useState<'Web Application' | 'Mobile App' | 'REST API' | 'Microservice'>('Web Application')
  const [projectDescription, setProjectDescription] = useState('')
  const [endpoints, setEndpoints] = useState<string[]>([])
  const [endpointInput, setEndpointInput] = useState('')
  const [isAddingEndpoint, setIsAddingEndpoint] = useState(false)

  const showToast = (msg: string) => {
    setToastMessage(msg)
    setTimeout(() => setToastMessage(null), 3500)
  }

  // Filter projects by current subscription if provided
  const currentSubProjects = useMemo(() => {
    if (!subscription) return projects
    return projects.filter((p) => p.subscriptionId === subscription.id)
  }, [projects, subscription])

  const filteredProjects = useMemo(() => {
    return currentSubProjects.filter((proj) => {
      const matchesSearch =
        proj.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proj.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proj.description.toLowerCase().includes(searchQuery.toLowerCase())

      const matchesFilter =
        filterType === 'All'
          ? true
          : proj.type === filterType

      return matchesSearch && matchesFilter
    })
  }, [currentSubProjects, searchQuery, filterType])

  const handleAddEndpoint = () => {
    if (!endpointInput.trim()) return
    setEndpoints((prev) => [...prev, endpointInput.trim()])
    setEndpointInput('')
    setIsAddingEndpoint(false)
  }

  const handleRemoveEndpoint = (index: number) => {
    setEndpoints((prev) => prev.filter((_, i) => i !== index))
  }

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!projectName.trim()) return

    onCreateProject({
      subscriptionId: subscription?.id || 'sub-prompts',
      name: projectName.trim(),
      type: projectType,
      endpointsCount: endpoints.length,
      endpoints,
      description: projectDescription.trim() || 'No project description provided.',
    })

    setProjectName('')
    setProjectDescription('')
    setEndpoints([])
    setIsCreateModalOpen(false)
    showToast(`Project "${projectName.trim()}" created successfully!`)
  }

  const handleProjectClick = (proj: SubProject) => {
    onSelectProject(proj)
    navigate('/dashboard')
  }

  const subName = subscription?.name || 'prompts'

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 rounded-2xl border border-teal-500/30 bg-teal-900/90 px-4 py-3 text-sm font-medium text-white shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-5">
          <CheckCircle2 className="h-5 w-5 text-teal-400" />
          <span>{toastMessage}</span>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            className="ml-2 rounded-lg p-1 text-teal-300 hover:bg-teal-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Top Navbar */}
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/90 shadow-xs">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          {/* Left: Brand Heading */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-600 text-base font-bold text-white shadow-md shadow-teal-600/20">
              Q
            </div>
            <div>
              <div className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                Q-Agentix
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                AI QA & Testing Platform
              </div>
            </div>
          </div>

          {/* Right: Theme Toggle, Notifications, User Profile */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={toggleTheme}
              className="rounded-xl border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 transition"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <Moon className="h-4 w-4" /> : <SunMedium className="h-4 w-4" />}
            </button>

            <button
              type="button"
              className="relative rounded-xl border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 transition"
              aria-label="Notifications"
            >
              <Bell className="h-4 w-4" />
              <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-teal-500 ring-2 ring-white dark:ring-slate-900" />
            </button>

            {/* User Profile Pill */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                className="group flex items-center gap-2.5 rounded-full border border-slate-200 bg-slate-50/80 py-1 pl-1.5 pr-3 text-left transition hover:border-teal-500 hover:bg-white dark:border-slate-800 dark:bg-slate-800/80 dark:hover:border-teal-500"
              >
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-teal-500 text-xs font-bold text-white shadow-sm">
                  {user?.avatar || 'AW'}
                </div>
                <div className="text-left leading-tight hidden sm:block">
                  <div className="text-xs font-bold text-slate-900 dark:text-white">
                    {user?.name || 'Ada w'}
                  </div>
                  <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400">
                    {user?.role || 'Manager'}
                  </div>
                </div>
                <ChevronDown className="h-3 w-3 text-slate-400 group-hover:text-teal-600 transition" />
              </button>

              {/* User Dropdown Menu */}
              {isUserDropdownOpen && (
                <div className="absolute right-0 top-full mt-2 w-56 rounded-2xl border border-slate-200 bg-white p-2 shadow-xl dark:border-slate-800 dark:bg-slate-900 z-50 animate-in fade-in zoom-in-95">
                  <div className="border-b border-slate-100 px-3 py-2 dark:border-slate-800">
                    <div className="text-xs font-bold text-slate-900 dark:text-white">
                      {user?.name || 'Ada w'}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      {user?.email || 'ada.w@qagentix.io'}
                    </div>
                  </div>
                  <div className="mt-1 space-y-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserDropdownOpen(false)
                        navigate('/subscriptions')
                      }}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                    >
                      <Layers className="h-3.5 w-3.5 text-slate-400" />
                      Switch Subscription
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserDropdownOpen(false)
                        onLogout()
                        navigate('/login')
                      }}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Page Body */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Breadcrumb / Back to Subscriptions and Title Header */}
        <div className="mb-6 flex items-start gap-4">
          <button
            type="button"
            onClick={() => navigate('/subscriptions')}
            className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-xs transition hover:border-teal-500 hover:bg-teal-50 hover:text-teal-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-teal-500 dark:hover:bg-teal-950/50 dark:hover:text-teal-300"
            title="Back to Subscriptions"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>

          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-white">
                {subName}
              </h1>
              <span className="inline-flex items-center rounded-full border border-teal-200 bg-teal-50 px-2.5 py-0.5 text-xs font-bold text-teal-700 dark:border-teal-900 dark:bg-teal-950/60 dark:text-teal-300">
                {currentSubProjects.length} Projects
              </span>
            </div>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Select a project workspace application to enter the testing suite
            </p>
          </div>
        </div>

        {/* Search, Filter & Action Toolbar */}
        <div className="mb-6 flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-xs dark:border-slate-800 dark:bg-slate-900 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search projects by name or type..."
                className="w-full rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-10 pr-9 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-teal-500 focus:bg-white focus:ring-2 focus:ring-teal-500/20 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100 dark:focus:border-teal-400 dark:focus:bg-slate-800"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-0.5 text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {/* Filter Dropdown */}
            <div className="relative shrink-0">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full sm:w-auto appearance-none rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-9 pr-8 text-sm font-semibold text-slate-700 outline-none transition hover:border-slate-300 focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200 dark:hover:border-slate-600"
              >
                <option value="All">All Types</option>
                <option value="Web Application">Web Application</option>
                <option value="Mobile App">Mobile App</option>
                <option value="REST API">REST API</option>
                <option value="Microservice">Microservice</option>
              </select>
              <SlidersHorizontal className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            </div>
          </div>

          {/* Right Toolbar Actions */}
          <div className="flex items-center justify-between sm:justify-end gap-2.5">
            {/* View Switcher */}
            <div className="flex items-center rounded-xl border border-slate-200 bg-slate-100/80 p-1 dark:border-slate-700 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`rounded-lg p-1.5 transition ${
                  viewMode === 'grid'
                    ? 'bg-white text-teal-600 shadow-xs dark:bg-slate-700 dark:text-teal-300'
                    : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
                title="Grid View"
              >
                <Grid className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`rounded-lg p-1.5 transition ${
                  viewMode === 'list'
                    ? 'bg-white text-teal-600 shadow-xs dark:bg-slate-700 dark:text-teal-300'
                    : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
                title="List View"
              >
                <List className="h-4 w-4" />
              </button>
            </div>

            {/* + Create Project Button */}
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(true)}
              className="flex items-center gap-2 rounded-xl bg-teal-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-teal-600/20 transition hover:bg-teal-700 hover:shadow-lg active:scale-95"
            >
              <Plus className="h-4 w-4 stroke-[2.5]" />
              <span>Create Project</span>
            </button>
          </div>
        </div>

        {/* Projects Grid View */}
        {viewMode === 'grid' && (
          <>
            {filteredProjects.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-200 bg-white/50 p-12 text-center dark:border-slate-800 dark:bg-slate-900/40">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500">
                  <Search className="h-6 w-6" />
                </div>
                <h3 className="mt-3 text-base font-bold text-slate-800 dark:text-slate-200">
                  No projects found
                </h3>
                <p className="mt-1 max-w-sm text-xs text-slate-500 dark:text-slate-400">
                  No project matches "{searchQuery}". Try changing your search or create a new project.
                </p>
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(true)}
                  className="mt-4 inline-flex items-center gap-2 rounded-xl bg-teal-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-teal-700"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Create Project</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3">
                {filteredProjects.map((proj) => (
                  <div
                    key={proj.id}
                    onClick={() => handleProjectClick(proj)}
                    className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-xs transition-all duration-200 hover:-translate-y-1 hover:border-teal-500/50 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900 cursor-pointer"
                  >
                    {/* Top Colored Accent Stripe */}
                    <div className={`h-1.5 w-full bg-gradient-to-r ${proj.accentGradient}`} />

                    <div className="p-5 flex-1 flex flex-col justify-between">
                      <div>
                        {/* Card Header: Icon + Title + 3-Dots Menu */}
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-500/10 text-teal-600 transition group-hover:bg-teal-500/20 group-hover:scale-105 dark:bg-teal-500/20 dark:text-teal-400">
                              <Layers className="h-5 w-5" />
                            </div>
                            <div>
                              <h3 className="text-base font-bold text-slate-900 group-hover:text-teal-600 transition dark:text-white dark:group-hover:text-teal-400">
                                {proj.name}
                              </h3>
                              <span className="text-[11px] font-medium text-slate-400 dark:text-slate-500">
                                {proj.type}
                              </span>
                            </div>
                          </div>

                          {/* 3-Dots Menu */}
                          <div
                            className="relative"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <button
                              type="button"
                              onClick={() =>
                                setActiveMenuId(activeMenuId === proj.id ? null : proj.id)
                              }
                              className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition"
                            >
                              <MoreVertical className="h-4 w-4" />
                            </button>

                            {activeMenuId === proj.id && (
                              <div className="absolute right-0 top-full mt-1.5 w-44 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl dark:border-slate-800 dark:bg-slate-900 z-30">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setActiveMenuId(null)
                                    handleProjectClick(proj)
                                  }}
                                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-teal-50 hover:text-teal-700 dark:text-slate-200 dark:hover:bg-teal-950/40 dark:hover:text-teal-300"
                                >
                                  <ArrowRight className="h-3.5 w-3.5" />
                                  Enter Workspace
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setActiveMenuId(null)
                                    onDeleteProject(proj.id)
                                    showToast(`Project "${proj.name}" removed`)
                                  }}
                                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                  Delete
                                </button>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Application Type & Endpoints Badge */}
                        <div className="mt-3.5 flex items-center justify-between">
                          <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                            {proj.type}
                          </span>

                          <span className="inline-flex items-center gap-1 rounded-full border border-teal-200 bg-teal-50/90 px-2.5 py-0.5 text-[11px] font-bold text-teal-700 dark:border-teal-900 dark:bg-teal-950/50 dark:text-teal-300">
                            <Globe className="h-3 w-3 text-teal-500" />
                            <span>{proj.endpointsCount} Endpoints</span>
                          </span>
                        </div>

                        {/* Description */}
                        <p className="mt-2.5 text-xs leading-relaxed text-slate-500 dark:text-slate-400 line-clamp-2">
                          {proj.description}
                        </p>

                        {/* Stats Row: Stories | Cases | Scripts */}
                        <div className="mt-4 flex items-center justify-between rounded-xl bg-slate-50/80 px-3 py-2 text-xs font-semibold dark:bg-slate-800/60">
                          <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-200">
                            <BookOpen className="h-3.5 w-3.5 text-teal-600 dark:text-teal-400" />
                            <span>{proj.storiesCount} Stories</span>
                          </div>

                          <div className="h-3.5 w-[1px] bg-slate-200 dark:bg-slate-700" />

                          <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-200">
                            <ClipboardList className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                            <span>{proj.testCasesCount} Cases</span>
                          </div>

                          <div className="h-3.5 w-[1px] bg-slate-200 dark:bg-slate-700" />

                          <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-200">
                            <Code2 className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                            <span>{proj.scriptsCount} Scripts</span>
                          </div>
                        </div>
                      </div>

                      {/* Footer: Created timestamp with Clock icon */}
                      <div>
                        <div className="mt-4 border-t border-dashed border-slate-200 pt-3 dark:border-slate-800">
                          <div className="flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500">
                            <div className="flex items-center gap-1.5">
                              <Clock className="h-3.5 w-3.5 text-slate-400" />
                              <span>Created {proj.createdAt}</span>
                            </div>
                            <div className="flex items-center gap-1 font-semibold text-teal-600 group-hover:translate-x-0.5 transition dark:text-teal-400">
                              <span>Open</span>
                              <ArrowRight className="h-3 w-3" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Projects List / Table View */}
        {viewMode === 'list' && (
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 bg-slate-50/70 uppercase tracking-wider text-slate-400 dark:border-slate-800 dark:bg-slate-800/50 font-bold">
                  <tr>
                    <th className="px-5 py-3.5">Project Name</th>
                    <th className="px-4 py-3.5">Type</th>
                    <th className="px-4 py-3.5">Endpoints</th>
                    <th className="px-4 py-3.5">Stories / Test Cases</th>
                    <th className="px-4 py-3.5">Scripts</th>
                    <th className="px-4 py-3.5">Created Date</th>
                    <th className="px-5 py-3.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredProjects.map((proj) => (
                    <tr
                      key={proj.id}
                      onClick={() => handleProjectClick(proj)}
                      className="group hover:bg-teal-50/40 dark:hover:bg-slate-800/60 cursor-pointer transition"
                    >
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-500/10 text-teal-600 dark:bg-teal-500/20 dark:text-teal-400">
                            <Layers className="h-4 w-4" />
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 group-hover:text-teal-600 transition dark:text-white dark:group-hover:text-teal-400">
                              {proj.name}
                            </div>
                            <div className="text-[11px] text-slate-500">{proj.description}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 font-semibold text-slate-700 dark:text-slate-300">
                        {proj.type}
                      </td>
                      <td className="px-4 py-4">
                        <span className="inline-flex items-center gap-1 rounded-full bg-teal-50 px-2 py-0.5 text-[11px] font-bold text-teal-700 dark:bg-teal-950/50 dark:text-teal-300">
                          <Globe className="h-3 w-3" />
                          {proj.endpointsCount} Endpoints
                        </span>
                      </td>
                      <td className="px-4 py-4 font-medium text-slate-700 dark:text-slate-300">
                        {proj.storiesCount} stories • {proj.testCasesCount} cases
                      </td>
                      <td className="px-4 py-4 font-bold text-slate-700 dark:text-slate-300">
                        {proj.scriptsCount} scripts
                      </td>
                      <td className="px-4 py-4 text-slate-400">
                        {proj.createdAt}
                      </td>
                      <td className="px-5 py-4 text-right">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleProjectClick(proj)
                          }}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-teal-50 px-3 py-1.5 text-xs font-bold text-teal-700 transition hover:bg-teal-600 hover:text-white dark:bg-teal-950/50 dark:text-teal-300 dark:hover:bg-teal-600 dark:hover:text-white"
                        >
                          <span>Launch</span>
                          <ArrowRight className="h-3 w-3" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Create Project Modal (Matches Screenshot 2) */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-xl overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900 animate-in zoom-in-95 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4 dark:border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-600 text-white shadow-sm shadow-teal-600/30">
                  <Layers className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Create Project
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Configure a targeted workspace under <span className="font-semibold text-teal-600 dark:text-teal-400">{subName}</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="rounded-xl p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleFormSubmit} className="p-6 space-y-4 overflow-y-auto">
              {/* Creation Method (Direct Project vs Import from Jira) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  Creation Method <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Direct Project Option */}
                  <div
                    onClick={() => setCreationMethod('direct')}
                    className={`cursor-pointer rounded-2xl border-2 p-3.5 transition flex items-center gap-3 ${
                      creationMethod === 'direct'
                        ? 'border-teal-500 bg-teal-50/40 ring-2 ring-teal-500/20 dark:border-teal-400 dark:bg-teal-950/30'
                        : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-800/40'
                    }`}
                  >
                    <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl ${
                      creationMethod === 'direct' ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-500 dark:bg-slate-700'
                    }`}>
                      <Sparkles className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        Direct Project
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        Quick manual setup
                      </div>
                    </div>
                  </div>

                  {/* Jira Option */}
                  <div
                    onClick={() => setCreationMethod('jira')}
                    className={`cursor-pointer rounded-2xl border-2 p-3.5 transition flex items-center gap-3 opacity-90 ${
                      creationMethod === 'jira'
                        ? 'border-teal-500 bg-teal-50/40 ring-2 ring-teal-500/20 dark:border-teal-400 dark:bg-teal-950/30'
                        : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300 font-bold text-xs">
                      J
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900 dark:text-white">
                          Import from Jira
                        </span>
                        <span className="rounded-full bg-amber-100 px-1.5 py-0.2 text-[9px] font-bold text-amber-700 dark:bg-amber-950 dark:text-amber-300">
                          In Progress
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        Sync board epic or project
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Parent Subscription Readonly */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Parent Subscription <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  disabled
                  value={subName}
                  className="w-full rounded-xl border border-slate-200 bg-slate-100 px-3.5 py-2.5 text-sm font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 cursor-not-allowed"
                />
              </div>

              {/* Project Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Project Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="e.g. Mobile Banking App, Checkout API"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-teal-500 focus:bg-white focus:ring-2 focus:ring-teal-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              {/* Application Type */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Application Type
                </label>
                <select
                  value={projectType}
                  onChange={(e) => setProjectType(e.target.value as any)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm font-semibold text-slate-800 outline-none transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                >
                  <option value="Web Application">Web Application</option>
                  <option value="Mobile App">Mobile App (iOS / Android)</option>
                  <option value="REST API">REST API</option>
                  <option value="Microservice">Microservice</option>
                </select>
              </div>

              {/* Project Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Project Description <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <textarea
                  value={projectDescription}
                  onChange={(e) => setProjectDescription(e.target.value)}
                  placeholder="Provide details about the target application scope..."
                  rows={2}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-teal-500 focus:bg-white focus:ring-2 focus:ring-teal-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              {/* Environment Endpoints */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Environment Endpoints <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  {!isAddingEndpoint && (
                    <button
                      type="button"
                      onClick={() => setIsAddingEndpoint(true)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-teal-600 hover:text-teal-700 dark:text-teal-400"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>Add Endpoint</span>
                    </button>
                  )}
                </div>

                {/* Adding Endpoint Input Row */}
                {isAddingEndpoint && (
                  <div className="mb-2.5 flex items-center gap-2">
                    <input
                      type="url"
                      value={endpointInput}
                      onChange={(e) => setEndpointInput(e.target.value)}
                      placeholder="https://app.yourdomain.com"
                      className="flex-1 rounded-xl border border-teal-400 bg-white px-3 py-1.5 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-teal-500/20 dark:bg-slate-800 dark:text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={handleAddEndpoint}
                      className="rounded-xl bg-teal-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-teal-700"
                    >
                      Add
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddingEndpoint(false)
                        setEndpointInput('')
                      }}
                      className="rounded-xl border border-slate-200 px-2 py-1.5 text-xs text-slate-500 hover:bg-slate-100 dark:border-slate-700"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}

                {/* List of Added Endpoints */}
                {endpoints.length > 0 ? (
                  <div className="space-y-1.5">
                    {endpoints.map((ep, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-300"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <Link2 className="h-3.5 w-3.5 text-teal-500 shrink-0" />
                          <span className="truncate">{ep}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveEndpoint(idx)}
                          className="text-slate-400 hover:text-red-500 ml-2"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="rounded-xl border border-dashed border-slate-200 p-2.5 text-center text-xs text-slate-400 dark:border-slate-800">
                    No custom endpoints added yet.
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md shadow-teal-600/20 hover:bg-teal-700 active:scale-95 transition"
                >
                  + Create Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
