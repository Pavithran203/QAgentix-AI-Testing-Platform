import React, { useState, useMemo, useRef, useEffect } from 'react'
import Editor from '@monaco-editor/react'
import {
  Bot,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ClipboardCheck,
  Copy,
  Cpu,
  Download,
  ExternalLink,
  FileCode,
  FileSpreadsheet,
  FileText,
  FolderOpen,
  MessageSquare,
  Paperclip,
  Plus,
  RefreshCw,
  Send,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react'

export interface KiroStatus {
  installed: boolean
  executable?: string | null
  version?: string | null
  gateway_url?: string
  gateway_port?: number
  gateway_active: boolean
  mcp_server_available?: boolean
  mcp_server_path?: string
  mcp_registered: boolean
  mcp_config_path?: string | null
  mcp_handshake_ok: boolean
  mcp_tool_count: number
  mcp_error?: string | null
  connection_state: 'not_installed' | 'not_registered' | 'registered_unreachable' | 'connected'
}

export interface GeneratedTestCase {
  id: string
  title: string
  description: string
  steps: string[]
  expectedResult: string
  priority: 'High' | 'Medium' | 'Low'
  category: 'E2E' | 'Regression' | 'Boundary' | 'Security' | 'Smoke'
}

export interface GeneratedFile {
  path: string
  name: string
  language: string
  description: string
  content: string
}

export interface GeneratedBundle {
  title: string
  description: string
  summary: {
    totalCases: number
    positiveCount: number
    negativeCount: number
    edgeCount: number
    coverage: string
  }
  testCases: GeneratedTestCase[]
  files: GeneratedFile[]
}

export interface ChatAttachment {
  id: string
  name: string
  size: string
  type: string
  content?: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  timestamp: string
  content: string
  attachments?: ChatAttachment[]
  isGenerating?: boolean
  generationStep?: number
  bundle?: GeneratedBundle
}

export interface StoredChatSession {
  id: string
  userId: string
  title: string
  project: string
  createdAt: string
  updatedAt: string
  messages: ChatMessage[]
  storageLocation?: 'indexeddb' | 'filesystem' | 'memory'
  localFolderName?: string
}

interface KiroIdeWorkspaceProps {
  activeProjectName: string
  userEmail?: string
  userName?: string
  sessions: StoredChatSession[]
  activeSession: StoredChatSession
  activeSessionId: string
  setActiveSessionId: (id: string) => void
  onNewChat: () => void
  onClearAllChats: () => void
  lastSavedAt?: Date | null
  kiroInfo: KiroStatus | null
  kiroConnecting: boolean
  onConnectKiro: () => void
  onSendMessage: (promptText?: string) => void
  inputText: string
  setInputText: (text: string) => void
  attachedFiles: ChatAttachment[]
  onFileSelect: (files: FileList | null) => void
  onRemoveAttachment: (id: string) => void
  onDownloadZip: (bundle: GeneratedBundle) => void
  onSaveToLocalFolder: (bundle: GeneratedBundle) => void
  onDownloadSingleFile: (name: string, content: string, mime?: string) => void
  onCopyCode: (content: string, id: string) => void
  copiedFileId: string | null
  dynamicSuggestions: Array<{
    id: string
    label: string
    prompt: string
    badge: string
    color: string
  }>
  sampleBundle: GeneratedBundle
}

export const KiroIdeWorkspace: React.FC<KiroIdeWorkspaceProps> = ({
  activeProjectName,
  sessions,
  activeSession,
  activeSessionId,
  setActiveSessionId,
  onNewChat,
  onClearAllChats,
  lastSavedAt: _lastSavedAt,
  kiroInfo,
  kiroConnecting,
  onConnectKiro,
  onSendMessage,
  inputText,
  setInputText,
  attachedFiles,
  onFileSelect,
  onRemoveAttachment,
  onDownloadZip,
  onSaveToLocalFolder,
  onDownloadSingleFile: _onDownloadSingleFile,
  onCopyCode,
  copiedFileId,
  dynamicSuggestions,
  sampleBundle,
}) => {
  // State for layout panes
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isAgentPanelOpen, setIsAgentPanelOpen] = useState(true)
  const [autopilot, setAutopilot] = useState(true)
  const [agentMode, setAgentMode] = useState<'agent' | 'ask' | 'edit'>('agent')
  const [isSuggestionsOpen, setIsSuggestionsOpen] = useState(true)
  const [chatPanelWidth, setChatPanelWidth] = useState<number>(440)
  const [isResizingChat, setIsResizingChat] = useState<boolean>(false)

  // Editor tabs state
  const [openEditorTabs, setOpenEditorTabs] = useState<string[]>([
    'test-matrix',
    'tests/user-auth.spec.ts',
    'test-cases.csv',
    'playwright.config.ts',
  ])
  const [selectedEditorFile, setSelectedEditorFile] = useState<string>('test-matrix')

  // Find the active bundle from messages or fallback to sampleBundle
  const activeBundle: GeneratedBundle = useMemo(() => {
    const msgs = activeSession?.messages || []
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i]?.bundle) return msgs[i].bundle!
    }
    return sampleBundle
  }, [activeSession?.messages, sampleBundle])

  // Sync open tabs when bundle changes
  useEffect(() => {
    if (activeBundle?.files && activeBundle.files.length > 0) {
      const spec = activeBundle.files.find((f) => f.path.endsWith('.spec.ts'))
      if (spec && !openEditorTabs.includes(spec.path)) {
        setOpenEditorTabs((prev) => [...prev, spec.path])
        setSelectedEditorFile(spec.path)
      }
    }
  }, [activeBundle])

  const handleOpenEditorTab = (path: string) => {
    if (!openEditorTabs.includes(path)) {
      setOpenEditorTabs((prev) => [...prev, path])
    }
    setSelectedEditorFile(path)
  }

  const handleCloseEditorTab = (e: React.MouseEvent, path: string) => {
    e.stopPropagation()
    const nextTabs = openEditorTabs.filter((t) => t !== path)
    if (nextTabs.length === 0) return
    setOpenEditorTabs(nextTabs)
    if (selectedEditorFile === path) {
      setSelectedEditorFile(nextTabs[nextTabs.length - 1])
    }
  }

  // Active file content in editor
  const activeEditorContent = useMemo(() => {
    if (selectedEditorFile === 'test-matrix') return ''
    const f = activeBundle.files.find((file) => file.path === selectedEditorFile)
    return f ? f.content : ''
  }, [activeBundle, selectedEditorFile])

  const activeEditorLanguage = useMemo(() => {
    if (selectedEditorFile.endsWith('.ts')) return 'typescript'
    if (selectedEditorFile.endsWith('.json')) return 'json'
    if (selectedEditorFile.endsWith('.csv')) return 'plaintext'
    if (selectedEditorFile.endsWith('.yaml') || selectedEditorFile.endsWith('.yml')) return 'yaml'
    return 'markdown'
  }, [selectedEditorFile])

  // Filters for test cases table
  const [tableSearch, setTableSearch] = useState('')
  const [tableCategory, setTableCategory] = useState<string>('All')

  const filteredCases = useMemo(() => {
    return activeBundle.testCases.filter((tc) => {
      const matchesSearch =
        tableSearch === '' ||
        tc.title.toLowerCase().includes(tableSearch.toLowerCase()) ||
        tc.id.toLowerCase().includes(tableSearch.toLowerCase())
      const matchesCat = tableCategory === 'All' || tc.category === tableCategory
      return matchesSearch && matchesCat
    })
  }, [activeBundle.testCases, tableSearch, tableCategory])

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [activeSession?.messages])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      onSendMessage()
    }
  }

  // Auto-expand textarea dynamically up to 260px as the user types long multiline prompts
  useEffect(() => {
    const el = textareaRef.current
    if (el) {
      el.style.height = 'auto'
      const scrollH = el.scrollHeight
      const nextH = Math.min(Math.max(scrollH, 56), 260)
      el.style.height = `${nextH}px`
    }
  }, [inputText])

  // Drag-to-resize listener for Agent Chat window
  useEffect(() => {
    if (!isResizingChat) return
    const handleMouseMove = (e: MouseEvent) => {
      const newWidth = window.innerWidth - e.clientX
      const maxAllowed = Math.floor(window.innerWidth * 0.65)
      setChatPanelWidth(Math.max(320, Math.min(newWidth, maxAllowed)))
    }
    const handleMouseUp = () => setIsResizingChat(false)
    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isResizingChat])

  return (
    <div className="relative flex flex-col h-full min-h-0 flex-1 overflow-hidden bg-slate-50 text-slate-800 font-sans">
      {/* 1. CLEAN WORKSPACE HEADER */}
      <header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-3.5 select-none text-xs">
        {/* Left: Clean Project Context */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 font-bold text-teal-600">
            <Bot className="h-4 w-4 text-teal-500" />
            <span className="font-semibold text-xs tracking-tight text-slate-800">QAgentix Studio</span>
          </div>
          <span className="text-slate-300">/</span>
          <span className="text-[11px] font-medium text-slate-500">{activeProjectName}</span>
          <span className="text-slate-300">•</span>
          <span className="text-[11px] text-teal-600 font-medium truncate max-w-xs">{activeSession?.title || 'Test Suite'}</span>
        </div>

        {/* Right: Kiro Connection & Agent Focus */}
        <div className="flex items-center gap-2">
          {kiroInfo?.connection_state === 'connected' ? (
            <span
              className="inline-flex items-center gap-1.5 rounded-full bg-teal-50 px-2.5 py-1 text-[10px] font-semibold text-teal-700 border border-teal-200"
              title={`QAgentix MCP server is connected (${kiroInfo.mcp_tool_count} tools).`}
            >
              <Cpu className="h-3 w-3 text-teal-600" />
              <span>Kiro MCP ({kiroInfo.mcp_tool_count} tools)</span>
            </span>
          ) : kiroInfo?.connection_state === 'not_registered' ? (
            <button
              type="button"
              onClick={onConnectKiro}
              disabled={kiroConnecting}
              className="inline-flex items-center gap-1.5 rounded-full bg-teal-600 px-3 py-1 text-[10px] font-semibold text-white hover:bg-teal-700 transition shadow-xs disabled:opacity-50"
              title="Click to register QAgentix MCP server in Kiro"
            >
              <Cpu className="h-3 w-3" />
              <span>{kiroConnecting ? 'Connecting…' : 'Connect Kiro MCP'}</span>
            </button>
          ) : null}

          <a
            href="/architecture-3d.html"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 rounded-full bg-sky-50 px-2.5 py-1 text-[10px] font-semibold text-sky-700 border border-sky-200 hover:bg-sky-100 transition"
            title="Open interactive 3D Architecture Model"
          >
            <ExternalLink className="h-3 w-3" />
            <span className="hidden sm:inline">3D Architecture</span>
          </a>

          <button
            type="button"
            onClick={() => setIsAgentPanelOpen((prev) => !prev)}
            className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold border transition ${
              isAgentPanelOpen
                ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
            title="Toggle Right Agent Panel"
          >
            Agent Focus
          </button>
        </div>
      </header>

      {/* 2. MAIN 3-PANE CONTAINER */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* LEFT COLUMN: EXPLORER SIDEBAR */}
        <aside
          className={`${
            isSidebarOpen ? 'w-60 sm:w-64' : 'w-0'
          } shrink-0 transition-all duration-200 ease-in-out border-r border-slate-200 bg-white flex flex-col overflow-hidden select-none`}
        >
          {/* Explorer Header */}
          <div className="flex h-9 items-center justify-between border-b border-slate-200 px-3 text-[11px] font-bold tracking-wider text-slate-500 uppercase">
            <span>Explorer: QAgenticx</span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={onNewChat}
                className="rounded p-1 hover:bg-slate-100 text-slate-600 hover:text-slate-900"
                title="New Test Chat Scenario"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setIsSidebarOpen(false)}
                className="rounded p-1 hover:bg-slate-100 text-slate-600"
                title="Collapse Explorer"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {/* Section 1: Project Files Tree */}
          <div className="flex-1 overflow-y-auto p-2 space-y-4">
            <div>
              <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 font-bold flex items-center justify-between">
                <span>Workspace Files ({activeBundle.files.length})</span>
                <span className="text-[9px] text-teal-400 font-mono">v4.2</span>
              </div>
              <div className="space-y-0.5 text-xs">
                {/* Virtual Interactive Test Matrix Tab */}
                <button
                  type="button"
                  onClick={() => handleOpenEditorTab('test-matrix')}
                  className={`flex w-full items-center gap-2 rounded px-2 py-1 text-left transition ${
                    selectedEditorFile === 'test-matrix'
                      ? 'bg-teal-50 text-teal-900 border-l-2 border-teal-600 font-semibold shadow-xs'
                      : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <ClipboardCheck className="h-3.5 w-3.5 text-teal-600 shrink-0" />
                  <span className="truncate">Test Cases Matrix</span>
                  <span className="ml-auto rounded bg-teal-500/20 px-1 text-[9px] font-mono text-teal-300">
                    {activeBundle.testCases.length}
                  </span>
                </button>

                {/* Real Files in Bundle */}
                {activeBundle.files.map((file) => {
                  const isSelected = selectedEditorFile === file.path
                  const isSpec = file.path.endsWith('.spec.ts') || file.path.endsWith('.ts')
                  const isCsv = file.path.endsWith('.csv')
                  const isJson = file.path.endsWith('.json')
                  return (
                    <button
                      key={file.path}
                      type="button"
                      onClick={() => handleOpenEditorTab(file.path)}
                      className={`flex w-full items-center gap-2 rounded px-2 py-1 text-left transition ${
                        isSelected
                          ? 'bg-teal-50 text-teal-900 border-l-2 border-teal-600 font-semibold shadow-xs'
                          : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      {isSpec ? (
                        <FileCode className="h-3.5 w-3.5 text-teal-400 shrink-0" />
                      ) : isCsv ? (
                        <FileSpreadsheet className="h-3.5 w-3.5 text-blue-600 shrink-0" />
                      ) : isJson ? (
                        <FileText className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                      ) : (
                        <FileText className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                      )}
                      <span className="truncate">{file.path}</span>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Section 2: Recent Scenarios */}
            <div>
              <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Scenarios ({sessions.length})
              </div>
              <div className="space-y-0.5 text-xs">
                {sessions.map((sess) => {
                  const isActive = sess.id === activeSessionId
                  return (
                    <button
                      key={sess.id}
                      type="button"
                      onClick={() => setActiveSessionId(sess.id)}
                      className={`flex w-full items-center justify-between rounded px-2 py-1 text-left transition ${
                        isActive
                          ? 'bg-teal-50 text-teal-900 border-l-2 border-teal-600 font-semibold shadow-xs'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 truncate">
                        <MessageSquare className="h-3 w-3 shrink-0 text-teal-400" />
                        <span className="truncate">{sess.title}</span>
                      </div>
                      <span className="text-[9px] text-slate-500 shrink-0">
                        {sess.messages.length}
                      </span>
                    </button>
                  )
                })}
              </div>
            </div>
          </div>

          {/* Explorer Footer Quick Actions */}
          <div className="border-t border-slate-200 p-2 flex items-center justify-between text-[11px] text-slate-600">
            <button
              type="button"
              onClick={() => onDownloadZip(activeBundle)}
              className="flex items-center gap-1 rounded px-2 py-1 hover:bg-teal-50 text-teal-700 transition"
              title="Download entire project as ZIP"
            >
              <Download className="h-3 w-3" />
              <span>Export ZIP</span>
            </button>
            <button
              type="button"
              onClick={onClearAllChats}
              className="flex items-center gap-1 rounded px-2 py-1 hover:bg-red-950/40 text-red-400 transition"
              title="Clear all local conversations"
            >
              <Trash2 className="h-3 w-3" />
              <span>Clear</span>
            </button>
          </div>
        </aside>

        {/* CENTER COLUMN: MONACO CODE EDITOR & TEST CASES WORKSPACE */}
        <main className="flex flex-1 min-w-0 flex-col overflow-hidden bg-slate-100/60">
          {/* Editor Tabs Bar */}
          <div className="flex h-9 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-100/80 px-2 select-none">
            <div className="flex flex-1 min-w-0 items-center gap-1 overflow-x-auto no-scrollbar">
              {!isSidebarOpen && (
                <button
                  type="button"
                  onClick={() => setIsSidebarOpen(true)}
                  className="rounded p-1 text-slate-600 hover:bg-slate-200 hover:text-slate-900 mr-1"
                  title="Expand Explorer"
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              )}
              {openEditorTabs.map((tabPath) => {
                const isActive = selectedEditorFile === tabPath
                const tabTitle =
                  tabPath === 'test-matrix'
                    ? 'Test Cases Matrix'
                    : tabPath.split('/').pop() || tabPath
                return (
                  <div
                    key={tabPath}
                    onClick={() => setSelectedEditorFile(tabPath)}
                    className={`group flex items-center gap-2 border-r border-slate-200 px-3 py-1.5 text-xs cursor-pointer transition ${
                      isActive
                        ? 'bg-white text-slate-900 border-t-2 border-t-teal-600 font-bold shadow-xs'
                        : 'bg-slate-100/70 text-slate-500 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    {tabPath === 'test-matrix' ? (
                      <ClipboardCheck className="h-3.5 w-3.5 text-teal-600 shrink-0" />
                    ) : tabPath.endsWith('.ts') ? (
                      <FileCode className="h-3.5 w-3.5 text-teal-600 shrink-0" />
                    ) : tabPath.endsWith('.csv') ? (
                      <FileSpreadsheet className="h-3.5 w-3.5 text-blue-600 shrink-0" />
                    ) : tabPath.endsWith('.json') ? (
                      <FileText className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                    ) : (
                      <FileText className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                    )}
                    <span className="truncate max-w-[140px]">{tabTitle}</span>
                    <button
                      type="button"
                      onClick={(e) => handleCloseEditorTab(e, tabPath)}
                      className="rounded p-0.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700"
                      title="Close tab"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                )
              })}
            </div>

            {/* Quick Actions at Top Right of Editor */}
            <div className="flex items-center gap-1.5 shrink-0 pl-2">
              <button
                type="button"
                onClick={() => onSaveToLocalFolder(activeBundle)}
                className="hidden sm:inline-flex items-center gap-1 rounded bg-teal-50 px-2.5 py-1 text-[11px] font-semibold text-teal-700 hover:bg-teal-100 border border-teal-200 shadow-xs transition"
                title="Save files directly to PC folder"
              >
                <FolderOpen className="h-3 w-3" />
                <span>Save to Folder</span>
              </button>
              <button
                type="button"
                onClick={() => onDownloadZip(activeBundle)}
                className="hidden sm:inline-flex items-center gap-1 rounded bg-white px-2 py-1 text-[11px] font-semibold text-slate-700 border border-slate-200 hover:bg-slate-50 shadow-xs transition"
                title="Download complete test bundle as ZIP"
              >
                <Download className="h-3 w-3" />
                <span>Download .zip</span>
              </button>
              <button
                type="button"
                onClick={() => onCopyCode(activeEditorContent, selectedEditorFile)}
                className="rounded p-1 text-slate-600 hover:bg-slate-200 hover:text-slate-900"
                title="Copy current file code"
              >
                {copiedFileId === selectedEditorFile ? (
                  <Check className="h-3.5 w-3.5 text-emerald-600" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
              </button>
            </div>
          </div>

          {/* Breadcrumb Navigation */}
          <div className="flex h-6 shrink-0 items-center gap-1 border-b border-slate-200 bg-slate-50 px-4 text-[11px] text-slate-500 select-none">
            <span>D:</span>
            <span>&gt;</span>
            <span>QAgenticx</span>
            <span>&gt;</span>
            <span className="text-slate-700">{activeProjectName}</span>
            <span>&gt;</span>
            <span className="text-teal-600 font-semibold">{selectedEditorFile}</span>
          </div>

          {/* Editor Workspace Canvas */}
          <div className="flex-1 min-h-0 overflow-hidden relative">
            {selectedEditorFile === 'test-matrix' ? (
              /* TAB: INTERACTIVE TEST CASES MATRIX */
              <div className="flex flex-col h-full overflow-y-auto p-4 space-y-4 bg-slate-50/60">
                {/* Metric Summary Bar */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xs text-slate-800">
                    <div className="text-[10px] font-bold uppercase text-slate-400">Total Cases</div>
                    <div className="text-xl font-bold text-slate-900 mt-1">{activeBundle.summary.totalCases}</div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xs text-slate-800">
                    <div className="text-[10px] font-bold uppercase text-emerald-400">Positive (Smoke/E2E)</div>
                    <div className="text-xl font-bold text-emerald-600 mt-1">{activeBundle.summary.positiveCount}</div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xs text-slate-800">
                    <div className="text-[10px] font-bold uppercase text-red-400">Negative / Reg</div>
                    <div className="text-xl font-bold text-rose-600 mt-1">{activeBundle.summary.negativeCount}</div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xs text-slate-800">
                    <div className="text-[10px] font-bold uppercase text-amber-400">Boundary & Edge</div>
                    <div className="text-xl font-bold text-amber-600 mt-1">{activeBundle.summary.edgeCount}</div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xs text-slate-800">
                    <div className="text-[10px] font-bold uppercase text-teal-400">Spec Coverage</div>
                    <div className="text-xl font-bold text-teal-600 mt-1">{activeBundle.summary.coverage}</div>
                  </div>
                </div>

                {/* Filter and Search Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {['All', 'Smoke', 'Boundary', 'Security', 'Regression', 'E2E'].map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setTableCategory(cat)}
                        className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
                          tableCategory === cat
                            ? 'bg-teal-600 text-white font-bold shadow-xs'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    placeholder="Search test cases by ID or keyword…"
                    value={tableSearch}
                    onChange={(e) => setTableSearch(e.target.value)}
                    className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:border-teal-500 focus:outline-none w-64 shadow-xs"
                  />
                </div>

                {/* Cases Table */}
                <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-[10px] font-bold uppercase text-slate-500">
                        <th className="p-3 w-20">ID</th>
                        <th className="p-3">Scenario / Verification Title</th>
                        <th className="p-3 w-28">Category</th>
                        <th className="p-3 w-24">Priority</th>
                        <th className="p-3 w-40">Expected Outcome</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredCases.map((tc) => (
                        <tr key={tc.id} className="hover:bg-slate-50/80 transition group">
                          <td className="p-3 font-mono font-bold text-teal-400">{tc.id}</td>
                          <td className="p-3">
                            <div className="font-semibold text-slate-800">{tc.title}</div>
                            <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{tc.description}</div>
                            {tc.steps && tc.steps.length > 0 && (
                              <div className="mt-1.5 space-y-0.5 pl-2 border-l border-teal-500/30 text-[10px] text-slate-400">
                                {tc.steps.map((st, i) => (
                                  <div key={i}>• {st}</div>
                                ))}
                              </div>
                            )}
                          </td>
                          <td className="p-3">
                            <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-semibold text-blue-700 border border-blue-200">
                              {tc.category}
                            </span>
                          </td>
                          <td className="p-3">
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] font-bold border ${
                                tc.priority === 'High'
                                  ? 'bg-rose-50 text-rose-700 border-rose-200'
                                  : tc.priority === 'Medium'
                                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                                  : 'bg-slate-100 text-slate-700 border-slate-200'
                              }`}
                            >
                              {tc.priority}
                            </span>
                          </td>
                          <td className="p-3 text-[11px] text-slate-400">{tc.expectedResult}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              /* TAB: MONACO CODE EDITOR */
              <Editor
                height="100%"
                language={activeEditorLanguage}
                value={activeEditorContent}
                theme="vs"
                options={{
                  minimap: { enabled: true },
                  fontSize: 13,
                  lineNumbers: 'on',
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  padding: { top: 12, bottom: 12 },
                  readOnly: false,
                }}
              />
            )}
          </div>
        </main>

        {/* Draggable Divider for resizing Agent Panel */}
        {isAgentPanelOpen && (
          <div
            onMouseDown={() => setIsResizingChat(true)}
            className="w-1.5 hover:w-2 bg-slate-200 hover:bg-teal-500 active:bg-teal-600 cursor-col-resize transition-all z-20 shrink-0 select-none flex items-center justify-center group"
            title="Drag horizontally to resize the Chat Window"
          >
            <div className="h-8 w-0.5 rounded-full bg-slate-400 group-hover:bg-white transition" />
          </div>
        )}

        {/* RIGHT COLUMN: KIRO AI AGENT PANEL */}
        {isAgentPanelOpen && (
          <aside
            style={{ width: `${chatPanelWidth}px` }}
            className="shrink-0 border-l border-slate-200 bg-white flex flex-col min-h-0 overflow-hidden"
          >
            {/* Kiro Agent Header */}
            <div className="flex h-9 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50 px-3 select-none text-xs">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-900">Agent Workspace</span>
                <span className="rounded bg-teal-950/70 px-1.5 py-0.2 text-[9px] font-mono text-teal-300 border border-teal-800/60">
                  QAgentix AI
                </span>
              </div>
              <div className="flex items-center gap-1">
                {/* Width Presets */}
                <button
                  type="button"
                  onClick={() => setChatPanelWidth(380)}
                  className={`rounded px-1.5 py-0.5 text-[10px] font-mono transition ${
                    chatPanelWidth <= 400
                      ? 'bg-teal-100 text-teal-800 font-bold'
                      : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                  }`}
                  title="Compact size (380px)"
                >
                  S
                </button>
                <button
                  type="button"
                  onClick={() => setChatPanelWidth(520)}
                  className={`rounded px-1.5 py-0.5 text-[10px] font-mono transition ${
                    chatPanelWidth > 400 && chatPanelWidth <= 580
                      ? 'bg-teal-100 text-teal-800 font-bold'
                      : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                  }`}
                  title="Medium size (520px)"
                >
                  M
                </button>
                <button
                  type="button"
                  onClick={() => setChatPanelWidth(680)}
                  className={`rounded px-1.5 py-0.5 text-[10px] font-mono transition ${
                    chatPanelWidth > 580
                      ? 'bg-teal-100 text-teal-800 font-bold'
                      : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                  }`}
                  title="Wide size (680px)"
                >
                  L
                </button>
                <div className="h-3 w-px bg-slate-200 mx-0.5" />
                <button
                  type="button"
                  onClick={() => setIsAgentPanelOpen(false)}
                  className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                  title="Close Agent Panel"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Agent Chat Messages Feed */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-slate-50/40">
              {activeSession?.messages?.length === 0 ? (
                <div className="flex flex-col items-center justify-center min-h-[300px] text-center p-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-50 text-teal-600 mb-3 border border-teal-200 shadow-xs">
                    <Sparkles className="h-6 w-6" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 mb-1">QAgentix Autonomous QA Agent</h3>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4">
                    Ask to generate Playwright tests, Page Object Models, or drop Swagger/OpenAPI files to synthesize custom test matrices.
                  </p>

                  {/* Starter Suggestions Grid - only shown when user is NOT actively typing */}
                  {dynamicSuggestions.length > 0 && !inputText.trim() && attachedFiles.length === 0 && (
                    <div className="w-full max-w-sm space-y-2 text-left">
                      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 px-1">
                        <Sparkles className="h-3 w-3 text-teal-600" />
                        <span>Recommended Test Scenarios</span>
                      </div>
                      <div className="space-y-1.5">
                        {dynamicSuggestions.map((sug) => (
                          <div
                            key={sug.id}
                            className="group flex items-center justify-between gap-2 rounded-xl bg-white border border-slate-200 p-2.5 hover:border-teal-400 hover:bg-teal-50/50 transition cursor-pointer shadow-xs"
                            onClick={() => setInputText(sug.prompt)}
                          >
                            <span className="text-xs font-medium text-slate-800 truncate group-hover:text-teal-900">
                              {sug.label}
                            </span>
                            <span className="text-[10px] shrink-0 rounded-md bg-teal-50 border border-teal-200 px-2 py-0.5 text-teal-700 font-semibold">
                              {sug.badge}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                activeSession.messages.map((message) => {
                  const isUser = message.role === 'user'
                  return (
                    <div
                      key={message.id}
                      className={`flex flex-col rounded-xl p-3 text-xs leading-relaxed ${
                        isUser
                          ? 'bg-teal-50 border border-teal-200 text-teal-950 ml-4 shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-800 mr-2 shadow-xs'
                      }`}
                    >
                      {/* Message Sender & Timestamp */}
                      <div className="flex items-center justify-between mb-1.5 text-[10px] text-slate-400">
                        <span className="font-bold text-slate-900 flex items-center gap-1">
                          {isUser ? 'You' : <><Bot className="h-3 w-3 text-teal-400" /> Kiro Agent</>}
                        </span>
                        <span>{message.timestamp}</span>
                      </div>

                      {/* Attachments */}
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="mb-2 flex flex-wrap gap-1">
                          {message.attachments.map((att) => (
                            <span
                              key={att.id}
                              className="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[10px] text-teal-700 border border-slate-200"
                            >
                              <Paperclip className="h-2.5 w-2.5" />
                              {att.name}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* Generating Animated Steps */}
                      {message.isGenerating ? (
                        <div className="space-y-2 py-1">
                          <div className="flex items-center gap-2 text-xs font-bold text-teal-300">
                            <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                            <span>{message.content || 'Synthesizing test suite...'}</span>
                          </div>
                          <div className="grid grid-cols-2 gap-1 text-[10px]">
                            {['Ingesting Specs', 'Synthesizing Cases', 'Generating Scripts', 'Packaging Bundle'].map((st, i) => (
                              <div
                                key={st}
                                className={`rounded px-1.5 py-1 text-center font-semibold ${
                                  (message.generationStep || 1) > i + 1
                                    ? 'bg-teal-900/40 text-teal-300 border border-teal-700/40'
                                    : (message.generationStep || 1) === i + 1
                                    ? 'bg-teal-600 text-white animate-pulse'
                                    : 'bg-slate-800/40 text-slate-500'
                                }`}
                              >
                                {st}
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="whitespace-pre-wrap">{message.content}</div>
                      )}

                      {/* If message generated a bundle, show quick action cards */}
                      {message.bundle && (
                        <div className="mt-2.5 rounded-lg border border-teal-200 bg-white p-2.5 space-y-2 shadow-xs rounded-lg">
                          <div className="flex items-center justify-between text-[11px] font-bold text-slate-900">
                            <span className="truncate">{message.bundle.title}</span>
                            <span className="text-[10px] text-teal-400 font-mono">
                              {message.bundle.testCases.length} cases
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-1 pt-1">
                            <button
                              type="button"
                              onClick={() => handleOpenEditorTab('test-matrix')}
                              className="rounded bg-teal-600/30 hover:bg-teal-600/50 px-2 py-1 text-[10px] font-bold text-teal-200 border border-teal-500/40"
                            >
                              📊 Open Matrix
                            </button>
                            {message.bundle.files
                              .filter((f) => f.path.endsWith('.spec.ts'))
                              .map((f) => (
                                <button
                                  key={f.path}
                                  type="button"
                                  onClick={() => handleOpenEditorTab(f.path)}
                                  className="rounded bg-teal-600/30 hover:bg-teal-600/50 px-2 py-1 text-[10px] font-bold text-teal-200 border border-teal-500/40"
                                >
                                  📄 Open Spec
                                </button>
                              ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Dynamic Suggestion Prompts Box */}
            {dynamicSuggestions.length > 0 && (
              <div className="border-t border-slate-200 bg-slate-50/80 px-3 py-2 space-y-1.5">
                <div className="flex items-center justify-between px-0.5">
                  <button
                    type="button"
                    onClick={() => setIsSuggestionsOpen((v) => !v)}
                    className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-teal-700 hover:text-teal-800 transition"
                  >
                    <Sparkles className="h-3 w-3 text-teal-600" />
                    <span>
                      {inputText.trim()
                        ? `Suggested Prompts for "${inputText.trim().slice(0, 20)}${inputText.trim().length > 20 ? '...' : ''}"`
                        : 'Suggested Prompts'}
                    </span>
                    <span className="rounded-full bg-teal-100 border border-teal-200 px-1.5 py-0.2 text-[9px] font-semibold text-teal-800">
                      {dynamicSuggestions.length}
                    </span>
                    {isSuggestionsOpen ? (
                      <ChevronDown className="h-3 w-3 text-slate-400" />
                    ) : (
                      <ChevronUp className="h-3 w-3 text-slate-400" />
                    )}
                  </button>
                  <span className="text-[10px] text-slate-400">Click to use</span>
                </div>

                {isSuggestionsOpen && (
                  <div className="space-y-1 max-h-40 overflow-y-auto pr-0.5">
                    {dynamicSuggestions.map((sug) => (
                      <div
                        key={sug.id}
                        className="group flex items-center justify-between gap-2 rounded-lg bg-white border border-slate-200 px-2.5 py-1.5 hover:border-teal-400 hover:bg-teal-50/60 transition cursor-pointer shadow-xs"
                        onClick={() => setInputText(sug.prompt)}
                      >
                        <span className="text-[11px] font-medium text-slate-800 truncate group-hover:text-teal-900">
                          {sug.label}
                        </span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="text-[9px] rounded bg-slate-100 border border-slate-200 px-1.5 py-0.5 text-slate-600 font-medium group-hover:bg-teal-100 group-hover:text-teal-800">
                            {sug.badge}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation()
                              onSendMessage(sug.prompt)
                            }}
                            className="rounded p-1 text-slate-400 hover:text-teal-600 hover:bg-teal-100/60 transition"
                            title="Generate with this prompt now"
                          >
                            <Send className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* KIRO BOTTOM COMPOSER BOX */}
            <div className="p-3 border-t border-slate-200 bg-white">
              <div className="rounded-2xl border border-slate-200 bg-white p-2.5 shadow-sm focus-within:border-teal-500 focus-within:ring-2 focus-within:ring-teal-500/20 transition">
                {/* Attached files preview */}
                {attachedFiles.length > 0 && (
                  <div className="mb-2 flex flex-wrap gap-1">
                    {attachedFiles.map((att) => (
                      <span
                        key={att.id}
                        className="inline-flex items-center gap-1 rounded bg-teal-50 border border-teal-200 px-2 py-0.5 text-[10px] text-teal-700 font-medium"
                      >
                        <Paperclip className="h-2.5 w-2.5 text-teal-600" />
                        <span className="truncate max-w-[120px]">{att.name}</span>
                        <button
                          type="button"
                          onClick={() => onRemoveAttachment(att.id)}
                          className="hover:text-red-500 text-slate-400"
                        >
                          ✕
                        </button>
                      </span>
                    ))}
                  </div>
                )}

                {/* Input Textarea with multiline auto-expand */}
                <textarea
                  ref={textareaRef}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask a question, describe a test scenario, or paste requirements..."
                  className="w-full resize-y min-h-[56px] max-h-64 overflow-y-auto bg-transparent text-xs text-slate-800 placeholder-slate-400 focus:outline-none leading-relaxed p-0.5"
                />

                {/* Bottom Toolbar Row styled like Kiro in screenshot */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                  {/* Left tool triggers */}
                  <div className="flex items-center gap-2">
                    {/* Hidden file input */}
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      onChange={(e) => {
                        onFileSelect(e.target.files)
                        e.target.value = ''
                      }}
                      className="hidden"
                      id="kiro-file-upload"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-800"
                      title="Attach file or context (#)"
                    >
                      #
                    </button>

                    {/* Mode Selector */}
                    <select
                      value={agentMode}
                      onChange={(e) => setAgentMode(e.target.value as any)}
                      className="rounded bg-slate-50 border border-slate-200 px-1.5 py-0.5 text-[10px] text-slate-700 focus:outline-none"
                    >
                      <option value="agent">Auto (Agent)</option>
                      <option value="ask">Ask</option>
                      <option value="edit">Edit</option>
                    </select>

                    {/* Autopilot toggle */}
                    <button
                      type="button"
                      onClick={() => setAutopilot((v) => !v)}
                      className="flex items-center gap-1 text-[10px] text-slate-400 hover:text-white"
                      title="Toggle Autopilot mode"
                    >
                      <span>Autopilot</span>
                      <span
                        className={`inline-block h-3 w-6 rounded-full p-0.5 transition ${
                          autopilot ? 'bg-teal-600' : 'bg-slate-200'
                        }`}
                      >
                        <span
                          className={`block h-2 w-2 rounded-full bg-white transition transform ${
                            autopilot ? 'translate-x-3' : 'translate-x-0'
                          }`}
                        />
                      </span>
                    </button>
                  </div>

                  {/* Send Button */}
                  <button
                    type="button"
                    onClick={() => onSendMessage()}
                    disabled={!inputText.trim() && attachedFiles.length === 0}
                    className="flex h-7 w-7 items-center justify-center rounded-xl bg-teal-600 text-white shadow hover:bg-teal-500 disabled:opacity-40 disabled:cursor-not-allowed transition"
                    title="Send prompt"
                  >
                    <Send className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </aside>
        )}
      </div>


    </div>
  )
}
export default KiroIdeWorkspace
