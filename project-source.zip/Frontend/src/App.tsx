import { type ReactNode, createContext, useContext, useState, useRef, useEffect, useMemo, useCallback } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { ReactFlow, Background, Controls, MarkerType, Position, type Edge, type Node } from '@xyflow/react'
import Editor from '@monaco-editor/react'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import JSZip from 'jszip'
import {
  AlertTriangle,
  Bell,
  Bot,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ClipboardCheck,
  Code2,
  Copy,
  Cpu,
  Download,
  ExternalLink,
  Eye,
  EyeOff,
  FileCode,
  FileSpreadsheet,
  FileText,
  Folder,
  FolderArchive,
  FolderOpen,
  FolderPlus,
  Gauge,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Moon,
  Paperclip,
  Play,
  Plus,
  RefreshCw,
  Send,
  ShieldCheck,
  Sparkles,
  SunMedium,
  Target,
  Terminal,
  Trash2,
  MoreVertical,
  Pencil,
  TrendingUp,
  Upload,
  Users,
  X,
} from 'lucide-react'
import {
  BrowserRouter,
  Link,
  Navigate,
  NavLink,
  Outlet,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from 'react-router-dom'
import '@xyflow/react/dist/style.css'
import { SubscriptionsPage, type Subscription } from './SubscriptionsPage'
import { SubProjectsPage, type SubProject } from './SubProjectsPage'
import {
  listSubscriptions,
  createSubscription,
  deleteSubscription as apiDeleteSubscription,
  listSubProjects,
  createSubProject,
  deleteSubProject as apiDeleteProject,
} from './lib/subscriptionsApi'
import { apiLogin, apiLogout, apiMe, apiRegister, tokenStore, type ApiUser } from './lib/authApi'
import { listUsers, updateUserRole, updateUserStatus, type DirectoryUser, type Role as ApiRole } from './lib/usersApi'
import { browse, makeDir, createStructure, getTree, saveFile, readFile, type BrowseResult, type ProjectTree } from './lib/workspaceApi'
import { executeKiroTask, getKiroModels, readKiroFile, type KiroModelItem } from './lib/kiroApi'
import {
  getSummary as getDashboardSummary,
  getPassRateTrend,
  getExecutionTrend,
  getFailureCategories,
  getLocatorHealth,
  getRecentRuns,
  type Summary as DashboardSummary,
  type PassRatePoint,
  type ExecutionPoint,
  type FailureCategoryPoint,
  type LocatorHealthPoint,
  type RecentRuns as RecentRunsData,
} from './lib/dashboardApi'

const queryClient = new QueryClient()

const loginSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  remember: z.boolean().optional(),
})

type LoginFormValues = z.infer<typeof loginSchema>

const signupSchema = z
  .object({
    fullName: z.string().min(2, 'Full name must be at least 2 characters'),
    email: z.string().email('Please enter a valid work email address'),
    username: z.string().min(3, 'Username must be at least 3 characters'),
    password: z.string().min(6, 'Password must be at least 6 characters'),
    confirmPassword: z.string().min(6, 'Confirm password must be at least 6 characters'),
    agreeTerms: z.boolean().refine((val) => val === true, {
      message: 'You must agree to the Terms and Privacy Policy',
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  })

type SignupFormValues = z.infer<typeof signupSchema>

type Role = 'Admin' | 'Employee' | 'Test Lead' | 'Tester' | 'Viewer'

type User = {
  id: string
  name: string
  email: string
  role: Role
  avatar: string
}

type Project = {
  id: string
  name: string
  appUrl: string
  currentVersion: string
  lastRun: string
  passRate: number
  locatorVersion: string
  status: 'Healthy' | 'Needs review' | 'In progress'
  description: string
}

type Locator = {
  id: string
  page: string
  element: string
  tag: string
  strategy: string
  status: 'Healthy' | 'Broken' | 'Ambiguous' | 'Moved' | 'Fragile'
  stability: number
  selector: string
}

type TestCase = {
  id: string
  title: string
  description: string
  steps: string
  expectedResult: string
  priority: 'High' | 'Medium' | 'Low'
  status: 'Approved' | 'Draft' | 'Needs review'
}

type Run = {
  id: string
  project: string
  suite: string
  started: string
  duration: string
  passed: number
  failed: number
  status: 'Passed' | 'Failed' | 'Running' | 'Queued'
}

type Provider = {
  name: string
  model: string
  temperature: number
  status: 'Active' | 'Disabled' | 'Fallback'
  latency: number
  cost: number
  passRate: number
}

const mockProjects: Project[] = [
  {
    id: 'rammas',
    name: 'Rammas',
    appUrl: 'https://demo.rammas.ai',
    currentVersion: 'v3.4.2',
    lastRun: '2 hours ago',
    passRate: 94,
    locatorVersion: 'V2',
    status: 'Healthy',
    description: 'Customer communications and operations portal',
  },
  {
    id: 'aurora',
    name: 'Aurora Bank',
    appUrl: 'https://app.aurorabank.dev',
    currentVersion: 'v2.8.1',
    lastRun: '1 day ago',
    passRate: 89,
    locatorVersion: 'V1',
    status: 'Needs review',
    description: 'Retail banking onboarding flows',
  },
  {
    id: 'harbor',
    name: 'Harbor Ops',
    appUrl: 'https://ops.harborhq.io',
    currentVersion: 'v4.1.0',
    lastRun: '3 days ago',
    passRate: 91,
    locatorVersion: 'V2',
    status: 'In progress',
    description: 'Warehouse and logistics operations console',
  },
]

// Dashboard metrics/charts/runs are fetched live from the backend in
// DashboardPage via src/lib/dashboardApi.ts (FEAT-002). The former hardcoded
// dashboardStats/passRateTrend/executionTrend/failureCategories/recentRuns
// constants were removed from the render path.

const locators: Locator[] = [
  {
    id: 'src_dropdown',
    page: 'campaigns_page',
    element: 'Source dropdown',
    tag: 'select',
    strategy: 'Test ID',
    status: 'Healthy',
    stability: 96,
    selector: "data-testid='source-dropdown'",
  },
  {
    id: 'top_channel',
    page: 'channels_page',
    element: 'Top channel row',
    tag: 'button',
    strategy: 'Role + name',
    status: 'Fragile',
    stability: 73,
    selector: "role='button' name='Top Channel'",
  },
  {
    id: 'voice_option',
    page: 'voice_page',
    element: 'Voice list option',
    tag: 'li',
    strategy: 'Label',
    status: 'Ambiguous',
    stability: 68,
    selector: "label='Voice'",
  },
]

const testCases: TestCase[] = [
  {
    id: 'TC-2101',
    title: 'Validate selected channel count',
    description: 'Select the source and confirm counts match the listing',
    steps: '1. Open source dropdown 2. Select Rammas 3. Open top channel 4. Choose voice 5. Compare counts',
    expectedResult: 'Selected count equals listing count',
    priority: 'High',
    status: 'Approved',
  },
  {
    id: 'TC-2102',
    title: 'Voice option selection persists',
    description: 'Verify voice selection is retained after filtering',
    steps: '1. Open channel voice list 2. Choose a voice 3. Validate state remains',
    expectedResult: 'Voice remains selected',
    priority: 'Medium',
    status: 'Draft',
  },
]

const providers: Provider[] = [
  { name: 'Claude', model: 'claude-3.5-sonnet', temperature: 0.2, status: 'Active', latency: 1350, cost: 0.32, passRate: 96 },
  { name: 'OpenAI', model: 'gpt-4.1', temperature: 0.1, status: 'Active', latency: 1450, cost: 0.46, passRate: 93 },
  { name: 'Gemini', model: 'gemini-2.5-pro', temperature: 0.4, status: 'Fallback', latency: 1780, cost: 0.28, passRate: 91 },
  { name: 'Ollama', model: 'llama3.1:70b', temperature: 0.3, status: 'Disabled', latency: 2200, cost: 0.09, passRate: 88 },
]

const diffRows = [
  { page: 'login_page', locator: 'username_input', oldValue: '#username', newValue: '#user-name', attribute: 'ID', severity: 'Medium' },
  { page: 'checkout_page', locator: 'price_total', oldValue: 'text=Total', newValue: 'text=Amount due', attribute: 'Text', severity: 'High' },
  { page: 'settings_page', locator: 'save_button', oldValue: '[data-testid="save"]', newValue: '[data-testid="save-button"]', attribute: 'Test ID', severity: 'Low' },
]

const impactRows = [
  { locator: 'username_input', changedFrom: '#username', changedTo: '#user-name', affectedPage: 'Login page', affectedPageObject: 'LoginPage', affectedTests: '3 test cases', risk: 'Medium' },
  { locator: 'channel_row', changedFrom: 'button[name="Top Channel"]', changedTo: 'button[name="Top channel"]', affectedPage: 'Channels page', affectedPageObject: 'ChannelList', affectedTests: '5 test cases', risk: 'High' },
]

const healthRows = [
  { page: 'login_page', locator: 'username_input', status: 'Healthy', severity: 'Low', currentMatch: 'match=1', expected: 'match=1', suggestedReplacement: 'data-testid=username' },
  { page: 'channels_page', locator: 'top_channel', status: 'Moved', severity: 'Medium', currentMatch: 'no match', expected: 'match=1', suggestedReplacement: '[data-testid="channel-row-1"]' },
]

const agentFlowNodes: Node[] = [
  { id: 'planner', data: { label: 'Planner' }, position: { x: 0, y: 80 }, sourcePosition: Position.Right, targetPosition: Position.Left },
  { id: 'generator', data: { label: 'Generator' }, position: { x: 200, y: 80 }, sourcePosition: Position.Right, targetPosition: Position.Left },
  { id: 'validator', data: { label: 'Validator' }, position: { x: 400, y: 80 }, sourcePosition: Position.Right, targetPosition: Position.Left },
  { id: 'executor', data: { label: 'Executor' }, position: { x: 600, y: 80 }, sourcePosition: Position.Right, targetPosition: Position.Left },
  { id: 'analyst', data: { label: 'Analyst' }, position: { x: 800, y: 80 }, sourcePosition: Position.Right, targetPosition: Position.Left },
  { id: 'reporter', data: { label: 'Reporter' }, position: { x: 1000, y: 80 }, sourcePosition: Position.Right, targetPosition: Position.Left },
]

const agentFlowEdges: Edge[] = [
  { id: 'e1', source: 'planner', target: 'generator', markerEnd: { type: MarkerType.Arrow }, type: 'smoothstep' },
  { id: 'e2', source: 'generator', target: 'validator', markerEnd: { type: MarkerType.Arrow }, type: 'smoothstep' },
  { id: 'e3', source: 'validator', target: 'executor', markerEnd: { type: MarkerType.Arrow }, type: 'smoothstep' },
  { id: 'e4', source: 'executor', target: 'analyst', markerEnd: { type: MarkerType.Arrow }, type: 'smoothstep' },
  { id: 'e5', source: 'analyst', target: 'reporter', markerEnd: { type: MarkerType.Arrow }, type: 'smoothstep' },
]

const navGroups = [
  {
    title: 'OVERVIEW',
    items: [
      { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard },
    ],
  },
  {
    title: 'AI AUTOMATION',
    items: [
      { label: 'Agent Workspace', to: '/agent', icon: Sparkles },
      { label: 'Test Cases', to: '/test-cases', icon: ClipboardCheck },
      { label: 'Scripts', to: '/scripts/rammas-validation', icon: Code2 },
    ],
  },
  {
    title: 'EXECUTION',
    items: [
      { label: 'Runs', to: '/runs', icon: Play },
      { label: 'Live Execution', to: '/runs/run-1985/live', icon: Gauge },
      { label: 'Reports', to: '/reports/run-1985', icon: TrendingUp },
    ],
  },
  {
    title: 'ADMIN',
    items: [
      { label: 'Users', to: '/users', icon: Users },
      { label: 'AI Providers', to: '/settings/providers', icon: Cpu },
    ],
  },
]

const themeContext = createContext<{
  theme: 'light' | 'dark'
  toggleTheme: () => void
}>({
  theme: 'light',
  toggleTheme: () => undefined,
})

const authContext = createContext<{
  user: User | null
  isAuthenticated: boolean
  loading: boolean
  login: (values: LoginFormValues) => Promise<void>
  signup: (values: SignupFormValues) => Promise<void>
  logout: () => void
}>({
  user: null,
  isAuthenticated: false,
  loading: true,
  login: async () => undefined,
  signup: async () => undefined,
  logout: () => undefined,
})

const projectContext = createContext<{
  projectId: string
  setProjectId: (value: string) => void
}>({
  projectId: 'rammas',
  setProjectId: () => undefined,
})

const subscriptionContext = createContext<{
  subscriptions: Subscription[]
  activeSubscription: Subscription | null
  setActiveSubscription: (sub: Subscription | null) => void
  addSubscription: (newSub: Omit<Subscription, 'id' | 'code' | 'createdAt' | 'projectsCount' | 'activeAgents' | 'totalRuns' | 'accentGradient'>) => void
  deleteSubscription: (id: string) => void
}>({
  subscriptions: [],
  activeSubscription: null,
  setActiveSubscription: () => undefined,
  addSubscription: () => undefined,
  deleteSubscription: () => undefined,
})

function SubscriptionProvider({ children }: { children: ReactNode }) {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([])
  const [activeSubscription, setActiveSubscription] = useState<Subscription | null>(null)

  // Load subscriptions from the backend on mount (DB is the source of truth).
  const refresh = async () => {
    setSubscriptions(await listSubscriptions())
  }

  useEffect(() => {
    void refresh()
  }, [])

  const addSubscription = async (newSub: Omit<Subscription, 'id' | 'code' | 'createdAt' | 'projectsCount' | 'activeAgents' | 'totalRuns' | 'accentGradient'>) => {
    await createSubscription({
      name: newSub.name,
      category: newSub.category,
      plan: newSub.plan,
      status: newSub.status,
      description: newSub.description,
    })
    await refresh()
  }

  const deleteSubscription = async (id: string) => {
    await apiDeleteSubscription(id)
    if (activeSubscription?.id === id) {
      setActiveSubscription(null)
    }
    await refresh()
  }

  return (
    <subscriptionContext.Provider
      value={{
        subscriptions,
        activeSubscription,
        setActiveSubscription,
        addSubscription,
        deleteSubscription,
      }}
    >
      {children}
    </subscriptionContext.Provider>
  )
}

function useSubscription() {
  return useContext(subscriptionContext)
}

const projectListContext = createContext<{
  projects: SubProject[]
  activeProject: SubProject | null
  setActiveProject: (proj: SubProject | null) => void
  addProject: (newProj: Omit<SubProject, 'id' | 'createdAt' | 'storiesCount' | 'testCasesCount' | 'scriptsCount' | 'accentGradient'>) => void
  deleteProject: (id: string) => void
}>({
  projects: [],
  activeProject: null,
  setActiveProject: () => undefined,
  addProject: () => undefined,
  deleteProject: () => undefined,
})

function ProjectListProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<SubProject[]>([])
  const [activeProject, setActiveProject] = useState<SubProject | null>(null)

  // Load all subprojects from the backend; the page filters by subscription.
  const refresh = async () => {
    setProjects(await listSubProjects())
  }

  useEffect(() => {
    void refresh()
  }, [])

  const addProject = async (newProj: Omit<SubProject, 'id' | 'createdAt' | 'storiesCount' | 'testCasesCount' | 'scriptsCount' | 'accentGradient'>) => {
    await createSubProject({
      subscriptionId: newProj.subscriptionId,
      name: newProj.name,
      type: newProj.type,
      endpointsCount: newProj.endpointsCount,
      endpoints: newProj.endpoints,
      description: newProj.description,
    })
    await refresh()
  }

  const deleteProject = async (id: string) => {
    await apiDeleteProject(id)
    if (activeProject?.id === id) {
      setActiveProject(null)
    }
    await refresh()
  }

  return (
    <projectListContext.Provider
      value={{
        projects,
        activeProject,
        setActiveProject,
        addProject,
        deleteProject,
      }}
    >
      {children}
    </projectListContext.Provider>
  )
}

function useProjectList() {
  return useContext(projectListContext)
}

function SubscriptionRouteWrapper() {
  const { subscriptions, setActiveSubscription, addSubscription, deleteSubscription } = useSubscription()
  const { theme, toggleTheme } = useTheme()
  const { user, logout } = useAuth()

  return (
    <SubscriptionsPage
      subscriptions={subscriptions}
      onSelectSubscription={setActiveSubscription}
      onAddSubscription={addSubscription}
      onDeleteSubscription={deleteSubscription}
      theme={theme}
      toggleTheme={toggleTheme}
      user={user}
      onLogout={logout}
    />
  )
}

function SubProjectRouteWrapper() {
  const { activeSubscription } = useSubscription()
  const { projects, setActiveProject, addProject, deleteProject } = useProjectList()
  const { setProjectId } = useProject()
  const { theme, toggleTheme } = useTheme()
  const { user, logout } = useAuth()

  const handleSelectProject = (proj: SubProject) => {
    setActiveProject(proj)
    setProjectId(proj.id)
  }

  return (
    <SubProjectsPage
      subscription={activeSubscription}
      projects={projects}
      onSelectProject={handleSelectProject}
      onCreateProject={addProject}
      onDeleteProject={deleteProject}
      theme={theme}
      toggleTheme={toggleTheme}
      user={user}
      onLogout={logout}
    />
  )
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <ThemeProvider>
          <AuthProvider>
            <SubscriptionProvider>
              <ProjectListProvider>
                <ProjectProvider>
                  <Routes>
                    <Route path="/login" element={<LoginPage />} />
                    <Route element={<ProtectedRoute />}>
                      <Route path="/subscriptions" element={<SubscriptionRouteWrapper />} />
                      <Route path="/subprojects" element={<SubProjectRouteWrapper />} />
                      <Route element={<AppShell />}>
                        <Route path="/" element={<Navigate to="/subscriptions" replace />} />
                        <Route path="/dashboard" element={<DashboardPage />} />
                        <Route path="/projects" element={<ProjectsPage />} />
                        <Route path="/projects/new" element={<ProjectsPage />} />
                        <Route path="/projects/:projectId" element={<ProjectDetailPage />} />
                        <Route path="/harvest" element={<HarvestPage />} />
                        <Route path="/locators" element={<LocatorExplorerPage />} />
                        <Route path="/locator-health" element={<LocatorHealthPage />} />
                        <Route path="/agent" element={<AgentWorkspacePage />} />
                        <Route path="/test-cases" element={<TestCasesPage />} />
                        <Route path="/test-cases/:id" element={<TestCasesPage />} />
                        <Route path="/scripts/:id" element={<ScriptReviewPage />} />
                        <Route path="/runs" element={<RunsPage />} />
                        <Route path="/runs/:id" element={<RunDetailPage />} />
                        <Route path="/runs/:id/live" element={<LiveExecutionPage />} />
                        <Route path="/reports/:id" element={<ReportPage />} />
                        <Route path="/versions" element={<VersionsPage />} />
                        <Route path="/versions/compare" element={<VersionsPage />} />
                        <Route path="/impact-analysis" element={<ImpactAnalysisPage />} />
                        <Route path="/patches/:id" element={<PatchReviewPage />} />
                        <Route path="/settings" element={<SettingsPage />} />
                        <Route path="/settings/providers" element={<SettingsPage />} />
                        <Route path="/provider-comparison" element={<ProviderComparisonPage />} />
                        <Route path="/users" element={<UsersPage />} />
                        <Route path="/onboarding" element={<OnboardingPage />} />
                        <Route path="*" element={<Navigate to="/subscriptions" replace />} />
                      </Route>
                    </Route>
                  </Routes>
                </ProjectProvider>
              </ProjectListProvider>
            </SubscriptionProvider>
          </AuthProvider>
        </ThemeProvider>
      </BrowserRouter>
    </QueryClientProvider>
  )
}

function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<'light' | 'dark'>('light')
  const toggleTheme = () => setTheme((current) => (current === 'light' ? 'dark' : 'light'))

  return <themeContext.Provider value={{ theme, toggleTheme }}>{children}</themeContext.Provider>
}

function mapApiUser(apiUser: ApiUser): User {
  return {
    id: apiUser.id,
    name: apiUser.name,
    email: apiUser.email,
    role: (apiUser.role as Role) ?? 'Admin',
    avatar: apiUser.avatar,
  }
}

function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // Restore the session on first load if a token is present.
  useEffect(() => {
    let cancelled = false
    const restore = async () => {
      if (!tokenStore.access) {
        setLoading(false)
        return
      }
      const apiUser = await apiMe()
      if (!cancelled) {
        setUser(apiUser ? mapApiUser(apiUser) : null)
        setLoading(false)
      }
    }
    void restore()
    return () => {
      cancelled = true
    }
  }, [])

  const login = async (values: LoginFormValues) => {
    const res = await apiLogin({ username: values.username, password: values.password })
    setUser(mapApiUser(res.user))
  }

  const signup = async (values: SignupFormValues) => {
    const res = await apiRegister({
      fullName: values.fullName,
      email: values.email,
      username: values.username,
      password: values.password,
    })
    setUser(mapApiUser(res.user))
  }

  const logout = () => {
    void apiLogout()
    setUser(null)
  }

  return (
    <authContext.Provider
      value={{ user, login, signup, logout, loading, isAuthenticated: Boolean(user) }}
    >
      {children}
    </authContext.Provider>
  )
}

function ProjectProvider({ children }: { children: ReactNode }) {
  const [projectId, setProjectId] = useState('rammas')

  return <projectContext.Provider value={{ projectId, setProjectId }}>{children}</projectContext.Provider>
}

function ProtectedRoute() {
  const { isAuthenticated, loading } = useAuth()

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white text-sm text-slate-500 dark:bg-slate-950 dark:text-slate-400">
        Loading...
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  return <Outlet />
}

function useTheme() {
  return useContext(themeContext)
}

function useAuth() {
  return useContext(authContext)
}

function useProject() {
  return useContext(projectContext)
}

function AppShell() {
  const { theme, toggleTheme } = useTheme()
  const { user, logout } = useAuth()
  const { activeSubscription } = useSubscription()
  const { activeProject } = useProjectList()
  const location = useLocation()
  const currentPath = location.pathname.replace(/^\//, '') || 'dashboard'
  // Collapse/expand the main navigation sidebar.
  const [navCollapsed, setNavCollapsed] = useState(false)

  return (
    <div className={theme === 'dark' ? 'dark' : ''}>
      <div className="h-screen overflow-hidden bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
        <div className="flex h-screen min-h-0">
          <aside className={`relative hidden h-screen shrink-0 border-r border-slate-200 bg-white/90 shadow-soft backdrop-blur transition-all duration-300 ease-in-out dark:border-slate-800 dark:bg-slate-900/90 lg:flex lg:flex-col ${navCollapsed ? 'w-16' : 'w-60'}`}>
            {/* Collapse/expand handle, vertically centered on the sidebar edge */}
            <button
              type="button"
              onClick={() => setNavCollapsed((prev) => !prev)}
              className="absolute -right-3 top-1/2 z-20 flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 shadow-md transition hover:text-teal-600 hover:border-teal-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400 dark:hover:text-teal-400"
              title={navCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              aria-label={navCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              <ChevronDown className={`h-4 w-4 transition-transform ${navCollapsed ? '-rotate-90' : 'rotate-90'}`} />
            </button>
            <div className={`flex items-center border-b border-slate-200 py-5 dark:border-slate-800 ${navCollapsed ? 'justify-center px-2' : 'gap-3 px-4'}`}>
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-600 text-sm font-bold text-white shadow-lg shadow-teal-600/20">Q</div>
              {!navCollapsed && (
                <div>
                  <div className="text-lg font-semibold">QAgentix</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">AI QA Platform</div>
                </div>
              )}
            </div>

            <nav className={`min-h-0 flex-1 space-y-6 overflow-y-auto overscroll-contain py-5 ${navCollapsed ? 'px-2' : 'px-4'}`}>
              {navGroups.map((group) => (
                <div key={group.title}>
                  {!navCollapsed && (
                    <div className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-400 dark:text-slate-500">{group.title}</div>
                  )}
                  <div className="space-y-1">
                    {group.items.map((item) => {
                      const Icon = item.icon
                      return (
                        <NavLink
                          key={item.to}
                          to={item.to}
                          title={navCollapsed ? item.label : undefined}
                          className={({ isActive }) =>
                            `flex items-center rounded-xl py-2.5 text-sm font-medium transition ${navCollapsed ? 'justify-center px-2' : 'gap-3 px-3'} ${isActive
                              ? 'bg-teal-50 text-teal-700 ring-1 ring-teal-200 dark:bg-teal-950/40 dark:text-teal-200 dark:ring-teal-900'
                              : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                            }`
                          }
                        >
                          <Icon className="h-4 w-4 shrink-0" />
                          {!navCollapsed && item.label}
                        </NavLink>
                      )
                    })}
                  </div>
                </div>
              ))}
            </nav>

            <div className={`border-t border-slate-200 py-4 dark:border-slate-800 ${navCollapsed ? 'px-2' : 'px-4'}`}>
              {navCollapsed ? (
                <div className="flex flex-col items-center gap-2">
                  <button type="button" title="Help" className="rounded-xl p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">
                    <Sparkles className="h-4 w-4" />
                  </button>
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-900 text-xs font-semibold text-white dark:bg-slate-100 dark:text-slate-900" title={user?.name}>{user?.avatar}</div>
                  <button type="button" onClick={logout} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700" aria-label="Logout" title="Logout">
                    <LogOut className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <>
                  <div className="mb-3 flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">
                    <Sparkles className="h-4 w-4" />
                    Help
                  </div>
                  <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800/60">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-900 text-xs font-semibold text-white dark:bg-slate-100 dark:text-slate-900">{user?.avatar}</div>
                      <div>
                        <div className="text-sm font-medium">{user?.name}</div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">{user?.role}</div>
                      </div>
                    </div>
                    <button type="button" onClick={logout} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700" aria-label="Logout">
                      <LogOut className="h-4 w-4" />
                    </button>
                  </div>
                </>
              )}
            </div>
          </aside>

          <div className="flex h-screen min-h-0 min-w-0 flex-1 flex-col">
            <header className="border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-800 dark:bg-slate-900/90">
              <div className="flex h-20 items-center justify-between gap-4 px-6">
                <div className="flex items-center gap-3 flex-wrap">
                  <h1 className="text-lg font-bold capitalize text-slate-800 dark:text-slate-100">
                    {currentPath === 'dashboard'
                      ? 'Dashboard'
                      : currentPath === 'agent'
                        ? 'Agent Workspace'
                        : currentPath === 'test-cases'
                          ? 'Test Cases'
                          : currentPath.startsWith('scripts')
                            ? 'Scripts'
                            : currentPath.replace(/-/g, ' ')}
                  </h1>
                  {activeSubscription && (
                    <Link
                      to="/subscriptions"
                      title="Switch subscription workspace"
                      className="hidden sm:inline-flex items-center gap-2 rounded-xl border border-teal-200/80 bg-teal-50/70 px-3 py-1.5 text-xs font-semibold text-teal-700 transition hover:border-teal-400 hover:bg-teal-100 dark:border-teal-900/70 dark:bg-teal-950/40 dark:text-teal-300 dark:hover:bg-teal-900/50"
                    >
                      <span className="h-2 w-2 rounded-full bg-teal-500 animate-pulse" />
                      <span>{activeSubscription.name}</span>
                      <span className="font-mono text-[10px] text-teal-600/80 dark:text-teal-400/80">({activeSubscription.code})</span>
                    </Link>
                  )}
                  {activeProject && (
                    <Link
                      to="/subprojects"
                      title="Switch project"
                      className="hidden md:inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 transition hover:border-teal-400 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800/80 dark:text-slate-200"
                    >
                      <FolderOpen className="h-3.5 w-3.5 text-teal-600 dark:text-teal-400" />
                      <span>{activeProject.name}</span>
                    </Link>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <button type="button" className="rounded-xl border border-slate-200 p-2.5 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800" aria-label="Notifications">
                    <Bell className="h-4 w-4" />
                  </button>
                  <button type="button" onClick={toggleTheme} className="rounded-xl border border-slate-200 p-2.5 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800" aria-label="Toggle theme">
                    {theme === 'light' ? <Moon className="h-4 w-4" /> : <SunMedium className="h-4 w-4" />}
                  </button>
                </div>
              </div>
            </header>

            <main className="min-h-0 flex-1 flex flex-col overflow-y-auto overscroll-contain p-4 lg:p-5">
              <Outlet />
            </main>
          </div>
        </div>
      </div>
    </div>
  )
}

function LoginPage() {
  const navigate = useNavigate()
  const { login, signup } = useAuth()
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [forgotPasswordNotice, setForgotPasswordNotice] = useState(false)
  const [authError, setAuthError] = useState<string | null>(null)

  const {
    register: registerLogin,
    handleSubmit: handleLoginSubmit,
    formState: { errors: loginErrors, isSubmitting: isLoginSubmitting },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: '', password: '', remember: false },
  })

  const {
    register: registerSignup,
    handleSubmit: handleSignupSubmit,
    formState: { errors: signupErrors, isSubmitting: isSignupSubmitting },
  } = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      fullName: '',
      email: '',
      username: '',
      password: '',
      confirmPassword: '',
      agreeTerms: false,
    },
  })

  const onLoginSubmit = async (values: LoginFormValues) => {
    setAuthError(null)
    try {
      await login(values)
      navigate('/subscriptions')
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Unable to sign in')
    }
  }

  const onSignupSubmit = async (values: SignupFormValues) => {
    setAuthError(null)
    try {
      await signup(values)
      navigate('/subscriptions')
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Unable to create account')
    }
  }

  const handleModeChange = (newMode: 'signin' | 'signup') => {
    setMode(newMode)
    setForgotPasswordNotice(false)
    setAuthError(null)
  }

  return (
    <div className="min-h-screen w-full bg-white dark:bg-slate-950">
      <div className="grid min-h-screen w-full grid-cols-1 md:grid-cols-[0.9fr_1.1fr] lg:grid-cols-2">
        <div className="flex flex-col justify-between gap-5 bg-[radial-gradient(circle_at_top,_rgba(20,184,166,0.16),_transparent_45%),linear-gradient(135deg,#f0fdfa,#ecfeff,#f8fafc)] p-4 sm:p-6 md:min-h-screen md:p-8 lg:p-14 dark:bg-[radial-gradient(circle_at_top,_rgba(20,184,166,0.2),_transparent_45%),linear-gradient(135deg,#0f172a,#111827,#0f172a)]">
          <div>
            <div className="mb-4 flex items-center gap-3 sm:mb-7 lg:mb-10">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-600 text-lg font-bold text-white sm:h-12 sm:w-12 sm:rounded-2xl">Q</div>
              <div>
                <div className="text-xl font-semibold text-slate-900 sm:text-2xl dark:text-white">QAgentix</div>
                <div className="text-sm text-slate-600 dark:text-slate-300">AI-assisted test automation</div>
              </div>
            </div>
            <div className="max-w-md max-sm:hidden">
              <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-teal-200 bg-teal-50 px-3 py-1 text-xs font-medium text-teal-700 sm:mb-4 dark:border-teal-900 dark:bg-teal-950/40 dark:text-teal-200">
                <ShieldCheck className="h-3.5 w-3.5" />
                Secure authentication
              </div>
              <h1 className="text-2xl font-semibold tracking-tight text-slate-900 sm:text-3xl lg:text-4xl dark:text-white">Automate product quality with AI testing workflows.</h1>
              <p className="mt-3 text-sm text-slate-600 sm:mt-5 sm:text-base dark:text-slate-300">Design locator-aware, AI-generated Playwright validation across your application ecosystem — all in one workflow.</p>
            </div>
          </div>
          <div className="hidden gap-4 text-sm text-slate-600 lg:grid lg:grid-cols-2 dark:text-slate-300">
            <div className="rounded-2xl border border-slate-200 bg-white/70 p-4 dark:border-slate-700 dark:bg-slate-900/60">
              <div className="mb-2 flex items-center gap-2 font-medium text-slate-900 dark:text-white"><Target className="h-4 w-4 text-teal-600" /> Locator validation</div>
              Detect, compare and heal outdated selectors before release.
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white/70 p-4 dark:border-slate-700 dark:bg-slate-900/60">
              <div className="mb-2 flex items-center gap-2 font-medium text-slate-900 dark:text-white"><Cpu className="h-4 w-4 text-purple-600" /> AI test planning</div>
              Turn natural-language requirements into structured QA cases.
            </div>
          </div>
        </div>

        <div className="flex w-full items-center justify-center px-5 py-6 sm:px-8 md:px-8 lg:px-14">
          <div className="w-full max-w-sm sm:max-w-md">
            <div className="mb-5 sm:mb-6">
              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-teal-700 dark:text-teal-300">
                {mode === 'signin' ? 'Welcome back' : 'Get started with QAgentix'}
              </div>
              <h2 className="mt-1.5 text-2xl font-semibold text-slate-900 sm:text-3xl dark:text-white">
                {mode === 'signin' ? 'Sign in to QAgentix' : 'Create an account'}
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                {mode === 'signin'
                  ? 'Access your test suites, AI locator agents, and execution dashboards.'
                  : 'Start your automated QA workspace with intelligent AI test agents.'}
              </p>
            </div>

            {authError && (
              <div className="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-800 dark:border-red-800 dark:bg-red-950/50 dark:text-red-200">
                {authError}
              </div>
            )}

            {forgotPasswordNotice && mode === 'signin' && (
              <div className="mb-4 rounded-lg border border-teal-200 bg-teal-50 p-3 text-xs text-teal-800 dark:border-teal-800 dark:bg-teal-950/50 dark:text-teal-200 flex items-start justify-between">
                <div>
                  <p className="font-semibold">Password reset link</p>
                  <p className="mt-0.5">For demo environments, enter your username and any 6+ character password to sign in directly.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setForgotPasswordNotice(false)}
                  className="text-teal-600 hover:text-teal-800 dark:text-teal-300"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            {mode === 'signin' ? (
              <form onSubmit={handleLoginSubmit(onLoginSubmit)} className="space-y-4">
                <div>
                  <label htmlFor="username" className="mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300">
                    Username or Email
                  </label>
                  <input
                    id="username"
                    type="text"
                    autoComplete="username"
                    placeholder="e.g. alicia or alicia@qagentix.io"
                    {...registerLogin('username')}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none ring-0 transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-50"
                  />
                  {loginErrors.username && <p className="mt-1 text-xs text-red-500">{loginErrors.username.message}</p>}
                </div>

                <div>
                  <label htmlFor="password" className="mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      placeholder="••••••••"
                      {...registerLogin('password')}
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 pr-10 text-sm text-slate-900 outline-none ring-0 transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-50"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {loginErrors.password && <p className="mt-1 text-xs text-red-500">{loginErrors.password.message}</p>}
                </div>

                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      {...registerLogin('remember')}
                      className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                    />
                    Remember me
                  </label>
                  <button
                    type="button"
                    onClick={() => setForgotPasswordNotice(true)}
                    className="text-sm font-medium text-teal-700 hover:text-teal-800 dark:text-teal-300"
                  >
                    Forgot password?
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={isLoginSubmitting}
                  className="w-full rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm shadow-teal-700/20 transition hover:bg-teal-800 disabled:opacity-70"
                >
                  {isLoginSubmitting ? 'Signing in...' : 'Sign In'}
                </button>

                <p className="pt-1 text-center text-xs text-slate-600 dark:text-slate-400">
                  Don't have an account?{' '}
                  <button
                    type="button"
                    onClick={() => handleModeChange('signup')}
                    className="font-semibold text-teal-700 hover:underline dark:text-teal-400"
                  >
                    Sign up
                  </button>
                </p>
              </form>
            ) : (
              <form onSubmit={handleSignupSubmit(onSignupSubmit)} className="space-y-3.5">
                <div>
                  <label htmlFor="fullName" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
                    Full Name
                  </label>
                  <input
                    id="fullName"
                    type="text"
                    autoComplete="name"
                    placeholder="e.g. Alicia Morgan"
                    {...registerSignup('fullName')}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none ring-0 transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-50"
                  />
                  {signupErrors.fullName && <p className="mt-1 text-xs text-red-500">{signupErrors.fullName.message}</p>}
                </div>

                <div>
                  <label htmlFor="email" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
                    Work Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    autoComplete="email"
                    placeholder="alicia@company.com"
                    {...registerSignup('email')}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none ring-0 transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-50"
                  />
                  {signupErrors.email && <p className="mt-1 text-xs text-red-500">{signupErrors.email.message}</p>}
                </div>

                <div>
                  <label htmlFor="signup-username" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
                    Username
                  </label>
                  <input
                    id="signup-username"
                    type="text"
                    autoComplete="username"
                    placeholder="e.g. alicia_qa"
                    {...registerSignup('username')}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none ring-0 transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-50"
                  />
                  {signupErrors.username && <p className="mt-1 text-xs text-red-500">{signupErrors.username.message}</p>}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="signup-password" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        id="signup-password"
                        type={showPassword ? 'text' : 'password'}
                        autoComplete="new-password"
                        placeholder="••••••••"
                        {...registerSignup('password')}
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 outline-none ring-0 transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-50"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {signupErrors.password && <p className="mt-1 text-xs text-red-500">{signupErrors.password.message}</p>}
                  </div>

                  <div>
                    <label htmlFor="confirmPassword" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
                      Confirm
                    </label>
                    <div className="relative">
                      <input
                        id="confirmPassword"
                        type={showConfirmPassword ? 'text' : 'password'}
                        autoComplete="new-password"
                        placeholder="••••••••"
                        {...registerSignup('confirmPassword')}
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 outline-none ring-0 transition focus:border-teal-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-50"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                        aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {signupErrors.confirmPassword && <p className="mt-1 text-xs text-red-500">{signupErrors.confirmPassword.message}</p>}
                  </div>
                </div>

                <div>
                  <label className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      {...registerSignup('agreeTerms')}
                      className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                    />
                    <span>
                      I agree to the{' '}
                      <span className="text-teal-700 dark:text-teal-300 font-medium">Terms of Service</span> and{' '}
                      <span className="text-teal-700 dark:text-teal-300 font-medium">Privacy Policy</span>.
                    </span>
                  </label>
                  {signupErrors.agreeTerms && <p className="mt-1 text-xs text-red-500">{signupErrors.agreeTerms.message}</p>}
                </div>

                <button
                  type="submit"
                  disabled={isSignupSubmitting}
                  className="w-full rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm shadow-teal-700/20 transition hover:bg-teal-800 disabled:opacity-70"
                >
                  {isSignupSubmitting ? 'Creating account...' : 'Create Account'}
                </button>

                <p className="pt-1 text-center text-xs text-slate-600 dark:text-slate-400">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => handleModeChange('signin')}
                    className="font-semibold text-teal-700 hover:underline dark:text-teal-400"
                  >
                    Sign in
                  </button>
                </p>
              </form>
            )}

            <div className="relative my-5">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200 dark:border-slate-800" />
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-white px-2 text-slate-500 dark:bg-slate-950 dark:text-slate-400">
                  or continue with
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  login({ username: 'google_user', password: 'password123' })
                  navigate('/subscriptions')
                }}
                className="flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 transition"
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                Google
              </button>
              <button
                type="button"
                onClick={() => {
                  login({ username: 'sso_user', password: 'password123' })
                  navigate('/subscriptions')
                }}
                className="flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 transition"
              >
                <ShieldCheck className="h-4 w-4 text-teal-600" />
                Enterprise SSO
              </button>
            </div>

            <div className="mt-5 flex items-center justify-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <ShieldCheck className="h-4 w-4 shrink-0 text-teal-600" />
              Secure workspace authentication. Your credentials stay private.
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// --- Dashboard data plumbing (FEAT-002) -------------------------------------
// Each dashboard section owns its own {data,loading,error,reload} state so a
// failed fetch only degrades that section and a Retry button re-triggers it.
type SectionState<T> = { data: T | null; loading: boolean; error: string | null; reload: () => void }

function useDashboardSection<T>(fetcher: () => Promise<T>): SectionState<T> {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  // Keep the latest fetcher without forcing callers to memoize it.
  const fetcherRef = useRef(fetcher)
  fetcherRef.current = fetcher

  const reload = useCallback(() => {
    let cancelled = false
    setLoading(true)
    setError(null)
    fetcherRef.current()
      .then((result) => { if (!cancelled) setData(result) })
      .catch((err: unknown) => { if (!cancelled) setError(err instanceof Error ? err.message : 'Request failed') })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [])

  useEffect(() => {
    const cleanup = reload()
    return cleanup
  }, [reload])

  return { data, loading, error, reload }
}

// Inline state helpers that preserve the surrounding card chrome.
function SectionLoading({ className = 'py-10' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center text-sm text-slate-500 dark:text-slate-400 ${className}`}>
      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
      Loading…
    </div>
  )
}

function SectionError({ message, onRetry, className = 'py-10' }: { message: string; onRetry: () => void; className?: string }) {
  return (
    <div className={`flex flex-col items-center justify-center gap-3 text-center text-sm text-slate-500 dark:text-slate-400 ${className}`}>
      <div className="flex items-center gap-2 text-red-600 dark:text-red-300">
        <AlertTriangle className="h-4 w-4" />
        {message}
      </div>
      <Button variant="secondary" onClick={onRetry}>Retry</Button>
    </div>
  )
}

function SectionEmpty({ message = 'No data yet', className = 'py-10' }: { message?: string; className?: string }) {
  return (
    <div className={`flex items-center justify-center text-sm text-slate-500 dark:text-slate-400 ${className}`}>
      {message}
    </div>
  )
}

// Stable failure-category -> colour lookup keeping the existing palette so the
// pie chart looks identical regardless of which categories the backend returns.
const FAILURE_CATEGORY_COLORS: Record<string, string> = {
  'Product Bug': '#ef4444',
  'Locator Changed': '#f59e0b',
  'Timing Flaky': '#8b5cf6',
  'Test Data': '#3b82f6',
  Environment: '#22c55e',
  Other: '#64748b',
}
const FAILURE_CATEGORY_FALLBACK = '#64748b'

// Format a UTC ISO timestamp to the user's local time; fall back to the raw
// string if it is not parseable.
function formatStarted(iso: string): string {
  if (!iso) return '—'
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return iso
  return date.toLocaleString()
}

function DashboardPage() {
  const summary = useDashboardSection<DashboardSummary>(getDashboardSummary)
  const passRate = useDashboardSection<PassRatePoint[]>(() => getPassRateTrend({ interval: 'month' }))
  const execution = useDashboardSection<ExecutionPoint[]>(() => getExecutionTrend({ interval: 'day' }))
  const failures = useDashboardSection<FailureCategoryPoint[]>(() => getFailureCategories())
  const locatorHealth = useDashboardSection<LocatorHealthPoint[]>(getLocatorHealth)

  const [runsPage, setRunsPage] = useState(1)
  const RUNS_PAGE_SIZE = 10
  const recent = useDashboardSection<RecentRunsData>(
    useCallback(() => getRecentRuns({ page: runsPage, pageSize: RUNS_PAGE_SIZE }), [runsPage]),
  )

  // Map backend series into the {name,value} shape the existing charts expect.
  const passRateData = (passRate.data ?? []).map((p) => ({ name: p.period, value: p.passRate ?? 0 }))
  const executionData = (execution.data ?? []).map((p) => ({ name: p.period, value: p.executionCount }))
  const failureData = (failures.data ?? []).map((f) => ({
    name: f.category,
    value: f.count,
    color: FAILURE_CATEGORY_COLORS[f.category] ?? FAILURE_CATEGORY_FALLBACK,
  }))

  const recentRunsData = recent.data
  const totalRunRows = recentRunsData?.total ?? 0
  const totalPages = Math.max(1, Math.ceil(totalRunRows / RUNS_PAGE_SIZE))

  // Project the backend rows onto the existing Run row type (keeps the table
  // columns/rendering identical). `started` stays the UTC ISO string here and is
  // formatted to local time at render; duration falls back to an em dash.
  const runRows: Run[] = (recentRunsData?.items ?? []).map((run) => ({
    id: run.id,
    project: run.project,
    suite: run.suite,
    started: run.started,
    duration: run.duration ?? '—',
    passed: run.passed,
    failed: run.failed,
    status: run.status as Run['status'],
  }))

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Dashboard"
        action={<Button variant="primary">Start AI Test</Button>}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-6">
        <MetricCard
          label="Total Projects"
          value={summary.loading ? '—' : summary.error ? '—' : (summary.data?.totalProjects ?? 0).toString()}
          detail=""
          tone="blue"
        />
        <MetricCard
          label="Total Test Cases"
          value={summary.loading ? '—' : summary.error ? '—' : summary.data?.totalTestCases == null ? 'Unavailable' : summary.data.totalTestCases.toString()}
          detail=""
          tone="purple"
        />
        <MetricCard
          label="Total Runs"
          value={summary.loading ? '—' : summary.error ? '—' : (summary.data?.totalRuns ?? 0).toString()}
          detail=""
          tone="green"
        />
        <MetricCard
          label="Pass Rate"
          value={summary.loading ? '—' : summary.error ? '—' : summary.data?.passRate == null ? 'Unavailable' : `${summary.data.passRate}%`}
          detail=""
          tone="green"
        />
        <MetricCard
          label="Failed Tests"
          value={summary.loading ? '—' : summary.error ? '—' : (summary.data?.failedTests ?? 0).toString()}
          detail=""
          tone="red"
        />
        <MetricCard
          label="Locator Issues"
          value={summary.loading ? '—' : summary.error ? '—' : summary.data?.locatorIssues == null ? 'Unavailable' : summary.data.locatorIssues.toString()}
          detail=""
          tone="amber"
        />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <SectionCard title="Pass Rate Trend">
          <div className="h-64 w-full">
            {passRate.loading ? (
              <SectionLoading className="h-full" />
            ) : passRate.error ? (
              <SectionError message={passRate.error} onRetry={passRate.reload} className="h-full" />
            ) : passRateData.length === 0 ? (
              <SectionEmpty message="No historical pass-rate data yet" className="h-full" />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={passRateData}>
                  <defs>
                    <linearGradient id="passFill" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#14b8a6" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="#14b8a6" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} />
                  <YAxis tickLine={false} axisLine={false} domain={[60, 100]} />
                  <Tooltip />
                  <Area dataKey="value" stroke="#14b8a6" fill="url(#passFill)" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>

        <SectionCard title="Quick Start">
          <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-800/50 dark:text-slate-300">
            “Select Rammas as source, open the top channel and voice, and confirm the selected count matches the listing count.”
          </div>
          <Button variant="primary" className="mt-4 w-full">Start AI Test</Button>
        </SectionCard>
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <SectionCard title="Test Execution Trend">
          <div className="h-52 w-full">
            {execution.loading ? (
              <SectionLoading className="h-full" />
            ) : execution.error ? (
              <SectionError message={execution.error} onRetry={execution.reload} className="h-full" />
            ) : executionData.length === 0 ? (
              <SectionEmpty message="No execution records yet" className="h-full" />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={executionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} />
                  <YAxis tickLine={false} axisLine={false} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]} fill="#8b5cf6" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>

        <SectionCard title="Failure Categories">
          {failures.loading ? (
            <SectionLoading className="h-52" />
          ) : failures.error ? (
            <SectionError message={failures.error} onRetry={failures.reload} className="h-52" />
          ) : failureData.length === 0 ? (
            <SectionEmpty message="No failures recorded yet" className="h-52" />
          ) : (
            <>
              <div className="h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie dataKey="value" data={failureData} innerRadius={36} outerRadius={72} paddingAngle={4}>
                      {failureData.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-3 space-y-2 text-sm">
                {failureData.map((category) => (
                  <div key={category.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: category.color }} />
                      {category.name}
                    </div>
                    <span className="font-medium">{category.value}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </SectionCard>

        <SectionCard title="Locator Health">
          {locatorHealth.loading ? (
            <SectionLoading />
          ) : locatorHealth.error ? (
            <SectionError message={locatorHealth.error} onRetry={locatorHealth.reload} />
          ) : (locatorHealth.data?.length ?? 0) === 0 ? (
            <SectionEmpty message="Locator health analysis is unavailable" />
          ) : (
            <div className="space-y-4">
              {locatorHealth.data!.map((entry) => (
                <div key={entry.status} className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800/40">
                  <div>
                    <div className="font-medium">{entry.status}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{entry.percentage}% of locators</div>
                  </div>
                  <div className="h-2.5 w-24 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
                    <div className="h-full rounded-full bg-teal-500" style={{ width: `${entry.percentage}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>

      <SectionCard title="Recent Runs">
        {recent.loading ? (
          <SectionLoading />
        ) : recent.error ? (
          <SectionError message={recent.error} onRetry={recent.reload} />
        ) : (recentRunsData?.items.length ?? 0) === 0 ? (
          <SectionEmpty message="No runs recorded yet" />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="min-w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                    <th className="py-3 pr-4 font-medium">Run ID</th>
                    <th className="py-3 pr-4 font-medium">Project</th>
                    <th className="py-3 pr-4 font-medium">Test Suite</th>
                    <th className="py-3 pr-4 font-medium">Started</th>
                    <th className="py-3 pr-4 font-medium">Duration</th>
                    <th className="py-3 pr-4 font-medium">Passed</th>
                    <th className="py-3 pr-4 font-medium">Failed</th>
                    <th className="py-3 pr-4 font-medium">Status</th>
                    <th className="py-3 pr-4 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {runRows.map((run) => (
                    <tr key={run.id} className="border-b border-slate-200 dark:border-slate-700">
                      <td className="py-3 pr-4 font-medium">{run.id}</td>
                      <td className="py-3 pr-4">{run.project}</td>
                      <td className="py-3 pr-4">{run.suite}</td>
                      <td className="py-3 pr-4">{formatStarted(run.started)}</td>
                      <td className="py-3 pr-4">{run.duration}</td>
                      <td className="py-3 pr-4">{run.passed}</td>
                      <td className="py-3 pr-4">{run.failed}</td>
                      <td className="py-3 pr-4"><StatusPill status={run.status} /></td>
                      <td className="py-3 pr-4">
                        <Link to={`/runs/${run.id}`} className="text-teal-700 hover:text-teal-800 dark:text-teal-300">View</Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {totalRunRows > RUNS_PAGE_SIZE && (
              <div className="mt-4 flex items-center justify-between text-sm text-slate-600 dark:text-slate-300">
                <span>Page {runsPage} of {totalPages}</span>
                <div className="flex gap-2">
                  <Button
                    variant="secondary"
                    disabled={runsPage <= 1}
                    onClick={() => setRunsPage((p) => Math.max(1, p - 1))}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="secondary"
                    disabled={runsPage >= totalPages}
                    onClick={() => setRunsPage((p) => Math.min(totalPages, p + 1))}
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </SectionCard>
    </div>
  )
}

function ProjectsPage() {
  const { setProjectId } = useProject()
  return (
    <div className="space-y-6">
      <SectionHeader title="Projects" action={<Button variant="primary">Create Project</Button>} />
      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <SectionCard title="Project portfolio">
          <div className="grid gap-4 md:grid-cols-2">
            {mockProjects.map((project) => (
              <div key={project.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800/60">
                <div className="mb-4 flex items-start justify-between gap-3">
                  <div>
                    <div className="text-lg font-semibold">{project.name}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{project.appUrl}</div>
                  </div>
                  <StatusPill status={project.status} />
                </div>
                <div className="grid gap-2 text-sm text-slate-600 dark:text-slate-300">
                  <div className="flex justify-between"><span>Current version</span><span className="font-medium">{project.currentVersion}</span></div>
                  <div className="flex justify-between"><span>Last run</span><span className="font-medium">{project.lastRun}</span></div>
                  <div className="flex justify-between"><span>Pass rate</span><span className="font-medium">{project.passRate}%</span></div>
                  <div className="flex justify-between"><span>Locator version</span><span className="font-medium">{project.locatorVersion}</span></div>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button variant="secondary" onClick={() => setProjectId(project.id)}>Open</Button>
                  <Link to={`/projects/${project.id}`} className="inline-flex items-center rounded-xl border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-700">View</Link>
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Create project">
          <form className="space-y-4">
            <Field label="Project Name"><input defaultValue="Rammas Validation" className="field" /></Field>
            <Field label="Application URL"><input defaultValue="https://demo.rammas.ai" className="field" /></Field>
            <Field label="Username"><input defaultValue="qa-user" className="field" /></Field>
            <Field label="Password"><input type="password" defaultValue="••••••••" className="field" /></Field>
            <Field label="Initial Version"><input defaultValue="v3.4.2" className="field" /></Field>
            <Field label="Description"><textarea defaultValue="Customer communications and operations portal" className="field min-h-[100px]" /></Field>
            <Button variant="primary" className="w-full">Save project</Button>
          </form>
        </SectionCard>
      </div>
    </div>
  )
}

function ProjectDetailPage() {
  const { projectId } = useProject()
  const project = mockProjects.find((item) => item.id === projectId) ?? mockProjects[0]

  return (
    <div className="space-y-6">
      <SectionHeader title={project.name} action={<Button variant="primary">Harvest Locators</Button>} />
      <div className="grid gap-6 xl:grid-cols-4">
        <MetricCard label="Environment" value="Production" detail="Stable target" tone="blue" />
        <MetricCard label="Versions" value="v3.4.2" detail="Latest release" tone="purple" />
        <MetricCard label="Locator Status" value="96% Health" detail="12 flagged" tone="green" />
        <MetricCard label="Recent Failures" value="4" detail="2 critical" tone="red" />
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <SectionCard title="Project information">
          <div className="space-y-3 text-sm text-slate-600 dark:text-slate-300">
            <div className="flex justify-between"><span>Application URL</span><span className="font-medium">{project.appUrl}</span></div>
            <div className="flex justify-between"><span>Current version</span><span className="font-medium">{project.currentVersion}</span></div>
            <div className="flex justify-between"><span>Last run</span><span className="font-medium">{project.lastRun}</span></div>
            <div className="flex justify-between"><span>Target status</span><span className="font-medium">{project.status}</span></div>
          </div>
        </SectionCard>

        <SectionCard title="Recent failures">
          <ul className="space-y-3 text-sm">
            {['Username selector changed', 'Channel row mismatch', 'Voice dropdown ambiguous', 'High latency detection'].map((item) => (
              <li key={item} className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800/40">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                {item}
              </li>
            ))}
          </ul>
        </SectionCard>
      </div>
    </div>
  )
}

function HarvestPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Harvest locators" action={<div className="flex gap-2"><Button variant="secondary">Stop</Button><Button variant="primary">Start Harvest</Button></div>} />

      <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <SectionCard title="Live progress">
          <div className="space-y-5">
            <ProgressRow label="Pages discovered" value={24} total={32} />
            <ProgressRow label="Elements discovered" value={386} total={500} />
            <ProgressRow label="Locators created" value={142} total={200} />
            <ProgressRow label="Fragile locators" value={21} total={40} />
            <ProgressRow label="Failed pages" value={4} total={10} />
          </div>
        </SectionCard>

        <SectionCard title="Locator table">
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                  <th className="pr-4 py-2 font-medium">Element</th>
                  <th className="pr-4 py-2 font-medium">Tag</th>
                  <th className="pr-4 py-2 font-medium">Strategy</th>
                  <th className="pr-4 py-2 font-medium">Status</th>
                  <th className="pr-4 py-2 font-medium">Stability</th>
                  <th className="pr-4 py-2 font-medium">Selector</th>
                </tr>
              </thead>
              <tbody>
                {locators.map((locator) => (
                  <tr key={locator.id} className="border-b border-slate-200 dark:border-slate-700">
                    <td className="py-3 pr-4">{locator.element}</td>
                    <td className="py-3 pr-4">{locator.tag}</td>
                    <td className="py-3 pr-4">{locator.strategy}</td>
                    <td className="py-3 pr-4"><StatusPill status={locator.status} /></td>
                    <td className="py-3 pr-4">{locator.stability}%</td>
                    <td className="py-3 pr-4">{locator.selector}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

function LocatorExplorerPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Locator explorer" action={<Button variant="primary">Test Locator</Button>} />
      <div className="grid gap-6 xl:grid-cols-[0.75fr_1.25fr_1fr]">
        <SectionCard title="Pages">
          <div className="space-y-3 text-sm">
            {['Login page', 'Dashboard', 'Channels page', 'Reports page', 'Settings page'].map((page) => (
              <div key={page} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 dark:border-slate-700 dark:bg-slate-800/60">{page}</div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Locator list">
          <div className="space-y-3">
            {locators.map((item) => (
              <div key={item.id} className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800/60">
                <div className="flex items-center justify-between gap-3">
                  <div className="font-medium">{item.element}</div>
                  <StatusPill status={item.status} />
                </div>
                <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">{item.selector}</div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Locator details">
          <div className="space-y-3 text-sm text-slate-600 dark:text-slate-300">
            <div className="flex justify-between"><span>Locator key</span><span className="font-medium">source_dropdown</span></div>
            <div className="flex justify-between"><span>Page</span><span className="font-medium">campaigns_page</span></div>
            <div className="flex justify-between"><span>Strategy</span><span className="font-medium">Test ID</span></div>
            <div className="flex justify-between"><span>Stability</span><span className="font-medium">96%</span></div>
            <div className="flex justify-between"><span>Uniqueness</span><span className="font-medium">High</span></div>
            <div className="flex justify-between"><span>Last verified</span><span className="font-medium">Today</span></div>
          </div>
          <div className="mt-5 flex gap-2">
            <Button variant="secondary">Copy</Button>
            <Button variant="secondary">Compare</Button>
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

function LocatorHealthPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Locator health" action={<Button variant="primary">Check Health</Button>} />
      <SectionCard title="Health matrix">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                <th className="pr-4 py-3 font-medium">Page</th>
                <th className="pr-4 py-3 font-medium">Locator</th>
                <th className="pr-4 py-3 font-medium">Status</th>
                <th className="pr-4 py-3 font-medium">Severity</th>
                <th className="pr-4 py-3 font-medium">Current match</th>
                <th className="pr-4 py-3 font-medium">Expected</th>
                <th className="pr-4 py-3 font-medium">Suggested replacement</th>
              </tr>
            </thead>
            <tbody>
              {healthRows.map((row) => (
                <tr key={`${row.page}-${row.locator}`} className="border-b border-slate-200 dark:border-slate-700">
                  <td className="py-3 pr-4">{row.page}</td>
                  <td className="py-3 pr-4">{row.locator}</td>
                  <td className="py-3 pr-4"><StatusPill status={row.status} /></td>
                  <td className="py-3 pr-4">{row.severity}</td>
                  <td className="py-3 pr-4">{row.currentMatch}</td>
                  <td className="py-3 pr-4">{row.expected}</td>
                  <td className="py-3 pr-4">{row.suggestedReplacement}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}

interface ChatAttachment {
  id: string
  name: string
  size: string
  type: string
  content?: string
}

// A single file read from a locally uploaded folder (for the IDE view).
interface UploadedFile {
  path: string // path relative to the uploaded folder root, e.g. "src/app.ts"
  name: string
  size: string
  language: string
  content?: string
}

// Nested tree node for the IDE explorer.
interface IdeTreeNode {
  name: string
  path: string
  dirs: Map<string, IdeTreeNode>
  files: UploadedFile[]
}

interface GeneratedTestCase {
  id: string
  title: string
  description: string
  steps: string[]
  expectedResult: string
  priority: 'High' | 'Medium' | 'Low'
  category: 'E2E' | 'Regression' | 'Boundary' | 'Security' | 'Smoke'
}

interface GeneratedFile {
  path: string
  name: string
  language: string
  description: string
  content: string
}

interface GeneratedBundle {
  title: string
  description: string
  summary: {
    totalCases: number
    positiveCount: number
    negativeCount: number
    edgeCount: number
    coverage: string
  }
  testCases: GeneratedTestCase[]
  files: GeneratedFile[]
}

interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  timestamp: string
  content: string
  attachments?: ChatAttachment[]
  bundle?: GeneratedBundle
  isGenerating?: boolean
  generationStep?: number
}

interface ChatSession {
  id: string
  title: string
  project: string
  createdAt: string
  messages: ChatMessage[]
}

// Backend-backed project folder panel for the Agent Workspace sidebar.
// Shows the predefined structure, lets the user browse the LOCAL filesystem,
// pick any folder, and creates the structure (Features/Scripts/Test_cases/
// Test_data/Reports) INSIDE that folder. The backend owns the filesystem.
function ProjectPanel({
  selected,
  onSelect,
  autoOpenKey = 0,
}: {
  selected: string | null
  onSelect: (base: string | null) => void
  autoOpenKey?: number
}) {
  const [tree, setTree] = useState<ProjectTree | null>(null)
  const [error, setError] = useState<string | null>(null)

  // Folder-browser modal state.
  const [browserOpen, setBrowserOpen] = useState(false)
  const [browsing, setBrowsing] = useState<BrowseResult | null>(null)
  const [busy, setBusy] = useState(false)
  const [newFolderName, setNewFolderName] = useState('')

  // File editor modal state (create / modify a file in a subfolder).
  const [editor, setEditor] = useState<{
    folder: string
    filename: string
    content: string
    isNew: boolean
  } | null>(null)
  const [editorBusy, setEditorBusy] = useState(false)

  useEffect(() => {
    if (!selected) { setTree(null); return }
    getTree(selected).then(setTree).catch(() => setTree(null))
  }, [selected])

  const openBrowser = async () => {
    setError(null)
    setBrowserOpen(true)
    try {
      setBrowsing(await browse('')) // start at drive roots
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to browse')
    }
  }

  // Open the folder browser when the parent bumps autoOpenKey (e.g. New Test Chat).
  useEffect(() => {
    if (autoOpenKey > 0) void openBrowser()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoOpenKey])

  const navigate = async (path: string) => {
    setError(null)
    try {
      setBrowsing(await browse(path))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Cannot open folder')
    }
  }

  // Option 1 — Create a NEW folder (named) at the current location, then
  // create the predefined structure inside it and select it.
  const createNewProject = async () => {
    const name = newFolderName.trim()
    if (!browsing?.path || !name) return
    setBusy(true)
    setError(null)
    try {
      const made = await makeDir(browsing.path, name)
      const res = await createStructure(made.path)
      setBrowserOpen(false)
      setNewFolderName('')
      onSelect(res.path)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create folder')
    } finally {
      setBusy(false)
    }
  }

  // Option 2 — Use the EXISTING folder currently open: create the predefined
  // structure directly inside it and select it.
  const selectExisting = async () => {
    if (!browsing?.path) return
    setBusy(true)
    setError(null)
    try {
      const res = await createStructure(browsing.path)
      setBrowserOpen(false)
      onSelect(res.path)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to select folder')
    } finally {
      setBusy(false)
    }
  }

  const refreshTree = async () => {
    if (selected) setTree(await getTree(selected))
  }

  // Open the editor to create a new file in a subfolder.
  const openNewFile = (folder: string) => {
    setEditor({ folder, filename: '', content: '', isNew: true })
  }

  // Open the editor to modify an existing file.
  const openEditFile = async (folder: string, filename: string) => {
    if (!selected) return
    setError(null)
    try {
      const f = await readFile(selected, folder, filename)
      setEditor({ folder, filename, content: f.content, isNew: false })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to read file')
    }
  }

  const saveEditor = async () => {
    if (!selected || !editor) return
    const filename = editor.filename.trim()
    if (!filename) return
    setEditorBusy(true)
    setError(null)
    try {
      await saveFile(selected, editor.folder, filename, editor.content)
      setEditor(null)
      await refreshTree()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save file')
    } finally {
      setEditorBusy(false)
    }
  }

  const fileCount = tree
    ? Object.values(tree.folders).reduce((n, files) => n + files.length, 0)
    : 0

  return (
    <>
      {/* Panel body is hidden by default; it only appears once a project
          folder is selected (via the New Test Chat flow). */}
      {selected && (
      <div className="border-b border-slate-100 px-3 pb-3 dark:border-slate-800">
        <div className="px-1 pt-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Project Folder
        </div>

        {error && (
          <div className="mt-1 rounded-md bg-red-50 px-2 py-1 text-[10px] text-red-700 dark:bg-red-950/40 dark:text-red-300">
            {error}
          </div>
        )}

      {tree && (
        <div className="mt-2 overflow-hidden rounded-lg border border-slate-200 bg-slate-50/60 dark:border-slate-700 dark:bg-slate-800/40">
          {/* Project header */}
          <div className="flex items-center gap-1.5 border-b border-slate-200 px-2.5 py-1.5 dark:border-slate-700">
            <FolderOpen className="h-3.5 w-3.5 shrink-0 text-teal-600" />
            <span className="truncate text-[11px] font-bold text-slate-800 dark:text-slate-100">{tree.name}</span>
            <span className="ml-auto shrink-0 rounded-full bg-slate-200 px-1.5 py-0.5 text-[9px] font-semibold text-slate-600 dark:bg-slate-700 dark:text-slate-300">
              {fileCount} files
            </span>
          </div>
          <div className="truncate px-2.5 py-1 text-[9px] text-slate-400" title={tree.path}>{tree.path}</div>

          {/* Aligned folder rows */}
          <ul className="px-1 pb-1.5">
            {Object.entries(tree.folders).map(([folder, files]) => (
              <li key={folder} className="group/folder">
                <div className="flex items-center gap-1.5 rounded-md px-1.5 py-1 text-[11px] text-slate-700 dark:text-slate-200">
                  <Folder className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                  <span className="flex-1 truncate font-medium">{folder}</span>
                  <button
                    type="button"
                    onClick={() => openNewFile(folder)}
                    className="shrink-0 rounded p-0.5 text-slate-400 opacity-0 transition hover:bg-teal-100 hover:text-teal-600 group-hover/folder:opacity-100 dark:hover:bg-teal-950"
                    title={`Add a file to ${folder}`}
                  >
                    <Plus className="h-3 w-3" />
                  </button>
                  <span className="w-4 shrink-0 text-right tabular-nums text-[10px] text-slate-400">{files.length}</span>
                </div>
                {files.length > 0 && (
                  <ul className="ml-[1.1rem] border-l border-slate-200 dark:border-slate-700">
                    {files.map((f) => (
                      <li key={f.name}>
                        <button
                          type="button"
                          onClick={() => void openEditFile(folder, f.name)}
                          className="flex w-full items-center gap-1.5 rounded py-0.5 pl-2 pr-1.5 text-left text-[10px] text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700/60"
                          title="Open to edit"
                        >
                          <FileText className="h-2.5 w-2.5 shrink-0 text-slate-400" />
                          <span className="truncate">{f.name}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
      </div>
      )}

      {/* Folder browser modal */}
      {browserOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setBrowserOpen(false)}>
          <div
            className="flex max-h-[70vh] w-full max-w-lg flex-col rounded-xl border border-slate-200 bg-white shadow-xl dark:border-slate-700 dark:bg-slate-900"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5 dark:border-slate-700">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Create project in a local folder</h3>
              <button type="button" onClick={() => setBrowserOpen(false)} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4" />
              </button>
            </div>

            {error && (
              <div className="border-b border-slate-100 bg-red-50 px-4 py-2 text-[11px] text-red-700 dark:border-slate-800 dark:bg-red-950/40 dark:text-red-300">
                {error}
              </div>
            )}

            {/* Current path + up */}
            <div className="flex items-center gap-2 border-b border-slate-100 px-4 py-2 dark:border-slate-800">
              <button
                type="button"
                disabled={!browsing?.parent}
                onClick={() => browsing?.parent && void navigate(browsing.parent)}
                className="rounded-md border border-slate-300 px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300"
              >
                Up
              </button>
              <div className="min-w-0 flex-1 truncate rounded-md bg-slate-100 px-2 py-1 text-[11px] text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                {browsing?.path || 'This PC'}
              </div>
            </div>

            {/* Drive / home shortcuts at root */}
            {browsing && !browsing.path && (
              <div className="flex flex-wrap gap-1.5 px-4 py-2">
                {browsing.drives.map((d) => (
                  <button key={d} type="button" onClick={() => void navigate(d)} className="rounded-md border border-slate-300 px-2 py-1 text-[11px] hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">{d}</button>
                ))}
                <button type="button" onClick={() => void navigate(browsing.home)} className="rounded-md border border-slate-300 px-2 py-1 text-[11px] hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">Home</button>
              </div>
            )}

            {/* Folder list */}
            <div className="flex-1 overflow-y-auto px-2 py-1">
              {browsing?.folders.length === 0 && browsing?.path && (
                <div className="px-2 py-4 text-center text-xs text-slate-400">No subfolders here. You can select this folder.</div>
              )}
              {browsing?.folders.map((f) => (
                <button
                  key={f.path}
                  type="button"
                  onDoubleClick={() => void navigate(f.path)}
                  onClick={() => void navigate(f.path)}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Folder className="h-3.5 w-3.5 shrink-0 text-teal-600" />
                  <span className="truncate">{f.name}</span>
                </button>
              ))}
            </div>

            {/* New folder row */}
            {browsing?.path && (
              <div className="border-t border-slate-200 px-4 py-3 dark:border-slate-700">
                {/* Optional: create a new folder at this location */}
                <div className="mb-2 flex items-center gap-2">
                  <input
                    value={newFolderName}
                    onChange={(e) => setNewFolderName(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') void createNewProject() }}
                    placeholder="New folder name (optional)"
                    className="min-w-0 flex-1 rounded-md border border-slate-300 px-2 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                  <button
                    type="button"
                    disabled={!newFolderName.trim() || busy}
                    onClick={() => void createNewProject()}
                    className="flex shrink-0 items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:border-teal-500 hover:text-teal-600 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300"
                  >
                    <FolderPlus className="h-3.5 w-3.5" />
                    <span>Create new folder</span>
                  </button>
                </div>

                {/* Default action: use the folder currently open */}
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void selectExisting()}
                  className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-teal-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-teal-700 disabled:opacity-40"
                >
                  <FolderOpen className="h-3.5 w-3.5" />
                  <span>{busy ? 'Working...' : 'Select this folder'}</span>
                </button>

                <div className="mt-2 truncate text-[10px] text-slate-400" title={browsing.path}>
                  Structure (Features, Scripts, Test_cases, Test_data, Reports) is created inside the chosen folder.
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* File editor modal (create / modify a file in a subfolder) */}
      {editor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setEditor(null)}>
          <div
            className="flex max-h-[80vh] w-full max-w-2xl flex-col rounded-xl border border-slate-200 bg-white shadow-xl dark:border-slate-700 dark:bg-slate-900"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5 dark:border-slate-700">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {editor.isNew ? `New file in ${editor.folder}` : `Edit ${editor.folder}/${editor.filename}`}
              </h3>
              <button type="button" onClick={() => setEditor(null)} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="px-4 py-2">
              <input
                value={editor.filename}
                onChange={(e) => setEditor({ ...editor, filename: e.target.value })}
                disabled={!editor.isNew}
                placeholder="filename.ext (e.g. login.feature, test_login.py)"
                className="w-full rounded-md border border-slate-300 px-2 py-1.5 text-xs disabled:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:disabled:bg-slate-800/60"
              />
            </div>
            <textarea
              value={editor.content}
              onChange={(e) => setEditor({ ...editor, content: e.target.value })}
              placeholder="File content..."
              className="mx-4 mb-2 min-h-[260px] flex-1 resize-none rounded-md border border-slate-300 p-2 font-mono text-xs text-slate-800 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
            <div className="flex items-center justify-end gap-2 border-t border-slate-200 px-4 py-2.5 dark:border-slate-700">
              <button type="button" onClick={() => setEditor(null)} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:border-slate-700 dark:text-slate-300">
                Cancel
              </button>
              <button
                type="button"
                disabled={!editor.filename.trim() || editorBusy}
                onClick={() => void saveEditor()}
                className="rounded-lg bg-teal-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-teal-700 disabled:opacity-40"
              >
                {editorBusy ? 'Saving...' : 'Save file'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}


// Persist the Agent Workspace IDE view across navigation (within the session)
// so returning to the page restores the same folder/chat without re-uploading.
const AGENT_WS_KEY = 'qagentix.agentWorkspace'
interface AgentWsSnapshot {
  showWelcome: boolean
  ideMode: boolean
  uploadedFolderName: string | null
  uploadedFiles: UploadedFile[]
  activeIdeFile: string | null
  expandedFolders: Record<string, boolean>
  sessions: ChatSession[]
  activeSessionId: string
}
function loadAgentWsSnapshot(): AgentWsSnapshot | null {
  try {
    const raw = sessionStorage.getItem(AGENT_WS_KEY)
    return raw ? (JSON.parse(raw) as AgentWsSnapshot) : null
  } catch {
    return null
  }
}

const DEFAULT_KIRO_MODELS: KiroModelItem[] = [
  {
    id: 'auto',
    name: 'Auto (Kiro Smart Router)',
    badge: 'Recommended',
    provider: 'Kiro Native',
    description: 'Automatically routes planning, testcase matrix, and Playwright code to optimal models',
    context_window: '200k',
    latency: 'Adaptive',
    icon: 'sparkles',
  },
  {
    id: 'gemini-3.8-flash-medium',
    name: 'Gemini 3.8 Flash Medium',
    badge: 'Kiro Default',
    provider: 'Google DeepMind',
    description: 'Default high-throughput model with verified locator synthesis and low latency',
    context_window: '1M',
    latency: 'Ultra-fast',
    icon: 'zap',
  },
  {
    id: 'claude-3-7-sonnet',
    name: 'Claude 3.7 Sonnet',
    badge: 'Hybrid Reasoning',
    provider: 'Anthropic',
    description: 'State-of-the-art software architecture, deep Gherkin BDD, and Playwright POM generation',
    context_window: '200k',
    latency: 'Medium',
    icon: 'brain',
  },
  {
    id: 'claude-3-5-sonnet',
    name: 'Claude 3.5 Sonnet',
    badge: 'Popular',
    provider: 'Anthropic',
    description: 'Industry benchmark for resilient test design, negative boundary scenarios, and locator robustness',
    context_window: '200k',
    latency: 'Fast',
    icon: 'code',
  },
  {
    id: 'claude-3-5-haiku',
    name: 'Claude 3.5 Haiku',
    badge: 'High Speed',
    provider: 'Anthropic',
    description: 'Lightweight rapid response model for instant test case and prompt optimization',
    context_window: '200k',
    latency: 'Ultra-fast',
    icon: 'zap',
  },
  {
    id: 'gpt-4o',
    name: 'GPT-4o',
    badge: 'Omni',
    provider: 'OpenAI',
    description: 'High performance across test automation, schema contract validation, and fixtures',
    context_window: '128k',
    latency: 'Fast',
    icon: 'cpu',
  },
  {
    id: 'gpt-4o-mini',
    name: 'GPT-4o mini',
    badge: 'Efficient',
    provider: 'OpenAI',
    description: 'Cost-effective model for high volume test suites and standard CRUD assertions',
    context_window: '128k',
    latency: 'Ultra-fast',
    icon: 'zap',
  },
  {
    id: 'o3-mini',
    name: 'o3-mini',
    badge: 'Reasoning',
    provider: 'OpenAI',
    description: 'Deep STEM reasoning for complex algorithmic QA, cryptography, and RBAC matrix',
    context_window: '200k',
    latency: 'Deliberate',
    icon: 'layers',
  },
  {
    id: 'deepseek-r1',
    name: 'DeepSeek R1',
    badge: 'Reasoning',
    provider: 'DeepSeek',
    description: 'Open reasoning model with thorough edge-case analysis and test condition exploration',
    context_window: '64k',
    latency: 'Moderate',
    icon: 'shield',
  },
  {
    id: 'deepseek-v3',
    name: 'DeepSeek V3',
    badge: 'High Speed',
    provider: 'DeepSeek',
    description: 'Strong coding efficiency for multi-page test framework generation',
    context_window: '128k',
    latency: 'Fast',
    icon: 'code',
  },
  {
    id: 'gemini-2.0-flash',
    name: 'Gemini 2.0 Flash',
    badge: 'High Speed',
    provider: 'Google DeepMind',
    description: 'Ultra-fast generation for rapid prompt refinement and instant test script prototyping',
    context_window: '1M',
    latency: 'Ultra-fast',
    icon: 'zap',
  },
  {
    id: 'gemini-1.5-pro',
    name: 'Gemini 1.5 Pro',
    badge: 'Long Context',
    provider: 'Google DeepMind',
    description: 'Handles immense PRD documents and legacy codebases up to 2 million tokens',
    context_window: '2M',
    latency: 'Balanced',
    icon: 'layers',
  },
]

function AgentWorkspacePage() {
  const { activeProject } = useProjectList()
  const wsSnapshot = loadAgentWsSnapshot()
  // Persist the selected project folder so it survives a page refresh. The
  // folders/files themselves live on disk (never deleted by refresh); this just
  // remembers which project was open so the tree re-loads automatically.
  const [selectedProjectFolder, setSelectedProjectFolder] = useState<string | null>(
    () => localStorage.getItem('qagentix.projectFolder')
  )
  const [folderPickerKey, setFolderPickerKey] = useState(0)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // VS Code-style welcome landing. Shown first unless a previous view was saved.
  const [showWelcome, setShowWelcome] = useState(() => wsSnapshot?.showWelcome ?? true)
  const dismissWelcome = () => setShowWelcome(false)

  useEffect(() => {
    if (selectedProjectFolder) {
      localStorage.setItem('qagentix.projectFolder', selectedProjectFolder)
    } else {
      localStorage.removeItem('qagentix.projectFolder')
    }
  }, [selectedProjectFolder])

  // Initial Sample Data for rich out-of-the-box experience
  const sampleBundleRammas: GeneratedBundle = {
    title: 'Rammas E2E Channel & Voice Selection Suite',
    description: 'Autonomous Playwright test suite with self-healing locators, Page Object Model classes, and negative edge-case assertions.',
    summary: {
      totalCases: 6,
      positiveCount: 4,
      negativeCount: 1,
      edgeCount: 1,
      coverage: '98.5%',
    },
    testCases: [
      {
        id: 'TC-101',
        title: 'Verify authenticated user can access channel overview and select source "Rammas"',
        description: 'Ensures the root operations portal loads and source selector defaults to Rammas with active badge display.',
        steps: [
          'Navigate to operations portal at /dashboard',
          'Locate source selection dropdown element [data-testid="source-select"]',
          'Choose "Rammas" from options list',
          'Assert active badge text equals "Rammas"',
        ],
        expectedResult: 'System displays Rammas channels and sets global context with status 200 OK.',
        priority: 'High',
        category: 'Smoke',
      },
      {
        id: 'TC-102',
        title: 'Voice filter persists across pagination state and itemized summary count',
        description: 'Validates that applying voice filters maintains selected state when advancing through paginated tables.',
        steps: [
          'Filter channel table by voice type "Outbound Voice"',
          'Advance to page 2 using table pagination button',
          'Verify voice filter checkbox remains selected',
          'Assert summary counter matches count of visible filtered rows',
        ],
        expectedResult: 'Pagination maintains active filters without resetting user query parameters.',
        priority: 'High',
        category: 'E2E',
      },
      {
        id: 'TC-103',
        title: 'Negative validation: Empty search keyword displays resilient zero-state banner',
        description: 'Tests search input behavior when matching criteria fails or query is cleared.',
        steps: [
          'Input non-existent query "##__INVALID_FILTER__##" in channel search',
          'Wait for grid re-render',
          'Verify empty state illustration and "No channels found" message is visible',
          'Click "Reset Filters" action button',
        ],
        expectedResult: 'No unhandled JavaScript exceptions; graceful zero-state banner is rendered.',
        priority: 'Medium',
        category: 'Boundary',
      },
      {
        id: 'TC-104',
        title: 'Security & Auth check: Unauthorized role cannot modify channel configuration',
        description: 'Ensures Viewer role cannot trigger administrative mutations or channel edits.',
        steps: [
          'Authenticate with viewer credentials session',
          'Attempt to click channel action "Edit Configuration"',
          'Verify edit modal is disabled or access denied banner appears',
        ],
        expectedResult: 'RBAC restriction strictly enforced; mutative controls are disabled for viewers.',
        priority: 'High',
        category: 'Security',
      },
      {
        id: 'TC-105',
        title: 'Batch channel enable/disable toggle updates real-time analytics counter',
        description: 'Verifies bulk operation status reflection across the dashboard telemetry cards.',
        steps: [
          'Select first 3 active channel rows via checkboxes',
          'Click bulk action "Disable Channels"',
          'Confirm action in prompt modal',
          'Verify active channel count decreases by exactly 3 in KPI metric card',
        ],
        expectedResult: 'Telemetry cards reflect updated channel states without full page refresh.',
        priority: 'Medium',
        category: 'Regression',
      },
      {
        id: 'TC-106',
        title: 'Export channels summary report as CSV with matching row schema',
        description: 'Checks report export triggers download and validates payload row count.',
        steps: [
          'Click "Export CSV" in channels table toolbar',
          'Intercept browser download event',
          'Verify filename conforms to rammas-channels-{date}.csv',
        ],
        expectedResult: 'Browser receives CSV payload with Content-Disposition header and valid rows.',
        priority: 'Low',
        category: 'E2E',
      },
    ],
    files: [
      {
        path: 'tests/rammas-channels.spec.ts',
        name: 'rammas-channels.spec.ts',
        language: 'typescript',
        description: 'Main Playwright E2E test execution suite using Page Object Model',
        content: `import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ChannelsPage } from '../pages/ChannelsPage';
import testData from '../fixtures/testData.json';

test.describe('Rammas Operations - Channel & Voice Validation', () => {
  let loginPage: LoginPage;
  let channelsPage: ChannelsPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    channelsPage = new ChannelsPage(page);
    await page.goto(process.env.APP_URL || 'https://demo.rammas.ai');
    await loginPage.login(testData.credentials.username, testData.credentials.password);
    await expect(page).toHaveURL(/.*(subscriptions|dashboard)/);
  });

  test('TC-101: Source selection displays Rammas channels', async ({ page }) => {
    await channelsPage.selectSource('Rammas');
    await expect(channelsPage.sourceBadge).toBeVisible();
    await expect(channelsPage.sourceBadge).toContainText('Rammas');
    const rowCount = await channelsPage.getChannelRowsCount();
    expect(rowCount).toBeGreaterThan(0);
  });

  test('TC-102: Voice filter retains state across pagination', async () => {
    await channelsPage.applyVoiceFilter('Outbound Voice');
    await expect(channelsPage.activeFilterPill).toHaveText(/Outbound/i);
    await channelsPage.nextPage();
    await expect(channelsPage.activeFilterPill).toBeVisible();
  });

  test('TC-103: Negative validation handles empty search query gracefully', async ({ page }) => {
    await channelsPage.searchChannels('##__INVALID_FILTER__##');
    await expect(channelsPage.emptyStateAlert).toBeVisible();
    await channelsPage.clearSearch();
  });
});
`,
      },
      {
        path: 'pages/LoginPage.ts',
        name: 'LoginPage.ts',
        language: 'typescript',
        description: 'Page Object Model class for login authentication',
        content: `import { type Page, type Locator } from '@playwright/test';

export class LoginPage {
  readonly page: Page;
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly errorMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.usernameInput = page.getByLabel(/username/i).or(page.locator('#username'));
    this.passwordInput = page.getByLabel(/password/i).or(page.locator('#password'));
    this.loginButton = page.getByRole('button', { name: /sign in|login/i });
    this.errorMessage = page.locator('[role="alert"]').or(page.locator('.text-red-500'));
  }

  async login(user: string, pass: string) {
    await this.usernameInput.fill(user);
    await this.passwordInput.fill(pass);
    await this.loginButton.click();
  }
}
`,
      },
      {
        path: 'pages/ChannelsPage.ts',
        name: 'ChannelsPage.ts',
        language: 'typescript',
        description: 'Page Object Model class for Channel management and filters',
        content: `import { type Page, type Locator } from '@playwright/test';

export class ChannelsPage {
  readonly page: Page;
  readonly sourceSelect: Locator;
  readonly sourceBadge: Locator;
  readonly channelRows: Locator;
  readonly voiceFilterCheckbox: Locator;
  readonly activeFilterPill: Locator;
  readonly paginationNextButton: Locator;
  readonly searchInput: Locator;
  readonly emptyStateAlert: Locator;

  constructor(page: Page) {
    this.page = page;
    this.sourceSelect = page.getByTestId('source-select').or(page.locator('[aria-label="Select source"]'));
    this.sourceBadge = page.locator('[data-testid="active-source-badge"]').or(page.locator('.badge-source'));
    this.channelRows = page.locator('table tbody tr');
    this.voiceFilterCheckbox = page.getByLabel(/outbound voice/i);
    this.activeFilterPill = page.locator('[data-testid="filter-pill"]');
    this.paginationNextButton = page.getByRole('button', { name: /next page|next/i });
    this.searchInput = page.getByPlaceholder(/search channels/i);
    this.emptyStateAlert = page.getByText(/no channels found/i);
  }

  async selectSource(sourceName: string) {
    if (await this.sourceSelect.isVisible()) {
      await this.sourceSelect.click();
      await this.page.getByRole('option', { name: sourceName }).click();
    }
  }

  async applyVoiceFilter(filterName: string) {
    await this.page.getByText(filterName).click();
  }

  async nextPage() {
    await this.paginationNextButton.click();
  }

  async searchChannels(query: string) {
    await this.searchInput.fill(query);
    await this.page.keyboard.press('Enter');
  }

  async clearSearch() {
    await this.searchInput.clear();
  }

  async getChannelRowsCount() {
    return await this.channelRows.count();
  }
}
`,
      },
      {
        path: 'fixtures/testData.json',
        name: 'testData.json',
        language: 'json',
        description: 'Environment and credential fixtures',
        content: JSON.stringify(
          {
            targetApp: 'https://demo.rammas.ai',
            credentials: {
              username: 'qa-lead@rammas.ai',
              password: 'SuperSecretPass123!',
            },
            filters: {
              sources: ['Rammas', 'Operations Portal', 'Customer Gateway'],
              channels: ['Outbound Voice', 'Inbound Voice', 'SMS Messaging', 'Webhooks'],
            },
          },
          null,
          2
        ),
      },
      {
        path: 'playwright.config.ts',
        name: 'playwright.config.ts',
        language: 'typescript',
        description: 'Playwright execution runner configuration',
        content: `import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  retries: process.env.CI ? 2 : 1,
  workers: process.env.CI ? 1 : undefined,
  reporter: [['html'], ['list']],
  use: {
    baseURL: process.env.APP_URL || 'https://demo.rammas.ai',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
  ],
});
`,
      },
      {
        path: 'test-cases.json',
        name: 'test-cases.json',
        language: 'json',
        description: 'Structured test cases in standard JSON format',
        content: '', // will be populated dynamically
      },
      {
        path: 'test-cases.csv',
        name: 'test-cases.csv',
        language: 'csv',
        description: 'Test cases matrix in CSV format for Jira, TestRail, or Zephyr',
        content: '', // will be populated dynamically
      },
      {
        path: 'README.md',
        name: 'README.md',
        language: 'markdown',
        description: 'Instructions to run the generated Playwright test suite locally or in CI/CD',
        content: `# QAgentix Generated Playwright Test Suite

This automated test suite was synthesized by **QAgentix AI Test Orchestrator** for **Rammas Operations Platform**.

## Prerequisites
- Node.js 18+ installed

## Quick Start
\`\`\`bash
# 1. Install dependencies
npm install @playwright/test

# 2. Install browser binaries
npx playwright install --with-deps

# 3. Run all test cases in headless mode
npx playwright test

# 4. Run tests with UI inspector
npx playwright test --ui

# 5. View test execution report
npx playwright show-report
\`\`\`
`,
      },
    ],
  }

  // Populate dynamic JSON and CSV content for sample bundle
  sampleBundleRammas.files.find((f) => f.path === 'test-cases.json')!.content = JSON.stringify(
    sampleBundleRammas.testCases,
    null,
    2
  )
  sampleBundleRammas.files.find((f) => f.path === 'test-cases.csv')!.content = [
    'ID,Title,Category,Priority,Steps,ExpectedResult',
    ...sampleBundleRammas.testCases.map(
      (tc) =>
        `"${tc.id}","${tc.title.replace(/"/g, '""')}","${tc.category}","${tc.priority}","${tc.steps.join(' | ').replace(/"/g, '""')}","${tc.expectedResult.replace(/"/g, '""')}"`
    ),
  ].join('\n')

  // Chat Sessions State - Starts completely empty with no pre-loaded dummy chats or suggestions
  const [sessions, setSessions] = useState<ChatSession[]>(
    () =>
      wsSnapshot?.sessions ?? [
        {
          id: 'session-1',
          title: 'New Test Generation',
          project: activeProject?.name || 'Rammas',
          createdAt: 'Just now',
          messages: [],
        },
      ]
  )

  const [activeSessionId, setActiveSessionId] = useState<string>(() => wsSnapshot?.activeSessionId ?? 'session-1')
  const [inputText, setInputText] = useState('')
  const [attachedFiles, setAttachedFiles] = useState<ChatAttachment[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)
  const folderInputRef = useRef<HTMLInputElement>(null)
  // Handle to the on-disk folder (File System Access API), when available.
  const dirHandleRef = useRef<FileSystemDirectoryHandle | null>(null)
  const [uploadedFolderName, setUploadedFolderName] = useState<string | null>(() => wsSnapshot?.uploadedFolderName ?? null)
  // Uploaded local folder files for the VS Code-style IDE view.
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>(() => wsSnapshot?.uploadedFiles ?? [])
  const [activeIdeFile, setActiveIdeFile] = useState<string | null>(() => wsSnapshot?.activeIdeFile ?? null)
  const [ideMode, setIdeMode] = useState(() => wsSnapshot?.ideMode ?? false)
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>(() => wsSnapshot?.expandedFolders ?? {})
  // Editor tabs and content cache for IDE view
  const [openEditorTabs, setOpenEditorTabs] = useState<string[]>(() => {
    if (wsSnapshot?.activeIdeFile) return [wsSnapshot.activeIdeFile]
    return []
  })
  const [ideFileContents, setIdeFileContents] = useState<Record<string, string>>({})
  const [ideViewLayout, setIdeViewLayout] = useState<'split' | 'editor' | 'chat'>('split')
  const [isLoadingFile, setIsLoadingFile] = useState(false)
  const [editorCopied, setEditorCopied] = useState(false)
  // "Create Folder" modal + new-file prompt state.
  const [createFolderOpen, setCreateFolderOpen] = useState(false)
  const [createFolderName, setCreateFolderName] = useState('')
  // Backend filesystem browser state for the Create Folder modal: lets the user
  // choose a local path (via the server) instead of the Chrome picker, which
  // blocks folders it considers to contain "system files".
  const [createFolderBrowsing, setCreateFolderBrowsing] = useState<BrowseResult | null>(null)
  const [createFolderError, setCreateFolderError] = useState<string | null>(null)
  const [createFolderBusy, setCreateFolderBusy] = useState(false)
  const [newFilePath, setNewFilePath] = useState('')
  const [newFilePromptOpen, setNewFilePromptOpen] = useState(false)
  const [isDraggingOverChat, setIsDraggingOverChat] = useState(false)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [copiedFileId, setCopiedFileId] = useState<string | null>(null)
  const [activeBundleTab, setActiveBundleTab] = useState<'tree' | 'cases' | 'code'>('tree')
  const [selectedPreviewFile, setSelectedPreviewFile] = useState<string>('tests/rammas-channels.spec.ts')
  const [isDropUpOpen, setIsDropUpOpen] = useState(true)
  const dropUpRef = useRef<HTMLDivElement>(null)

  // Kiro AI Models state & dropdown
  const [selectedModel, setSelectedModel] = useState<string>('auto')
  const [kiroModels, setKiroModels] = useState<KiroModelItem[]>(DEFAULT_KIRO_MODELS)
  const [isModelDropdownOpen, setIsModelDropdownOpen] = useState(false)
  const [modelSearchQuery, setModelSearchQuery] = useState('')
  const modelDropdownRef = useRef<HTMLDivElement>(null)
  const [isAskMenuOpen, setIsAskMenuOpen] = useState(false)
  const askMenuRef = useRef<HTMLDivElement>(null)

  // Fetch connected models from backend Kiro API
  useEffect(() => {
    let mounted = true
    void getKiroModels()
      .then((data) => {
        if (mounted && data?.models && data.models.length > 0) {
          setKiroModels(data.models)
          if (data.active_model) {
            setSelectedModel((prev) => (prev === 'auto' ? data.active_model : prev))
          }
        }
      })
      .catch((err) => {
        console.warn('Could not load Kiro models, using local catalog:', err)
      })
    return () => {
      mounted = false
    }
  }, [])

  // Close popovers on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (modelDropdownRef.current && !modelDropdownRef.current.contains(e.target as unknown as HTMLElement)) {
        setIsModelDropdownOpen(false)
      }
      if (askMenuRef.current && !askMenuRef.current.contains(e.target as unknown as HTMLElement)) {
        setIsAskMenuOpen(false)
      }
    }
    if (isModelDropdownOpen || isAskMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside)
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [isModelDropdownOpen, isAskMenuOpen])

  const filteredKiroModels = useMemo(() => {
    const q = modelSearchQuery.toLowerCase().trim()
    if (!q) return kiroModels
    return kiroModels.filter(
      (m) =>
        m.name.toLowerCase().includes(q) ||
        m.provider.toLowerCase().includes(q) ||
        m.badge.toLowerCase().includes(q) ||
        m.description.toLowerCase().includes(q)
    )
  }, [kiroModels, modelSearchQuery])

  const currentModelObj = useMemo(() => {
    return kiroModels.find((m) => m.id === selectedModel) || kiroModels[0] || DEFAULT_KIRO_MODELS[0]
  }, [kiroModels, selectedModel])

  // Format file size utility
  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  // Handle file selection from chat box upload option
  const handleFileSelect = (files: FileList | null) => {
    if (!files || files.length === 0) return
    const newAttachments: ChatAttachment[] = Array.from(files).map((file) => ({
      id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: file.name,
      size: formatFileSize(file.size),
      type: file.type || file.name.split('.').pop() || 'file',
    }))
    setAttachedFiles((prev) => [...prev, ...newAttachments])
  }

  // Map a filename to a Monaco language id.
  const detectLanguage = (name: string): string => {
    const ext = name.split('.').pop()?.toLowerCase() || ''
    const map: Record<string, string> = {
      ts: 'typescript', tsx: 'typescript', js: 'javascript', jsx: 'javascript',
      json: 'json', html: 'html', css: 'css', scss: 'scss', md: 'markdown',
      py: 'python', java: 'java', go: 'go', rb: 'ruby', php: 'php', rs: 'rust',
      yaml: 'yaml', yml: 'yaml', xml: 'xml', sql: 'sql', sh: 'shell',
      c: 'c', cpp: 'cpp', cs: 'csharp', feature: 'gherkin', txt: 'plaintext', csv: 'plaintext',
    }
    return map[ext] || 'plaintext'
  }

  // Clear the messages of the currently active chat session.
  const resetActiveChat = () => {
    setInputText('')
    setSessions((prev) => prev.map((s) => (s.id === activeSessionId ? { ...s, messages: [] } : s)))
  }

  // Open a folder in the IDE from a list of {path, size} entries (paths are
  // already relative to the folder root). Shared by both pickers.
  const openFolderInIde = (rootName: string, entries: { path: string; size: number }[]) => {
    setUploadedFolderName(rootName)

    const uploaded: UploadedFile[] = []

    for (const entry of entries) {
      const name = entry.path.split('/').pop() || entry.path
      uploaded.push({
        path: entry.path,
        name,
        size: formatFileSize(entry.size),
        language: detectLanguage(name),
      })
    }

    uploaded.sort((a, b) => a.path.localeCompare(b.path))

    // Expand every folder segment by default so the tree opens fully.
    const expanded: Record<string, boolean> = {}
    for (const f of uploaded) {
      const parts = f.path.split('/')
      let prefix = ''
      for (let i = 0; i < parts.length - 1; i++) {
        prefix = prefix ? `${prefix}/${parts[i]}` : parts[i]
        expanded[prefix] = true
      }
    }

    setUploadedFiles(uploaded)
    setActiveIdeFile(uploaded[0]?.path ?? null)
    setExpandedFolders(expanded)
    // Uploaded folders are read-only snapshots; no writable disk handle.
    dirHandleRef.current = null
    // Start a fresh, empty chat for the newly opened folder.
    setAttachedFiles([])
    resetActiveChat()
    setIdeMode(true)
    setShowWelcome(false)
  }

  // Fallback handler for the hidden <input webkitdirectory> (older browsers).
  const handleFolderSelect = (files: FileList | null) => {
    if (!files || files.length === 0) return
    const fileArr = Array.from(files)
    const firstRel = (fileArr[0] as File & { webkitRelativePath?: string }).webkitRelativePath || ''
    const rootName = firstRel.split('/')[0] || 'Uploaded Folder'
    const entries = fileArr.map((file) => {
      const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name
      const relInside = rel.includes('/') ? rel.slice(rel.indexOf('/') + 1) : rel
      return { path: relInside || file.name, size: file.size }
    })
    openFolderInIde(rootName, entries)
  }

  // Preferred folder picker: File System Access API. Shows a normal folder
  // picker + a single permission prompt instead of the browser's
  // "Upload N files to this site?" confirmation.
  const pickFolder = async () => {
    const picker = (window as unknown as { showDirectoryPicker?: (opts?: unknown) => Promise<FileSystemDirectoryHandle> }).showDirectoryPicker
    if (typeof picker !== 'function') {
      // Fallback to the hidden input for browsers without the API.
      folderInputRef.current?.click()
      return
    }
    try {
      const dirHandle = await picker()
      const entries: { path: string; size: number }[] = []

      // Directories that are large and rarely relevant — skip them so a repo
      // with node_modules/venv doesn't load tens of thousands of files.
      const IGNORED_DIRS = new Set([
        'node_modules', '.git', 'venv', '.venv', 'env', '__pycache__', 'dist',
        'build', '.next', 'out', 'coverage', '.cache', '.turbo', 'target',
        '.idea', '.vscode', '.pytest_cache', '.mypy_cache', '.gradle',
      ])
      const MAX_FILES = 3000

      // Recursively walk the directory handle (size is fetched lazily later).
      const walk = async (handle: FileSystemDirectoryHandle, prefix: string): Promise<void> => {
        for await (const child of (handle as any).values()) {
          if (entries.length >= MAX_FILES) return
          const childPath = prefix ? `${prefix}/${child.name}` : child.name
          if (child.kind === 'file') {
            entries.push({ path: childPath, size: 0 })
          } else if (child.kind === 'directory') {
            if (IGNORED_DIRS.has(child.name) || child.name.startsWith('.')) continue
            await walk(child as FileSystemDirectoryHandle, childPath)
          }
        }
      }

      await walk(dirHandle, '')
      dirHandleRef.current = dirHandle
      openFolderInIde(dirHandle.name || 'Project', entries)
    } catch {
      // User cancelled the picker — do nothing.
    }
  }

  // Helper to read file from disk handle if available
  const readFileFromDisk = async (relPath: string): Promise<string | null> => {
    if (!dirHandleRef.current) return null
    try {
      const parts = relPath.replace(/\\/g, '/').split('/').filter(Boolean)
      let dir = dirHandleRef.current
      for (let i = 0; i < parts.length - 1; i++) {
        dir = await dir.getDirectoryHandle(parts[i])
      }
      const fileHandle = await dir.getFileHandle(parts[parts.length - 1])
      const file = await fileHandle.getFile()
      return await file.text()
    } catch (err) {
      console.warn('Could not read file from disk handle:', err)
      return null
    }
  }

  // Open any file in the IDE editor when clicked in the explorer tree or tabs
  const openIdeFile = async (path: string) => {
    setActiveIdeFile(path)
    setOpenEditorTabs((prev) => (prev.includes(path) ? prev : [...prev, path]))
    if (ideViewLayout === 'chat') {
      setIdeViewLayout('split')
    }

    // If content is already in memory, nothing more to fetch
    if (ideFileContents[path]) return

    // Check if uploadedFiles already has the content
    const existing = uploadedFiles.find((f) => f.path === path)
    if (existing?.content) {
      setIdeFileContents((prev) => ({ ...prev, [path]: existing.content! }))
      return
    }

    // Try reading from disk handle
    if (dirHandleRef.current) {
      setIsLoadingFile(true)
      const diskContent = await readFileFromDisk(path)
      setIsLoadingFile(false)
      if (diskContent !== null) {
        setIdeFileContents((prev) => ({ ...prev, [path]: diskContent }))
        return
      }
    }

    // Fetch from backend /agent/kiro/read-file
    try {
      setIsLoadingFile(true)
      const res = await readKiroFile({
        workspace_path: selectedProjectFolder || uploadedFolderName || '',
        relative_path: path,
      })
      if (typeof res?.content === 'string') {
        setIdeFileContents((prev) => ({ ...prev, [path]: res.content }))
      }
    } catch (err) {
      console.warn('Could not fetch file content from backend:', err)
    } finally {
      setIsLoadingFile(false)
    }
  }

  const closeEditorTab = (path: string, e?: React.MouseEvent) => {
    e?.stopPropagation()
    const nextTabs = openEditorTabs.filter((t) => t !== path)
    setOpenEditorTabs(nextTabs)
    if (activeIdeFile === path) {
      setActiveIdeFile(nextTabs[nextTabs.length - 1] ?? null)
    }
  }

  // Open the Create Folder modal and start browsing the local filesystem
  // (via the backend) at the drive roots / home shortcut.
  const openCreateFolderModal = async () => {
    setCreateFolderName('')
    setCreateFolderError(null)
    setCreateFolderBrowsing(null)
    setCreateFolderOpen(true)
    try {
      const start = await browse('')
      // Jump straight into the user's home directory as a sensible default.
      setCreateFolderBrowsing(start.home ? await browse(start.home) : start)
    } catch (err) {
      setCreateFolderError(err instanceof Error ? err.message : 'Failed to browse filesystem')
    }
  }

  // Navigate the backend filesystem browser to a path ('' => drive roots).
  const createFolderNavigate = async (path: string) => {
    setCreateFolderError(null)
    try {
      setCreateFolderBrowsing(await browse(path))
    } catch (err) {
      setCreateFolderError(err instanceof Error ? err.message : 'Cannot open folder')
    }
  }

  // Open a backend-backed project folder (by absolute path) in the IDE view.
  const openBackendFolderInIde = (absPath: string, displayName: string) => {
    dirHandleRef.current = null // backend-backed: no browser disk handle
    setSelectedProjectFolder(absPath)
    try { localStorage.setItem('qagentix.projectFolder', absPath) } catch { /* ignore */ }
    setUploadedFolderName(displayName)
    setUploadedFiles([])
    setActiveIdeFile(null)
    setExpandedFolders({ __root__: true })
    setAttachedFiles([])
    resetActiveChat()
    setCreateFolderName('')
    setCreateFolderOpen(false)
    setCreateFolderBrowsing(null)
    setCreateFolderError(null)
    setIdeMode(true)
    dismissWelcome()
  }

  // Create a new project folder at the chosen local path (via the backend),
  // verifying whether it already exists. If it exists we open it; otherwise we
  // create it. Either way the predefined structure is ensured inside it.
  //
  // Uses the backend filesystem API rather than Chrome's showDirectoryPicker,
  // which blocks folders it deems to contain "system files".
  const handleCreateNewFolder = async () => {
    const name = createFolderName.trim()
    const parent = createFolderBrowsing?.path
    if (!name) { setCreateFolderError('Enter a folder name.'); return }
    if (!parent) { setCreateFolderError('Choose a location first.'); return }

    setCreateFolderBusy(true)
    setCreateFolderError(null)
    try {
      // Verify-and-create: makeDir reports whether the folder already existed.
      const made = await makeDir(parent, name)
      // Ensure the predefined QAgentix structure inside it (idempotent).
      const res = await createStructure(made.path)
      openBackendFolderInIde(res.path, res.name)
    } catch (err) {
      setCreateFolderError(err instanceof Error ? err.message : 'Failed to create folder')
    } finally {
      setCreateFolderBusy(false)
    }
  }

  // Add a new (empty) file to the current IDE project.
  const handleAddNewFile = () => {
    const raw = newFilePath.trim().replace(/^\/+/, '')
    if (!raw) return
    if (uploadedFiles.some((f) => f.path === raw)) {
      setNewFilePath('')
      setNewFilePromptOpen(false)
      setActiveIdeFile(raw)
      return
    }
    const fileName = raw.split('/').pop() || raw
    const next: UploadedFile = {
      path: raw,
      name: fileName,
      size: '0 B',
      language: detectLanguage(fileName),
    }
    const updated = [...uploadedFiles, next].sort((a, b) => a.path.localeCompare(b.path))

    // Expand every folder segment leading to the new file.
    setExpandedFolders((prev) => {
      const exp: Record<string, boolean> = { ...prev, __root__: true }
      const parts = raw.split('/')
      let prefix = ''
      for (let i = 0; i < parts.length - 1; i++) {
        prefix = prefix ? `${prefix}/${parts[i]}` : parts[i]
        exp[prefix] = true
      }
      return exp
    })
    setUploadedFiles(updated)
    setActiveIdeFile(raw)
    setOpenEditorTabs((prev) => (prev.includes(raw) ? prev : [...prev, raw]))
    setIdeFileContents((prev) => ({ ...prev, [raw]: '' }))
    setNewFilePath('')
    setNewFilePromptOpen(false)

    // If the folder lives on disk, create the empty file there too.
    if (dirHandleRef.current) {
      void (async () => {
        try {
          const parts = raw.split('/')
          let dir = dirHandleRef.current!
          for (let i = 0; i < parts.length - 1; i++) {
            dir = await dir.getDirectoryHandle(parts[i], { create: true })
          }
          const fileHandle = await dir.getFileHandle(parts[parts.length - 1], { create: true })
          const writable = await fileHandle.createWritable()
          await writable.close() // create empty file
        } catch {
          /* ignore write errors (permission revoked, etc.) */
        }
      })()
    }
  }

  // Remove attached file before sending
  const handleRemoveAttachment = (id: string) => {
    setAttachedFiles((prev) => prev.filter((f) => f.id !== id))
  }

  // Drag & drop handlers for chat composer
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDraggingOverChat(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDraggingOverChat(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDraggingOverChat(false)
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files)
    }
  }

  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0]

  // Build the IDE file tree once per folder change (not on every keystroke).
  const ideTree = useMemo(() => {
    const root: IdeTreeNode = { name: uploadedFolderName ?? 'root', path: '', dirs: new Map(), files: [] }
    for (const f of uploadedFiles) {
      const parts = f.path.split('/')
      let node = root
      let prefix = ''
      for (let i = 0; i < parts.length - 1; i++) {
        prefix = prefix ? `${prefix}/${parts[i]}` : parts[i]
        if (!node.dirs.has(parts[i])) {
          node.dirs.set(parts[i], { name: parts[i], path: prefix, dirs: new Map(), files: [] })
        }
        node = node.dirs.get(parts[i])!
      }
      node.files.push(f)
    }
    return root
  }, [uploadedFiles, uploadedFolderName])

  // Persist the IDE view so navigating away and back restores the same screen.
  useEffect(() => {
    const snapshot: AgentWsSnapshot = {
      showWelcome,
      ideMode,
      uploadedFolderName,
      uploadedFiles,
      activeIdeFile,
      expandedFolders,
      sessions,
      activeSessionId,
    }
    try {
      sessionStorage.setItem(AGENT_WS_KEY, JSON.stringify(snapshot))
    } catch {
      /* ignore quota / serialization errors */
    }
  }, [showWelcome, ideMode, uploadedFolderName, uploadedFiles, activeIdeFile, expandedFolders, sessions, activeSessionId])

  // Auto-scroll to bottom of chat
  useEffect(() => {
    if (typeof messagesEndRef.current?.scrollIntoView === 'function') {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [activeSession?.messages])

  // Dynamic Prompt Suggestions Engine - Populated when a file is uploaded OR text input is provided
  const dynamicSuggestions = useMemo(() => {
    const hasFiles = attachedFiles.length > 0
    const query = inputText.toLowerCase().trim()
    const rawInput = inputText.trim()

    if (!hasFiles && !rawInput) {
      return []
    }

    // CASE 1: File(s) are uploaded
    if (hasFiles) {
      const primaryFile = attachedFiles[0]
      const fileName = primaryFile.name
      const nameLower = fileName.toLowerCase()
      const ext = fileName.split('.').pop()?.toLowerCase() || ''

      const suggestions = []

      // If user also typed custom instruction
      if (rawInput) {
        suggestions.push({
          id: 'sug-file-custom',
          label: `✨ Focus on "${rawInput.slice(0, 24)}${rawInput.length > 24 ? '...' : ''}" in ${fileName}`,
          prompt: `Based on specification file "${fileName}", specifically focus on: "${rawInput}". Synthesize complete automated Playwright test suite, Page Object Models, and test cases matrix.`,
          badge: 'Tailored Suite',
          color: 'teal',
        })
      }

      if (nameLower.includes('swagger') || nameLower.includes('openapi') || nameLower.includes('api') || ext === 'yaml' || ext === 'yml') {
        suggestions.push(
          {
            id: 'sug-file-api-1',
            label: `⚡ Playwright API Test Suite (.zip) for ${fileName}`,
            prompt: `Generate a complete Playwright TypeScript API test project for ${fileName} with automated request fixtures, status code assertions, and schema checks.`,
            badge: 'Folder (.zip)',
            color: 'teal',
          },
          {
            id: 'sug-file-api-2',
            label: `📋 Synthesize API Test Cases Matrix`,
            prompt: `Extract structured functional and negative test cases covering 200, 400, 401, 403, and 500 status codes from ${fileName} into CSV and JSON.`,
            badge: 'CSV & JSON',
            color: 'blue',
          },
          {
            id: 'sug-file-api-3',
            label: `🛡️ Security & Boundary Tests for Endpoints`,
            prompt: `Generate boundary parameter validation, malformed input rejection, and token authorization expiry tests for endpoints in ${fileName}.`,
            badge: 'Security Suite',
            color: 'purple',
          },
          {
            id: 'sug-file-api-4',
            label: `📦 Zod Schema & Response Contract Assertions`,
            prompt: `Create Playwright tests with strict JSON Schema and contract validation for all REST response payloads defined in ${fileName}.`,
            badge: 'Spec (.spec.ts)',
            color: 'teal',
          }
        )
      } else if (nameLower.includes('auth') || nameLower.includes('login')) {
        suggestions.push(
          {
            id: 'sug-file-auth-1',
            label: `🔒 Full Auth & Session Suite (.zip) for ${fileName}`,
            prompt: `Generate complete Playwright test suite for ${fileName}: valid credentials, incorrect password, invalid email format, account lockout, and session token expiry.`,
            badge: 'Folder (.zip)',
            color: 'teal',
          },
          {
            id: 'sug-file-auth-2',
            label: `🛡️ RBAC Permissions & Privilege Escalation`,
            prompt: `Generate test cases verifying role-based access control (Admin, Test Lead, Viewer) ensuring viewers cannot perform unauthorized actions based on ${fileName}.`,
            badge: 'Security Suite',
            color: 'purple',
          },
          {
            id: 'sug-file-auth-3',
            label: `📊 Export Auth Test Cases Matrix`,
            prompt: `Extract all authentication and session validation test cases from ${fileName} into CSV and JSON matrix with prerequisites and expected outcomes.`,
            badge: 'CSV / JSON',
            color: 'blue',
          }
        )
      } else {
        suggestions.push(
          {
            id: 'sug-file-gen-1',
            label: `⚡ Generate Complete Playwright Test Suite (.zip)`,
            prompt: `Synthesize a modular Playwright TypeScript project bundle with configs, Page Object Models, and spec files based on specification: ${fileName}.`,
            badge: 'Folder (.zip)',
            color: 'teal',
          },
          {
            id: 'sug-file-gen-2',
            label: `🧪 Extract Test Cases Matrix (CSV & JSON)`,
            prompt: `Extract functional, regression, and boundary test cases based on ${fileName} with prerequisites, procedures, and expected results.`,
            badge: 'CSV & JSON',
            color: 'blue',
          },
          {
            id: 'sug-file-gen-3',
            label: `🎯 Smoke & Critical Path Regression Suite`,
            prompt: `Generate automated smoke tests verifying core user journeys and critical workflows defined in ${fileName}.`,
            badge: 'Spec (.spec.ts)',
            color: 'purple',
          },
          {
            id: 'sug-file-gen-4',
            label: `🛡️ Negative & Resilient Error Handling`,
            prompt: `Generate negative test scenarios covering boundary inputs, network timeouts, and fallback banners from ${fileName}.`,
            badge: 'Edge Cases',
            color: 'teal',
          }
        )
      }

      return suggestions
    }

    // CASE 2: Input text is provided (no files attached)
    if (query.includes('login') || query.includes('auth') || query.includes('signin') || query.includes('sign in')) {
      return [
        {
          id: 'sug-auth-1',
          label: '🔒 Playwright Suite: Auth & Session Expiry',
          prompt: 'Generate complete Playwright tests for Authentication: valid login, incorrect password, invalid email format, account lockout, and session token expiry.',
          badge: 'Folder (.zip)',
          color: 'teal',
        },
        {
          id: 'sug-auth-2',
          label: '🛡️ RBAC Permissions & Privilege Escalation Tests',
          prompt: 'Generate test cases verifying role-based access control (Admin, Test Lead, Viewer) ensuring viewers cannot perform unauthorized mutations.',
          badge: 'Script (.spec.ts)',
          color: 'purple',
        },
        {
          id: 'sug-auth-3',
          label: '📊 Export Auth Test Cases to CSV Matrix',
          prompt: 'Create a spreadsheet matrix of authentication test cases with prerequisites, verification steps, and expected results.',
          badge: 'CSV File',
          color: 'blue',
        },
        {
          id: 'sug-auth-4',
          label: '🎯 Self-Healing Locators for Login Form',
          prompt: 'Generate resilient multi-strategy locators (test-id, role, text, css fallback) with assertion timeouts for login authentication.',
          badge: 'POM Class',
          color: 'teal',
        },
      ]
    }

    if (query.includes('api') || query.includes('endpoint') || query.includes('backend') || query.includes('rest')) {
      return [
        {
          id: 'sug-api-1',
          label: '⚡ Hybrid API + UI Playwright Suite',
          prompt: 'Generate Playwright test scripts combining API request fixtures with UI validation assertions for endpoint status and schema integrity.',
          badge: 'Folder (.zip)',
          color: 'teal',
        },
        {
          id: 'sug-api-2',
          label: '📦 Zod Schema & Contract Assertions',
          prompt: 'Generate JSON schema validation test cases ensuring REST API responses strictly match expected payload contracts.',
          badge: 'Script (.spec.ts)',
          color: 'blue',
        },
        {
          id: 'sug-api-3',
          label: '🧪 API Boundary & Error Codes Matrix',
          prompt: 'Generate positive, boundary, and negative test cases covering 200, 400, 401, 403, and 500 error response scenarios.',
          badge: 'CSV / JSON',
          color: 'purple',
        },
      ]
    }

    if (query.includes('checkout') || query.includes('cart') || query.includes('payment') || query.includes('order') || query.includes('billing')) {
      return [
        {
          id: 'sug-pay-1',
          label: '💳 E-Commerce & Checkout Flow Suite',
          prompt: 'Generate end-to-end Playwright tests for shopping cart: add item, update quantity, coupon code application, and payment gateway simulation.',
          badge: 'Folder (.zip)',
          color: 'teal',
        },
        {
          id: 'sug-pay-2',
          label: '🛡️ Payment Boundary & Fraud Prevention Cases',
          prompt: 'Generate boundary test cases for expired cards, invalid CVV, insufficient funds, and network timeout handling.',
          badge: 'CSV / JSON',
          color: 'blue',
        },
        {
          id: 'sug-pay-3',
          label: '⚡ Order Confirmation & Receipt Verification',
          prompt: 'Synthesize tests asserting order creation, email invoice dispatch simulation, and customer dashboard transaction history.',
          badge: 'Spec (.spec.ts)',
          color: 'purple',
        },
      ]
    }

    // Default suggestions for any other typed text
    return [
      {
        id: 'sug-typed-1',
        label: `⚡ Generate Full Test Suite for "${rawInput.slice(0, 26)}${rawInput.length > 26 ? '...' : ''}"`,
        prompt: `Based on "${rawInput}", generate a complete modular Playwright test project folder with configs, pages, and specs ready to download.`,
        badge: 'Folder (.zip)',
        color: 'teal',
      },
      {
        id: 'sug-typed-2',
        label: `🧪 Synthesize Test Cases Matrix`,
        prompt: `Extract functional and regression test cases with step-by-step procedures and expected outcomes based on: ${rawInput}`,
        badge: 'CSV / JSON',
        color: 'blue',
      },
      {
        id: 'sug-typed-3',
        label: `🎯 Generate Self-Healing Locators & Playwright Script`,
        prompt: `Generate automated Playwright script using resilient multi-strategy locators and assertion timeouts for: ${rawInput}`,
        badge: 'Script (.spec.ts)',
        color: 'purple',
      },
      {
        id: 'sug-typed-4',
        label: `🛡️ Edge Cases & Boundary Validation`,
        prompt: `Synthesize negative test scenarios, network latency degradation handling, and boundary checks for: ${rawInput}`,
        badge: 'Security / Edge',
        color: 'teal',
      },
    ]
  }, [inputText, attachedFiles])

  // ---------------------------------------------------------------------------
  // PROMPT OPTIMIZER ENGINE
  // Scores the current prompt (0-100) across clarity signals and can rewrite a
  // weak prompt into a structured, high-signal instruction for the AI.
  // ---------------------------------------------------------------------------
  const promptAnalysis = useMemo(() => {
    const text = inputText.trim()
    const hasFiles = attachedFiles.length > 0
    const words = text ? text.split(/\s+/).filter(Boolean) : []
    const lower = text.toLowerCase()

    // Signal keywords that make a QA/test prompt actionable.
    const actionWords = ['generate', 'create', 'write', 'build', 'test', 'validate', 'verify', 'extract', 'synthesize', 'automate']
    const artifactWords = ['playwright', 'test case', 'test cases', 'script', 'page object', 'pom', 'csv', 'json', 'suite', 'locator', 'assertion', 'scenario']
    const detailWords = ['boundary', 'negative', 'edge', 'positive', 'regression', 'smoke', 'security', 'status code', 'schema', 'coverage', 'priority']

    const has = (list: string[]) => list.some((k) => lower.includes(k))

    const checks = [
      { id: 'length', label: 'Enough detail (12+ words)', ok: words.length >= 12, weight: 25 },
      { id: 'action', label: 'Clear action verb', ok: has(actionWords), weight: 20 },
      { id: 'artifact', label: 'Target artifact named (Playwright, test cases, CSV...)', ok: has(artifactWords), weight: 20 },
      { id: 'detail', label: 'Scenario depth (boundary, negative, coverage...)', ok: has(detailWords), weight: 20 },
      { id: 'context', label: 'Context provided (attachment or specifics)', ok: hasFiles || words.length >= 20, weight: 15 },
    ]

    const score = text
      ? checks.reduce((sum, c) => sum + (c.ok ? c.weight : 0), 0)
      : 0

    const tier = score >= 80 ? 'Strong' : score >= 50 ? 'Good' : 'Weak'
    const missing = checks.filter((c) => !c.ok)

    return { score, tier, checks, missing, words: words.length }
  }, [inputText, attachedFiles])

  // Rewrite the current prompt into a richer, structured instruction.
  const handleOptimizePrompt = () => {
    const base = inputText.trim()
    if (!base) return

    const fileRef =
      attachedFiles.length > 0
        ? ` Use the attached specification "${attachedFiles[0].name}" as the source of truth.`
        : ''

    const optimized = [
      `Act as a senior QA automation engineer. Based on the following requirement: "${base}".${fileRef}`,
      '',
      'Deliver:',
      '1. A complete Playwright (TypeScript) test suite using the Page Object Model.',
      '2. A test cases matrix covering positive, negative, boundary, and edge scenarios with priority and expected results.',
      '3. Resilient multi-strategy locators (test-id, role, text, CSS fallback) with assertion timeouts.',
      '',
      'Constraints: keep tests modular and runnable, export the matrix as CSV and JSON, and note any assumptions.',
    ].join('\n')

    setInputText(optimized)
    // Refocus the composer so the user sees the rewritten prompt.
    textareaRef.current?.focus()
  }

  // Auto-open drop-up when new suggestions arrive
  useEffect(() => {
    if (dynamicSuggestions.length > 0) {
      setIsDropUpOpen(true)
    } else {
      setIsDropUpOpen(false)
    }
  }, [dynamicSuggestions.length])

  // Close drop-up when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropUpRef.current && !dropUpRef.current.contains(e.target as unknown as HTMLElement)) {
        setIsDropUpOpen(false)
      }
    }
    if (isDropUpOpen) {
      document.addEventListener('mousedown', handleClickOutside)
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [isDropUpOpen])

  // Create New Chat Session
  const handleCreateNewChat = () => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'New Test Generation Chat',
      project: activeProject?.name || 'Rammas',
      createdAt: 'Just now',
      messages: [],
    }
    setSessions((prev) => [newSession, ...prev])
    setActiveSessionId(newSession.id)
    setInputText('')
    setAttachedFiles([])
    // Prompt the user to select a local project folder for this new chat.
    setFolderPickerKey((k) => k + 1)
  }

  // Which session's 3-dot menu is open (by id), and inline-rename state.
  const [openMenuId, setOpenMenuId] = useState<string | null>(null)
  const [renamingId, setRenamingId] = useState<string | null>(null)
  const [renameValue, setRenameValue] = useState('')

  const handleStartRename = (sess: ChatSession) => {
    setOpenMenuId(null)
    setRenamingId(sess.id)
    setRenameValue(sess.title)
  }

  const handleCommitRename = (id: string) => {
    const title = renameValue.trim()
    if (title) {
      setSessions((prev) => prev.map((s) => (s.id === id ? { ...s, title } : s)))
    }
    setRenamingId(null)
    setRenameValue('')
  }

  const handleDeleteSession = (id: string) => {
    setOpenMenuId(null)
    setSessions((prev) => {
      const remaining = prev.filter((s) => s.id !== id)
      // Keep at least one session so the workspace is never empty.
      if (remaining.length === 0) {
        const fresh: ChatSession = {
          id: `session-${Date.now()}`,
          title: 'New Test Generation Chat',
          project: activeProject?.name || 'Rammas',
          createdAt: 'Just now',
          messages: [],
        }
        setActiveSessionId(fresh.id)
        return [fresh]
      }
      // If the deleted session was active, switch to the first remaining one.
      if (id === activeSessionId) {
        setActiveSessionId(remaining[0].id)
      }
      return remaining
    })
  }

  // Download entire folder as ZIP
  const handleDownloadZip = async (bundle: GeneratedBundle) => {
    try {
      const zip = new JSZip()
      const folderName = bundle.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'qagentix-suite'
      const rootFolder = zip.folder(folderName) || zip

      bundle.files.forEach((file) => {
        rootFolder.file(file.path, file.content)
      })

      const blob = await zip.generateAsync({ type: 'blob' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${folderName}.zip`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (err) {
      console.error('Failed to generate ZIP:', err)
    }
  }

  // Download individual file
  const handleDownloadSingleFile = (filename: string, content: string, mime: string = 'text/plain') => {
    const blob = new Blob([content], { type: mime })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Copy code to clipboard
  const handleCopyCode = (content: string, id: string) => {
    navigator.clipboard.writeText(content)
    setCopiedFileId(id)
    setTimeout(() => setCopiedFileId(null), 2000)
  }

  // Submit User Message & Trigger Generation
  const handleSendMessage = async (customPromptText?: string) => {
    const rawText = customPromptText !== undefined ? customPromptText : inputText
    const hasFiles = attachedFiles.length > 0
    if (!rawText.trim() && !hasFiles) return

    const filesToSend = [...attachedFiles]
    const promptToSend = rawText.trim()
      ? rawText.trim()
      : `Generate automated Playwright test suite for attached specification: ${filesToSend.map((f) => f.name).join(', ')}`

    const userMsgId = `user-msg-${Date.now()}`
    const assistantMsgId = `ai-msg-${Date.now()}`

    const userMessage: ChatMessage = {
      id: userMsgId,
      role: 'user',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      content: promptToSend,
      attachments: filesToSend.length > 0 ? filesToSend : undefined,
    }

    const activeModelLabel = currentModelObj.name

    const placeholderAiMessage: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      content: filesToSend.length > 0
        ? `Connecting to Kiro IDE Agent (${activeModelLabel}) & analyzing specifications (${filesToSend.map((f) => f.name).join(', ')})...`
        : `Connecting to Kiro IDE Agent Harness (${activeModelLabel})...`,
      isGenerating: true,
      generationStep: 1,
    }

    // Update active session title if it's first message or generic
    const updatedTitle =
      activeSession.messages.length === 0
        ? (rawText.trim() ? rawText.trim().slice(0, 32) : filesToSend[0]?.name.slice(0, 32) || 'Uploaded Specs')
        : activeSession.title

    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            title: updatedTitle,
            messages: [...s.messages, userMessage, placeholderAiMessage],
          }
        }
        return s
      })
    )

    setInputText('')
    setAttachedFiles([])

    // Update to step 2: Connecting to Kiro
    setTimeout(() => {
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: s.messages.map((m) => (m.id === assistantMsgId ? { ...m, generationStep: 2 } : m)),
            }
          }
          return s
        })
      )
    }, 250)

    try {
      // Execute prompt agentically via backend Kiro integration with selected model
      const kiroResult = await executeKiroTask({
        prompt: promptToSend,
        workspace_path: uploadedFolderName || undefined,
        document_name: filesToSend[0]?.name,
        session_id: activeSessionId,
        model: selectedModel,
      })

      // Advance to step 3: Synthesis & placement
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: s.messages.map((m) => (m.id === assistantMsgId ? { ...m, generationStep: 3 } : m)),
            }
          }
          return s
        })
      )

      // Check folder and place generated artifacts into project folder
      if (kiroResult.artifacts && kiroResult.artifacts.length > 0) {
        const newUploaded: UploadedFile[] = []

        for (const art of kiroResult.artifacts) {
          const relPath = art.relative_path.replace(/\\/g, '/')
          const fileName = relPath.split('/').pop() || relPath
          const fileContent = art.content || ''
          const fileSize = fileContent ? formatFileSize(new Blob([fileContent]).size) : '1.2 KB'

          newUploaded.push({
            path: relPath,
            name: fileName,
            size: fileSize,
            language: detectLanguage(fileName),
            content: fileContent,
          })

          // If folder is mounted via File System Access API (dirHandleRef), write directly to disk!
          if (dirHandleRef.current) {
            void (async () => {
              try {
                const parts = relPath.split('/')
                let dir = dirHandleRef.current!
                for (let i = 0; i < parts.length - 1; i++) {
                  dir = await dir.getDirectoryHandle(parts[i], { create: true })
                }
                const fileHandle = await dir.getFileHandle(parts[parts.length - 1], { create: true })
                const writable = await fileHandle.createWritable()
                await writable.write(fileContent)
                await writable.close()
              } catch (diskErr) {
                console.warn('Could not write artifact to local disk handle:', diskErr)
              }
            })()
          }
        }

        // Merge with existing uploadedFiles without duplicates
        setUploadedFiles((prev) => {
          const existingMap = new Map(prev.map((f) => [f.path, f]))
          for (const item of newUploaded) {
            existingMap.set(item.path, item)
          }
          return Array.from(existingMap.values()).sort((a, b) => a.path.localeCompare(b.path))
        })

        // Also store in ideFileContents cache
        const newContents: Record<string, string> = {}
        for (const art of kiroResult.artifacts) {
          if (art.content) {
            newContents[art.relative_path.replace(/\\/g, '/')] = art.content
          }
        }
        setIdeFileContents((prev) => ({ ...prev, ...newContents }))

        // Expand folder segments leading to the new files
        setExpandedFolders((prev) => {
          const updated: Record<string, boolean> = { ...prev, __root__: true }
          for (const item of newUploaded) {
            const parts = item.path.split('/')
            let prefix = ''
            for (let i = 0; i < parts.length - 1; i++) {
              prefix = prefix ? `${prefix}/${parts[i]}` : parts[i]
              updated[prefix] = true
            }
          }
          return updated
        })

        // Open main test spec in the IDE Monaco Editor
        const mainSpec = newUploaded.find((f) => f.path.endsWith('.spec.ts')) || newUploaded[0]
        if (mainSpec) {
          setActiveIdeFile(mainSpec.path)
          setOpenEditorTabs((prev) => (prev.includes(mainSpec.path) ? prev : [...prev, mainSpec.path]))
        }
      }

      // Build dynamic bundle tailored to the prompt or uploaded specification
      const promptLower = promptToSend.toLowerCase()
      const subject =
        filesToSend.length > 0
          ? filesToSend[0].name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ')
          : promptLower.includes('auth') || promptLower.includes('login')
          ? 'Authentication & Access Control'
          : promptLower.includes('api') || promptLower.includes('endpoint')
          ? 'API & Schema Validation'
          : promptLower.includes('cart') || promptLower.includes('checkout')
          ? 'Shopping Cart & Checkout Flow'
          : 'Application Quality Suite'

      // Extract test cases from kiro artifacts if available, or generate default structured cases
      let parsedTestCases: any[] = []
      const tcArtifact = kiroResult.artifacts?.find((a) => a.relative_path.includes('testcases.json') || a.relative_path.includes('test-cases.json'))
      if (tcArtifact?.content) {
        try {
          parsedTestCases = JSON.parse(tcArtifact.content)
        } catch {
          /* fallback */
        }
      }

      const bundleTestCases = parsedTestCases.length > 0 ? parsedTestCases : [
        {
          id: 'TC-101',
          title: `Verify ${subject} primary workflow execution with valid inputs`,
          description: `Executes core happy path flow for ${subject} and verifies 200 OK status.`,
          steps: [
            `Navigate to target application root`,
            `Trigger ${subject} primary action container`,
            `Supply valid test fixtures`,
            `Assert success confirmation toast appears`,
          ],
          expectedResult: `System records transaction state and renders expected view.`,
          priority: 'High',
          category: 'Smoke',
        },
        {
          id: 'TC-102',
          title: `Verify ${subject} validation rules reject invalid and malformed parameters`,
          description: `Ensures client-side and server-side boundaries reject illegal characters.`,
          steps: [
            `Trigger action with malformed input: "###<script>alert(1)</script>###"`,
            `Attempt submission`,
            `Verify inline validation error message is rendered`,
          ],
          expectedResult: `Input is rejected with validation banner; no unhandled exceptions.`,
          priority: 'High',
          category: 'Boundary',
        },
        {
          id: 'TC-103',
          title: `Filter persistence and state preservation during navigation`,
          description: `Validates query parameters and table state across grid navigation.`,
          steps: [
            `Apply custom filter criteria on view`,
            `Navigate through workflow`,
            `Verify filter badge remains selected`,
          ],
          expectedResult: `Context retains active settings across boundaries.`,
          priority: 'Medium',
          category: 'Regression',
        },
        {
          id: 'TC-104',
          title: `Negative case: Network timeout fallback and resilient retry`,
          description: `Tests simulated network latency or degraded API responses.`,
          steps: [
            `Simulate slow network latency via route throttle`,
            `Observe loading spinner state`,
            `Verify timeout boundary does not crash page layout`,
          ],
          expectedResult: `UI shows retry button gracefully without breaking DOM.`,
          priority: 'Medium',
          category: 'Boundary',
        },
        {
          id: 'TC-105',
          title: `Security check: RBAC permission restrictions on restricted actions`,
          description: `Ensures non-admin roles cannot perform administrative mutations.`,
          steps: [
            `Impersonate viewer test role`,
            `Verify action buttons have disabled attribute`,
            `Attempt direct route access and verify redirect`,
          ],
          expectedResult: `Unauthorized action is blocked with 403 Forbidden alert.`,
          priority: 'High',
          category: 'Security',
        },
      ]

      const bundleFiles = (kiroResult.artifacts && kiroResult.artifacts.length > 0)
        ? kiroResult.artifacts.map((a) => ({
            path: a.relative_path,
            name: a.relative_path.split('/').pop() || a.relative_path,
            language: detectLanguage(a.relative_path),
            description: `Generated ${a.category} placed in ${uploadedFolderName || 'project folder'}`,
            content: a.content || '',
          }))
        : [
            {
              path: `Scripts/${subject.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.spec.ts`,
              name: `${subject.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.spec.ts`,
              language: 'typescript',
              description: 'Main Playwright test spec covering positive and negative scenarios',
              content: `import { test, expect } from '@playwright/test';\n\ntest.describe('${subject}', () => {\n  test('TC-101: Primary flow', async ({ page }) => {\n    await page.goto('/');\n    await expect(page.locator('body')).toBeVisible();\n  });\n});`,
            },
          ]

      const generatedBundle: GeneratedBundle = {
        title: `${subject} - Playwright Quality Suite`,
        description: `Automated test cases and Playwright TypeScript scripts synthesized by Kiro Agent (Gemini 3.8 Flash Medium) and placed in folder ${uploadedFolderName || 'workspace'}.`,
        summary: {
          totalCases: bundleTestCases.length,
          positiveCount: Math.ceil(bundleTestCases.length * 0.6),
          negativeCount: Math.floor(bundleTestCases.length * 0.2),
          edgeCount: Math.floor(bundleTestCases.length * 0.2),
          coverage: '99.2%',
        },
        testCases: bundleTestCases,
        files: bundleFiles,
      }

      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: s.messages.map((m) =>
                m.id === assistantMsgId
                  ? {
                      ...m,
                      isGenerating: false,
                      content: kiroResult.response || `I have connected to Kiro IDE Agent (Gemini 3.8 Flash Medium) and synthesized **${bundleTestCases.length} automated test cases** and placed ${bundleFiles.length} files directly into folder **${uploadedFolderName || 'project folder'}**. You can inspect them in the explorer tree on the left, edit them in the editor, or download the full suite.`,
                      bundle: (kiroResult.artifacts && kiroResult.artifacts.length > 0) ? generatedBundle : undefined,
                    }
                  : m
              ),
            }
          }
          return s
        })
      )
    } catch (err: any) {
      console.warn('Kiro task execution failed:', err)

      // Fallback synthesis so user is never blocked
      const promptLower = promptToSend.toLowerCase()
      const subject =
        filesToSend.length > 0
          ? filesToSend[0].name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ')
          : promptLower.includes('auth') || promptLower.includes('login')
          ? 'Authentication & Access Control'
          : 'Application Quality Suite'

      const fallbackBundle: GeneratedBundle = {
        title: `${subject} - Playwright Suite`,
        description: `Synthesized test cases and scripts for ${subject}.`,
        summary: { totalCases: 5, positiveCount: 3, negativeCount: 1, edgeCount: 1, coverage: '98.5%' },
        testCases: [
          {
            id: 'TC-101',
            title: `Verify ${subject} primary workflow`,
            description: `Core happy path for ${subject}.`,
            steps: ['Navigate to application root', 'Execute workflow', 'Assert success toast'],
            expectedResult: 'System processes workflow successfully.',
            priority: 'High',
            category: 'Smoke',
          },
          {
            id: 'TC-102',
            title: `Validate boundary inputs for ${subject}`,
            description: 'Ensures invalid characters are rejected.',
            steps: ['Input invalid payload', 'Verify validation feedback'],
            expectedResult: 'Input rejected gracefully.',
            priority: 'High',
            category: 'Boundary',
          },
        ],
        files: [
          {
            path: `Scripts/${subject.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.spec.ts`,
            name: `${subject.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.spec.ts`,
            language: 'typescript',
            description: 'Playwright spec',
            content: `import { test, expect } from '@playwright/test';\n\ntest.describe('${subject}', () => {\n  test('TC-101: Primary flow', async ({ page }) => {\n    await page.goto('/');\n    await expect(page.locator('body')).toBeVisible();\n  });\n});`,
          },
        ],
      }

      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: s.messages.map((m) =>
                m.id === assistantMsgId
                  ? {
                      ...m,
                      isGenerating: false,
                      content: `I have synthesized **${fallbackBundle.testCases.length} automated test cases** for **${subject}** and prepared the Playwright test suite. Note: Backend agent bridge reported: ${err.message || 'connection error'}.`,
                      bundle: fallbackBundle,
                    }
                  : m
              ),
            }
          }
          return s
        })
      )
    }
  }

  // Handle enter key in textarea
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // VS Code-style Welcome landing shown first when entering the Agent Workspace.
  if (showWelcome) {
    const startActions = [
      { icon: FolderOpen, label: 'Upload Folder...', hint: 'Pick a folder from your computer to upload', onClick: () => void pickFolder() },
      { icon: FolderPlus, label: 'Create Folder...', hint: 'Choose a local path and create a new project folder', onClick: () => void openCreateFolderModal() },
    ]

    return (
      <div className="relative flex h-full min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto bg-white px-8 py-10 text-slate-900 dark:bg-slate-950 dark:text-slate-100 sm:px-14 lg:px-20">
        <div className="flex w-full max-w-md flex-col items-center">
          {/* Heading */}
          <div className="mb-10 flex flex-col items-center gap-3 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-600 text-lg font-bold text-white shadow-lg shadow-teal-600/20">Q</div>
            <div>
              <h1 className="text-3xl font-semibold tracking-tight">QAgentix Agent Workspace</h1>
              <p className="text-sm text-slate-500 dark:text-slate-400">AI test generation, evolved</p>
            </div>
          </div>

          <div className="w-full">
            <ul className="flex flex-col items-center gap-3">
              {startActions.map((a) => {
                const Icon = a.icon
                return (
                  <li key={a.label} className="w-full">
                    <button
                      type="button"
                      onClick={a.onClick}
                      title={a.hint}
                      className="group flex w-full items-center justify-center gap-3 rounded-xl border border-slate-200 bg-slate-50/70 px-4 py-3 text-sm font-semibold text-teal-700 transition hover:border-teal-300 hover:bg-teal-50 dark:border-slate-800 dark:bg-slate-900/60 dark:text-teal-400 dark:hover:border-teal-800 dark:hover:bg-teal-950/40"
                    >
                      <Icon className="h-5 w-5 shrink-0 text-teal-600 dark:text-teal-400" />
                      <span>{a.label}</span>
                    </button>
                  </li>
                )
              })}
            </ul>
          </div>

          {/* Hidden local folder picker: lets the user upload an entire folder
              from their computer (reads all files in-browser). */}
          <input
            ref={(el) => {
              folderInputRef.current = el
              if (el) {
                el.setAttribute('webkitdirectory', '')
                el.setAttribute('directory', '')
              }
            }}
            type="file"
            multiple
            onChange={(e) => {
              const picked = e.target.files && e.target.files.length > 0
              handleFolderSelect(e.target.files)
              e.target.value = ''
              if (picked) dismissWelcome()
            }}
            className="hidden"
            aria-label="Upload folder from computer"
          />
        </div>

        {/* Create Folder modal — choose a local path (via backend), verify
            existence, then create or open the folder. */}
        {createFolderOpen && (() => {
          const closeCreate = () => {
            if (createFolderBusy) return
            setCreateFolderOpen(false)
            setCreateFolderBrowsing(null)
            setCreateFolderError(null)
          }
          const b = createFolderBrowsing
          const nameTrim = createFolderName.trim()
          // Does a folder with this name already exist at the current location?
          const existing = !!b && !!nameTrim && b.folders.some((f) => f.name.toLowerCase() === nameTrim.toLowerCase())
          return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
            <div className="flex max-h-[85vh] w-full max-w-lg flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
              <div className="mb-3 flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-600/10 text-teal-600 dark:bg-teal-950 dark:text-teal-400">
                  <FolderPlus className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-800 dark:text-slate-100">Create new folder</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Choose a location on your system, then name your project</div>
                </div>
              </div>

              {/* Location toolbar: current path + up + drive/home shortcuts */}
              <div className="mb-2 flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => void createFolderNavigate(b?.parent ?? '')}
                  disabled={!b}
                  title="Up one level"
                  className="rounded-md border border-slate-300 px-2 py-1 text-[11px] font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  ↑ Up
                </button>
                <div className="min-w-0 flex-1 truncate rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                  {b?.path || 'This PC'}
                </div>
              </div>
              {b && b.drives.length > 0 && (
                <div className="mb-2 flex flex-wrap gap-1.5">
                  {b.drives.map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => void createFolderNavigate(d)}
                      className="rounded-md border border-slate-200 px-2 py-0.5 text-[10px] font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                    >
                      {d}
                    </button>
                  ))}
                  {b.home && (
                    <button
                      type="button"
                      onClick={() => void createFolderNavigate(b.home)}
                      className="rounded-md border border-slate-200 px-2 py-0.5 text-[10px] font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                    >
                      🏠 Home
                    </button>
                  )}
                </div>
              )}

              {/* Folder list at the current location */}
              <div className="mb-3 min-h-[8rem] flex-1 overflow-y-auto rounded-lg border border-slate-200 bg-slate-50/60 p-1 dark:border-slate-700 dark:bg-slate-800/40">
                {!b ? (
                  <div className="p-3 text-[11px] text-slate-400">Loading…</div>
                ) : b.folders.length === 0 ? (
                  <div className="p-3 text-[11px] text-slate-400">No subfolders here. You can create your folder at this location.</div>
                ) : (
                  b.folders.map((f) => (
                    <button
                      key={f.path}
                      type="button"
                      onDoubleClick={() => void createFolderNavigate(f.path)}
                      onClick={() => setCreateFolderName(f.name)}
                      title="Double-click to open, click to use this name"
                      className="flex w-full items-center gap-2 rounded-md px-2 py-1 text-left text-[12px] text-slate-700 hover:bg-teal-50 dark:text-slate-200 dark:hover:bg-teal-950/40"
                    >
                      <FolderOpen className="h-3.5 w-3.5 shrink-0 text-teal-600" />
                      <span className="truncate">{f.name}</span>
                    </button>
                  ))
                )}
              </div>

              {/* New folder name */}
              <input
                autoFocus
                value={createFolderName}
                onChange={(e) => { setCreateFolderName(e.target.value); setCreateFolderError(null) }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') void handleCreateNewFolder()
                  if (e.key === 'Escape') closeCreate()
                }}
                placeholder="New folder name, e.g. my-test-project"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />

              {existing && (
                <div className="mt-2 rounded-md bg-amber-50 px-2.5 py-1.5 text-[11px] text-amber-700 dark:bg-amber-950/40 dark:text-amber-300">
                  A folder named “{nameTrim}” already exists here — it will be opened instead of created.
                </div>
              )}
              {createFolderError && (
                <div className="mt-2 rounded-md bg-red-50 px-2.5 py-1.5 text-[11px] text-red-700 dark:bg-red-950/40 dark:text-red-300">
                  {createFolderError}
                </div>
              )}

              <div className="mt-4 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={closeCreate}
                  disabled={createFolderBusy}
                  className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => void handleCreateNewFolder()}
                  disabled={!nameTrim || !b?.path || createFolderBusy}
                  className="rounded-lg bg-teal-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-teal-700 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {createFolderBusy ? 'Working…' : existing ? 'Open Existing' : 'Create & Open'}
                </button>
              </div>
            </div>
          </div>
          )
        })()}
      </div>
    )
  }

  // ===========================================================================
  // VS CODE-STYLE IDE VIEW
  // Renders after a folder is uploaded or created: file tree (left) + chat (center).
  // ===========================================================================
  if (ideMode) {
    const activeFile = uploadedFiles.find((f) => f.path === activeIdeFile) || uploadedFiles[0] || null

    const fileIconFor = (name: string) => {
      if (/\.(ts|tsx|js|jsx)$/.test(name)) return <FileCode className="h-3.5 w-3.5 shrink-0 text-teal-500" />
      if (/\.(csv|xlsx)$/.test(name)) return <FileSpreadsheet className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
      if (/\.(json)$/.test(name)) return <FileCode className="h-3.5 w-3.5 shrink-0 text-amber-500" />
      if (/\.feature$/.test(name)) return <FileCode className="h-3.5 w-3.5 shrink-0 text-purple-500" />
      if (/\.md$/.test(name)) return <FileText className="h-3.5 w-3.5 shrink-0 text-blue-400" />
      return <FileText className="h-3.5 w-3.5 shrink-0 text-slate-400" />
    }

    const getMonacoLanguage = (name: string): string => {
      const lower = name.toLowerCase()
      if (/\.(ts|tsx)$/.test(lower)) return 'typescript'
      if (/\.(js|jsx)$/.test(lower)) return 'javascript'
      if (/\.py$/.test(lower)) return 'python'
      if (/\.json$/.test(lower)) return 'json'
      if (/\.md$/.test(lower)) return 'markdown'
      if (/\.feature$/.test(lower)) return 'markdown'
      if (/\.html$/.test(lower)) return 'html'
      if (/\.css$/.test(lower)) return 'css'
      if (/\.(yaml|yml)$/.test(lower)) return 'yaml'
      if (/\.sql$/.test(lower)) return 'sql'
      if (/\.sh$/.test(lower)) return 'shell'
      return 'plaintext'
    }

    const displayTabs = openEditorTabs.length > 0
      ? openEditorTabs
      : (activeFile ? [activeFile.path] : [])

    // Tree is memoized above (ideTree) so it isn't rebuilt on every keystroke.
    const root = ideTree

    const renderTree = (node: IdeTreeNode, depth: number): ReactNode => {
      const dirs = Array.from(node.dirs.values()).sort((a, b) => a.name.localeCompare(b.name))
      const files = [...node.files].sort((a, b) => a.name.localeCompare(b.name))
      return (
        <>
          {dirs.map((dir) => {
            const isOpen = expandedFolders[dir.path] ?? false
            return (
              <div key={dir.path}>
                <button
                  type="button"
                  onClick={() => setExpandedFolders((prev) => ({ ...prev, [dir.path]: !isOpen }))}
                  style={{ paddingLeft: `${depth * 12 + 8}px` }}
                  className="flex w-full items-center gap-1 py-1 pr-2 text-left text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  <ChevronDown className={`h-3 w-3 shrink-0 text-slate-400 transition-transform ${isOpen ? '' : '-rotate-90'}`} />
                  {isOpen ? <FolderOpen className="h-3.5 w-3.5 shrink-0 text-amber-500" /> : <Folder className="h-3.5 w-3.5 shrink-0 text-amber-500" />}
                  <span className="truncate">{dir.name}</span>
                </button>
                {isOpen && renderTree(dir, depth + 1)}
              </div>
            )
          })}
          {files.map((f) => {
            const isActive = f.path === activeFile?.path
            return (
              <button
                key={f.path}
                type="button"
                onClick={() => openIdeFile(f.path)}
                title={f.path}
                style={{ paddingLeft: `${depth * 12 + 22}px` }}
                className={`flex w-full items-center gap-1.5 py-1 pr-2 text-left text-xs transition ${
                  isActive
                    ? 'bg-teal-50 font-semibold text-teal-900 dark:bg-teal-950/60 dark:text-teal-200'
                    : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                {fileIconFor(f.name)}
                <span className="truncate">{f.name}</span>
              </button>
            )
          })}
        </>
      )
    }

    return (
      <div className="relative flex h-full min-h-0 flex-1 flex-col overflow-hidden bg-slate-50 dark:bg-slate-950">
        <div className="flex min-h-0 flex-1">
          {/* LEFT: File Explorer */}
          {!isSidebarOpen ? (
            /* Collapsed rail */
            <div className="flex w-10 shrink-0 flex-col items-center gap-1 border-r border-slate-200 bg-white py-2 dark:border-slate-800 dark:bg-slate-900">
              <button
                type="button"
                onClick={() => setIsSidebarOpen(true)}
                className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-teal-600 dark:text-slate-400 dark:hover:bg-slate-800"
                title="Expand Explorer"
                aria-label="Expand Explorer"
              >
                <FolderOpen className="h-4 w-4" />
              </button>
            </div>
          ) : (
          <aside className="flex w-60 shrink-0 flex-col border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between px-3 py-2">
              <span className="text-[11px] font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Explorer</span>
              <div className="flex items-center gap-0.5">
                <button
                  type="button"
                  onClick={() => { setNewFilePath(''); setNewFilePromptOpen(true) }}
                  className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-teal-600 dark:hover:bg-slate-800"
                  title="New file"
                >
                  <Plus className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => void pickFolder()}
                  className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-teal-600 dark:hover:bg-slate-800"
                  title="Open a different folder"
                >
                  <Upload className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setIsSidebarOpen(false)}
                  className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-teal-600 dark:hover:bg-slate-800"
                  title="Collapse Explorer"
                  aria-label="Collapse Explorer"
                >
                  <ChevronDown className="h-3.5 w-3.5 rotate-90" />
                </button>
              </div>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto pb-2">
              {/* Root folder header */}
              <button
                type="button"
                onClick={() => setExpandedFolders((prev) => ({ ...prev, __root__: !(prev.__root__ ?? true) }))}
                className="flex w-full items-center gap-1 px-2 py-1 text-left text-xs font-bold text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <ChevronDown className={`h-3 w-3 shrink-0 text-slate-400 transition-transform ${(expandedFolders.__root__ ?? true) ? '' : '-rotate-90'}`} />
                <span className="truncate uppercase tracking-wide">{uploadedFolderName ?? 'Project'}</span>
              </button>

              {/* Inline new-file input */}
              {newFilePromptOpen && (
                <div className="px-2 py-1.5">
                  <input
                    autoFocus
                    value={newFilePath}
                    onChange={(e) => setNewFilePath(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleAddNewFile()
                      if (e.key === 'Escape') { setNewFilePath(''); setNewFilePromptOpen(false) }
                    }}
                    onBlur={() => { if (!newFilePath.trim()) setNewFilePromptOpen(false) }}
                    placeholder="path/to/file.ts"
                    className="w-full rounded-md border border-teal-400 bg-white px-2 py-1 text-xs text-slate-900 focus:outline-none dark:bg-slate-800 dark:text-white"
                    aria-label="New file path"
                  />
                </div>
              )}

              {(expandedFolders.__root__ ?? true) && (
                <div>{renderTree(root, 1)}</div>
              )}
              {uploadedFiles.length === 0 && !newFilePromptOpen && (
                <div className="px-3 py-4 text-center">
                  <p className="text-[11px] text-slate-400">This folder is empty.</p>
                  <button
                    type="button"
                    onClick={() => { setNewFilePath(''); setNewFilePromptOpen(true) }}
                    className="mt-2 inline-flex items-center gap-1 rounded-md border border-dashed border-slate-300 px-2 py-1 text-[11px] font-medium text-teal-600 hover:border-teal-400 hover:bg-teal-50 dark:border-slate-700 dark:text-teal-400 dark:hover:bg-teal-950/40"
                  >
                    <Plus className="h-3 w-3" /> New file
                  </button>
                </div>
              )}
            </div>
          </aside>
          )}

          {/* CENTER: Monaco Code Editor (when layout is 'split' or 'editor') */}
          {(ideViewLayout === 'split' || ideViewLayout === 'editor') && (
            <section className="flex min-w-0 flex-1 flex-col bg-[#1e1e1e] border-r border-slate-200 dark:border-slate-800">
              {/* Tab Strip */}
              <div className="flex h-9 shrink-0 items-center border-b border-slate-200 bg-slate-100/90 dark:border-slate-800 dark:bg-slate-950 overflow-x-auto scrollbar-none">
                <div className="flex items-center h-full min-w-0">
                  {displayTabs.map((tabPath) => {
                    const isTabActive = tabPath === activeFile?.path
                    const tabName = tabPath.split('/').pop() || tabPath
                    return (
                      <div
                        key={tabPath}
                        onClick={() => openIdeFile(tabPath)}
                        className={`group flex h-full cursor-pointer items-center gap-1.5 border-r border-slate-200 px-3 text-xs transition ${
                          isTabActive
                            ? 'border-t-2 border-t-teal-500 bg-white font-semibold text-slate-900 dark:border-r-slate-800 dark:bg-[#1e1e1e] dark:text-white'
                            : 'text-slate-600 hover:bg-slate-200/60 dark:border-r-slate-800 dark:text-slate-400 dark:hover:bg-slate-900/60'
                        }`}
                      >
                        {fileIconFor(tabName)}
                        <span className="truncate max-w-[150px]">{tabName}</span>
                        <button
                          type="button"
                          onClick={(e) => closeEditorTab(tabPath, e)}
                          className="rounded p-0.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition"
                          title="Close tab"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    )
                  })}
                </div>

                {/* Tab Strip Actions */}
                <div className="ml-auto flex items-center gap-2 px-3 shrink-0">
                  {activeFile && (
                    <button
                      type="button"
                      onClick={() => {
                        const code = ideFileContents[activeFile.path] ?? activeFile.content ?? ''
                        navigator.clipboard.writeText(code)
                        setEditorCopied(true)
                        setTimeout(() => setEditorCopied(false), 2000)
                      }}
                      className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium text-slate-600 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800 transition"
                      title="Copy file code"
                    >
                      {editorCopied ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                      <span>{editorCopied ? 'Copied' : 'Copy'}</span>
                    </button>
                  )}

                  {/* Layout toggle group */}
                  <div className="flex items-center rounded-lg border border-slate-200 bg-white p-0.5 dark:border-slate-800 dark:bg-slate-900">
                    <button
                      type="button"
                      onClick={() => setIdeViewLayout('editor')}
                      className={`inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-semibold transition ${
                        ideViewLayout === 'editor'
                          ? 'bg-teal-600 text-white shadow-xs'
                          : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                      }`}
                      title="Maximize Code Editor"
                    >
                      <Code2 className="h-3 w-3" />
                      <span>Editor</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIdeViewLayout('split')}
                      className={`inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-semibold transition ${
                        ideViewLayout === 'split'
                          ? 'bg-teal-600 text-white shadow-xs'
                          : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                      }`}
                      title="Split Screen (Editor + Chat)"
                    >
                      <Eye className="h-3 w-3" />
                      <span>Split</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIdeViewLayout('chat')}
                      className="inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-semibold text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 transition"
                      title="Maximize AI Chat"
                    >
                      <MessageSquare className="h-3 w-3" />
                      <span>Chat</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Breadcrumb info bar */}
              {activeFile && (
                <div className="flex h-7 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-3 text-xs text-slate-500 dark:border-slate-800/80 dark:bg-[#181818] dark:text-slate-400">
                  <div className="flex items-center gap-1.5 truncate font-mono text-[11px]">
                    <FileCode className="h-3.5 w-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                    <span className="truncate text-slate-700 dark:text-slate-300 font-medium">{activeFile.path}</span>
                  </div>
                  <div className="flex items-center gap-3 shrink-0 text-[11px]">
                    <span className="rounded bg-teal-50 px-1.5 py-0.2 font-mono text-[10px] font-semibold uppercase text-teal-700 dark:bg-teal-950/60 dark:text-teal-300">
                      {activeFile.language}
                    </span>
                    <span>
                      {(ideFileContents[activeFile.path] ?? activeFile.content ?? '').split('\n').length} lines
                    </span>
                    <span>{activeFile.size}</span>
                  </div>
                </div>
              )}

              {/* Monaco Editor Container */}
              <div className="relative min-h-0 flex-1 bg-[#1e1e1e]">
                {isLoadingFile ? (
                  <div className="flex h-full flex-col items-center justify-center gap-2 text-slate-400">
                    <RefreshCw className="h-6 w-6 animate-spin text-teal-500" />
                    <span className="text-xs">Loading {activeFile?.name}...</span>
                  </div>
                ) : activeFile ? (
                  <Editor
                    height="100%"
                    language={getMonacoLanguage(activeFile.name)}
                    value={ideFileContents[activeFile.path] ?? activeFile.content ?? ''}
                    onChange={(val) => {
                      if (val !== undefined) {
                        setIdeFileContents((prev) => ({ ...prev, [activeFile.path]: val }))
                      }
                    }}
                    theme="vs-dark"
                    options={{
                      minimap: { enabled: false },
                      fontSize: 13,
                      lineNumbers: 'on',
                      automaticLayout: true,
                      scrollBeyondLastLine: false,
                      wordWrap: 'on',
                      padding: { top: 12, bottom: 12 },
                    }}
                  />
                ) : (
                  <div className="flex h-full flex-col items-center justify-center p-8 text-center text-slate-400">
                    <FileCode className="h-12 w-12 text-slate-600 mb-3" />
                    <div className="text-sm font-semibold text-slate-300">No file selected</div>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs">
                      Click any file in the Explorer on the left to open and view it in the editor.
                    </p>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* RIGHT / CENTER: Chat */}
          {(ideViewLayout === 'split' || ideViewLayout === 'chat') && (
            <section className={`flex min-w-0 flex-col bg-white dark:bg-slate-900 ${ideViewLayout === 'split' ? 'w-[420px] xl:w-[480px] shrink-0 border-l border-slate-200 dark:border-slate-800' : 'flex-1'}`}>
              <div className="flex items-center justify-between border-b border-slate-100 px-4 py-2.5 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4 text-teal-600 dark:text-teal-400" />
                  <span className="text-sm font-bold text-slate-800 dark:text-slate-100">Chat</span>
                </div>
                <div className="flex items-center gap-2">
                  {ideViewLayout === 'chat' && (
                    <div className="flex items-center rounded-lg border border-slate-200 bg-slate-100 p-0.5 dark:border-slate-800 dark:bg-slate-800">
                      <button
                        type="button"
                        onClick={() => setIdeViewLayout('editor')}
                        className="inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-semibold text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                        title="Show Editor"
                      >
                        <Code2 className="h-3 w-3" /> Editor
                      </button>
                      <button
                        type="button"
                        onClick={() => setIdeViewLayout('split')}
                        className="inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-semibold text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                        title="Show Split Screen"
                      >
                        <Eye className="h-3 w-3" /> Split
                      </button>
                    </div>
                  )}
                  <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-500 dark:bg-slate-800 dark:text-slate-400">QAgentix AI</span>
                  <button
                    type="button"
                    onClick={() => { setIdeMode(false); setShowWelcome(true) }}
                    className="rounded-md px-2 py-1 text-[11px] font-semibold text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                    title="Close folder and return to welcome"
                  >
                    Close Folder
                  </button>
                </div>
              </div>

            {/* Messages */}
            <div className="min-h-0 flex-1 overflow-y-auto p-4">
              <div className="mx-auto w-full max-w-3xl space-y-4">
                {activeSession.messages.length === 0 ? (
                  <div className="mt-16 flex flex-col items-center px-4 text-center">
                    <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500">
                      <MessageSquare className="h-7 w-7" />
                    </div>
                    <div className="text-base font-semibold text-slate-700 dark:text-slate-200">Ask about your code</div>
                    <p className="mt-1 max-w-sm text-sm text-slate-400 dark:text-slate-500">
                      AI responses may be inaccurate. Generate tests or ask questions about the files in{' '}
                      <span className="font-semibold text-teal-600 dark:text-teal-400">{uploadedFolderName}</span>.
                    </p>
                  </div>
                ) : (
                  activeSession.messages.map((message) => {
                    const isUser = message.role === 'user'
                    return (
                      <div key={message.id} className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
                        <div
                          className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                            isUser
                              ? 'bg-teal-700 text-white rounded-tr-none'
                              : 'border border-slate-200 bg-slate-50 text-slate-800 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-100 rounded-tl-none'
                          }`}
                        >
                          {message.isGenerating ? (
                            <span className="flex items-center gap-2 font-semibold text-teal-600 dark:text-teal-300">
                              <RefreshCw className="h-4 w-4 animate-spin" />
                              {message.content || 'Thinking...'}
                            </span>
                          ) : (
                            <span className="whitespace-pre-wrap">{message.content}</span>
                          )}
                        </div>
                      </div>
                    )
                  })
                )}
                <div ref={messagesEndRef} />
              </div>
            </div>

            {/* Composer with suggestions drop-up, prompt score, optimizer */}
            <div className="border-t border-slate-100 p-3 dark:border-slate-800">
              <div className="mx-auto w-full max-w-3xl space-y-2">
                {/* Suggested Prompts drop-up + prompt score + Optimize Prompt */}
                {dynamicSuggestions.length > 0 && (
                  <div ref={dropUpRef} className="relative">
                    <div className="flex items-center justify-between gap-2 pb-1">
                      <button
                        type="button"
                        onClick={() => setIsDropUpOpen((prev) => !prev)}
                        className="group inline-flex items-center gap-2 rounded-xl border border-teal-200/90 bg-teal-50/90 px-3 py-1.5 text-xs font-semibold text-teal-800 shadow-xs transition hover:bg-teal-100 hover:border-teal-300 active:scale-95 dark:border-teal-800/80 dark:bg-teal-950/70 dark:text-teal-200 dark:hover:bg-teal-900/60 cursor-pointer"
                        aria-expanded={isDropUpOpen}
                        title={isDropUpOpen ? 'Collapse suggestion prompts' : 'Open suggestion prompts'}
                      >
                        <Sparkles className="h-3.5 w-3.5 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform duration-300" />
                        <span>Suggested Prompts</span>
                        <span className="rounded-full bg-teal-600 px-1.5 text-[10px] font-bold leading-none text-white py-0.5">{dynamicSuggestions.length}</span>
                        <ChevronUp className={`h-3.5 w-3.5 text-teal-600 dark:text-teal-400 transition-transform duration-300 ${isDropUpOpen ? 'rotate-180' : 'rotate-0'}`} />
                      </button>

                      {inputText.trim().length > 0 && (
                        <div className="flex items-center gap-2">
                          <div
                            className={`hidden sm:flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold ring-1 ${
                              promptAnalysis.score >= 80
                                ? 'bg-emerald-50 text-emerald-700 ring-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:ring-emerald-900'
                                : promptAnalysis.score >= 50
                                  ? 'bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:ring-amber-900'
                                  : 'bg-rose-50 text-rose-700 ring-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:ring-rose-900'
                            }`}
                            title={
                              promptAnalysis.missing.length > 0
                                ? `To improve: ${promptAnalysis.missing.map((m) => m.label).join(', ')}`
                                : 'Great prompt! All quality signals present.'
                            }
                          >
                            <Gauge className="h-3.5 w-3.5" />
                            <span>Prompt score {promptAnalysis.score}</span>
                          </div>
                          <button
                            type="button"
                            onClick={handleOptimizePrompt}
                            className="group inline-flex items-center gap-1.5 rounded-xl border border-teal-300 bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-[11px] font-semibold text-white shadow-sm transition hover:from-teal-600 hover:to-emerald-600 active:scale-95 cursor-pointer"
                            title="Rewrite your prompt into a structured, high-quality instruction"
                          >
                            <Sparkles className="h-3.5 w-3.5 group-hover:rotate-12 transition-transform duration-300" />
                            <span>Optimize Prompt</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Drop-up panel */}
                    <div
                      className={`absolute bottom-full left-0 right-0 mb-2.5 z-40 rounded-2xl border border-slate-200/90 bg-white/95 shadow-2xl shadow-teal-950/10 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-900/95 overflow-hidden transition-all duration-300 ease-out origin-bottom transform ${
                        isDropUpOpen
                          ? 'opacity-100 translate-y-0 scale-100 pointer-events-auto'
                          : 'opacity-0 translate-y-3 scale-[0.98] pointer-events-none'
                      }`}
                    >
                      <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/70 dark:bg-slate-800/40">
                        <div className="flex items-center gap-2">
                          <div className="flex h-5 w-5 items-center justify-center rounded-md bg-teal-600/10 text-teal-600 dark:bg-teal-950 dark:text-teal-400">
                            <Sparkles className="h-3 w-3" />
                          </div>
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-100">Suggested Prompts</span>
                          <span className="rounded-full bg-slate-200/80 px-2 py-0.5 text-[10px] font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">{dynamicSuggestions.length} options</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setIsDropUpOpen(false)}
                          className="rounded-lg p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 dark:hover:text-slate-200 dark:hover:bg-slate-800 transition cursor-pointer"
                          title="Close drop-up"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <div className="max-h-72 overflow-y-auto space-y-1 p-2 divide-y divide-slate-100/90 dark:divide-slate-800/60">
                        {dynamicSuggestions.map((sug) => (
                          <button
                            key={sug.id}
                            type="button"
                            onClick={() => { handleSendMessage(sug.prompt); setIsDropUpOpen(false) }}
                            className="group w-full flex items-start justify-between gap-3 p-2.5 rounded-xl border border-transparent hover:border-teal-200/70 hover:bg-gradient-to-r hover:from-teal-50/80 hover:to-transparent dark:hover:border-teal-800/60 dark:hover:from-teal-950/40 text-left transition active:scale-[0.99] cursor-pointer"
                          >
                            <div className="flex items-start gap-2.5 min-w-0">
                              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-teal-600/10 text-teal-600 dark:bg-teal-950 dark:text-teal-400 group-hover:bg-teal-600 group-hover:text-white transition mt-0.5">
                                <Sparkles className="h-3 w-3" />
                              </div>
                              <div className="min-w-0">
                                <div className="text-xs font-semibold text-slate-800 group-hover:text-teal-700 dark:text-slate-200 dark:group-hover:text-teal-300 transition">{sug.label}</div>
                                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5 leading-relaxed">{sug.prompt}</p>
                              </div>
                            </div>
                            <div className="shrink-0 flex items-center gap-1.5 pt-0.5">
                              <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[9px] font-bold text-slate-600 group-hover:bg-teal-200/60 group-hover:text-teal-900 dark:bg-slate-800 dark:text-slate-300 transition">{sug.badge}</span>
                              <Send className="h-3 w-3 text-teal-600 opacity-0 group-hover:opacity-100 transition" />
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Composer box */}
                <div className="rounded-xl border border-slate-300 bg-white focus-within:border-teal-500 focus-within:ring-2 focus-within:ring-teal-500/20 dark:border-slate-700 dark:bg-slate-800">
                  {/* Current file context chip */}
                  {activeFile && (
                    <div className="flex items-center gap-1.5 border-b border-slate-100 px-3 py-2 dark:border-slate-700/60">
                      <FileCode className="h-3.5 w-3.5 text-teal-600 dark:text-teal-400" />
                      <span className="truncate text-[11px] font-medium text-slate-600 dark:text-slate-300" title={activeFile.path}>
                        {activeFile.name}
                      </span>
                      <span className="ml-auto text-[10px] text-slate-400">Current file context</span>
                    </div>
                  )}
                  <textarea
                    ref={textareaRef}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Ask about your code or generate tests..."
                    rows={2}
                    className="max-h-40 min-h-[52px] w-full resize-none bg-transparent px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-white"
                  />
                  {/* Ask / Models action row */}
                  <div className="flex items-center gap-2 border-t border-slate-100 px-3 py-2 dark:border-slate-700/60 relative">
                    {/* Built-in Agent Ask Menu */}
                    <div className="relative" ref={askMenuRef}>
                      <button
                        type="button"
                        onClick={() => setIsAskMenuOpen((prev) => !prev)}
                        className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700/60 transition shadow-xs cursor-pointer"
                        title="Start with a built-in agent template (Spec, Plan, Bug Fix, Quick Spec)"
                      >
                        <Plus className="h-3 w-3 text-teal-600 dark:text-teal-400" /> Ask
                      </button>

                      {isAskMenuOpen && (
                        <div className="absolute bottom-full left-0 mb-2 w-72 rounded-xl border border-slate-200 bg-white/95 backdrop-blur-md shadow-2xl dark:border-slate-700 dark:bg-slate-900/95 z-50 overflow-hidden p-1.5 animate-in fade-in slide-in-from-bottom-2 duration-150">
                          <div className="px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                            Start with a built-in agent
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setInputText('Synthesize structured feature development and acceptance criteria for: ')
                              setIsAskMenuOpen(false)
                              textareaRef.current?.focus()
                            }}
                            className="w-full text-left p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-start gap-2.5 cursor-pointer"
                          >
                            <FileText className="h-4 w-4 text-teal-600 dark:text-teal-400 mt-0.5 shrink-0" />
                            <div>
                              <div className="text-xs font-semibold text-slate-900 dark:text-white">Spec</div>
                              <div className="text-[10px] text-slate-500 dark:text-slate-400">Structured feature development</div>
                            </div>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setInputText('Create plan-only mode breakdown that helps break ideas down into test steps: ')
                              setIsAskMenuOpen(false)
                              textareaRef.current?.focus()
                            }}
                            className="w-full text-left p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-start gap-2.5 cursor-pointer"
                          >
                            <ClipboardCheck className="h-4 w-4 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0" />
                            <div>
                              <div className="text-xs font-semibold text-slate-900 dark:text-white">Plan</div>
                              <div className="text-[10px] text-slate-500 dark:text-slate-400">Plan-only mode that breaks ideas down</div>
                            </div>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setInputText('Structured bug-fix workflow: investigate, diagnose, and heal broken locators: ')
                              setIsAskMenuOpen(false)
                              textareaRef.current?.focus()
                            }}
                            className="w-full text-left p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-start gap-2.5 cursor-pointer"
                          >
                            <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
                            <div>
                              <div className="text-xs font-semibold text-slate-900 dark:text-white">Bug Fix</div>
                              <div className="text-[10px] text-slate-500 dark:text-slate-400">Investigate, diagnose, and fix</div>
                            </div>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setInputText('Fast spec workflow: clarify, then auto-generate requirements and test cases: ')
                              setIsAskMenuOpen(false)
                              textareaRef.current?.focus()
                            }}
                            className="w-full text-left p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-start gap-2.5 cursor-pointer"
                          >
                            <Sparkles className="h-4 w-4 text-purple-600 dark:text-purple-400 mt-0.5 shrink-0" />
                            <div>
                              <div className="text-xs font-semibold text-slate-900 dark:text-white">Quick Spec</div>
                              <div className="text-[10px] text-slate-500 dark:text-slate-400">Fast spec clarification then auto-generate</div>
                            </div>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Models dropdown selector */}
                    <div className="relative" ref={modelDropdownRef}>
                      <button
                        type="button"
                        onClick={() => setIsModelDropdownOpen((prev) => !prev)}
                        className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700/60 transition shadow-xs cursor-pointer"
                        title="Click to view all available Kiro AI models"
                      >
                        <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="font-semibold text-slate-900 dark:text-white max-w-[140px] truncate">
                          {currentModelObj.name}
                        </span>
                        <ChevronDown className={`h-3 w-3 text-slate-400 transition-transform ${isModelDropdownOpen ? 'rotate-180' : ''}`} />
                      </button>

                      {isModelDropdownOpen && (
                        <div className="absolute bottom-full left-0 mb-2 w-80 sm:w-96 rounded-xl border border-slate-200 bg-white/98 backdrop-blur-md shadow-2xl dark:border-slate-700 dark:bg-slate-900/98 z-50 overflow-hidden flex flex-col max-h-[440px] animate-in fade-in slide-in-from-bottom-2 duration-150">
                          {/* Header */}
                          <div className="flex items-center justify-between border-b border-slate-100 px-3 py-2.5 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50">
                            <div className="flex items-center gap-2">
                              <Bot className="h-4 w-4 text-teal-600 dark:text-teal-400" />
                              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Kiro AI Models</span>
                            </div>
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-400">
                              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                              Connected
                            </span>
                          </div>

                          {/* Search Filter */}
                          <div className="border-b border-slate-100 p-2 dark:border-slate-800">
                            <input
                              type="text"
                              value={modelSearchQuery}
                              onChange={(e) => setModelSearchQuery(e.target.value)}
                              placeholder="Search models (Claude, Gemini, GPT, o3, DeepSeek)..."
                              className="w-full rounded-lg bg-slate-100 px-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500 dark:bg-slate-800 dark:text-white"
                            />
                          </div>

                          {/* Model List */}
                          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60 p-1">
                            {filteredKiroModels.length === 0 ? (
                              <div className="p-4 text-center text-xs text-slate-400">No models match your search.</div>
                            ) : (
                              filteredKiroModels.map((m) => {
                                const isSelected = selectedModel === m.id
                                return (
                                  <button
                                    key={m.id}
                                    type="button"
                                    onClick={() => {
                                      setSelectedModel(m.id)
                                      setIsModelDropdownOpen(false)
                                    }}
                                    className={`w-full flex items-start gap-2.5 p-2 rounded-lg text-left transition cursor-pointer ${
                                      isSelected
                                        ? 'bg-teal-50 text-teal-900 dark:bg-teal-950/40 dark:text-teal-200'
                                        : 'hover:bg-slate-50 text-slate-700 dark:hover:bg-slate-800/60 dark:text-slate-300'
                                    }`}
                                  >
                                    <div className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center">
                                      {isSelected ? (
                                        <Check className="h-3.5 w-3.5 text-teal-600 dark:text-teal-400 font-bold" />
                                      ) : (
                                        <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-slate-600" />
                                      )}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-1.5 flex-wrap">
                                        <span className="text-xs font-semibold text-slate-900 dark:text-white">
                                          {m.name}
                                        </span>
                                        <span className="rounded bg-slate-100 px-1.5 py-0.2 text-[9px] font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                                          {m.provider}
                                        </span>
                                        {m.badge && (
                                          <span className="rounded bg-teal-100/70 px-1.5 py-0.2 text-[9px] font-semibold text-teal-700 dark:bg-teal-900/40 dark:text-teal-300">
                                            {m.badge}
                                          </span>
                                        )}
                                      </div>
                                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                                        {m.description}
                                      </p>
                                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400">
                                        <span>Context: {m.context_window}</span>
                                        <span>•</span>
                                        <span>Latency: {m.latency}</span>
                                      </div>
                                    </div>
                                  </button>
                                )
                              })
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => handleSendMessage()}
                      disabled={!inputText.trim()}
                      className="ml-auto flex h-8 w-8 items-center justify-center rounded-lg bg-teal-600 text-white hover:bg-teal-700 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
                      title="Send"
                      aria-label="Send"
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>
          )}
        </div>

        {/* Status bar */}
        <div className="flex h-6 shrink-0 items-center justify-between bg-teal-700 px-3 text-[10px] font-medium text-white">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1"><FolderOpen className="h-3 w-3" /> {uploadedFolderName ?? 'Project'}</span>
            <span>{uploadedFiles.length} files</span>
          </div>
          <div className="flex items-center gap-3">
            {activeFile && <span className="uppercase">{activeFile.language}</span>}
            <span>UTF-8</span>
            <span>LF</span>
            <span>Spaces: 2</span>
          </div>
        </div>

        {/* Hidden folder input so "Open a different folder" works in the IDE view */}
        <input
          ref={(el) => {
            folderInputRef.current = el
            if (el) {
              el.setAttribute('webkitdirectory', '')
              el.setAttribute('directory', '')
            }
          }}
          type="file"
          multiple
          onChange={(e) => {
            handleFolderSelect(e.target.files)
            e.target.value = ''
          }}
          className="hidden"
          aria-label="Upload folder from computer"
        />
      </div>
    )
  }

  return (
    <div className="relative flex h-full min-h-0 flex-1 overflow-hidden bg-slate-50 dark:bg-slate-950">
      {/* LEFT SIDEBAR: ChatGPT-style Conversations & Model Info */}
      <aside
        className={`${
          isSidebarOpen ? 'w-64 sm:w-72' : 'w-0'
        } shrink-0 transition-all duration-300 ease-in-out border-r border-slate-200 bg-white/95 dark:border-slate-800 dark:bg-slate-900/95 flex flex-col overflow-hidden`}
      >
        <div className="p-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-600 text-white shadow-sm font-bold text-xs">
              QA
            </div>
            <div>
              <div className="text-xs font-bold text-slate-800 dark:text-slate-100">Agent Workspace</div>
              <div className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-teal-500 animate-pulse" />
                Playwright AI v4.2
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsSidebarOpen(false)}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
            title="Collapse sidebar"
          >
            <ChevronDown className="h-4 w-4 -rotate-90" />
          </button>
        </div>

        {/* New Chat Button */}
        <div className="p-3">
          <button
            type="button"
            onClick={handleCreateNewChat}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-teal-600 to-teal-700 px-3 py-2 text-xs font-bold text-white shadow-sm shadow-teal-700/20 hover:from-teal-700 hover:to-teal-800 transition"
          >
            <Plus className="h-4 w-4" />
            <span>New Chat</span>
          </button>
        </div>

        {/* Uploaded local folder banner */}
        {uploadedFolderName && (
          <div className="mx-3 mb-1 flex items-center gap-2 rounded-xl border border-teal-200 bg-teal-50/80 px-2.5 py-2 dark:border-teal-800/60 dark:bg-teal-950/40">
            <FolderOpen className="h-4 w-4 shrink-0 text-teal-600 dark:text-teal-400" />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[11px] font-bold text-teal-900 dark:text-teal-200" title={uploadedFolderName}>{uploadedFolderName}</div>
              <div className="text-[9px] text-teal-600/80 dark:text-teal-400/80">{attachedFiles.length} file(s) uploaded</div>
            </div>
            <button
              type="button"
              onClick={() => void pickFolder()}
              className="rounded-lg p-1 text-teal-600 hover:bg-teal-200/60 dark:text-teal-400 dark:hover:bg-teal-900/60"
              title="Upload a different folder"
            >
              <Upload className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        {/* Project folder selector (backend-backed local storage) */}
        <ProjectPanel selected={selectedProjectFolder} onSelect={setSelectedProjectFolder} autoOpenKey={folderPickerKey} />

        {/* Sessions List */}
        <div className="flex-1 overflow-y-auto px-2 py-1 space-y-1">
          <div className="px-2 pt-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Recent Conversations
          </div>
          {sessions.map((sess) => {
            const isActive = sess.id === activeSessionId
            const isRenaming = renamingId === sess.id
            const isMenuOpen = openMenuId === sess.id
            return (
              <div
                key={sess.id}
                className={`group relative flex items-center gap-1 rounded-lg pr-1 transition ${
                  isActive
                    ? 'bg-teal-50 dark:bg-teal-950/60 ring-1 ring-teal-500/20'
                    : 'hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                {isRenaming ? (
                  <input
                    autoFocus
                    value={renameValue}
                    onChange={(e) => setRenameValue(e.target.value)}
                    onBlur={() => handleCommitRename(sess.id)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleCommitRename(sess.id)
                      if (e.key === 'Escape') { setRenamingId(null); setRenameValue('') }
                    }}
                    className="flex-1 min-w-0 rounded-md border border-teal-400 bg-white px-2 py-1.5 text-xs text-slate-900 focus:outline-none dark:bg-slate-800 dark:text-white"
                    aria-label="Rename conversation"
                  />
                ) : (
                  <button
                    type="button"
                    onClick={() => setActiveSessionId(sess.id)}
                    className={`flex min-w-0 flex-1 items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-xs transition ${
                      isActive
                        ? 'text-teal-900 font-bold dark:text-teal-100'
                        : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <MessageSquare className={`h-3.5 w-3.5 shrink-0 ${isActive ? 'text-teal-600 dark:text-teal-400' : 'text-slate-400'}`} />
                    <span className="truncate flex-1">{sess.title}</span>
                  </button>
                )}

                {!isRenaming && (
                  <div className="relative shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        setOpenMenuId(isMenuOpen ? null : sess.id)
                      }}
                      className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 opacity-0 transition hover:bg-slate-200 hover:text-slate-600 group-hover:opacity-100 dark:hover:bg-slate-700 dark:hover:text-slate-200"
                      title="Options"
                      aria-label="Conversation options"
                    >
                      <MoreVertical className="h-4 w-4" />
                    </button>

                    {isMenuOpen && (
                      <>
                        {/* click-away backdrop */}
                        <div className="fixed inset-0 z-10" onClick={() => setOpenMenuId(null)} />
                        <div className="absolute right-0 top-8 z-20 w-32 overflow-hidden rounded-lg border border-slate-200 bg-white py-1 shadow-lg dark:border-slate-700 dark:bg-slate-800">
                          <button
                            type="button"
                            onClick={() => handleStartRename(sess)}
                            className="flex w-full items-center gap-2 px-3 py-1.5 text-left text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                            <span>Rename</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteSession(sess.id)}
                            className="flex w-full items-center gap-2 px-3 py-1.5 text-left text-xs text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/40"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {/* Footer Quick Links */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 space-y-1 text-xs">
          <Link
            to="/test-cases"
            className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <ClipboardCheck className="h-3.5 w-3.5 text-teal-600" />
            <span>Test Cases Repository</span>
          </Link>
          <Link
            to="/scripts/rammas-validation"
            className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <Code2 className="h-3.5 w-3.5 text-blue-600" />
            <span>Script Review & Monaco</span>
          </Link>
        </div>
      </aside>

      {/* MAIN CHAT AREA */}
      <main className="flex min-w-0 flex-1 flex-col overflow-hidden">
        {/* Header Bar */}
        <header className="flex h-12 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-2">
            {!isSidebarOpen && (
              <button
                type="button"
                onClick={() => setIsSidebarOpen(true)}
                className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                title="Expand sessions sidebar"
              >
                <MessageSquare className="h-4 w-4" />
              </button>
            )}
            <div className="flex items-center gap-2">
              <Bot className="h-4 w-4 text-teal-600 dark:text-teal-400" />
              <h1 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                {activeSession.title}
              </h1>
            </div>
          </div>

        </header>

        {/* Messages Feed */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeSession.messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-[360px] max-w-md mx-auto text-center py-8 px-4 animate-in fade-in duration-200">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-600/10 text-teal-600 dark:bg-teal-950/60 dark:text-teal-400 mb-3 shadow-inner">
                <Sparkles className="h-6 w-6" />
              </div>
              <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 mb-1.5">
                AI Autonomous Quality Suite Orchestrator
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Upload your API specification, OpenAPI YAML, or PRD document in the chat box, or describe your test scenario to generate complete Playwright suites.
              </p>
            </div>
          ) : (
            activeSession.messages.map((message) => {
              const isUser = message.role === 'user'

              return (
                <div key={message.id} className={`flex gap-3 max-w-4xl mx-auto ${isUser ? 'justify-end' : 'justify-start'}`}>
                  {/* Assistant Avatar */}
                  {!isUser && (
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-tr from-teal-600 to-cyan-600 text-white shadow-sm font-bold text-xs mt-0.5">
                      <Bot className="h-4 w-4" />
                    </div>
                  )}

                  {/* Message Bubble */}
                  <div
                    className={`flex flex-col min-w-0 max-w-3xl rounded-2xl p-4 shadow-sm ${
                      isUser
                        ? 'bg-teal-700 text-white rounded-tr-none'
                        : 'border border-slate-200/90 bg-white text-slate-900 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100 rounded-tl-none'
                    }`}
                  >
                    {/* Header info */}
                    <div className="flex items-center justify-between gap-3 mb-1 text-[10px] opacity-75">
                      <span className="font-semibold">{isUser ? 'You' : 'QAgentix AI Test Agent'}</span>
                      <span>{message.timestamp}</span>
                    </div>

                    {/* Attached files chips inside user message */}
                    {message.attachments && message.attachments.length > 0 && (
                      <div className="mb-2 flex flex-wrap gap-1.5">
                        {message.attachments.map((att) => (
                          <div
                            key={att.id}
                            className={`flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11px] font-medium border ${
                              isUser
                                ? 'bg-white/10 border-white/20 text-white'
                                : 'bg-slate-100 border-slate-200 text-slate-700 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300'
                            }`}
                          >
                            <FileText className="h-3 w-3 shrink-0" />
                            <span className="truncate max-w-[180px]">{att.name}</span>
                            <span className="opacity-70 text-[10px]">({att.size})</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Generating Animated State */}
                    {message.isGenerating ? (
                      <div className="space-y-3 py-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-teal-600 dark:text-teal-400">
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          <span>{message.content || 'Generating autonomous quality suite...'}</span>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                          {[
                            { step: 1, label: 'Ingesting Specs' },
                            { step: 2, label: 'Synthesizing Cases' },
                            { step: 3, label: 'Generating Scripts' },
                            { step: 4, label: 'Packaging Bundle' },
                          ].map((st) => {
                            const isDone = (message.generationStep || 1) > st.step
                            const isCurrent = (message.generationStep || 1) === st.step
                            return (
                              <div
                                key={st.step}
                                className={`flex items-center gap-1.5 rounded-lg p-1.5 text-[10px] font-semibold ${
                                  isDone
                                    ? 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300'
                                    : isCurrent
                                    ? 'bg-teal-600 text-white animate-pulse'
                                    : 'bg-slate-100 text-slate-400 dark:bg-slate-800'
                                }`}
                              >
                                {isDone ? (
                                  <Check className="h-3 w-3" />
                                ) : (
                                  <span className="flex h-3 w-3 items-center justify-center rounded-full border border-current text-[8px]">
                                    {st.step}
                                  </span>
                                )}
                                <span className="truncate">{st.label}</span>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs leading-relaxed whitespace-pre-wrap">{message.content}</div>
                    )}

                    {/* GENERATED BUNDLE ARTIFACT CARD */}
                    {message.bundle && (
                      <div className="mt-3.5 rounded-xl border border-teal-500/30 bg-slate-50/70 dark:bg-slate-950/60 p-3 shadow-sm space-y-3">
                        {/* Bundle Header */}
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/80 pb-2.5 dark:border-slate-800">
                          <div className="flex items-center gap-2">
                            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-600 text-white">
                              <FolderArchive className="h-3.5 w-3.5" />
                            </div>
                            <div>
                              <div className="text-xs font-bold text-slate-900 dark:text-white">
                                {message.bundle.title}
                              </div>
                              <div className="text-[10px] text-slate-500 dark:text-slate-400">
                                {message.bundle.summary.totalCases} Test Cases • {message.bundle.summary.coverage} Spec Coverage • {message.bundle.files.length} Files
                              </div>
                            </div>
                          </div>

                          {/* Quick Download Buttons */}
                          <div className="flex flex-wrap items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleDownloadZip(message.bundle!)}
                              className="inline-flex items-center gap-1.5 rounded-lg bg-teal-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-teal-700 transition"
                              title="Download complete test project folder as a ZIP archive"
                            >
                              <Download className="h-3.5 w-3.5" />
                              <span>Download Folder (.zip)</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                const csvFile = message.bundle!.files.find((f) => f.path.endsWith('.csv'))
                                if (csvFile) handleDownloadSingleFile(csvFile.name, csvFile.content, 'text/csv')
                              }}
                              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                              title="Download test cases matrix as CSV"
                            >
                              <FileSpreadsheet className="h-3.5 w-3.5 text-blue-600" />
                              <span>.CSV</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                const specFile = message.bundle!.files.find((f) => f.path.endsWith('.spec.ts'))
                                if (specFile) handleDownloadSingleFile(specFile.name, specFile.content, 'application/typescript')
                              }}
                              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                              title="Download main test spec script"
                            >
                              <FileCode className="h-3.5 w-3.5 text-teal-600" />
                              <span>.TS</span>
                            </button>
                          </div>
                        </div>

                        {/* Interactive Viewer Subtabs */}
                        <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2">
                          <button
                            type="button"
                            onClick={() => setActiveBundleTab('tree')}
                            className={`pb-1.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
                              activeBundleTab === 'tree'
                                ? 'border-teal-600 text-teal-700 dark:border-teal-400 dark:text-teal-300'
                                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                            }`}
                          >
                            <Folder className="h-3.5 w-3.5" />
                            <span>Project Files ({message.bundle.files.length})</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveBundleTab('cases')}
                            className={`pb-1.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
                              activeBundleTab === 'cases'
                                ? 'border-teal-600 text-teal-700 dark:border-teal-400 dark:text-teal-300'
                                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                            }`}
                          >
                            <ClipboardCheck className="h-3.5 w-3.5" />
                            <span>Test Cases Matrix ({message.bundle.testCases.length})</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveBundleTab('code')}
                            className={`pb-1.5 text-xs font-bold transition flex items-center gap-1.5 border-b-2 ${
                              activeBundleTab === 'code'
                                ? 'border-teal-600 text-teal-700 dark:border-teal-400 dark:text-teal-300'
                                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                            }`}
                          >
                            <Terminal className="h-3.5 w-3.5" />
                            <span>Code Preview</span>
                          </button>
                        </div>

                        {/* TAB 1: FOLDER TREE & FILES LIST */}
                        {activeBundleTab === 'tree' && (
                          <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-2 rounded-xl border border-slate-200 bg-white p-2 dark:border-slate-800 dark:bg-slate-900">
                            {/* File Tree Navigation */}
                            <div className="space-y-1 border-r border-slate-100 pr-2 dark:border-slate-800">
                              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1">
                                Generated Folder Structure
                              </div>
                              {message.bundle.files.map((file) => {
                                const isSelected = selectedPreviewFile === file.path
                                return (
                                  <button
                                    key={file.path}
                                    type="button"
                                    onClick={() => setSelectedPreviewFile(file.path)}
                                    className={`flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-left text-xs transition ${
                                      isSelected
                                        ? 'bg-teal-50 text-teal-900 font-bold dark:bg-teal-950/60 dark:text-teal-200'
                                        : 'text-slate-700 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800'
                                    }`}
                                  >
                                    <div className="flex items-center gap-1.5 truncate">
                                      {file.path.endsWith('.spec.ts') || file.path.endsWith('.ts') ? (
                                        <FileCode className="h-3.5 w-3.5 shrink-0 text-teal-600" />
                                      ) : file.path.endsWith('.csv') ? (
                                        <FileSpreadsheet className="h-3.5 w-3.5 shrink-0 text-blue-600" />
                                      ) : (
                                        <FileText className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                                      )}
                                      <span className="truncate">{file.path}</span>
                                    </div>
                                    <span className="text-[9px] uppercase font-semibold text-slate-400 shrink-0">
                                      {file.language}
                                    </span>
                                  </button>
                                )
                              })}
                            </div>

                            {/* Selected File Preview Box */}
                            {(() => {
                              const currentFile =
                                message.bundle.files.find((f) => f.path === selectedPreviewFile) ||
                                message.bundle.files[0]
                              return (
                                <div className="flex flex-col min-h-[220px] max-h-[340px] rounded-lg bg-slate-950 text-slate-100 p-3 font-mono text-[11px] overflow-hidden">
                                  <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                                    <span className="text-teal-400 font-bold text-xs">{currentFile.path}</span>
                                    <div className="flex items-center gap-2">
                                      <button
                                        type="button"
                                        onClick={() => handleCopyCode(currentFile.content, currentFile.path)}
                                        className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-white transition"
                                      >
                                        {copiedFileId === currentFile.path ? (
                                          <>
                                            <Check className="h-3 w-3 text-emerald-400" />
                                            <span className="text-emerald-400">Copied!</span>
                                          </>
                                        ) : (
                                          <>
                                            <Copy className="h-3 w-3" />
                                            <span>Copy</span>
                                          </>
                                        )}
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleDownloadSingleFile(currentFile.name, currentFile.content)}
                                        className="inline-flex items-center gap-1 text-[10px] text-teal-400 hover:text-teal-300"
                                      >
                                        <Download className="h-3 w-3" />
                                        <span>Download</span>
                                      </button>
                                    </div>
                                  </div>
                                  <pre className="flex-1 overflow-y-auto leading-relaxed text-[11px] text-slate-300 font-mono">
                                    <code>{currentFile.content}</code>
                                  </pre>
                                </div>
                              )
                            })()}
                          </div>
                        )}

                        {/* TAB 2: TEST CASES TABLE */}
                        {activeBundleTab === 'cases' && (
                          <div className="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-slate-900">
                            <div className="max-h-[300px] overflow-y-auto">
                              <table className="w-full text-left text-xs border-collapse">
                                <thead className="sticky top-0 bg-slate-100 dark:bg-slate-800 text-[10px] uppercase font-bold text-slate-600 dark:text-slate-300">
                                  <tr>
                                    <th className="p-2.5">ID</th>
                                    <th className="p-2.5">Title & Steps</th>
                                    <th className="p-2.5">Expected Result</th>
                                    <th className="p-2.5">Priority</th>
                                    <th className="p-2.5">Type</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-[11px]">
                                  {message.bundle.testCases.map((tc) => (
                                    <tr key={tc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                      <td className="p-2.5 font-bold font-mono text-teal-600 dark:text-teal-400 whitespace-nowrap">
                                        {tc.id}
                                      </td>
                                      <td className="p-2.5 max-w-sm">
                                        <div className="font-semibold text-slate-900 dark:text-white">{tc.title}</div>
                                        <ul className="mt-1 list-disc list-inside text-[10px] text-slate-500 space-y-0.5">
                                          {tc.steps.map((st, i) => (
                                            <li key={i}>{st}</li>
                                          ))}
                                        </ul>
                                      </td>
                                      <td className="p-2.5 text-slate-600 dark:text-slate-300">{tc.expectedResult}</td>
                                      <td className="p-2.5">
                                        <span
                                          className={`inline-block rounded px-1.5 py-0.5 text-[9px] font-bold ${
                                            tc.priority === 'High'
                                              ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                                              : tc.priority === 'Medium'
                                              ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                                              : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                                          }`}
                                        >
                                          {tc.priority}
                                        </span>
                                      </td>
                                      <td className="p-2.5">
                                        <span className="rounded bg-teal-50 px-1.5 py-0.5 text-[9px] font-bold text-teal-700 dark:bg-teal-950 dark:text-teal-300">
                                          {tc.category}
                                        </span>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}

                        {/* TAB 3: CODE PREVIEW */}
                        {activeBundleTab === 'code' && (
                          <div className="rounded-xl bg-slate-950 text-slate-100 p-3 font-mono text-xs overflow-hidden max-h-[320px] flex flex-col">
                            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                              <span className="text-teal-400 font-bold">tests/rammas-channels.spec.ts</span>
                              <button
                                type="button"
                                onClick={() =>
                                  handleCopyCode(
                                    message.bundle!.files.find((f) => f.path.endsWith('.spec.ts'))?.content || '',
                                    'main-spec'
                                  )
                                }
                                className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-white"
                              >
                                {copiedFileId === 'main-spec' ? (
                                  <>
                                    <Check className="h-3 w-3 text-emerald-400" />
                                    <span className="text-emerald-400">Copied!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="h-3 w-3" />
                                    <span>Copy Code</span>
                                  </>
                                )}
                              </button>
                            </div>
                            <pre className="flex-1 overflow-y-auto leading-relaxed text-[11px] text-slate-300 font-mono">
                              <code>{message.bundle.files.find((f) => f.path.endsWith('.spec.ts'))?.content}</code>
                            </pre>
                          </div>
                        )}

                        {/* Navigation Actions to other pages in QAgentix */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-200/60 dark:border-slate-800 text-xs">
                          <span className="text-[10px] text-slate-500">
                            Ready to execute in your local terminal or CI/CD pipeline.
                          </span>
                          <div className="flex items-center gap-2">
                            <Link
                              to="/test-cases"
                              className="inline-flex items-center gap-1 font-semibold text-teal-600 hover:underline dark:text-teal-400 text-xs"
                            >
                              <ClipboardCheck className="h-3.5 w-3.5" />
                              <span>View in Test Cases</span>
                            </Link>
                            <span className="text-slate-300 dark:text-slate-700">•</span>
                            <Link
                              to="/scripts/rammas-validation"
                              className="inline-flex items-center gap-1 font-semibold text-teal-600 hover:underline dark:text-teal-400 text-xs"
                            >
                              <ExternalLink className="h-3.5 w-3.5" />
                              <span>Open in Monaco Editor</span>
                            </Link>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* User Avatar */}
                  {isUser && (
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-slate-800 text-white shadow-sm font-bold text-xs mt-0.5">
                      You
                    </div>
                  )}
                </div>
              )
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* BOTTOM INPUT & PROMPT SUGGESTIONS CONTAINER */}
        <div className="shrink-0 border-t border-slate-200 bg-white/95 p-3 backdrop-blur dark:border-slate-800 dark:bg-slate-900/95">
          <div className="max-w-4xl mx-auto space-y-2.5">
            {/* DYNAMIC PROMPT SUGGESTIONS DROP-UP MENU - Opens upwards above the chat box */}
            {dynamicSuggestions.length > 0 && (
              <div ref={dropUpRef} className="relative">
                {/* Drop-Up Trigger Button */}
                <div className="flex items-center justify-between pb-1 transition-all duration-200">
                  <button
                    type="button"
                    onClick={() => setIsDropUpOpen((prev) => !prev)}
                    className="group inline-flex items-center gap-2 rounded-xl border border-teal-200/90 bg-teal-50/90 px-3.5 py-1.5 text-xs font-semibold text-teal-800 shadow-xs transition-all duration-200 hover:bg-teal-100 hover:border-teal-300 hover:shadow-sm active:scale-95 dark:border-teal-800/80 dark:bg-teal-950/70 dark:text-teal-200 dark:hover:bg-teal-900/60 cursor-pointer"
                    aria-expanded={isDropUpOpen}
                    title={isDropUpOpen ? 'Collapse suggestion prompts' : 'Open suggestion prompts drop-up menu'}
                  >
                    <Sparkles className="h-3.5 w-3.5 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform duration-300" />
                    <span>
                      {attachedFiles.length > 0
                        ? `Suggested Prompts for ${attachedFiles[0].name}`
                        : 'Suggested Prompts'}
                    </span>
                    <span className="rounded-full bg-teal-600 px-1.5 py-0.2 text-[10px] font-bold text-white leading-none shadow-xs">
                      {dynamicSuggestions.length}
                    </span>
                    <ChevronUp
                      className={`h-3.5 w-3.5 text-teal-600 dark:text-teal-400 transition-transform duration-300 ease-in-out ${
                        isDropUpOpen ? 'rotate-180' : 'rotate-0'
                      }`}
                    />
                  </button>

                  {/* PROMPT OPTIMIZER: shows a live prompt score and rewrites weak prompts */}
                  {inputText.trim().length > 0 && (
                    <div className="flex items-center gap-2">
                      <div
                        className={`hidden sm:flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold ring-1 ${
                          promptAnalysis.score >= 80
                            ? 'bg-emerald-50 text-emerald-700 ring-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:ring-emerald-900'
                            : promptAnalysis.score >= 50
                              ? 'bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:ring-amber-900'
                              : 'bg-rose-50 text-rose-700 ring-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:ring-rose-900'
                        }`}
                        title={
                          promptAnalysis.missing.length > 0
                            ? `To improve: ${promptAnalysis.missing.map((m) => m.label).join(', ')}`
                            : 'Great prompt! All quality signals present.'
                        }
                      >
                        <Gauge className="h-3.5 w-3.5" />
                        <span>Prompt score {promptAnalysis.score}</span>
                      </div>
                      <button
                        type="button"
                        onClick={handleOptimizePrompt}
                        className="group inline-flex items-center gap-1.5 rounded-xl border border-teal-300 bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-[11px] font-semibold text-white shadow-sm transition-all duration-200 hover:from-teal-600 hover:to-emerald-600 hover:shadow active:scale-95 cursor-pointer"
                        title="Rewrite your prompt into a structured, high-quality instruction"
                      >
                        <Sparkles className="h-3.5 w-3.5 group-hover:rotate-12 transition-transform duration-300" />
                        <span>Optimize Prompt</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Drop-Up Menu Panel - Floats Upwards above the composer with buttery-smooth transition */}
                <div
                  className={`absolute bottom-full left-0 right-0 mb-2.5 z-40 rounded-2xl border border-slate-200/90 bg-white/95 shadow-2xl shadow-teal-950/10 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-900/95 dark:shadow-black/50 overflow-hidden transition-all duration-300 ease-out origin-bottom transform ${
                    isDropUpOpen
                      ? 'opacity-100 translate-y-0 scale-100 pointer-events-auto'
                      : 'opacity-0 translate-y-3 scale-[0.98] pointer-events-none'
                  }`}
                >
                  <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/70 dark:bg-slate-800/40 backdrop-blur-xs">
                    <div className="flex items-center gap-2">
                      <div className="flex h-5 w-5 items-center justify-center rounded-md bg-teal-600/10 text-teal-600 dark:bg-teal-950 dark:text-teal-400">
                        <Sparkles className="h-3 w-3" />
                      </div>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                        {attachedFiles.length > 0 ? `Prompts for ${attachedFiles[0].name}` : 'Suggested Prompts'}
                      </span>
                      <span className="rounded-full bg-slate-200/80 px-2 py-0.5 text-[10px] font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                        {dynamicSuggestions.length} options
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsDropUpOpen(false)}
                      className="rounded-lg p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 dark:hover:text-slate-200 dark:hover:bg-slate-800 transition-colors duration-150 cursor-pointer"
                      title="Close drop-up menu"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="max-h-72 overflow-y-auto space-y-1 p-2 divide-y divide-slate-100/90 dark:divide-slate-800/60 scroll-smooth">
                    {dynamicSuggestions.map((sug) => (
                      <button
                        key={sug.id}
                        type="button"
                        onClick={() => {
                          handleSendMessage(sug.prompt)
                          setIsDropUpOpen(false)
                        }}
                        className="group w-full flex items-start justify-between gap-3 p-2.5 rounded-xl border border-transparent hover:border-teal-200/70 hover:bg-gradient-to-r hover:from-teal-50/80 hover:to-transparent dark:hover:border-teal-800/60 dark:hover:from-teal-950/40 dark:hover:to-transparent text-left transition-all duration-200 ease-out active:scale-[0.99] cursor-pointer"
                      >
                        <div className="flex items-start gap-2.5 min-w-0">
                          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-teal-600/10 text-teal-600 dark:bg-teal-950 dark:text-teal-400 group-hover:bg-teal-600 group-hover:text-white group-hover:scale-105 transition-all duration-200 mt-0.5">
                            <Sparkles className="h-3 w-3" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-xs font-semibold text-slate-800 group-hover:text-teal-700 dark:text-slate-200 dark:group-hover:text-teal-300 transition-colors duration-150">
                              {sug.label}
                            </div>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5 leading-relaxed group-hover:text-slate-600 dark:group-hover:text-slate-300 transition-colors duration-150">
                              {sug.prompt}
                            </p>
                          </div>
                        </div>
                        <div className="shrink-0 flex items-center gap-1.5 pt-0.5">
                          <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[9px] font-bold text-slate-600 group-hover:bg-teal-200/60 group-hover:text-teal-900 dark:bg-slate-800 dark:text-slate-300 transition-colors duration-150">
                            {sug.badge}
                          </span>
                          <Send className="h-3 w-3 text-teal-600 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all duration-200" />
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Floating ChatGPT style Composer with upload option only inside the chat box */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`relative rounded-2xl border bg-white shadow-sm transition dark:bg-slate-800/90 ${
                isDraggingOverChat
                  ? 'border-teal-500 ring-2 ring-teal-500/30 bg-teal-50/50 dark:bg-teal-950/20'
                  : 'border-slate-300 focus-within:border-teal-500 focus-within:ring-2 focus-within:ring-teal-500/20 dark:border-slate-700'
              }`}
            >
              {/* Attached Files Preview Chips (Inside the chat box, above textarea) */}
              {attachedFiles.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 p-2.5 pb-1 border-b border-slate-100 dark:border-slate-700/60">
                  {attachedFiles.map((att) => (
                    <div
                      key={att.id}
                      className="group flex items-center gap-2 rounded-xl border border-teal-200 bg-teal-50/80 px-2.5 py-1.5 text-xs text-teal-900 dark:border-teal-800/60 dark:bg-teal-950/50 dark:text-teal-200 animate-in fade-in zoom-in-95 duration-150"
                    >
                      <div className="flex h-5 w-5 items-center justify-center rounded-md bg-teal-600/10 text-teal-700 dark:text-teal-300">
                        <FileText className="h-3 w-3" />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="truncate max-w-[160px] font-semibold text-[11px] leading-tight">
                          {att.name}
                        </span>
                        <span className="text-[9px] text-teal-600/75 dark:text-teal-400/75 leading-tight">
                          {att.size}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveAttachment(att.id)}
                        className="rounded-full p-0.5 text-teal-700 hover:bg-teal-200/60 hover:text-teal-900 dark:text-teal-400 dark:hover:bg-teal-900/60 transition"
                        title={`Remove ${att.name}`}
                        aria-label={`Remove ${att.name}`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-1 rounded-xl border border-dashed border-slate-300 px-2.5 py-1 text-[11px] font-medium text-slate-500 hover:border-teal-500 hover:text-teal-600 dark:border-slate-700 dark:text-slate-400 dark:hover:text-teal-400 transition"
                    title="Add more files"
                  >
                    <Plus className="h-3 w-3" />
                    <span>Add more</span>
                  </button>
                </div>
              )}

              {/* Composer Input & Action Buttons */}
              <div className="flex items-end">
                {/* Hidden File Input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={(e) => {
                    handleFileSelect(e.target.files)
                    e.target.value = ''
                  }}
                  className="hidden"
                  id="chat-box-file-upload"
                  data-testid="chat-file-input"
                  aria-label="File upload input"
                  accept=".json,.yaml,.yml,.csv,.txt,.pdf,.md,.doc,.docx,.png,.jpg,.jpeg,.zip"
                />

                {/* Hidden Folder Input (local folder upload) */}
                <input
                  ref={(el) => {
                    folderInputRef.current = el
                    if (el) {
                      el.setAttribute('webkitdirectory', '')
                      el.setAttribute('directory', '')
                    }
                  }}
                  type="file"
                  multiple
                  onChange={(e) => {
                    handleFolderSelect(e.target.files)
                    e.target.value = ''
                  }}
                  className="hidden"
                  aria-label="Upload folder from computer"
                />

                {/* Upload & Prompt Trigger Buttons inside Chat Box */}
                <div className="p-2 pr-0 flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex h-8 w-8 items-center justify-center rounded-xl text-slate-500 hover:text-teal-600 hover:bg-teal-50 dark:text-slate-400 dark:hover:text-teal-300 dark:hover:bg-slate-700/60 transition"
                    title="Upload specification file"
                    aria-label="Upload specification file"
                  >
                    <Paperclip className="h-4 w-4" />
                  </button>

                  {dynamicSuggestions.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setIsDropUpOpen((prev) => !prev)}
                      className={`flex h-8 items-center gap-1.5 px-2.5 rounded-xl text-xs font-semibold transition-all duration-200 active:scale-95 cursor-pointer ${
                        isDropUpOpen
                          ? 'bg-teal-100/90 text-teal-900 dark:bg-teal-950 dark:text-teal-200 ring-1 ring-teal-400/40 shadow-xs'
                          : 'text-slate-500 hover:text-teal-600 hover:bg-teal-50 dark:text-slate-400 dark:hover:text-teal-300 dark:hover:bg-slate-700/60'
                      }`}
                      title={isDropUpOpen ? 'Collapse suggestion prompts' : 'Open suggestion prompts drop-up'}
                    >
                      <Sparkles className="h-3.5 w-3.5 text-teal-600 dark:text-teal-400" />
                      <span className="text-[11px] hidden sm:inline">Prompts</span>
                      <span className="rounded-full bg-teal-600 text-white px-1.5 text-[9px] font-bold leading-none py-0.5">
                        {dynamicSuggestions.length}
                      </span>
                      <ChevronUp
                        className={`h-3 w-3 text-teal-600 dark:text-teal-400 transition-transform duration-300 ease-in-out ${
                          isDropUpOpen ? 'rotate-180' : 'rotate-0'
                        }`}
                      />
                    </button>
                  )}
                </div>

                {/* Textarea */}
                <textarea
                  ref={textareaRef}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={
                    attachedFiles.length > 0
                      ? 'Add instructions for attached file(s) or click Send...'
                      : 'Ask QAgentix AI, enter requirements, or describe what test cases to generate...'
                  }
                  rows={1}
                  className="max-h-32 min-h-[44px] flex-1 resize-none bg-transparent py-3 px-3 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-white"
                  style={{ height: 'auto' }}
                />

                {/* Send Button */}
                <div className="p-2">
                  <button
                    type="button"
                    onClick={() => handleSendMessage()}
                    disabled={!inputText.trim() && attachedFiles.length === 0}
                    className="flex h-8 w-8 items-center justify-center rounded-xl bg-teal-600 text-white shadow-sm hover:bg-teal-700 disabled:opacity-40 disabled:cursor-not-allowed transition"
                    title="Send prompt to generate test cases"
                    aria-label="Send prompt to generate test cases"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Drag overlay notice if hovering */}
              {isDraggingOverChat && (
                <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center rounded-2xl bg-teal-600/10 backdrop-blur-xs border-2 border-dashed border-teal-500 text-xs font-semibold text-teal-700 dark:text-teal-300">
                  Drop files to attach to chat
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

function TestCasesPage() {
  const navigate = useNavigate()
  const [casesList, setCasesList] = useState<TestCase[]>(testCases)
  const [selectedIds, setSelectedIds] = useState<string[]>(testCases.map((t) => t.id))
  const [viewingCase, setViewingCase] = useState<TestCase | null>(null)

  const isAllSelected = casesList.length > 0 && selectedIds.length === casesList.length
  const isSomeSelected = selectedIds.length > 0 && selectedIds.length < casesList.length

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds([])
    } else {
      setSelectedIds(casesList.map((t) => t.id))
    }
  }

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    )
  }

  const handleDeleteCase = (id: string) => {
    setCasesList((prev) => prev.filter((item) => item.id !== id))
    setSelectedIds((prev) => prev.filter((item) => item !== id))
  }

  const handleExport = () => {
    const casesToExport =
      selectedIds.length > 0
        ? casesList.filter((t) => selectedIds.includes(t.id))
        : casesList

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      ['ID,Title,Description,Steps,Expected Result,Priority']
        .concat(
          casesToExport.map(
            (t) =>
              `"${t.id}","${t.title}","${t.description.replace(/"/g, '""')}","${t.steps.replace(/"/g, '""')}","${t.expectedResult.replace(/"/g, '""')}","${t.priority}"`
          )
        )
        .join('\n')
    const encodedUri = encodeURI(csvContent)
    const link = document.createElement('a')
    link.setAttribute('href', encodedUri)
    link.setAttribute('download', 'generated_testcases.csv')
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Generated Testcases"
        action={
          <div className="flex items-center gap-3">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {selectedIds.length} of {casesList.length} selected
            </span>
            <Button
              variant="secondary"
              onClick={handleExport}
              disabled={selectedIds.length === 0}
              className="gap-1.5 text-xs font-semibold disabled:opacity-50"
            >
              <Upload className="h-3.5 w-3.5" />
              Export {selectedIds.length > 0 ? `(${selectedIds.length})` : ''}
            </Button>
            <Button
              variant="primary"
              onClick={() => {
                const selectedCases = casesList.filter((t) => selectedIds.includes(t.id))
                navigate('/scripts/rammas-validation', {
                  state: { selectedCases }
                })
              }}
              disabled={selectedIds.length === 0}
              className="gap-1.5 text-xs font-semibold disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-teal-600/20"
            >
              <Code2 className="h-3.5 w-3.5" />
              Generate Script {selectedIds.length > 0 ? `(${selectedIds.length})` : ''}
            </Button>
          </div>
        }
      />
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                <th className="py-3 pr-3 w-10">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    ref={(el) => {
                      if (el) el.indeterminate = isSomeSelected
                    }}
                    onChange={toggleSelectAll}
                    aria-label="Select all test cases"
                    className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 dark:border-slate-700 dark:bg-slate-800 cursor-pointer"
                  />
                </th>
                <th className="pr-4 py-3 font-medium">ID</th>
                <th className="pr-4 py-3 font-medium">Test Case</th>
                <th className="pr-4 py-3 font-medium">Description</th>
                <th className="pr-4 py-3 font-medium">Steps</th>
                <th className="pr-4 py-3 font-medium">Expected result</th>
                <th className="pr-4 py-3 font-medium">Priority</th>
                <th className="py-3 pr-4 text-center font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {casesList.map((item) => {
                const isSelected = selectedIds.includes(item.id)
                return (
                  <tr
                    key={item.id}
                    onClick={() => toggleSelectRow(item.id)}
                    className={`cursor-pointer border-b border-slate-200 transition dark:border-slate-700 ${isSelected
                      ? 'bg-teal-50/50 hover:bg-teal-50 dark:bg-teal-950/20 dark:hover:bg-teal-950/30'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      }`}
                  >
                    <td className="py-3 pr-3" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectRow(item.id)}
                        aria-label={`Select ${item.title}`}
                        className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 dark:border-slate-700 dark:bg-slate-800 cursor-pointer"
                      />
                    </td>
                    <td className="py-3 pr-4 font-medium">{item.id}</td>
                    <td className="py-3 pr-4 font-medium text-slate-900 dark:text-slate-100">{item.title}</td>
                    <td className="py-3 pr-4">{item.description}</td>
                    <td className="py-3 pr-4">{item.steps}</td>
                    <td className="py-3 pr-4">{item.expectedResult}</td>
                    <td className="py-3 pr-4">{item.priority}</td>
                    <td className="py-3 pr-4" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => setViewingCase(item)}
                          className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-blue-200 bg-blue-50/80 text-blue-600 shadow-sm transition hover:border-blue-600 hover:bg-blue-600 hover:text-white hover:shadow-md dark:border-blue-900/60 dark:bg-blue-950/40 dark:text-blue-400 dark:hover:border-blue-500 dark:hover:bg-blue-600 dark:hover:text-white"
                          aria-label={`View ${item.id}`}
                          title="View Details"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteCase(item.id)}
                          className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-red-200 bg-red-50/80 text-red-600 shadow-sm transition hover:border-red-600 hover:bg-red-600 hover:text-white hover:shadow-md dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-400 dark:hover:border-red-500 dark:hover:bg-red-600 dark:hover:text-white"
                          aria-label={`Delete ${item.id}`}
                          title="Delete Test Case"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* View Test Case Modal */}
      {viewingCase && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-sm">
          <div className="w-full max-w-xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <span className="rounded-lg bg-teal-50 px-2.5 py-1 text-xs font-bold text-teal-700 dark:bg-teal-950 dark:text-teal-300">
                  {viewingCase.id}
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {viewingCase.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setViewingCase(null)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 space-y-3.5 text-xs">
              <div>
                <span className="font-semibold text-slate-500 dark:text-slate-400">Description:</span>
                <p className="mt-1 text-slate-700 dark:text-slate-300">{viewingCase.description}</p>
              </div>
              <div>
                <span className="font-semibold text-slate-500 dark:text-slate-400">Steps:</span>
                <div className="mt-1.5 space-y-2 rounded-xl border border-slate-200/80 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-800/60">
                  {(() => {
                    const steps = viewingCase.steps.includes('\n')
                      ? viewingCase.steps
                        .split('\n')
                        .map((s) => s.replace(/^\d+[\.\)]\s*/, '').trim())
                        .filter(Boolean)
                      : viewingCase.steps
                        .split(/(?:^|\s+)(?=\d+[\.\)]\s+)/)
                        .map((s) => s.replace(/^\d+[\.\)]\s*/, '').trim())
                        .filter(Boolean)
                    const finalSteps = steps.length > 0 ? steps : [viewingCase.steps]
                    return finalSteps.map((step, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs">
                        <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-teal-100 text-[11px] font-bold text-teal-700 dark:bg-teal-950 dark:text-teal-300">
                          {idx + 1}
                        </span>
                        <span className="font-mono leading-relaxed text-slate-800 dark:text-slate-200">
                          {step}
                        </span>
                      </div>
                    ))
                  })()}
                </div>
              </div>
              <div>
                <span className="font-semibold text-slate-500 dark:text-slate-400">Expected Result:</span>
                <p className="mt-1 rounded-lg bg-emerald-50/60 p-2.5 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300">
                  {viewingCase.expectedResult}
                </p>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <span className="font-semibold text-slate-500 dark:text-slate-400">Priority:</span>
                <span
                  className={`rounded-full px-2.5 py-0.5 text-[10px] font-semibold ${viewingCase.priority === 'High'
                    ? 'bg-red-100 text-red-700 dark:bg-red-950/50 dark:text-red-300'
                    : viewingCase.priority === 'Medium'
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300'
                      : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                >
                  {viewingCase.priority}
                </span>
              </div>
            </div>

            <div className="mt-5 flex justify-end border-t border-slate-100 pt-3 dark:border-slate-800">
              <Button variant="secondary" onClick={() => setViewingCase(null)} className="h-8 px-4 text-xs">
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function ScriptReviewPage() {
  const location = useLocation()
  const navigate = useNavigate()
  const stateSelectedCases = (location.state as { selectedCases?: TestCase[] } | null)?.selectedCases
  const activeCases = stateSelectedCases && stateSelectedCases.length > 0 ? stateSelectedCases : testCases

  const generateScenarioScript = (tc: TestCase) => {
    const funcName = `test_${tc.id.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_${tc.title.toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 30).replace(/^_+|_+$/g, '')}`
    const stepsArray = tc.steps.includes('\n')
      ? tc.steps.split('\n').map((s) => s.replace(/^\d+[\.\)]\s*/, '').trim()).filter(Boolean)
      : tc.steps.split(/(?:^|\s+)(?=\d+[\.\)]\s+)/).map((s) => s.replace(/^\d+[\.\)]\s*/, '').trim()).filter(Boolean)
    const formattedSteps = (stepsArray.length > 0 ? stepsArray : [tc.steps])
      .map((s, idx) => `    # Step ${idx + 1}: ${s}\n    page.wait_for_timeout(300)`)
      .join('\n\n')

    return `from playwright.sync_api import Page, expect
import pytest

"""
Test Scenario: ${tc.title}
Case ID: ${tc.id}
Priority: ${tc.priority}
Description: ${tc.description}
Expected Result: ${tc.expectedResult}
"""

def ${funcName}(page: Page):
    # Step 0: Initialize and open target application
    page.goto("https://demo.rammas.ai")
    page.wait_for_load_state("networkidle")

${formattedSteps}

    # Step final: Validate assertion matching expected result
    # Expected: ${tc.expectedResult}
    expect(page.locator("body")).to_be_visible()
    print("✓ Scenario [${tc.id}] '${tc.title}' executed successfully.")
`
  }

  const scenarioFiles = useMemo(() => {
    return activeCases.map((tc) => {
      const sanitizedTitle = tc.title.toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 28).replace(/^_+|_+$/g, '')
      const fileName = `test_${tc.id.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_${sanitizedTitle}.py`
      return {
        path: `tests/scenarios/${fileName}`,
        name: fileName,
        case: tc,
        category: 'scenario' as const,
        language: 'python',
        content: generateScenarioScript(tc),
      }
    })
  }, [activeCases])

  const allFiles = scenarioFiles
  const [selectedFilePath, setSelectedFilePath] = useState<string>(scenarioFiles[0]?.path || '')
  const [selectedScenarioPaths, setSelectedScenarioPaths] = useState<string[]>(() =>
    scenarioFiles.map((f) => f.path)
  )
  const [fileContents, setFileContents] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {}
    for (const file of scenarioFiles) {
      initial[file.path] = file.content
    }
    return initial
  })

  const toggleSelectScenario = (path: string) => {
    setSelectedScenarioPaths((prev) =>
      prev.includes(path) ? prev.filter((p) => p !== path) : [...prev, path]
    )
  }

  const toggleSelectAllScenarios = () => {
    if (selectedScenarioPaths.length === scenarioFiles.length) {
      setSelectedScenarioPaths([])
    } else {
      setSelectedScenarioPaths(scenarioFiles.map((f) => f.path))
    }
  }

  useEffect(() => {
    if (scenarioFiles.length > 0 && !scenarioFiles.some((f) => f.path === selectedFilePath)) {
      setSelectedFilePath(scenarioFiles[0].path)
    }
    setSelectedScenarioPaths(scenarioFiles.map((f) => f.path))
    setFileContents((prev) => {
      const next = { ...prev }
      for (const file of scenarioFiles) {
        if (!next[file.path]) {
          next[file.path] = file.content
        }
      }
      return next
    })
  }, [scenarioFiles, selectedFilePath])

  const currentFile = allFiles.find((f) => f.path === selectedFilePath) || allFiles[0]
  const currentCode = fileContents[currentFile.path] ?? currentFile.content

  const [copied, setCopied] = useState(false)
  const [isValidated, setIsValidated] = useState(false)

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleValidate = () => {
    setIsValidated(true)
    setTimeout(() => setIsValidated(false), 3000)
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Scripts"
        action={
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              onClick={handleCopyCode}
              className="gap-1.5 text-xs font-semibold"
            >
              <FileText className="h-3.5 w-3.5" />
              {copied ? 'Copied!' : 'Copy Code'}
            </Button>
            <Button
              variant="secondary"
              onClick={handleValidate}
              className="gap-1.5 text-xs font-semibold"
            >
              <CheckCircle2 className="h-3.5 w-3.5 text-teal-600" />
              {isValidated ? 'Validated ✓' : 'Validate'}
            </Button>
            <Button
              variant="primary"
              onClick={() =>
                navigate('/runs/run-1985/live', {
                  state: {
                    selectedScenarios: scenarioFiles.filter((f) =>
                      selectedScenarioPaths.includes(f.path)
                    ),
                  },
                })
              }
              disabled={selectedScenarioPaths.length === 0}
              className="gap-1.5 text-xs font-semibold shadow-md shadow-teal-600/20 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              {selectedScenarioPaths.length > 0
                ? `Run Selected (${selectedScenarioPaths.length} Scenario${
                    selectedScenarioPaths.length > 1 ? 's' : ''
                  })`
                : 'Select Scenarios to Run'}
            </Button>
          </div>
        }
      />

      {isValidated && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-800 dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            <span className="font-semibold">Syntax & Playwright API pre-flight check passed with 0 errors!</span>
          </div>
          <span className="text-[11px] opacity-80">Ready for automated execution</span>
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-[0.75fr_1.25fr]">
        {/* Scenarios List */}
        <SectionCard>
          <div className="space-y-4">
            {/* Scenarios Group */}
            <div>
              <div className="mb-2 flex items-center justify-between border-b border-slate-100 pb-2 dark:border-slate-800">
                <label className="flex items-center gap-2 cursor-pointer select-none text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={
                      selectedScenarioPaths.length > 0 &&
                      selectedScenarioPaths.length === scenarioFiles.length
                    }
                    onChange={toggleSelectAllScenarios}
                    className="h-3.5 w-3.5 rounded border-slate-300 text-teal-600 focus:ring-teal-500 dark:border-slate-700 dark:bg-slate-800 cursor-pointer"
                  />
                  <span>
                    Scenarios ({selectedScenarioPaths.length}/{scenarioFiles.length})
                  </span>
                </label>
                <span className="text-[10px] font-mono text-slate-400">tests/scenarios/</span>
              </div>

              <div className="space-y-1.5">
                {scenarioFiles.map((file) => {
                  const isActive = selectedFilePath === file.path
                  const isChecked = selectedScenarioPaths.includes(file.path)
                  return (
                    <div
                      key={file.path}
                      onClick={() => setSelectedFilePath(file.path)}
                      className={`group flex w-full items-center justify-between rounded-xl border p-2 text-left transition cursor-pointer ${
                        isActive
                          ? 'border-teal-500 bg-teal-50/80 shadow-sm ring-1 ring-teal-500/20 dark:border-teal-400 dark:bg-teal-950/40'
                          : 'border-slate-200 bg-slate-50/60 hover:border-slate-300 hover:bg-white dark:border-slate-700/80 dark:bg-slate-800/50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1 pr-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSelectScenario(file.path)}
                          onClick={(e) => e.stopPropagation()}
                          aria-label={`Select ${file.case.id} for run`}
                          className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 dark:border-slate-700 dark:bg-slate-800 cursor-pointer shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`rounded px-1.5 py-0.5 text-[10px] font-bold shrink-0 ${
                                isActive
                                  ? 'bg-teal-600 text-white'
                                  : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                              }`}
                            >
                              {file.case.id}
                            </span>
                            <span
                              className={`truncate text-xs font-semibold ${
                                isActive
                                  ? 'text-teal-950 dark:text-teal-100'
                                  : 'text-slate-800 dark:text-slate-200'
                              }`}
                            >
                              {file.name}
                            </span>
                          </div>
                          <p className="mt-0.5 truncate text-[11px] text-slate-500 dark:text-slate-400">
                            {file.case.title}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            navigate('/runs/run-1985/live', {
                              state: { selectedScenarios: [file] },
                            })
                          }}
                          title={`Run ${file.case.id}`}
                          className="rounded-lg p-1.5 text-slate-400 hover:bg-teal-600 hover:text-white dark:hover:bg-teal-600 transition"
                        >
                          <Play className="h-3 w-3" />
                        </button>
                        {isActive && (
                          <div className="h-2 w-2 rounded-full bg-teal-500" />
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </SectionCard>

        {/* Monaco Editor Card */}
        <SectionCard title={currentFile.path}>
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <span className="font-mono text-[11px] text-teal-700 dark:text-teal-300 font-semibold">
                {currentFile.language === 'python' ? 'Playwright Sync Python 3.11' : 'Markdown Spec'}
              </span>
              <span>{currentCode.split('\n').length} lines</span>
            </div>

            <div className="h-[560px] overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-700">
              <Editor
                height="100%"
                language={currentFile.language}
                value={currentCode}
                onChange={(val) => {
                  if (val !== undefined) {
                    setFileContents((prev) => ({ ...prev, [currentFile.path]: val }))
                  }
                }}
                theme="vs-dark"
                options={{
                  minimap: { enabled: false },
                  fontSize: 13,
                  lineNumbers: 'on',
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  padding: { top: 14, bottom: 14 },
                }}
              />
            </div>
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

function RunsPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Runs" action={<Button variant="primary">Run Test</Button>} />
      <SectionCard title="Run configuration">
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          <Field label="Browser"><select defaultValue="chromium" className="field"><option>Chromium</option><option>Firefox</option><option>WebKit</option></select></Field>
          <Field label="Mode"><select defaultValue="headless" className="field"><option>Headless</option><option>Headed</option></select></Field>
          <Field label="Workers"><input defaultValue="3" className="field" /></Field>
          <Field label="Retries"><input defaultValue="2" className="field" /></Field>
          <Field label="Viewport"><input defaultValue="1280x720" className="field" /></Field>
          <Field label="Video"><select defaultValue="On" className="field"><option>On</option><option>Off</option></select></Field>
          <Field label="Screenshot"><select defaultValue="On" className="field"><option>On</option><option>Off</option></select></Field>
          <Field label="Trace"><select defaultValue="On" className="field"><option>On</option><option>Off</option></select></Field>
        </div>
      </SectionCard>
    </div>
  )
}

function RunDetailPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Run - RUN-1985" action={<Button variant="primary">View Live</Button>} />
      <div className="grid gap-6 xl:grid-cols-4">
        <MetricCard label="Duration" value="08m 22s" detail="+32s vs baseline" tone="blue" />
        <MetricCard label="Passed" value="15" detail="94%" tone="green" />
        <MetricCard label="Failed" value="1" detail="1 issue" tone="red" />
        <MetricCard label="Status" value="Failed" detail="Needs review" tone="amber" />
      </div>
    </div>
  )
}

function LiveExecutionPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Live execution" action={<Button variant="secondary">Cancel</Button>} />
      <div className="grid gap-6 xl:grid-cols-[1fr_1.2fr_0.8fr]">
        <SectionCard title="Agent workflow">
          <div className="h-[320px]">
            <ReactFlow nodes={agentFlowNodes.slice(0, 5)} edges={agentFlowEdges.slice(0, 4)} fitView className="rounded-2xl border border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-800/60">
              <Background />
              <Controls />
            </ReactFlow>
          </div>
        </SectionCard>

        <SectionCard title="Execution console">
          <div className="space-y-2 rounded-2xl border border-slate-200 bg-slate-950 p-3 text-xs text-slate-200 dark:border-slate-700">
            {[
              '[08:14:02] INFO Planner created test plan',
              '[08:14:12] INFO Generator mapped locator set',
              '[08:15:46] INFO Validator passed preflight',
              '[08:16:12] WARN Preflight network slow',
              '[08:16:55] INFO Executor clicked top channel',
              '[08:17:18] ERROR Assertion mismatch on count',
            ].map((line) => (
              <div key={line}>{line}</div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Execution summary">
          <div className="space-y-3 text-sm">
            {['Planner ✓', 'Generator ✓', 'Validator ✓', 'Pre-flight ✓', 'Executor ●', 'Analyzer ○', 'Reporter ○'].map((item) => (
              <div key={item} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 dark:border-slate-700 dark:bg-slate-800/60">{item}</div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

function ReportPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Test report" action={<div className="flex gap-2"><Button variant="secondary">Export Markdown</Button><Button variant="primary">Export HTML</Button></div>} />
      <div className="grid gap-6 xl:grid-cols-4">
        <MetricCard label="Total" value="35" detail="Across suite" tone="blue" />
        <MetricCard label="Passed" value="29" detail="83%" tone="green" />
        <MetricCard label="Failed" value="6" detail="17%" tone="red" />
        <MetricCard label="Pass rate" value="83%" detail="-3% vs baseline" tone="amber" />
      </div>
      <SectionCard title="Failure details">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                <th className="pr-4 py-3 font-medium">Test case</th>
                <th className="pr-4 py-3 font-medium">Status</th>
                <th className="pr-4 py-3 font-medium">Category</th>
                <th className="pr-4 py-3 font-medium">Reason</th>
                <th className="pr-4 py-3 font-medium">Suggested fix</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-200 dark:border-slate-700">
                <td className="py-3 pr-4">TC-2101</td>
                <td className="py-3 pr-4"><StatusPill status="Failed" /></td>
                <td className="py-3 pr-4">Locator changed</td>
                <td className="py-3 pr-4">Selector #user-name no longer exists</td>
                <td className="py-3 pr-4">Update to [data-testid='username-input']</td>
              </tr>
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}

function VersionsPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Version compare" action={<Button variant="primary">Compare Versions</Button>} />
      <div className="grid gap-6 xl:grid-cols-4">
        <MetricCard label="Added" value="8" detail="New locators" tone="green" />
        <MetricCard label="Removed" value="3" detail="Legacy selectors" tone="red" />
        <MetricCard label="Changed" value="12" detail="Modified selectors" tone="amber" />
        <MetricCard label="Renamed" value="5" detail="Naming mismatches" tone="purple" />
      </div>
      <SectionCard title="Version delta">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                <th className="pr-4 py-3 font-medium">Page</th>
                <th className="pr-4 py-3 font-medium">Locator key</th>
                <th className="pr-4 py-3 font-medium">Old value</th>
                <th className="pr-4 py-3 font-medium">New value</th>
                <th className="pr-4 py-3 font-medium">Attribute</th>
                <th className="pr-4 py-3 font-medium">Severity</th>
              </tr>
            </thead>
            <tbody>
              {diffRows.map((row) => (
                <tr key={`${row.page}-${row.locator}`} className="border-b border-slate-200 dark:border-slate-700">
                  <td className="py-3 pr-4">{row.page}</td>
                  <td className="py-3 pr-4">{row.locator}</td>
                  <td className="py-3 pr-4">{row.oldValue}</td>
                  <td className="py-3 pr-4">{row.newValue}</td>
                  <td className="py-3 pr-4">{row.attribute}</td>
                  <td className="py-3 pr-4">{row.severity}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}

function ImpactAnalysisPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Impact analysis" />
      <SectionCard title="Affected locators">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                <th className="pr-4 py-3 font-medium">Locator</th>
                <th className="pr-4 py-3 font-medium">Changed from</th>
                <th className="pr-4 py-3 font-medium">Changed to</th>
                <th className="pr-4 py-3 font-medium">Affected page</th>
                <th className="pr-4 py-3 font-medium">Affected tests</th>
                <th className="pr-4 py-3 font-medium">Risk</th>
              </tr>
            </thead>
            <tbody>
              {impactRows.map((row) => (
                <tr key={row.locator} className="border-b border-slate-200 dark:border-slate-700">
                  <td className="py-3 pr-4">{row.locator}</td>
                  <td className="py-3 pr-4">{row.changedFrom}</td>
                  <td className="py-3 pr-4">{row.changedTo}</td>
                  <td className="py-3 pr-4">{row.affectedPage}</td>
                  <td className="py-3 pr-4">{row.affectedTests}</td>
                  <td className="py-3 pr-4">{row.risk}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}

function PatchReviewPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Patch review" action={<Button variant="primary">Approve patch</Button>} />
      <SectionCard title="Suggested patch">
        <div className="grid gap-6 xl:grid-cols-2">
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800/60">
            <div className="text-xs uppercase tracking-[0.18em] text-slate-500">Old locator</div>
            <div className="mt-2 font-mono text-sm">#username</div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800/60">
            <div className="text-xs uppercase tracking-[0.18em] text-slate-500">New locator</div>
            <div className="mt-2 font-mono text-sm">[data-testid='username-input']</div>
          </div>
        </div>
        <div className="mt-5 rounded-2xl border border-teal-200 bg-teal-50 p-4 text-sm text-teal-800 dark:border-teal-900 dark:bg-teal-950/40 dark:text-teal-200">
          AI explanation: “3 test cases are affected because the username locator changed after the latest page rewrite. The new stable ID preserves accessibility and reduces ambiguity.”
        </div>
      </SectionCard>
    </div>
  )
}

function SettingsPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Settings" />
      <div className="grid gap-6 xl:grid-cols-2">
        <SectionCard title="AI Providers">
          <div className="space-y-3">
            {providers.map((provider) => (
              <div key={provider.name} className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800/60">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-medium">{provider.name}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{provider.model}</div>
                  </div>
                  <StatusPill status={provider.status} />
                </div>
                <div className="mt-3 flex justify-between text-xs text-slate-600 dark:text-slate-300">
                  <span>Temp {provider.temperature}</span>
                  <span>Latency {provider.latency}ms</span>
                  <span>Cost ${provider.cost}/1k</span>
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Security">
          <div className="space-y-4">
            <Field label="API key"><input type="password" defaultValue="•••••••••••••••••••••" className="field" /></Field>
            <Field label="JWT refresh token"><input type="password" defaultValue="•••••••••••••••••••••" className="field" /></Field>
            <Field label="Project secret"><input type="password" defaultValue="•••••••••••••••••••••" className="field" /></Field>
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

function ProviderComparisonPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Provider comparison" />
      <SectionCard title="Metrics">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                <th className="pr-4 py-3 font-medium">Provider</th>
                <th className="pr-4 py-3 font-medium">Model</th>
                <th className="pr-4 py-3 font-medium">Compile rate</th>
                <th className="pr-4 py-3 font-medium">Pass rate</th>
                <th className="pr-4 py-3 font-medium">Tokens</th>
                <th className="pr-4 py-3 font-medium">Latency</th>
                <th className="pr-4 py-3 font-medium">Cost</th>
              </tr>
            </thead>
            <tbody>
              {providers.map((provider) => (
                <tr key={provider.name} className="border-b border-slate-200 dark:border-slate-700">
                  <td className="py-3 pr-4">{provider.name}</td>
                  <td className="py-3 pr-4">{provider.model}</td>
                  <td className="py-3 pr-4">{provider.passRate}%</td>
                  <td className="py-3 pr-4">{provider.passRate}%</td>
                  <td className="py-3 pr-4">486k</td>
                  <td className="py-3 pr-4">{provider.latency}ms</td>
                  <td className="py-3 pr-4">${provider.cost}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}

function UsersPage() {
  const { user } = useAuth()
  const isAdmin = user?.role === 'Admin'

  const [users, setUsers] = useState<DirectoryUser[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const loadUsers = async () => {
    setLoading(true)
    setError(null)
    try {
      setUsers(await listUsers())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load users')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (isAdmin) {
      void loadUsers()
    } else {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin])

  const handleRoleChange = async (id: string, role: ApiRole) => {
    setBusyId(id)
    setError(null)
    try {
      const updated = await updateUserRole(id, role)
      setUsers((prev) => prev.map((u) => (u.id === id ? updated : u)))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update role')
    } finally {
      setBusyId(null)
    }
  }

  const handleStatusToggle = async (u: DirectoryUser) => {
    setBusyId(u.id)
    setError(null)
    try {
      const updated = await updateUserStatus(u.id, !u.is_active)
      setUsers((prev) => prev.map((x) => (x.id === u.id ? updated : x)))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update status')
    } finally {
      setBusyId(null)
    }
  }

  if (!isAdmin) {
    return (
      <div className="space-y-6">
        <SectionHeader title="Users" />
        <SectionCard title="Access restricted">
          <div className="flex items-center gap-3 text-sm text-slate-600 dark:text-slate-300">
            <ShieldCheck className="h-5 w-5 text-teal-600" />
            <span>User management is available to Admin accounts only. Your role is <strong>{user?.role ?? 'Employee'}</strong>.</span>
          </div>
        </SectionCard>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Users"
        action={
          <Button variant="secondary" onClick={() => void loadUsers()}>
            <RefreshCw className="mr-1.5 h-4 w-4" /> Refresh
          </Button>
        }
      />
      <SectionCard title="User directory">
        {error && (
          <div className="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-800 dark:border-red-800 dark:bg-red-950/50 dark:text-red-200">
            {error}
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-700 dark:text-slate-400">
                <th className="pr-4 py-3 font-medium">Name</th>
                <th className="pr-4 py-3 font-medium">Email</th>
                <th className="pr-4 py-3 font-medium">Username</th>
                <th className="pr-4 py-3 font-medium">Role</th>
                <th className="pr-4 py-3 font-medium">Status</th>
                <th className="pr-4 py-3 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="py-6 text-center text-slate-400">Loading users...</td></tr>
              ) : users.length === 0 ? (
                <tr><td colSpan={6} className="py-6 text-center text-slate-400">No users found.</td></tr>
              ) : (
                users.map((row) => (
                  <tr key={row.id} className="border-b border-slate-200 dark:border-slate-700">
                    <td className="py-3 pr-4">{row.name}</td>
                    <td className="py-3 pr-4">{row.email}</td>
                    <td className="py-3 pr-4 text-slate-500">{row.username}</td>
                    <td className="py-3 pr-4">
                      <select
                        value={row.role === 'Admin' ? 'Admin' : 'Employee'}
                        disabled={busyId === row.id || row.id === user?.id}
                        onChange={(e) => void handleRoleChange(row.id, e.target.value as ApiRole)}
                        className="rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs dark:border-slate-700 dark:bg-slate-800 disabled:opacity-50"
                        title={row.id === user?.id ? 'You cannot change your own role' : 'Change role'}
                      >
                        <option value="Admin">Admin</option>
                        <option value="Employee">Employee</option>
                      </select>
                    </td>
                    <td className="py-3 pr-4"><StatusPill status={row.is_active ? 'Active' : 'Inactive'} /></td>
                    <td className="py-3 pr-4">
                      <button
                        type="button"
                        disabled={busyId === row.id || row.id === user?.id}
                        onClick={() => void handleStatusToggle(row)}
                        className="rounded-lg border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-600 hover:border-teal-500 hover:text-teal-600 disabled:opacity-50 dark:border-slate-700 dark:text-slate-300"
                        title={row.id === user?.id ? 'You cannot disable your own account' : 'Toggle active status'}
                      >
                        {row.is_active ? 'Disable' : 'Enable'}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  )
}

function OnboardingPage() {
  const steps = [
    'Create Project',
    'Configure Application',
    'Harvest Locators',
    'Create AI Test',
    'Review Test Case',
    'Generate Script',
    'Run Test',
    'View Report',
  ]

  return (
    <div className="space-y-6">
      <SectionHeader title="Onboarding" action={<Button variant="primary">Finish</Button>} />
      <SectionCard title="Rammas Validation">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {steps.map((step, index) => (
            <div key={step} className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800/60">
              <div className="mb-3 flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-xs font-semibold text-white">{index + 1}</div>
              <div className="text-sm font-medium">{step}</div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  )
}

function SectionHeader({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900 dark:text-white">{title}</h1>
      </div>
      {action}
    </div>
  )
}

function SectionCard({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900">
      {title && (
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">{title}</h2>
        </div>
      )}
      {children}
    </section>
  )
}

function MetricCard({ label, value, detail, tone }: { label: string; value: string; detail: string; tone: 'blue' | 'purple' | 'green' | 'red' | 'amber' }) {
  const palette = {
    blue: 'bg-teal-50 text-teal-700 ring-teal-100 dark:bg-teal-950/40 dark:text-teal-200 dark:ring-teal-900',
    purple: 'bg-purple-50 text-purple-700 ring-purple-100 dark:bg-purple-950/40 dark:text-purple-200 dark:ring-purple-900',
    green: 'bg-green-50 text-green-700 ring-green-100 dark:bg-green-950/40 dark:text-green-200 dark:ring-green-900',
    red: 'bg-red-50 text-red-700 ring-red-100 dark:bg-red-950/40 dark:text-red-200 dark:ring-red-900',
    amber: 'bg-amber-50 text-amber-700 ring-amber-100 dark:bg-amber-950/40 dark:text-amber-200 dark:ring-amber-900',
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900">
      <div className={`mb-3 inline-flex rounded-full px-2.5 py-1.5 text-xs font-medium ring-1 ${palette[tone]}`}>{label}</div>
      <div className="text-2xl font-semibold text-slate-900 dark:text-white">{value}</div>
      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">{detail}</div>
    </div>
  )
}

function StatusPill({ status }: { status: string }) {
  const styles = {
    Healthy: 'bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-200',
    Passed: 'bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-200',
    Active: 'bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-200',
    Approved: 'bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-200',
    'Needs review': 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-200',
    Failed: 'bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-200',
    Broken: 'bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-200',
    Ambiguous: 'bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-200',
    Moved: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-950/40 dark:text-yellow-200',
    Fragile: 'bg-purple-100 text-purple-700 dark:bg-purple-950/40 dark:text-purple-200',
    Inactive: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200',
    Draft: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200',
    Running: 'bg-teal-100 text-teal-700 dark:bg-teal-950/40 dark:text-teal-200',
    Queued: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200',
    'Started': 'bg-teal-100 text-teal-700 dark:bg-teal-950/40 dark:text-teal-200',
    Disabled: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200',
    Fallback: 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-200',
    'Low': 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200',
    'Medium': 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-200',
    'High': 'bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-200',
  }

  return <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${styles[status as keyof typeof styles] ?? 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200'}`}>{status}</span>
}

function ProgressRow({ label, value, total }: { label: string; value: number; total: number }) {
  const pct = (value / total) * 100
  return (
    <div>
      <div className="mb-2 flex items-center justify-between text-sm text-slate-600 dark:text-slate-300">
        <span>{label}</span>
        <span>{value}/{total}</span>
      </div>
      <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
        <div className="h-full rounded-full bg-teal-500" style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

function Button({
  children,
  className = '',
  variant = 'primary',
  disabled = false,
  onClick,
}: {
  children: ReactNode
  className?: string
  variant?: 'primary' | 'secondary'
  disabled?: boolean
  onClick?: () => void
}) {
  const styles = {
    primary: 'bg-teal-700 text-white hover:bg-teal-800 disabled:bg-teal-700/50 disabled:cursor-not-allowed',
    secondary:
      'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700',
  }

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={`inline-flex items-center justify-center rounded-xl px-3.5 py-2 text-sm font-medium transition ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  )
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
      <span className="mb-2 block">{label}</span>
      {children}
    </label>
  )
}

export default App
