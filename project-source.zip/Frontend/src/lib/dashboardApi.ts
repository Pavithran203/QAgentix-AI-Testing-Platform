// Dashboard API client — DB-backed (MongoDB via the backend).
// Mirrors the auth/refresh pattern in subscriptionsApi.ts / workspaceApi.ts.
// The camelCase JSON the backend (FEAT-001) returns matches the TS types below
// exactly. UNAVAILABLE metrics (totalTestCases, locatorIssues, locator-health)
// come back as null / [] and must render as an unavailable/empty state — never
// as fabricated values.

import { tokenStore, apiRefresh } from './authApi'

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

// ---- Response types (camelCase, mirroring the FEAT-001 contract) ----

export type TimeRange = {
  start: string | null
  end: string | null
}

export type Summary = {
  totalProjects: number
  totalTestCases: number | null
  totalRuns: number
  passRate: number | null
  failedTests: number
  locatorIssues: number | null
  timeRange: TimeRange
  lastUpdated: string
}

export type PassRatePoint = {
  period: string
  passed: number
  failed: number
  passRate: number | null
}

export type ExecutionPoint = {
  period: string
  executionCount: number
}

export type FailureCategoryPoint = {
  category: string
  count: number
}

export type LocatorHealthPoint = {
  status: string
  count: number
  percentage: number
  populationCount: number
}

export type RecentRunRow = {
  id: string
  project: string
  suite: string
  started: string
  duration: string | null
  passed: number
  failed: number
  status: string
}

export type RecentRuns = {
  items: RecentRunRow[]
  total: number
  page: number
  pageSize: number
}

export type TestResultRow = {
  testcaseRef: string | null
  status: string
  failureCategory: string | null
  durationMs: number | null
  executedAt: string
}

export type ArtifactRef = {
  kind: string
  filename: string
  ref: string
}

export type RunDetail = {
  id: string
  project: string
  suite: string
  started: string
  completed: string | null
  duration: string | null
  passed: number
  failed: number
  status: string
  results: TestResultRow[]
  artifacts: ArtifactRef[]
}

// ---- Query param shapes ----

export type TrendParams = {
  startDate?: string
  endDate?: string
  interval?: 'day' | 'week' | 'month'
}

export type FailureCategoryParams = {
  startDate?: string
  endDate?: string
}

export type RecentRunsParams = {
  page?: number
  pageSize?: number
  projectId?: string
  status?: string
  startDate?: string
  endDate?: string
}

// ---- Fetch plumbing (verbatim shape from subscriptionsApi.ts) ----

async function parseError(res: Response): Promise<string> {
  try {
    const data = await res.json()
    if (typeof data?.detail === 'string') return data.detail
    if (Array.isArray(data?.detail) && data.detail[0]?.msg) return data.detail[0].msg
  } catch {
    /* ignore */
  }
  return `Request failed (${res.status})`
}

async function authedFetch(path: string, init: RequestInit = {}, retry = true): Promise<Response> {
  const access = tokenStore.access
  const headers = new Headers(init.headers)
  if (access) headers.set('Authorization', `Bearer ${access}`)
  const res = await fetch(`${API_BASE}${path}`, { ...init, headers })
  if (res.status === 401 && retry) {
    const refreshed = await apiRefresh()
    if (refreshed) return authedFetch(path, init, false)
  }
  return res
}

async function getJson<T>(path: string): Promise<T> {
  const res = await authedFetch(path)
  if (!res.ok) throw new Error(await parseError(res))
  return res.json() as Promise<T>
}

function buildQuery(params: Record<string, string | number | undefined>): string {
  const search = new URLSearchParams()
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') {
      search.set(key, String(value))
    }
  }
  const qs = search.toString()
  return qs ? `?${qs}` : ''
}

// ---- Endpoints ----

export async function getSummary(): Promise<Summary> {
  return getJson<Summary>('/dashboard/summary')
}

export async function getPassRateTrend(params: TrendParams = {}): Promise<PassRatePoint[]> {
  const query = buildQuery({
    start_date: params.startDate,
    end_date: params.endDate,
    interval: params.interval,
  })
  return getJson<PassRatePoint[]>(`/dashboard/pass-rate-trend${query}`)
}

export async function getExecutionTrend(params: TrendParams = {}): Promise<ExecutionPoint[]> {
  const query = buildQuery({
    start_date: params.startDate,
    end_date: params.endDate,
    interval: params.interval,
  })
  return getJson<ExecutionPoint[]>(`/dashboard/execution-trend${query}`)
}

export async function getFailureCategories(params: FailureCategoryParams = {}): Promise<FailureCategoryPoint[]> {
  const query = buildQuery({
    start_date: params.startDate,
    end_date: params.endDate,
  })
  return getJson<FailureCategoryPoint[]>(`/dashboard/failure-categories${query}`)
}

export async function getLocatorHealth(): Promise<LocatorHealthPoint[]> {
  return getJson<LocatorHealthPoint[]>('/dashboard/locator-health')
}

export async function getRecentRuns(params: RecentRunsParams = {}): Promise<RecentRuns> {
  const query = buildQuery({
    page: params.page,
    page_size: params.pageSize,
    project_id: params.projectId,
    status: params.status,
    start_date: params.startDate,
    end_date: params.endDate,
  })
  return getJson<RecentRuns>(`/dashboard/recent-runs${query}`)
}

export async function getRun(runId: string): Promise<RunDetail> {
  return getJson<RunDetail>(`/runs/${encodeURIComponent(runId)}`)
}
