/**
 * chatStorage.ts — IndexedDB persistence layer for Agent Workspace chat sessions.
 *
 * Database: qagentix_chats (v1)
 * Object Store: chat_sessions (keyPath: "id")
 * Indexes: userId, updatedAt
 *
 * Each record wraps a ChatSession with the owning userId and an updatedAt
 * timestamp so we can scope queries per user and sort by recency.
 */

// ─── Types ───────────────────────────────────────────────────────────────────

/** Mirror of the ChatMessage interface defined in App.tsx */
export interface StoredChatAttachment {
  id: string
  name: string
  size: string
  type: string
  content?: string
}

export interface StoredTestCase {
  id: string
  title: string
  description: string
  steps: string[]
  expectedResult: string
  priority: 'High' | 'Medium' | 'Low'
  category: 'E2E' | 'Regression' | 'Boundary' | 'Security' | 'Smoke'
}

export interface StoredFile {
  path: string
  name: string
  language: string
  description: string
  content: string
}

export interface StoredBundle {
  title: string
  description: string
  summary: {
    totalCases: number
    positiveCount: number
    negativeCount: number
    edgeCount: number
    coverage: string
  }
  testCases: StoredTestCase[]
  files: StoredFile[]
}

export interface StoredChatMessage {
  id: string
  role: 'user' | 'assistant'
  timestamp: string
  content: string
  attachments?: StoredChatAttachment[]
  bundle?: StoredBundle
  isGenerating?: boolean
  generationStep?: number
}

export type StorageLocation = 'indexeddb' | 'filesystem' | 'memory'

/** The record persisted in IndexedDB or direct local file system. */
export interface StoredChatSession {
  id: string
  userId: string
  title: string
  project: string
  createdAt: string
  updatedAt: string
  messages: StoredChatMessage[]
  storageLocation?: StorageLocation
  localFolderName?: string
}

// ─── Constants ───────────────────────────────────────────────────────────────

const DB_NAME = 'qagentix_chats'
const DB_VERSION = 2
const STORE_NAME = 'chat_sessions'

// ─── Database Initialisation ─────────────────────────────────────────────────

/** Open (and create if needed) the IndexedDB database. */
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)

    request.onupgradeneeded = () => {
      const db = request.result
      let store: IDBObjectStore
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        store = db.createObjectStore(STORE_NAME, { keyPath: 'id' })
      } else {
        store = (request.transaction as IDBTransaction).objectStore(STORE_NAME)
      }
      if (!store.indexNames.contains('userId')) {
        store.createIndex('userId', 'userId', { unique: false })
      }
      if (!store.indexNames.contains('updatedAt')) {
        store.createIndex('updatedAt', 'updatedAt', { unique: false })
      }
      if (!store.indexNames.contains('project')) {
        store.createIndex('project', 'project', { unique: false })
      }
    }

    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

// ─── CRUD Operations ─────────────────────────────────────────────────────────

/**
 * Load all chat sessions belonging to a specific user, sorted by updatedAt
 * descending (newest first).
 */
export async function loadSessions(userId: string): Promise<StoredChatSession[]> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly')
    const store = tx.objectStore(STORE_NAME)
    const index = store.index('userId')
    const request = index.getAll(userId)

    request.onsuccess = () => {
      const sessions: StoredChatSession[] = request.result ?? []
      // Sort newest-first by updatedAt
      sessions.sort((a, b) => (b.updatedAt > a.updatedAt ? 1 : -1))
      resolve(sessions)
    }
    request.onerror = () => reject(request.error)
    tx.oncomplete = () => db.close()
  })
}

/**
 * Save (upsert) a single chat session.
 * Automatically stamps `updatedAt` to the current ISO time.
 */
export async function saveSession(userId: string, session: StoredChatSession): Promise<void> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite')
    const store = tx.objectStore(STORE_NAME)
    // Filter out sessions that are mid-generation (transient state)
    const cleanMessages = session.messages.map((m) => ({
      ...m,
      isGenerating: undefined,
      generationStep: undefined,
    }))
    store.put({
      ...session,
      userId,
      messages: cleanMessages,
      updatedAt: new Date().toISOString(),
    })
    tx.oncomplete = () => {
      db.close()
      resolve()
    }
    tx.onerror = () => {
      db.close()
      reject(tx.error)
    }
  })
}

/**
 * Bulk save all sessions for a user.
 * Removes any old sessions from the store that are no longer in the array.
 */
export async function saveSessions(userId: string, sessions: StoredChatSession[]): Promise<void> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite')
    const store = tx.objectStore(STORE_NAME)

    // First, delete any existing sessions for this user that aren't in the new list
    const index = store.index('userId')
    const cursorReq = index.openCursor(userId)
    const newIds = new Set(sessions.map((s) => s.id))

    cursorReq.onsuccess = () => {
      const cursor = cursorReq.result
      if (cursor) {
        if (!newIds.has(cursor.value.id)) {
          cursor.delete()
        }
        cursor.continue()
      }
    }

    // Then upsert all current sessions
    const now = new Date().toISOString()
    for (const session of sessions) {
      const cleanMessages = session.messages.map((m) => ({
        ...m,
        isGenerating: undefined,
        generationStep: undefined,
      }))
      store.put({
        ...session,
        userId,
        messages: cleanMessages,
        updatedAt: session.updatedAt || now,
      })
    }

    tx.oncomplete = () => {
      db.close()
      resolve()
    }
    tx.onerror = () => {
      db.close()
      reject(tx.error)
    }
  })
}

/**
 * Delete a single session by ID.
 */
export async function deleteSession(sessionId: string): Promise<void> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite')
    const store = tx.objectStore(STORE_NAME)
    store.delete(sessionId)
    tx.oncomplete = () => {
      db.close()
      resolve()
    }
    tx.onerror = () => {
      db.close()
      reject(tx.error)
    }
  })
}

/**
 * Clear ALL sessions belonging to a user.
 */
export async function clearAllSessions(userId: string): Promise<void> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite')
    const store = tx.objectStore(STORE_NAME)
    const index = store.index('userId')
    const cursorReq = index.openCursor(userId)

    cursorReq.onsuccess = () => {
      const cursor = cursorReq.result
      if (cursor) {
        cursor.delete()
        cursor.continue()
      }
    }

    tx.oncomplete = () => {
      db.close()
      resolve()
    }
    tx.onerror = () => {
      db.close()
      reject(tx.error)
    }
  })
}
