/**
 * Feature & TestCase Type Definitions and API Client for QAgentix
 * Aligned with Backend Pydantic Schemas in app/schemas/
 */

export type Priority = 'Critical' | 'High' | 'Medium' | 'Low'

export type TestCaseCategory =
  | 'Smoke'
  | 'E2E'
  | 'Regression'
  | 'Boundary'
  | 'Security'
  | 'Performance'
  | 'Integration'
  | 'Unit'

export type TestCaseStatus = 'Approved' | 'Draft' | 'Needs review' | 'Deprecated'

export type FeatureStatus = 'Draft' | 'In Review' | 'Approved' | 'Active' | 'Deprecated'

export type AutomationStatus = 'Automated' | 'Manual' | 'Candidate' | 'Obsolete'

export interface TestStep {
  stepNumber: number
  action: string
  expectedResult?: string | null
  testData?: any
}

export interface TraceabilityInfo {
  featureId?: string | null
  requirementIds?: string[]
  userStoryIds?: string[]
  sourceDocuments?: string[]
  targetUrl?: string | null
  scriptPath?: string | null
  testMethod?: string | null
  automationStatus?: AutomationStatus
  tags?: string[]
}

export interface TestCase {
  id: string
  title: string
  description?: string
  priority: Priority
  category?: TestCaseCategory
  status?: TestCaseStatus
  preconditions?: string[]
  steps: TestStep[] | string[] | string
  expectedResult: string
  traceability?: TraceabilityInfo
}

export interface FeatureTraceability {
  requirementIds?: string[]
  userStoryIds?: string[]
  sourceDocuments?: string[]
  targetUrl?: string | null
  epicId?: string | null
}

export interface Feature {
  id: string
  title: string
  description?: string
  priority: Priority
  status?: FeatureStatus
  userStory?: string | null
  traceability?: FeatureTraceability
  testCaseIds?: string[]
  tags?: string[]
  metadata?: Record<string, any>
}

export interface TraceabilityReport {
  feature_id: string
  feature_title: string
  total_requirements: number
  covered_requirements_count: number
  uncovered_requirements: string[]
  requirement_coverage_pct: number
  total_test_cases: number
  automated_test_cases_count: number
  automation_coverage_pct: number
  unlinked_test_cases: string[]
  requirement_to_test_cases: Record<string, string[]>
  is_fully_traced: boolean
}

export interface TraceabilityMatrixPayload {
  feature: Feature
  testCases: TestCase[]
}

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

export async function validateTestCaseApi(testCase: TestCase): Promise<{
  status: string
  testCase: TestCase
  gherkin: string
  markdown: string
  csvRow: Record<string, string>
}> {
  const res = await fetch(`${API_BASE}/test-design/testcase/validate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(testCase),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Validation failed' }))
    throw new Error(err.detail || `HTTP ${res.status}`)
  }
  return res.json()
}

export async function validateFeatureApi(feature: Feature): Promise<{
  status: string
  feature: Feature
  gherkin: string
  markdown: string
}> {
  const res = await fetch(`${API_BASE}/test-design/feature/validate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(feature),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Validation failed' }))
    throw new Error(err.detail || `HTTP ${res.status}`)
  }
  return res.json()
}

export async function verifyTraceabilityApi(payload: TraceabilityMatrixPayload): Promise<{
  status: string
  traceabilityReport: TraceabilityReport
}> {
  const res = await fetch(`${API_BASE}/test-design/traceability/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Verification failed' }))
    throw new Error(err.detail || `HTTP ${res.status}`)
  }
  return res.json()
}

export async function getTestDesignSamplesApi(): Promise<{
  feature: Feature
  testCases: TestCase[]
  traceabilityReport: TraceabilityReport
}> {
  const res = await fetch(`${API_BASE}/test-design/samples`)
  if (!res.ok) {
    throw new Error(`Failed to load samples (${res.status})`)
  }
  return res.json()
}
