/**
 * useChatPersistence.ts — React hook that syncs Agent Workspace chat sessions
 * to/from IndexedDB, scoped per logged-in user.
 *
 * Usage inside AgentWorkspacePage:
 *   const { sessions, setSessions, isLoaded, clearAll } = useChatPersistence(userId, projectName)
 *
 * Behaviour:
 *  - On mount: loads all sessions from IndexedDB for the given userId.
 *  - On sessions change: debounced auto-save (300ms) to IndexedDB.
 *  - Cleans up transient fields (isGenerating, generationStep) before persisting.
 */

import { useState, useEffect, useRef, useCallback } from 'react'
import {
  loadSessions,
  saveSessions,
  clearAllSessions,
  type StoredChatSession,
} from './chatStorage'
import { saveSessionToLocalFolder } from './fileSystemStorage'

/** The shape exposed to the consuming component. */
export interface ChatPersistenceResult {
  /** The current list of chat sessions (reactive). */
  sessions: StoredChatSession[]
  /** React state setter — use exactly like you would from useState. */
  setSessions: React.Dispatch<React.SetStateAction<StoredChatSession[]>>
  /** True once the initial load from IndexedDB has completed. */
  isLoaded: boolean
  /** Wipe all locally stored sessions for this user. */
  clearAll: () => Promise<void>
  /** Timestamp of the last successful save, or null if never saved. */
  lastSavedAt: Date | null
}

export function useChatPersistence(
  userId: string | undefined,
  defaultProject: string
): ChatPersistenceResult {
  const [sessions, setSessionsRaw] = useState<StoredChatSession[]>([])
  const [isLoaded, setIsLoaded] = useState(false)
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null)

  // Ref to skip the first save triggered by the initial load setting state
  const skipNextSave = useRef(true)
  // Debounce timer ref
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ─── Load on mount / user change ────────────────────────────────────────────
  useEffect(() => {
    if (!userId) {
      setSessionsRaw([])
      setLastSavedAt(null)
      setIsLoaded(true)
      return
    }

    let cancelled = false
    const load = async () => {
      try {
        const stored = await loadSessions(userId)
        if (cancelled) return

        if (stored.length > 0) {
          skipNextSave.current = true
          setSessionsRaw(stored)
        } else {
          // No stored sessions — create a fresh default one
          const freshSession: StoredChatSession = {
            id: `session-${Date.now()}`,
            userId,
            title: 'New Test Generation',
            project: defaultProject,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            messages: [],
          }
          skipNextSave.current = true
          setSessionsRaw([freshSession])
        }
      } catch (err) {
        console.error('[useChatPersistence] Failed to load from IndexedDB:', err)
        // Fall back to empty fresh session
        const freshSession: StoredChatSession = {
          id: `session-${Date.now()}`,
          userId,
          title: 'New Test Generation',
          project: defaultProject,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          messages: [],
        }
        skipNextSave.current = true
        setSessionsRaw([freshSession])
      } finally {
        if (!cancelled) setIsLoaded(true)
      }
    }
    void load()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId])

  // ─── Debounced auto-save on sessions change ─────────────────────────────────
  useEffect(() => {
    // Skip the save triggered by the initial load
    if (skipNextSave.current) {
      skipNextSave.current = false
      return
    }

    if (!userId || !isLoaded) return

    // Clear any pending save
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current)
    }

    // Debounce 300ms
    saveTimerRef.current = setTimeout(async () => {
      try {
        // 1. Sync filesystem sessions to local directory if configured
        for (const s of sessions) {
          if (s.storageLocation === 'filesystem') {
            void saveSessionToLocalFolder(s)
          }
        }

        // 2. Persist to IndexedDB (exclude ephemeral/memory sessions)
        const toPersist = sessions.filter((s) => s.storageLocation !== 'memory')
        const tagged = toPersist.map((s) => ({ ...s, userId }))
        await saveSessions(userId, tagged)
        setLastSavedAt(new Date())
      } catch (err) {
        console.error('[useChatPersistence] Failed to save sessions:', err)
      }
    }, 300)

    return () => {
      if (saveTimerRef.current) {
        clearTimeout(saveTimerRef.current)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessions, userId, isLoaded])

  // ─── Clear all sessions for this user ───────────────────────────────────────
  const clearAll = useCallback(async () => {
    if (!userId) return
    try {
      await clearAllSessions(userId)
      const freshSession: StoredChatSession = {
        id: `session-${Date.now()}`,
        userId,
        title: 'New Test Generation',
        project: defaultProject,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [],
      }
      skipNextSave.current = true
      setSessionsRaw([freshSession])
      setLastSavedAt(null)
    } catch (err) {
      console.error('[useChatPersistence] Failed to clear IndexedDB:', err)
    }
  }, [userId, defaultProject])

  return {
    sessions,
    setSessions: setSessionsRaw,
    isLoaded,
    clearAll,
    lastSavedAt,
  }
}
