// Workspace API client — browse the local filesystem (via backend) and store
// artifacts into the predefined structure inside a chosen folder.
// The backend owns all filesystem access.

import { tokenStore, apiRefresh } from './authApi'

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

export type BrowseResult = {
  path: string
  parent: string | null
  drives: string[]
  home: string
  folders: { name: string; path: string }[]
}

export type FileEntry = { name: string; size: number; modified: string }

export type ProjectTree = {
  name: string
  path: string
  folders: Record<string, FileEntry[]>
}

export type ArtifactKind = 'feature' | 'script' | 'testcase' | 'testdata' | 'report'
export type ArtifactFile = { kind: ArtifactKind; filename: string; content: string }

async function parseError(res: Response): Promise<string> {
  try {
    const data = await res.json()
    if (typeof data?.detail === 'string') return data.detail
    if (Array.isArray(data?.detail) && data.detail[0]?.msg) return data.detail[0].msg
  } catch {
    /* ignore */
  }
  return `Request failed (${res.status})`
}

async function authedFetch(path: string, init: RequestInit = {}, retry = true): Promise<Response> {
  const access = tokenStore.access
  const headers = new Headers(init.headers)
  if (access) headers.set('Authorization', `Bearer ${access}`)
  const res = await fetch(`${API_BASE}${path}`, { ...init, headers })
  if (res.status === 401 && retry) {
    const refreshed = await apiRefresh()
    if (refreshed) return authedFetch(path, init, false)
  }
  return res
}

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const res = await authedFetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(await parseError(res))
  return res.json() as Promise<T>
}

export async function getStructure(): Promise<{ subfolders: string[] }> {
  const res = await authedFetch('/workspace/structure')
  if (!res.ok) throw new Error(await parseError(res))
  return res.json()
}

// Browse the local filesystem. Pass '' to get drive roots + home.
export async function browse(path: string): Promise<BrowseResult> {
  return postJson('/workspace/browse', { path })
}

// Create a new folder inside an existing directory (while browsing).
export async function makeDir(parent: string, name: string): Promise<{ name: string; path: string; existed: boolean }> {
  return postJson('/workspace/mkdir', { parent, name })
}

// Create the predefined structure inside the chosen base folder.
export async function createStructure(base: string): Promise<{ name: string; path: string; subfolders: string[] }> {
  return postJson('/workspace/structure', { base })
}

export async function getTree(base: string): Promise<ProjectTree> {
  return postJson('/workspace/tree', { base })
}

export async function writeFiles(base: string, files: ArtifactFile[]): Promise<{ count: number }> {
  return postJson('/workspace/files/batch', { base, files })
}

// Create or modify a single file inside a subfolder (folder = "Scripts" etc.).
export async function saveFile(base: string, folder: string, filename: string, content: string): Promise<{ folder: string; name: string; path: string; size: number }> {
  return postJson('/workspace/files', { base, kind: folder, filename, content })
}

// Read a file's content for editing.
export async function readFile(base: string, folder: string, filename: string): Promise<{ folder: string; name: string; content: string }> {
  return postJson('/workspace/read', { base, folder, filename })
}
