// Admin user-management API client (RBAC).
// All endpoints require the Admin role on the backend.

import { tokenStore, apiRefresh } from './authApi'

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

export type Role = 'Admin' | 'Employee'

export type DirectoryUser = {
  id: string
  name: string
  email: string
  username: string
  role: string
  is_active: boolean
  created_at: string
  avatar: string
}

async function parseError(res: Response): Promise<string> {
  try {
    const data = await res.json()
    if (typeof data?.detail === 'string') return data.detail
    if (Array.isArray(data?.detail) && data.detail[0]?.msg) return data.detail[0].msg
  } catch {
    /* ignore */
  }
  return `Request failed (${res.status})`
}

async function authedFetch(path: string, init: RequestInit = {}, retry = true): Promise<Response> {
  const access = tokenStore.access
  const headers = new Headers(init.headers)
  if (access) headers.set('Authorization', `Bearer ${access}`)
  const res = await fetch(`${API_BASE}${path}`, { ...init, headers })
  if (res.status === 401 && retry) {
    const refreshed = await apiRefresh()
    if (refreshed) return authedFetch(path, init, false)
  }
  return res
}

export async function listUsers(): Promise<DirectoryUser[]> {
  const res = await authedFetch('/users')
  if (!res.ok) throw new Error(await parseError(res))
  return res.json() as Promise<DirectoryUser[]>
}

export async function updateUserRole(userId: string, role: Role): Promise<DirectoryUser> {
  const res = await authedFetch(`/users/${userId}/role`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ role }),
  })
  if (!res.ok) throw new Error(await parseError(res))
  return res.json() as Promise<DirectoryUser>
}

export async function updateUserStatus(userId: string, isActive: boolean): Promise<DirectoryUser> {
  const res = await authedFetch(`/users/${userId}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ is_active: isActive }),
  })
  if (!res.ok) throw new Error(await parseError(res))
  return res.json() as Promise<DirectoryUser>
}
