// Kiro IDE Agent API client
// Connects the QAgentix frontend to the backend Kiro IDE agent harness.

import { tokenStore, apiRefresh } from './authApi'

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

export type KiroStatus = {
  installed: boolean
  version: string | null
  cli_path: string
  mode: string
  message: string
  install_guide: string
}

export type KiroModelItem = {
  id: string
  name: string
  badge: string
  provider: string
  description: string
  context_window: string
  latency: string
  icon: string
}

export type KiroModelsResponse = {
  connected: boolean
  harness: string
  active_model: string
  models: KiroModelItem[]
}

export type KiroStepLog = {
  step_number: number
  title: string
  detail: string
  status: 'pending' | 'in_progress' | 'completed' | 'failed'
}

export type KiroGeneratedArtifact = {
  file_path: string
  relative_path: string
  category: 'script' | 'testcase' | 'feature' | 'report'
  content?: string
}

export type KiroExecuteRequest = {
  prompt: string
  workspace_path?: string
  document_content?: string
  document_name?: string
  session_id?: string
  timeout_seconds?: number
  trust_all_tools?: boolean
  model?: string
}

export type KiroExecuteResponse = {
  session_id: string
  status: string
  connected_surface: string
  response: string
  steps: KiroStepLog[]
  artifacts: KiroGeneratedArtifact[]
  execution_time_seconds: number
  error?: string
  model_used?: string
}

async function parseError(res: Response): Promise<string> {
  try {
    const data = await res.json()
    if (typeof data?.detail === 'string') return data.detail
    if (Array.isArray(data?.detail) && data.detail[0]?.msg) return data.detail[0].msg
  } catch {
    /* ignore */
  }
  return `Request failed (${res.status})`
}

async function authedFetch(path: string, init: RequestInit = {}, retry = true): Promise<Response> {
  const access = tokenStore.access
  const headers = new Headers(init.headers)
  if (access) headers.set('Authorization', `Bearer ${access}`)
  const res = await fetch(`${API_BASE}${path}`, { ...init, headers })
  if (res.status === 401 && retry) {
    const refreshed = await apiRefresh()
    if (refreshed) return authedFetch(path, init, false)
  }
  return res
}

export async function getKiroStatus(): Promise<KiroStatus> {
  const res = await authedFetch('/agent/kiro/status')
  if (!res.ok) throw new Error(await parseError(res))
  return res.json()
}

export async function getKiroModels(): Promise<KiroModelsResponse> {
  const res = await authedFetch('/agent/kiro/models')
  if (!res.ok) throw new Error(await parseError(res))
  return res.json()
}

export async function executeKiroTask(payload: KiroExecuteRequest): Promise<KiroExecuteResponse> {
  const res = await authedFetch('/agent/kiro/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) throw new Error(await parseError(res))
  return res.json()
}

export async function readKiroFile(payload: {
  workspace_path?: string
  relative_path: string
}): Promise<{ relative_path: string; content: string; size: number }> {
  const res = await authedFetch('/agent/kiro/read-file', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) throw new Error(await parseError(res))
  return res.json()
}
