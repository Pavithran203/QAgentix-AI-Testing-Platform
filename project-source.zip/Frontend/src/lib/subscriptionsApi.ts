// Subscriptions & SubProjects API client — DB-backed (MongoDB via the backend).
// Mirrors the auth/refresh pattern in workspaceApi.ts. The camelCase JSON the
// backend returns matches the Subscription / SubProject TS types exactly, so the
// page components need no changes.

import { tokenStore, apiRefresh } from './authApi'
import type { Subscription } from '../SubscriptionsPage'
import type { SubProject } from '../SubProjectsPage'

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

export type NewSubscription = {
  name: string
  category: Subscription['category']
  plan: string
  status: Subscription['status']
  description: string
}

export type NewSubProject = {
  subscriptionId: string
  name: string
  type: SubProject['type']
  endpointsCount: number
  endpoints: string[]
  description: string
}

async function parseError(res: Response): Promise<string> {
  try {
    const data = await res.json()
    if (typeof data?.detail === 'string') return data.detail
    if (Array.isArray(data?.detail) && data.detail[0]?.msg) return data.detail[0].msg
  } catch {
    /* ignore */
  }
  return `Request failed (${res.status})`
}

async function authedFetch(path: string, init: RequestInit = {}, retry = true): Promise<Response> {
  const access = tokenStore.access
  const headers = new Headers(init.headers)
  if (access) headers.set('Authorization', `Bearer ${access}`)
  const res = await fetch(`${API_BASE}${path}`, { ...init, headers })
  if (res.status === 401 && retry) {
    const refreshed = await apiRefresh()
    if (refreshed) return authedFetch(path, init, false)
  }
  return res
}

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const res = await authedFetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(await parseError(res))
  return res.json() as Promise<T>
}

export async function listSubscriptions(): Promise<Subscription[]> {
  const res = await authedFetch('/subscriptions')
  if (!res.ok) throw new Error(await parseError(res))
  return res.json()
}

export async function createSubscription(body: NewSubscription): Promise<Subscription> {
  return postJson('/subscriptions', body)
}

export async function deleteSubscription(id: string): Promise<void> {
  const res = await authedFetch(`/subscriptions/${id}`, { method: 'DELETE' })
  if (!res.ok) throw new Error(await parseError(res))
}

export async function getSummary(): Promise<{ subscriptionCount: number; subprojectCount: number }> {
  const res = await authedFetch('/subscriptions/summary')
  if (!res.ok) throw new Error(await parseError(res))
  return res.json()
}

export async function listSubProjects(subscriptionId?: string): Promise<SubProject[]> {
  const path = subscriptionId
    ? `/subprojects?subscriptionId=${encodeURIComponent(subscriptionId)}`
    : '/subprojects'
  const res = await authedFetch(path)
  if (!res.ok) throw new Error(await parseError(res))
  return res.json()
}

export async function createSubProject(body: NewSubProject): Promise<SubProject> {
  return postJson('/subprojects', body)
}

export async function deleteSubProject(id: string): Promise<void> {
  const res = await authedFetch(`/subprojects/${id}`, { method: 'DELETE' })
  if (!res.ok) throw new Error(await parseError(res))
}
