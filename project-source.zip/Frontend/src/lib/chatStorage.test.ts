import { describe, it, expect } from 'vitest'
import {
  loadSessions,
  saveSessions,
  saveSession,
  deleteSession,
  clearAllSessions,
  type StoredChatSession,
} from './chatStorage'

describe('chatStorage service', () => {
  it('exposes all planned CRUD functions', () => {
    expect(typeof loadSessions).toBe('function')
    expect(typeof saveSession).toBe('function')
    expect(typeof saveSessions).toBe('function')
    expect(typeof deleteSession).toBe('function')
    expect(typeof clearAllSessions).toBe('function')
  })

  it('correctly constructs StoredChatSession objects', () => {
    const session: StoredChatSession = {
      id: 'session-123',
      userId: 'user-abc',
      title: 'Checkout Flow Tests',
      project: 'Rammas',
      createdAt: '2026-10-21T10:00:00Z',
      updatedAt: '2026-10-21T10:00:00Z',
      messages: [
        {
          id: 'msg-1',
          role: 'user',
          content: 'Generate test cases for cart checkout',
          timestamp: '10:00 AM',
        },
      ],
    }

    expect(session.id).toBe('session-123')
    expect(session.userId).toBe('user-abc')
    expect(session.project).toBe('Rammas')
    expect(session.messages).toHaveLength(1)
  })
})
