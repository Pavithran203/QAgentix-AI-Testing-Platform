// Auth API client for the QAgenticx backend.
// Talks to the FastAPI service under /api (proxied by Vite in dev).

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

const ACCESS_KEY = 'qagenticx.accessToken'
const REFRESH_KEY = 'qagenticx.refreshToken'

export type ApiUser = {
  id: string
  name: string
  email: string
  username: string
  role: string
  avatar: string
}

export type TokenResponse = {
  access_token: string
  refresh_token: string
  token_type: string
  user: ApiUser
}

export type LoginPayload = { username: string; password: string }
export type RegisterPayload = {
  fullName: string
  email: string
  username: string
  password: string
}

export const tokenStore = {
  get access() {
    return localStorage.getItem(ACCESS_KEY)
  },
  get refresh() {
    return localStorage.getItem(REFRESH_KEY)
  },
  set(tokens: { access: string; refresh: string }) {
    localStorage.setItem(ACCESS_KEY, tokens.access)
    localStorage.setItem(REFRESH_KEY, tokens.refresh)
  },
  clear() {
    localStorage.removeItem(ACCESS_KEY)
    localStorage.removeItem(REFRESH_KEY)
  },
}

async function parseError(res: Response): Promise<string> {
  try {
    const data = await res.json()
    if (typeof data?.detail === 'string') return data.detail
    if (Array.isArray(data?.detail) && data.detail[0]?.msg) return data.detail[0].msg
  } catch {
    /* ignore non-JSON bodies */
  }
  return `Request failed (${res.status})`
}

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(await parseError(res))
  return res.json() as Promise<T>
}

export async function apiLogin(payload: LoginPayload): Promise<TokenResponse> {
  const data = await postJson<TokenResponse>('/auth/login', payload)
  tokenStore.set({ access: data.access_token, refresh: data.refresh_token })
  return data
}

export async function apiRegister(payload: RegisterPayload): Promise<TokenResponse> {
  const data = await postJson<TokenResponse>('/auth/register', payload)
  tokenStore.set({ access: data.access_token, refresh: data.refresh_token })
  return data
}

export async function apiRefresh(): Promise<TokenResponse | null> {
  const refresh = tokenStore.refresh
  if (!refresh) return null
  try {
    const data = await postJson<TokenResponse>('/auth/refresh', { refreshToken: refresh })
    tokenStore.set({ access: data.access_token, refresh: data.refresh_token })
    return data
  } catch {
    tokenStore.clear()
    return null
  }
}

// GET /auth/me using the current access token; auto-refreshes once on 401.
export async function apiMe(retry = true): Promise<ApiUser | null> {
  const access = tokenStore.access
  if (!access) return null

  const res = await fetch(`${API_BASE}/auth/me`, {
    headers: { Authorization: `Bearer ${access}` },
  })

  if (res.status === 401 && retry) {
    const refreshed = await apiRefresh()
    if (!refreshed) return null
    return apiMe(false)
  }

  if (!res.ok) return null
  return res.json() as Promise<ApiUser>
}

export async function apiLogout(): Promise<void> {
  const access = tokenStore.access
  if (access) {
    try {
      await fetch(`${API_BASE}/auth/logout`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${access}` },
      })
    } catch {
      /* best-effort; tokens are cleared regardless */
    }
  }
  tokenStore.clear()
}
