/**
 * fileSystemStorage.ts — Direct Local Folder Persistence using File System Access API
 *
 * Allows the user to select an actual physical directory on their computer
 * (e.g. C:\TestScenarios or D:\QAgentixProjects) and writes chat sessions
 * directly to their disk as formatted JSON and Markdown files.
 */

import type { StoredChatSession } from './chatStorage'

// Cache directory handle in memory for the active browser session
let cachedDirectoryHandle: FileSystemDirectoryHandle | null = null
let cachedDirectoryName: string | null = null

/** Checks if the browser supports the File System Access API */
export function isFileSystemAccessSupported(): boolean {
  return typeof window !== 'undefined' && 'showDirectoryPicker' in window
}

/** Get the currently selected folder name, if any */
export function getSelectedFolderName(): string | null {
  return cachedDirectoryName
}

/** Get the directory handle already granted by the user this session, if any */
export function getCachedDirectoryHandle(): FileSystemDirectoryHandle | null {
  return cachedDirectoryHandle
}

/** Minimal shape for a file inside a generated bundle. */
export interface BundleFileLike {
  path: string
  content: string
}

/** Minimal shape for a generated bundle to write to disk. */
export interface BundleLike {
  title: string
  files: BundleFileLike[]
}

/**
 * Write a generated bundle straight into the already-granted local folder,
 * preserving its nested folder structure (features/, test script/, etc.).
 * No picker and no zip — files land directly on disk under a project subfolder.
 * Returns the project folder name on success, or null if it could not write.
 */
// Keep directory/file segment names valid for the File System Access API
// (no slashes, no illegal characters, no stray spaces).
function sanitizeSegment(name: string): string {
  return (
    name
      .trim()
      .replace(/[\\/:*?"<>|]/g, '-') // characters disallowed on Windows / by the API
      .replace(/\s+/g, '-') // collapse spaces to hyphens
      .replace(/-+/g, '-')
      .replace(/(^-|-$)/g, '') || 'file'
  )
}

export async function saveBundleToLocalFolder(
  bundle: BundleLike,
  handle: FileSystemDirectoryHandle | null = cachedDirectoryHandle
): Promise<string | null> {
  if (!handle) return null

  // Re-verify write permission on the already-granted handle.
  const permHandle = handle as unknown as {
    queryPermission?: (d: { mode: 'readwrite' }) => Promise<PermissionState>
    requestPermission?: (d: { mode: 'readwrite' }) => Promise<PermissionState>
  }
  let perm: PermissionState = 'granted'
  if (permHandle.queryPermission) perm = await permHandle.queryPermission({ mode: 'readwrite' })
  if (perm !== 'granted' && permHandle.requestPermission) {
    perm = await permHandle.requestPermission({ mode: 'readwrite' })
  }
  if (perm !== 'granted') {
    throw new Error('permission-denied')
  }

  const projectFolderName =
    bundle.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'qagentix-suite'
  const projectDir = await handle.getDirectoryHandle(projectFolderName, { create: true })

  for (const file of bundle.files) {
    const segments = file.path.split('/').filter(Boolean).map(sanitizeSegment)
    const fileName = segments.pop() as string
    let dir = projectDir
    for (const seg of segments) {
      dir = await dir.getDirectoryHandle(seg, { create: true })
    }
    const fileHandle = await dir.getFileHandle(fileName, { create: true })
    const writable = await fileHandle.createWritable()
    await writable.write(file.content ?? '')
    await writable.close()
  }

  return projectFolderName
}

/**
 * Prompt the user with the native Windows/OS folder picker to select a directory on their PC.
 */
export async function promptUserForFolder(): Promise<{ handle: FileSystemDirectoryHandle; name: string } | null> {
  if (!isFileSystemAccessSupported()) {
    throw new Error('File System Access API is not supported in this browser. Please use Chrome, Edge, or Opera.')
  }

  try {
    const handle = await (window as unknown as {
      showDirectoryPicker: (options?: { mode?: 'read' | 'readwrite'; startIn?: string }) => Promise<FileSystemDirectoryHandle>
    }).showDirectoryPicker({
      mode: 'readwrite',
    })

    cachedDirectoryHandle = handle
    cachedDirectoryName = handle.name
    return { handle, name: handle.name }
  } catch (err) {
    if ((err as Error).name === 'AbortError') {
      // User cancelled the folder picker dialog
      return null
    }
    throw err
  }
}

/**
 * Write a chat session directly to the chosen local directory on the user's computer.
 * Saves both:
 * 1. A JSON file (`scenario-<id>.json`) for machine loading
 * 2. A Markdown file (`scenario-<id>.md`) for human reading in VS Code / Notepad
 */
export async function saveSessionToLocalFolder(
  session: StoredChatSession,
  handle: FileSystemDirectoryHandle | null = cachedDirectoryHandle
): Promise<boolean> {
  if (!handle) return false

  try {
    const sanitizedTitle = session.title.replace(/[^a-z0-9_-]/gi, '_').toLowerCase().slice(0, 40)
    const fileNameBase = `scenario_${sanitizedTitle || session.id}`

    // 1. Write structured JSON file
    const jsonHandle = await handle.getFileHandle(`${fileNameBase}.json`, { create: true })
    const jsonWritable = await jsonHandle.createWritable()
    await jsonWritable.write(
      JSON.stringify(
        {
          id: session.id,
          title: session.title,
          project: session.project,
          createdAt: session.createdAt,
          updatedAt: session.updatedAt,
          messages: session.messages,
        },
        null,
        2
      )
    )
    await jsonWritable.close()

    // 2. Write readable Markdown summary file
    const mdContent = generateScenarioMarkdown(session)
    const mdHandle = await handle.getFileHandle(`${fileNameBase}.md`, { create: true })
    const mdWritable = await mdHandle.createWritable()
    await mdWritable.write(mdContent)
    await mdWritable.close()

    return true
  } catch (err) {
    console.error('[fileSystemStorage] Failed to write session to local folder:', err)
    return false
  }
}

/** Format a chat session into readable Markdown documentation */
function generateScenarioMarkdown(session: StoredChatSession): string {
  const lines: string[] = [
    `# 🧪 Test Scenario: ${session.title}`,
    ``,
    `- **Session ID:** \`${session.id}\``,
    `- **Project:** ${session.project}`,
    `- **Created At:** ${session.createdAt}`,
    `- **Last Updated:** ${session.updatedAt}`,
    `- **Total Messages:** ${session.messages.length}`,
    ``,
    `---`,
    `## 💬 Conversation Transcript`,
    ``,
  ]

  for (const msg of session.messages) {
    const sender = msg.role === 'user' ? '👤 User' : '🤖 QAgentix AI'
    lines.push(`### ${sender} (${msg.timestamp})`)
    lines.push(msg.content)
    lines.push('')

    if (msg.attachments && msg.attachments.length > 0) {
      lines.push('**Attached Files:**')
      for (const att of msg.attachments) {
        lines.push(`- \`${att.name}\` (${att.size})`)
      }
      lines.push('')
    }

    if (msg.bundle) {
      lines.push(`#### 📦 Generated Test Bundle: ${msg.bundle.title}`)
      lines.push(msg.bundle.description)
      lines.push('')
      lines.push(`- Total Test Cases: **${msg.bundle.summary.totalCases}**`)
      lines.push(`- Test Files: **${msg.bundle.files.length}**`)
      lines.push('')
    }
  }

  return lines.join('\n')
}
