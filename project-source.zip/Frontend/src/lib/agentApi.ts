// Agent test-generation API client.
// Calls the FastAPI backend (/api/agent/generate), which runs the dynamic,
// input-driven test-suite synthesizer. Proxied by Vite in dev.

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

export interface AgentFileAttachment {
  name: string
  size?: string
  type?: string
  content?: string
}

export interface AgentGenerateRequest {
  prompt: string
  projectName?: string
  files?: AgentFileAttachment[]
  provider?: string
  model?: string
}

export interface ApiGeneratedTestCase {
  id: string
  title: string
  description: string
  steps: string[]
  expectedResult: string
  priority: 'High' | 'Medium' | 'Low'
  category: 'E2E' | 'Regression' | 'Boundary' | 'Security' | 'Smoke'
}

export interface ApiGeneratedFile {
  path: string
  name: string
  language: string
  description: string
  content: string
}

export interface ApiGeneratedBundle {
  title: string
  description: string
  summary: {
    totalCases: number
    positiveCount: number
    negativeCount: number
    edgeCount: number
    coverage: string
  }
  testCases: ApiGeneratedTestCase[]
  files: ApiGeneratedFile[]
  provider: string
  model: string
  generatedAt: string
  accepted: boolean
  acceptedAt?: string | null
}

async function parseError(res: Response): Promise<string> {
  try {
    const data = await res.json()
    if (typeof data?.detail === 'string') return data.detail
    if (Array.isArray(data?.detail) && data.detail[0]?.msg) return data.detail[0].msg
  } catch {
    /* ignore non-JSON bodies */
  }
  return `Generation failed (${res.status})`
}

/** Returned instead of a bundle when the message is a question, not a test request. */
export interface ApiAgentAnswer {
  kind: 'answer'
  message: string
}

export type ApiGenerateResult =
  | (ApiGeneratedBundle & { kind: 'bundle'; focus: 'suite' | 'cases' | 'script' | 'edge' })
  | ApiAgentAnswer

/**
 * Send a chat message to the backend. It returns a test-suite bundle for feature
 * descriptions and uploaded specs, or a short answer when the message is a question.
 * The bundle comes from the rule-based synthesizer, so it varies with the input.
 */
export async function apiGenerateBundle(req: AgentGenerateRequest): Promise<ApiGenerateResult> {
  const res = await fetch(`${API_BASE}/agent/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: req.prompt,
      projectName: req.projectName ?? 'Rammas',
      files: req.files ?? [],
      provider: req.provider,
      model: req.model,
    }),
  })
  if (!res.ok) throw new Error(await parseError(res))
  return res.json() as Promise<ApiGenerateResult>
}
