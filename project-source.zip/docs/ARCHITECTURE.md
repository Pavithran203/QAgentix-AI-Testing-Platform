# QAgentix — Architecture

## 1. Overview

QAgentix is a web application with a clear two-tier split:

- **Frontend** — a React + TypeScript single-page app (SPA) built with Vite.
- **Backend** — a FastAPI service providing authentication and health endpoints,
  backed by MongoDB.

Authentication is JWT-based (access + refresh tokens). The only data persisted
to MongoDB is the **users** collection. Generated test scripts and artifacts are
**never** stored in the database.

## 2. Repository layout

```
QAgentix_Dev/
├── Frontend/                 # React + Vite SPA
│   ├── src/
│   │   ├── App.tsx           # App shell, routing, AuthProvider, pages
│   │   ├── lib/authApi.ts    # Auth API client + token storage
│   │   ├── main.tsx          # React entry
│   │   └── ...
│   ├── public/               # Static assets (copied into dist on build)
│   ├── vite.config.ts        # Dev server (port 3000) + /api proxy
│   └── package.json
│
├── Backend/                  # FastAPI service
│   ├── app/
│   │   ├── main.py           # FastAPI app, lifespan, CORS, router mount
│   │   ├── core/
│   │   │   ├── config.py     # pydantic-settings configuration
│   │   │   └── security.py   # password hashing + JWT helpers
│   │   ├── db/
│   │   │   └── mongodb.py    # Motor client + Beanie init + startup indexes
│   │   ├── models/
│   │   │   └── user.py       # Beanie User document (users collection)
│   │   ├── schemas/
│   │   │   └── auth.py       # Pydantic request/response schemas
│   │   └── api/
│   │       ├── deps.py       # Auth dependencies (current user)
│   │       └── routes/
│   │           ├── health.py # GET /api/health
│   │           └── auth.py   # register / login / refresh / me / logout
│   ├── requirements.txt
│   ├── .env.example
│   └── README.md
│
├── docs/
│   ├── ARCHITECTURE.md       # this file
│   ├── DESIGN.md             # design decisions and data model
│   └── PROCESS.md            # end-to-end build process log
│
└── Q-Agentix/                # legacy git repository (.git only) — see notes
```

## 3. Component diagram

```
            ┌──────────────────────────────────────────────┐
            │                  Browser                      │
            │   React SPA (Vite)  http://localhost:3000     │
            │   - AuthProvider (session + tokens)           │
            │   - react-router-dom (client-side routing)    │
            │   - authApi.ts (fetch + localStorage tokens)  │
            └───────────────────────┬──────────────────────┘
                                     │  /api/*  (JSON over HTTP)
                     Vite dev proxy  │  (dev only; prod talks to API directly)
                                     ▼
            ┌──────────────────────────────────────────────┐
            │           FastAPI  http://localhost:8000      │
            │   - CORS middleware (allow all origins)       │
            │   - /api/health                               │
            │   - /api/auth/{register,login,refresh,me,     │
            │        logout}                                │
            │   - JWT verify dependency (get_current_user)  │
            └───────────────────────┬──────────────────────┘
                                     │  Motor (async) + Beanie ODM
                                     ▼
            ┌──────────────────────────────────────────────┐
            │        MongoDB  mongodb://localhost:27017     │
            │   db: qagenticx                               │
            │   collection: users (unique idx: username,    │
            │                       email)                  │
            └──────────────────────────────────────────────┘
```

## 4. Technology stack

### Frontend
| Concern            | Choice                        |
| ------------------ | ----------------------------- |
| Framework          | React 19 + TypeScript         |
| Build / dev server | Vite                          |
| Routing            | react-router-dom (BrowserRouter) |
| Forms / validation | react-hook-form + zod         |
| Data layer         | @tanstack/react-query         |
| Styling            | Tailwind CSS                  |

### Backend
| Concern          | Choice                              |
| ---------------- | ----------------------------------- |
| Framework        | FastAPI + Uvicorn                   |
| Config           | pydantic-settings                   |
| DB driver / ODM  | Motor (async) + Beanie              |
| Database         | MongoDB                             |
| Password hashing | passlib + bcrypt                    |
| Tokens           | python-jose (JWT, HS256)            |

## 5. Request flow (login example)

1. User submits username + password in the SPA login form.
2. `authApi.apiLogin()` POSTs JSON to `/api/auth/login`.
3. In dev, the Vite proxy forwards `/api/*` to `http://localhost:8000`.
4. FastAPI validates the body against `LoginRequest`, looks up the user via
   Beanie, verifies the bcrypt password hash.
5. On success it returns `{ access_token, refresh_token, token_type, user }`.
6. The SPA stores both tokens in `localStorage` and sets the user in
   `AuthProvider`.
7. Subsequent authed calls send `Authorization: Bearer <access_token>`.
8. On a 401, `authApi` tries `/api/auth/refresh` once using the refresh token.

## 6. Security model

- **Passwords** are stored only as bcrypt hashes.
- **Access tokens** are short-lived (default 30 min); **refresh tokens** are
  long-lived (default 7 days). Both are signed with `JWT_SECRET_KEY` (HS256).
- **Token type** is encoded in the JWT (`type: access|refresh`) and validated on
  use, so a refresh token cannot be used as an access token.
- **CORS** currently allows all origins (`*`). Because a wildcard origin cannot
  be combined with credentials in browsers, `allow_credentials` is `False`.
  This is safe because auth uses the `Authorization` header, not cookies.
- **No scripts/artifacts in the DB** — only user records are persisted.

## 7. Notes / follow-ups

- The legacy GitLab repository (`Q-Agentix/.git`) was left in place during the
  restructure; the project source now lives in `Frontend/` and `Backend/`. If
  you want version control to track the new structure, re-initialise git at the
  workspace root (or move the existing `.git`) as a deliberate step.
- `allow_origins=["*"]` is convenient for development. For production, restrict
  it to known origins and re-enable credentials only if you switch to cookies.
- The main JS bundle is large (~1.3 MB); consider code-splitting later.
