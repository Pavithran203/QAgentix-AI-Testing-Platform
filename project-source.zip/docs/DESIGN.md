# QAgentix — Design Document

## 1. Goals

1. Provide a clean two-folder structure: `Frontend/` and `Backend/`.
2. Backend built on FastAPI with proper separation of **config, schema, model,
   route** modules and a `main.py` entrypoint.
3. JWT authentication: register, login, refresh, current-user, logout.
4. Persist **only** the users collection in MongoDB. Never store generated
   Python scripts or test artifacts in the database (local filesystem now,
   cloud/object storage later).
5. CORS allows all origins (`*`).

## 2. Backend module responsibilities

| Module                     | Responsibility                                             |
| -------------------------- | ---------------------------------------------------------- |
| `app/main.py`              | Create the FastAPI app, lifespan (DB connect/close), CORS, mount routers. |
| `app/core/config.py`       | Centralised settings via pydantic-settings (env / `.env`). |
| `app/core/security.py`     | Password hashing (bcrypt) and JWT create/decode.           |
| `app/db/mongodb.py`        | Motor client lifecycle, Beanie init, startup indexes.      |
| `app/models/user.py`       | Beanie `User` document — the only persisted collection.    |
| `app/schemas/auth.py`      | Pydantic request/response contracts.                       |
| `app/api/deps.py`          | `get_current_user` dependency (validates bearer token).    |
| `app/api/routes/health.py` | `/health` endpoint.                                        |
| `app/api/routes/auth.py`   | Auth endpoints.                                            |

This mirrors the common FastAPI layering: **routes → schemas → models → db**,
with cross-cutting concerns (config, security) in `core`.

## 3. Data model

### `users` collection

| Field             | Type       | Notes                                  |
| ----------------- | ---------- | -------------------------------------- |
| `_id`             | ObjectId   | Mongo document id                      |
| `full_name`       | string     | Display name                           |
| `username`        | string     | **Unique index**                       |
| `email`           | string     | **Unique index**, validated as email   |
| `hashed_password` | string     | bcrypt hash — plaintext never stored   |
| `role`            | string     | Default `Admin`                        |
| `is_active`       | bool       | Default `true`                         |
| `created_at`      | datetime   | UTC, set on insert                     |
| `updated_at`      | datetime   | UTC                                    |

Indexes are declared on the Beanie document and built at startup by
`init_beanie`.

### Explicitly NOT stored

- Generated Python test scripts
- Test execution artifacts / reports
- Any uploaded or produced files

These live on the local filesystem (and later cloud/object storage), keeping the
database limited to identity/auth data.

## 4. API contracts

Base path: `/api`

| Method | Path              | Auth   | Request body                                   | Response                        |
| ------ | ----------------- | ------ | ---------------------------------------------- | ------------------------------- |
| GET    | `/health`         | –      | –                                              | `{ status, app, environment, database }` |
| POST   | `/auth/register`  | –      | `{ fullName, email, username, password }`      | `TokenResponse` (201)           |
| POST   | `/auth/login`     | –      | `{ username, password }`                       | `TokenResponse`                 |
| POST   | `/auth/refresh`   | –      | `{ refreshToken }`                             | `TokenResponse`                 |
| GET    | `/auth/me`        | Bearer | –                                              | `UserOut`                       |
| POST   | `/auth/logout`    | Bearer | –                                              | `{ detail }`                    |

### `TokenResponse`

```json
{
  "access_token": "…",
  "refresh_token": "…",
  "token_type": "bearer",
  "user": {
    "id": "…",
    "name": "…",
    "email": "…",
    "username": "…",
    "role": "Admin",
    "avatar": "RS"
  }
}
```

The frontend request bodies use camelCase (`fullName`, `refreshToken`). Pydantic
schemas accept these via field aliases with `populate_by_name=True`.

## 5. Authentication design

- **Hashing:** `passlib` with the bcrypt scheme.
- **Tokens:** HS256 JWTs via `python-jose`. Payload carries `sub` (user id),
  `type` (`access` / `refresh`), `iat`, `exp`.
- **Access vs refresh:** separate expiries; `decode_token(expected_type=...)`
  rejects a token used in the wrong context.
- **Current user dependency:** `get_current_user` extracts the bearer token,
  decodes it as an access token, loads the user, and checks `is_active`.
- **Logout:** stateless — the client discards tokens. The endpoint exists for
  symmetry and future server-side revocation.

### Error behaviour

| Case                        | Status |
| --------------------------- | ------ |
| Duplicate username/email    | 409    |
| Wrong username/password     | 401    |
| Disabled account on login   | 403    |
| Invalid/expired refresh     | 401    |
| Missing/invalid bearer token| 401/403|

## 6. Configuration

All settings come from environment variables or a `.env` file
(`Backend/.env`). Key values:

| Variable                      | Purpose                              | Default                      |
| ----------------------------- | ------------------------------------ | ---------------------------- |
| `MONGODB_URI`                 | Mongo connection string              | `mongodb://localhost:27017`  |
| `MONGODB_DB_NAME`             | Database name                        | `qagenticx`                  |
| `JWT_SECRET_KEY`              | HS256 signing secret                 | (generated per environment)  |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | Access token lifetime                | `30`                         |
| `REFRESH_TOKEN_EXPIRE_DAYS`   | Refresh token lifetime               | `7`                          |
| `CORS_ORIGINS`                | Allowed origins (comma-separated)*   | localhost:3000, :5173        |
| `API_PREFIX`                  | Router prefix                        | `/api`                       |

\* `CORS_ORIGINS` remains in config for flexibility, but `main.py` currently
hard-codes `allow_origins=["*"]` per the requirement. Switch back to
`settings.cors_origins` to lock origins down for production.

## 7. Frontend integration design

- `src/lib/authApi.ts` is the single integration point: it owns token storage
  (`localStorage`), builds requests to `/api`, and handles one automatic refresh
  on a 401.
- `AuthProvider` in `App.tsx` restores the session on load (`/auth/me`), exposes
  async `login` / `signup` / `logout`, and a `loading` flag so `ProtectedRoute`
  does not prematurely redirect during session restore.
- `vite.config.ts` runs the dev server on port 3000 and proxies `/api` to the
  backend, so the SPA and API appear same-origin in development.

## 8. Trade-offs and decisions

- **Wildcard CORS + no credentials:** chosen because the browser spec forbids
  `*` with credentials; bearer-header auth makes credentials unnecessary.
- **Stateless JWT:** simple and horizontally scalable; the cost is no instant
  server-side revocation (mitigated by short access-token lifetime).
- **Beanie over raw Motor:** gives typed documents and declarative indexes with
  little overhead, at the cost of an extra dependency.
