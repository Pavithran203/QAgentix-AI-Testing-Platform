# Q-Agentix Project Structure

This file describes a single shared project layout for the workflow that takes a user story and produces a test case, a test script, and a generation report. Five team members can work in the same repository and use the same prompt definition. Each run keeps its own inputs and outputs.

```text
QAgenticx/
├── Backend/
│   └── app/
│       ├── api/
│       │   └── routes/
│       │       ├── stories.py          # Submit and retrieve user stories
│       │       └── generations.py      # Start and retrieve generation runs
│       ├── core/                       # Configuration and shared services
│       ├── models/
│       │   ├── story.py                # Story and ownership metadata
│       │   └── generation.py           # Run status and artifact references
│       ├── schemas/                    # API input/output validation
│       └── services/
│           ├── story_processor.py      # Process one user story
│           ├── test_case_generator.py  # Generate one test case
│           ├── test_script_generator.py# Generate one test script
│           └── report_generator.py     # Generate the run report
│
├── Frontend/
│   └── src/
│       ├── pages/                      # Story submission and run results
│       ├── components/                 # Shared interface components
│       └── lib/                        # API client and shared types
│
├── prompts/
│   └── story_to_test.prompt.md         # Shared workflow prompt and output rules
│
├── projects/
│   └── <project-id>/
│       └── runs/
│           └── <run-id>/
│               ├── input/
│               │   └── user-story.md
│               ├── output/
│               │   ├── test-case.md
│               │   ├── test-script.md
│               │   └── generation-report.md
│               └── run.json            # Status, submitter, timestamps, prompt version
│
├── docs/
│   └── PROJECT_STRUCTURE.md            # This file
└── .env.example                        # Environment variable names (no secrets)
```

## One workflow run

1. A team member submits one user story. The application records the submitter and creates a unique run ID.
2. The backend reads the shared prompt and processes that story.
3. The run produces one test case, one test script, and one generation report in that run's output folder.
4. The run record links the input, outputs, prompt version, submitter, and processing status.

## Five-person collaboration

All five people use the same `prompts/story_to_test.prompt.md`. Each person's submission creates a separate run folder, so their inputs and generated files remain associated with the correct person and story. The shared prompt is maintained in version control; a run records which prompt version produced its outputs.

## Production use

The same layout applies in production. The application must load the prompt from its deployed configuration or packaged files, and generated artifacts must be saved to production storage with access controls. The `projects/` paths above describe the logical grouping; production can map them to object storage or another persistent store instead of local folders.

## Running generated test scripts

Generating a test script and executing it are separate steps. To run the generated script reliably, each run needs the following:

- **Structured test cases:** Give every case a stable ID, preconditions, ordered steps, test data, expected results, and priority. The script generator should create executable tests from these cases and include assertions for expected results.
- **A script contract:** Choose the supported language and test framework, define the entry point and dependencies, and specify how results map back to case IDs.
- **A test runner:** Invoke scripts through a known runner (for example, pytest for Python), capture standard output/error and exit status, apply a time limit, and emit machine-readable results.
- **A target environment:** Supply the application URL or API endpoint, required browser or service dependencies, and test data. Keep environment settings outside generated code and prompts.
- **Protected credentials:** Provide secrets using protected environment variables or a secrets manager. Never write secret values to generated files, run records, or logs.
- **Isolated execution:** Run each job in a clean restricted process or container with its own workspace, installed dependencies, resource limits, and cleanup.
- **Result and failure handling:** Map pass/fail/skip status, duration, and error details to each case ID. Distinguish generation errors, environment/setup errors, test failures, and runner crashes.
- **Artifacts and report:** Save the script, execution log, structured results, and report under the same run ID. Include the story/run ID, prompt version, environment identifier, overall/per-case status, duration, and failure summary.

For example, a run's outputs can be organized as:

```text
projects/<project-id>/runs/<run-id>/
├── input/
│   ├── user-story.md
│   └── execution-config.json      # Target and non-secret run settings
└── output/
    ├── test-cases.json            # Cases and expected results
    ├── test-script.py             # Generated executable tests
    ├── test-results.json          # Per-case results
    ├── execution-log.txt          # Runner output and errors (redacted)
    └── generation-report.md       # Generation plus execution summary
```

In production, the runner should be a controlled worker/service and artifacts should go to persistent storage. Do not execute generated scripts inside the web request process.
