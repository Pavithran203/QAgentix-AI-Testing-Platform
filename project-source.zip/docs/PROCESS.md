# QAgentix — Build Process

This document records the end-to-end process used to build the backend, connect
the UI, and restructure the project.

## Phase 0 — Diagnose the running frontend

- The app showed a `404` at `localhost:3000`, then a `404` specifically on
  `/agent`.
- Root causes found:
  1. A static server (`serve`) was pointed at a folder with no build output.
  2. The app is a client-side-routed SPA (`react-router-dom`), so deep links
     like `/agent` returned 404 from the static server.
- Fixes:
  - Built the actual source and served its own `dist/`.
  - Added SPA fallback (`serve.json` rewrite to `/index.html`, served with
    `--single`) so client routes resolve.

## Phase 1 — Backend scaffold (FastAPI)

Created the `Backend/` service with layered modules:

```
app/
  main.py            # app, lifespan, CORS, routers
  core/config.py     # pydantic-settings
  core/security.py   # bcrypt + JWT
  db/mongodb.py      # Motor + Beanie + startup indexes
  models/user.py     # User document (users collection only)
  schemas/auth.py    # request/response schemas
  api/deps.py        # get_current_user
  api/routes/health.py
  api/routes/auth.py
```

Supporting files: `requirements.txt`, `.env.example`, `.gitignore`, `README.md`.

### Dependencies

Installed into a virtual environment (`.venv`):
FastAPI, Uvicorn, pydantic, pydantic-settings, email-validator, Motor, Beanie,
passlib/bcrypt, python-jose, python-multipart.

## Phase 2 — Authentication logic

- Implemented register / login / refresh / me / logout.
- Passwords hashed with bcrypt; JWTs signed with HS256.
- Access and refresh tokens carry a `type` claim and separate expiries.
- Only user records are written to MongoDB — no scripts/artifacts.

### Issue encountered and fixed

- **pydantic-settings CORS parsing error:** a `list[str]` env field made
  pydantic-settings attempt JSON decoding of the `.env` value and crash.
  Fixed by storing the raw value as a `str` (env `CORS_ORIGINS`) and exposing a
  parsed `cors_origins` property.

## Phase 3 — Run and verify the backend

- Generated a strong `JWT_SECRET_KEY` into `Backend/.env`.
- Confirmed MongoDB reachable on `localhost:27017`.
- Started Uvicorn; startup connected to Mongo and ensured indexes.
- Verified via HTTP:
  - `GET /api/health` → `status: ok`, `database: connected`.
  - `POST /api/auth/register` → created a user.
  - `POST /api/auth/login` → tokens returned.
  - `GET /api/auth/me` → correct user with bearer token.
  - `POST /api/auth/refresh` → new access token.
  - Negative checks: wrong password → 401, missing token → 403.

## Phase 4 — Connect the UI

- Added `src/lib/authApi.ts`: fetch-based client, token storage in
  `localStorage`, auto-refresh once on 401.
- Rewired `AuthProvider` in `App.tsx` to call the real API (removed the mock
  user), restore sessions on load, and expose async login/signup/logout.
- Added an error banner and a loading guard in `ProtectedRoute`.
- Added a Vite dev proxy (`/api` → `http://localhost:8000`) and fixed the dev
  port to 3000.
- Verified: `tsc -b` passes; requests to `http://localhost:3000/api/...`
  proxy through to the backend and authenticate.

## Phase 5 — Restructure and CORS

- Moved the frontend from `Q-Agentix/QAgenticx` to top-level `Frontend/`.
- Renamed `backend/` to `Backend/`.
- Changed CORS to allow all origins: `allow_origins=["*"]` with
  `allow_credentials=False` (required because browsers reject `*` + credentials;
  safe since auth uses the `Authorization` header).
- Re-verified: backend imports and runs from `Backend/`, `Access-Control-Allow-Origin: *`
  is returned, and the frontend type-checks from `Frontend/`.

## How to run (development)

Prerequisites: MongoDB running on `mongodb://localhost:27017`.

### Backend
```powershell
cd Backend
python -m venv .venv                      # first time only
.\.venv\Scripts\python.exe -m pip install -r requirements.txt   # first time only
Copy-Item .env.example .env               # first time only; set JWT_SECRET_KEY
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```
- API docs: http://localhost:8000/docs
- Health:   http://localhost:8000/api/health

### Frontend
```powershell
cd Frontend
npm install        # first time only
npm run dev        # http://localhost:3000, proxies /api to :8000
```

## Known follow-ups

- The legacy GitLab repo lives in `Q-Agentix/.git`; decide whether to
  re-initialise git at the new root.
- Lock down CORS for production and consider code-splitting the large JS bundle.
