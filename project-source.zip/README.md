# QAgentix AI Testing Platform

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.


QAgentix is an AI-assisted software testing platform for designing, generating, executing, and reporting tests. It combines a FastAPI backend and agent framework with a React/Vite frontend and configurable model-provider integrations.

## Included files

- `Backend/app/`, `Backend/src/`, and `Backend/tests/`: API, agent framework, provider integrations, and tests.
- `Frontend/src/` and frontend npm manifests: web client source and build configuration.
- `docs/`, `projects/example/`, and configuration templates: architecture notes, a starter project, and local setup.

Local `.env` files, generated workspaces, caches, build output, and presentation notes are excluded. Add your own provider keys to a local `.env`; never commit secrets.

## Setup

Backend setup (Python 3.12):

```powershell
cd Backend
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -e ".[dev]"
pip install -r requirements.txt
playwright install chromium
```

Copy the root `.env.example` to `.env` and add only the provider keys you are authorized to use. Frontend setup:

```powershell
cd Frontend
npm install
npm run dev
```

