"""Tests for Kiro Gateway & MCP integration."""
from __future__ import annotations

import pytest

from app.core.kiro_gateway import (
    find_kiro_executable,
    get_kiro_status,
)
from app.core.llm import _normalize_provider


def test_kiro_executable_detection():
    exe = find_kiro_executable()
    # On this local machine, Kiro is installed at %LOCALAPPDATA%\Programs\Kiro
    assert exe is not None
    assert "kiro" in exe.lower()


def test_kiro_status_structure():
    status = get_kiro_status()
    assert "installed" in status
    assert status["installed"] is True
    assert "gateway_url" in status
    assert status["gateway_port"] == 39275


def test_kiro_provider_normalization():
    assert _normalize_provider("kiro") == "kiro"
    assert _normalize_provider("kiro_local") == "kiro"
    assert _normalize_provider("KIRO-LOCAL") == "kiro"
