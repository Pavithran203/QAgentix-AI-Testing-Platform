"""Tests for qagenticx.providers LLM factory, resilience, and retry."""

from unittest.mock import MagicMock, patch
import pytest

from qagenticx.providers import (
    AuthenticationError,
    get_chat_model,
    invoke_with_retry,
)
from qagenticx.settings import LLMSettings, ProviderSettings


@pytest.fixture
def dummy_settings():
    return LLMSettings(
        default_provider="openai",
        providers={
            "openai": ProviderSettings(
                default_model="gpt-4o",
                temperature=0.0,
                timeout_seconds=25.0,
                max_retries=2,
                api_key_env="TEST_OPENAI_KEY",
            ),
            "claude": ProviderSettings(
                default_model="claude-3-5-sonnet-20241022",
                temperature=0.2,
                timeout_seconds=30.0,
                max_retries=2,
                api_key_env="TEST_ANTHROPIC_KEY",
            ),
            "gemini": ProviderSettings(
                default_model="gemini-1.5-pro",
                temperature=0.0,
                timeout_seconds=20.0,
                max_retries=2,
                api_key_env="TEST_GOOGLE_KEY",
            ),
            "ollama": ProviderSettings(
                default_model="llama3.1",
                temperature=0.0,
                timeout_seconds=45.0,
                max_retries=1,
                base_url="http://localhost:11434",
            ),
        },
    )


def test_provider_selection_openai(dummy_settings, monkeypatch):
    """Verify openai returns ChatOpenAI with configured parameters."""
    monkeypatch.setenv("TEST_OPENAI_KEY", "sk-mock-openai-key")
    with patch("langchain_openai.ChatOpenAI") as mock_openai_cls:
        mock_instance = MagicMock()
        mock_openai_cls.return_value = mock_instance

        model = get_chat_model(dummy_settings, provider="openai")
        assert model == mock_instance
        mock_openai_cls.assert_called_once_with(
            model="gpt-4o",
            api_key="sk-mock-openai-key",
            temperature=0.0,
            timeout=25.0,
        )


def test_provider_selection_claude(dummy_settings, monkeypatch):
    """Verify claude returns ChatAnthropic with configured parameters."""
    monkeypatch.setenv("TEST_ANTHROPIC_KEY", "sk-ant-mock-key")
    with patch("langchain_anthropic.ChatAnthropic") as mock_anthropic_cls:
        mock_instance = MagicMock()
        mock_anthropic_cls.return_value = mock_instance

        model = get_chat_model(dummy_settings, provider="claude")
        assert model == mock_instance
        mock_anthropic_cls.assert_called_once_with(
            model="claude-3-5-sonnet-20241022",
            api_key="sk-ant-mock-key",
            temperature=0.2,
            timeout=30.0,
        )


def test_provider_selection_gemini(dummy_settings, monkeypatch):
    """Verify gemini returns ChatGoogleGenerativeAI with configured parameters."""
    monkeypatch.setenv("TEST_GOOGLE_KEY", "ai-mock-gemini-key")
    with patch("langchain_google_genai.ChatGoogleGenerativeAI") as mock_gemini_cls:
        mock_instance = MagicMock()
        mock_gemini_cls.return_value = mock_instance

        model = get_chat_model(dummy_settings, provider="gemini")
        assert model == mock_instance
        mock_gemini_cls.assert_called_once_with(
            model="gemini-1.5-pro",
            google_api_key="ai-mock-gemini-key",
            temperature=0.0,
            timeout=20.0,
        )


def test_provider_selection_ollama(dummy_settings):
    """Verify ollama returns ChatOllama using base_url without requiring API key."""
    with patch("langchain_ollama.ChatOllama") as mock_ollama_cls:
        mock_instance = MagicMock()
        mock_ollama_cls.return_value = mock_instance

        model = get_chat_model(dummy_settings, provider="ollama")
        assert model == mock_instance
        mock_ollama_cls.assert_called_once_with(
            model="llama3.1",
            base_url="http://localhost:11434",
            temperature=0.0,
            timeout=45.0,
        )


def test_missing_api_key_raises_clear_error(dummy_settings, monkeypatch):
    """Verify missing provider API key raises AuthenticationError."""
    monkeypatch.delenv("TEST_OPENAI_KEY", raising=False)
    with pytest.raises(AuthenticationError, match="Missing API key for provider 'openai'"):
        get_chat_model(dummy_settings, provider="openai")


def test_retry_on_transient_failures_then_succeeds():
    """Verify a model that fails twice with transient errors retries and succeeds."""
    mock_model = MagicMock()
    mock_model.invoke.side_effect = [
        ConnectionError("Network disconnected"),
        TimeoutError("504 Gateway Timeout"),
        "Successful Response",
    ]

    result = invoke_with_retry(
        mock_model,
        messages="Hello world",
        max_retries=3,
        backoff_base=0.01,
        backoff_max=0.05,
    )
    assert result == "Successful Response"
    assert mock_model.invoke.call_count == 3


def test_timeout_path_exercised():
    """Verify non-recoverable or persistent timeout raises exception after retry budget."""
    mock_model = MagicMock()
    mock_model.invoke.side_effect = TimeoutError("Request timed out")

    with pytest.raises(TimeoutError, match="Request timed out"):
        invoke_with_retry(
            mock_model,
            messages="Ping",
            max_retries=2,
            backoff_base=0.01,
            backoff_max=0.02,
        )
    # 1 initial attempt + 2 retries = 3 calls
    assert mock_model.invoke.call_count == 3


def test_non_retryable_error_fails_fast():
    """Verify authentication / 401 errors fail fast without retry."""
    mock_model = MagicMock()
    mock_model.invoke.side_effect = AuthenticationError("Invalid API key")

    with pytest.raises(AuthenticationError, match="Invalid API key"):
        invoke_with_retry(
            mock_model,
            messages="Ping",
            max_retries=3,
            backoff_base=0.01,
            backoff_max=0.02,
        )
    assert mock_model.invoke.call_count == 1
