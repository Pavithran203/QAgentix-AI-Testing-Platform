"""Tests for RBAC, Project Membership, Audit Logging, and User Management schemas."""

from unittest.mock import MagicMock
import pytest
from fastapi import HTTPException

from app.api.deps import (
    require_admin,
    require_test_lead,
    require_tester,
    require_viewer,
)
from app.core.roles import ALL_ROLES, DEFAULT_ROLE, Role
from app.schemas.audit import AuditLogItem
from app.schemas.membership import (
    AddProjectMemberRequest,
    ProjectMemberItem,
    UpdateProjectMemberRoleRequest,
)
from app.schemas.users import (
    CreateUserRequest,
    UpdateRoleRequest,
    UpdateStatusRequest,
    UserListItem,
)


def test_rbac_roles_definition():
    """Verify standard RBAC roles: Admin, Test Lead, Tester, Viewer."""
    assert Role.ADMIN == "Admin"
    assert Role.TEST_LEAD == "Test Lead"
    assert Role.TESTER == "Tester"
    assert Role.VIEWER == "Viewer"

    assert "Admin" in ALL_ROLES
    assert "Test Lead" in ALL_ROLES
    assert "Tester" in ALL_ROLES
    assert "Viewer" in ALL_ROLES
    assert DEFAULT_ROLE == Role.VIEWER


@pytest.mark.asyncio
async def test_rbac_hierarchy_permissions():
    """Verify role authorization checks enforce proper access levels."""
    admin_user = MagicMock(role=Role.ADMIN)
    lead_user = MagicMock(role=Role.TEST_LEAD)
    tester_user = MagicMock(role=Role.TESTER)
    viewer_user = MagicMock(role=Role.VIEWER)

    # Admin checks: passes all
    assert await require_admin(admin_user) == admin_user
    assert await require_test_lead(admin_user) == admin_user
    assert await require_tester(admin_user) == admin_user
    assert await require_viewer(admin_user) == admin_user

    # Test Lead checks: passes lead, tester, viewer; fails admin
    with pytest.raises(HTTPException) as exc_info:
        await require_admin(lead_user)
    assert exc_info.value.status_code == 403
    assert await require_test_lead(lead_user) == lead_user
    assert await require_tester(lead_user) == lead_user
    assert await require_viewer(lead_user) == lead_user

    # Tester checks: passes tester, viewer; fails lead, admin
    with pytest.raises(HTTPException):
        await require_admin(tester_user)
    with pytest.raises(HTTPException):
        await require_test_lead(tester_user)
    assert await require_tester(tester_user) == tester_user
    assert await require_viewer(tester_user) == tester_user

    # Viewer checks: passes viewer; fails tester, lead, admin
    with pytest.raises(HTTPException):
        await require_admin(viewer_user)
    with pytest.raises(HTTPException):
        await require_test_lead(viewer_user)
    with pytest.raises(HTTPException):
        await require_tester(viewer_user)
    assert await require_viewer(viewer_user) == viewer_user


def test_project_membership_schema():
    """Verify ProjectMemberItem and requests validate properly."""
    add_req = AddProjectMemberRequest(
        user_id="65f0a1b2c3d4e5f6a7b8c9d0",
        role=Role.TESTER,
    )
    assert add_req.role == Role.TESTER

    update_req = UpdateProjectMemberRoleRequest(role=Role.TEST_LEAD)
    assert update_req.role == Role.TEST_LEAD


def test_audit_log_schema():
    """Verify AuditLogItem schema serialization."""
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    log_item = AuditLogItem(
        id="audit-123",
        user_id="user-123",
        username="admin_alice",
        action="USER_ROLE_UPDATED",
        resource_type="user",
        resource_id="user-456",
        details={"old_role": "Tester", "new_role": "Test Lead"},
        ip_address="127.0.0.1",
        timestamp=now,
    )
    assert log_item.action == "USER_ROLE_UPDATED"
    assert log_item.resource_type == "user"
    assert log_item.details["new_role"] == "Test Lead"


def test_user_management_schemas():
    """Verify user management request and response schemas."""
    create_req = CreateUserRequest(
        full_name="Bob Tester",
        username="bob_qa",
        email="bob@example.com",
        password="SecurePassword123!",
        role=Role.TESTER,
    )
    assert create_req.role == Role.TESTER

    role_req = UpdateRoleRequest(role=Role.TEST_LEAD)
    assert role_req.role == Role.TEST_LEAD

    status_req = UpdateStatusRequest(is_active=False)
    assert status_req.is_active is False
