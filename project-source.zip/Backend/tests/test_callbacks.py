"""Tests for qagenticx.callbacks TokenUsageCallback."""

from langchain_core.outputs import ChatGeneration, LLMResult
from langchain_core.messages import AIMessage
from qagenticx.callbacks import TokenUsageCallback


def test_token_callback_accumulates_counts():
    """Verify TokenUsageCallback captures tokens and accumulates totals across calls."""
    cb = TokenUsageCallback()
    assert cb.total_tokens == 0
    assert cb.call_count == 0

    # Call 1: via llm_output dict (e.g. OpenAI style)
    res1 = LLMResult(
        generations=[[]],
        llm_output={
            "token_usage": {
                "prompt_tokens": 120,
                "completion_tokens": 30,
                "total_tokens": 150,
                "total_cost": 0.0025,
            }
        },
    )
    cb.on_llm_end(res1)

    assert cb.call_count == 1
    assert cb.prompt_tokens == 120
    assert cb.completion_tokens == 30
    assert cb.total_tokens == 150
    assert cb.total_cost == 0.0025

    # Call 2: via AIMessage usage_metadata (e.g. Anthropic / newer LangChain style)
    msg = AIMessage(
        content="Response text",
        usage_metadata={"input_tokens": 80, "output_tokens": 20, "total_tokens": 100},
    )
    res2 = LLMResult(generations=[[ChatGeneration(message=msg)]])
    cb.on_llm_end(res2)

    assert cb.call_count == 2
    assert cb.prompt_tokens == 200
    assert cb.completion_tokens == 50
    assert cb.total_tokens == 250

    summary = cb.get_summary()
    assert summary["call_count"] == 2
    assert summary["prompt_tokens"] == 200
    assert summary["completion_tokens"] == 50
    assert summary["total_tokens"] == 250

    # Reset
    cb.reset()
    assert cb.total_tokens == 0
    assert cb.call_count == 0
