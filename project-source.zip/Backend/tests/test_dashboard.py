"""Dashboard aggregation API tests (spec §12 items 1-9, 13)."""
from __future__ import annotations

from datetime import datetime, timezone

from app.models.run import Run, RunStatus
from app.models.subproject import SubProject
from app.models.test_result import FailureCategory, TestResult, TestResultStatus


def _utc(year, month, day):
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


async def _make_subproject(name="Alpha") -> SubProject:
    proj = SubProject(
        code=f"PRJ-{name}",
        subscription_id="sub1",
        name=name,
        type="web",
        description="desc",
        accent_gradient="g",
    )
    await proj.insert()
    return proj


async def _make_run(subproject_id="sub1", status=RunStatus.PASSED.value, **kwargs) -> Run:
    run = Run(
        run_id=kwargs.pop("run_id", f"RUN-{datetime.now().timestamp()}"),
        subproject_id=subproject_id,
        project_name=kwargs.pop("project_name", "Alpha"),
        test_suite=kwargs.pop("test_suite", "Smoke"),
        status=status,
        **kwargs,
    )
    await run.insert()
    return run


async def _make_result(status, executed_at, failure_category=None, subproject_id="sub1"):
    tr = TestResult(
        run_id="RUN-x",
        subproject_id=subproject_id,
        status=status,
        failure_category=failure_category,
        executed_at=executed_at,
    )
    await tr.insert()
    return tr


# --- §12.1 summary with no records ----------------------------------------
async def test_summary_no_records(client):
    resp = await client.get("/api/dashboard/summary")
    assert resp.status_code == 200
    data = resp.json()
    assert data["totalProjects"] == 0
    assert data["totalRuns"] == 0
    assert data["failedTests"] == 0
    assert data["passRate"] is None
    assert data["totalTestCases"] is None
    assert data["locatorIssues"] is None
    assert data["timeRange"] == {"start": None, "end": None}
    assert data["lastUpdated"] is not None


# --- §12.2 summary with multiple projects + runs + results ----------------
async def test_summary_with_records(client):
    await _make_subproject("Alpha")
    await _make_subproject("Beta")
    await _make_run(status=RunStatus.PASSED.value, run_id="RUN-1")
    await _make_run(status=RunStatus.FAILED.value, run_id="RUN-2")
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 2))
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 3))
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 4))

    data = (await client.get("/api/dashboard/summary")).json()
    assert data["totalProjects"] == 2
    assert data["totalRuns"] == 2
    assert data["failedTests"] == 1
    # 3 passed / 4 completed = 75.0
    assert data["passRate"] == 75.0


# --- §12.3 pass-rate math 1dp ---------------------------------------------
async def test_pass_rate_one_decimal(client):
    # 2 passed / 3 completed = 66.666.. -> 66.7
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 1))
    data = (await client.get("/api/dashboard/summary")).json()
    assert data["passRate"] == 66.7


# --- §12.4 exclusion of running/queued/cancelled + skipped ----------------
async def test_pass_rate_excludes_non_completed(client):
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 1))
    # The following must NOT affect the pass rate denominator/numerator.
    await _make_result(TestResultStatus.SKIPPED.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.RUNNING.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.QUEUED.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.CANCELLED.value, _utc(2024, 1, 1))

    data = (await client.get("/api/dashboard/summary")).json()
    # 1 passed / 2 completed = 50.0
    assert data["passRate"] == 50.0
    assert data["failedTests"] == 1


# --- §12.5 historical pass-rate by period, ordered on executed_at ---------
async def test_pass_rate_trend_ordered_by_period(client):
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 15))
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 20))
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 2, 10))
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 2, 11))

    resp = await client.get("/api/dashboard/pass-rate-trend", params={"interval": "month"})
    assert resp.status_code == 200
    points = resp.json()
    assert [p["period"] for p in points] == ["2024-01-01", "2024-02-01"]
    assert points[0]["passed"] == 1 and points[0]["failed"] == 1
    assert points[0]["passRate"] == 50.0
    assert points[1]["passRate"] == 100.0


async def test_pass_rate_trend_empty(client):
    assert (await client.get("/api/dashboard/pass-rate-trend")).json() == []


# --- §12.6 execution counts by period, zero-filled, chronological ---------
async def test_execution_trend_zero_filled(client):
    await _make_run(run_id="R1", started_at=_utc(2024, 3, 1))
    await _make_run(run_id="R2", started_at=_utc(2024, 3, 1))
    await _make_run(run_id="R3", started_at=_utc(2024, 3, 3))

    resp = await client.get("/api/dashboard/execution-trend", params={"interval": "day"})
    points = resp.json()
    periods = [p["period"] for p in points]
    # Chronological and zero-filled across the range (Mar 1..Mar 3).
    assert periods == ["2024-03-01", "2024-03-02", "2024-03-03"]
    counts = {p["period"]: p["executionCount"] for p in points}
    assert counts["2024-03-01"] == 2
    assert counts["2024-03-02"] == 0
    assert counts["2024-03-03"] == 1


async def test_execution_trend_empty(client):
    assert (await client.get("/api/dashboard/execution-trend")).json() == []


# --- §12.7 failure-category totals incl Other = failed count --------------
async def test_failure_categories_total_matches_failed(client):
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 1), FailureCategory.PRODUCT_BUG.value)
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 1), FailureCategory.PRODUCT_BUG.value)
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 1), FailureCategory.ENVIRONMENT.value)
    # Uncategorized failure -> folds into Other.
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 1), None)
    # Passed results do not count toward categories.
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 1))

    cats = (await client.get("/api/dashboard/failure-categories")).json()
    by_cat = {c["category"]: c["count"] for c in cats}
    assert by_cat["Product Bug"] == 2
    assert by_cat["Environment"] == 1
    assert by_cat["Other"] == 1
    # Chart total agrees with the failed-result count (4).
    assert sum(c["count"] for c in cats) == 4


async def test_failure_categories_empty(client):
    assert (await client.get("/api/dashboard/failure-categories")).json() == []


# --- §12.8 locator-health unavailable -------------------------------------
async def test_locator_health_unavailable(client):
    resp = await client.get("/api/dashboard/locator-health")
    assert resp.status_code == 200
    assert resp.json() == []


# --- §12.9 recent-runs pagination -----------------------------------------
async def test_recent_runs_pagination(client):
    for i in range(25):
        await _make_run(run_id=f"RUN-{i:03d}", started_at=_utc(2024, 1, 1 + (i % 27)))

    page1 = (await client.get("/api/dashboard/recent-runs", params={"page": 1, "page_size": 10})).json()
    assert page1["total"] == 25
    assert page1["page"] == 1
    assert page1["pageSize"] == 10
    assert len(page1["items"]) == 10

    page3 = (await client.get("/api/dashboard/recent-runs", params={"page": 3, "page_size": 10})).json()
    assert len(page3["items"]) == 5

    # Non-overlapping slices.
    ids1 = {r["id"] for r in page1["items"]}
    ids3 = {r["id"] for r in page3["items"]}
    assert ids1.isdisjoint(ids3)


async def test_recent_runs_invalid_page_size_422(client):
    resp = await client.get("/api/dashboard/recent-runs", params={"page_size": 500})
    assert resp.status_code == 422


# --- range validation ------------------------------------------------------
async def test_invalid_interval_422(client):
    resp = await client.get("/api/dashboard/pass-rate-trend", params={"interval": "year"})
    assert resp.status_code == 422


async def test_start_after_end_400(client):
    resp = await client.get(
        "/api/dashboard/pass-rate-trend",
        params={"start_date": "2024-02-01", "end_date": "2024-01-01"},
    )
    assert resp.status_code == 400


async def test_invalid_project_id_empty_page_not_500(client):
    resp = await client.get("/api/dashboard/recent-runs", params={"project_id": "not-an-objectid"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["items"] == []
    assert data["total"] == 0


# --- §12.13 unauthenticated -> 401 on every endpoint ----------------------
async def test_unauthenticated_endpoints_401(unauth_client):
    # An invalid bearer token drives get_current_user to reject with 401 (the
    # app's existing HTTPBearer returns 403 only when the header is wholly
    # absent; sending a bogus token exercises the 401 auth path).
    headers = {"Authorization": "Bearer not-a-real-token"}
    paths = [
        "/api/dashboard/summary",
        "/api/dashboard/pass-rate-trend",
        "/api/dashboard/execution-trend",
        "/api/dashboard/failure-categories",
        "/api/dashboard/locator-health",
        "/api/dashboard/recent-runs",
        "/api/runs/RUN-1",
    ]
    for path in paths:
        resp = await unauth_client.get(path, headers=headers)
        assert resp.status_code == 401, path

    assert (
        await unauth_client.post(
            "/api/runs", json={"subprojectId": "x", "testSuite": "s"}, headers=headers
        )
    ).status_code == 401
    assert (
        await unauth_client.post(
            "/api/runs/RUN-1/complete", json={"status": "Passed"}, headers=headers
        )
    ).status_code == 401
