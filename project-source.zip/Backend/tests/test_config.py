"""Tests for qagenticx.config project loader and schema."""

from pathlib import Path
import pytest

from qagenticx.config import (
    BrowserConfig,
    LLMConfig,
    ProjectConfig,
    ProjectConfigError,
    list_projects,
    load_project,
)


def test_minimal_load(tmp_path: Path):
    """Test loading a minimal valid project.yaml."""
    proj_dir = tmp_path / "minimal-proj"
    proj_dir.mkdir()
    (proj_dir / "project.yaml").write_text(
        """
name: Minimal Project
target_url: https://example.com/login
""",
        encoding="utf-8",
    )

    config = load_project("minimal-proj", projects_dir=tmp_path)
    assert config.id == "minimal-proj"
    assert config.name == "Minimal Project"
    assert config.target_url == "https://example.com/login"
    assert config.description == ""
    assert isinstance(config.browser, BrowserConfig)
    assert config.browser.engine == "chromium"
    assert config.browser.headless is True
    assert isinstance(config.llm, LLMConfig)
    assert config.llm.provider == "openai"
    assert config.goals == []


def test_folder_name_wins_over_yaml_id(tmp_path: Path):
    """Test that the folder name is used as id even if project.yaml specifies an id."""
    proj_dir = tmp_path / "folder-id"
    proj_dir.mkdir()
    (proj_dir / "project.yaml").write_text(
        """
id: id-inside-yaml
name: Override ID Project
target_url: https://example.com
""",
        encoding="utf-8",
    )

    config = load_project("folder-id", projects_dir=tmp_path)
    assert config.id == "folder-id"


def test_missing_project_raises(tmp_path: Path):
    """Test that loading a non-existent project folder raises ProjectConfigError."""
    with pytest.raises(ProjectConfigError, match="Project directory does not exist"):
        load_project("non-existent-project", projects_dir=tmp_path)


def test_missing_required_field_raises(tmp_path: Path):
    """Test that missing required fields (e.g. target_url) raises ProjectConfigError."""
    proj_dir = tmp_path / "missing-url"
    proj_dir.mkdir()
    (proj_dir / "project.yaml").write_text(
        """
name: Incomplete Project
""",
        encoding="utf-8",
    )

    with pytest.raises(ProjectConfigError, match="Schema validation error"):
        load_project("missing-url", projects_dir=tmp_path)


def test_unknown_field_rejected(tmp_path: Path):
    """Test that unknown fields are rejected because extra='forbid'."""
    proj_dir = tmp_path / "extra-field"
    proj_dir.mkdir()
    (proj_dir / "project.yaml").write_text(
        """
name: Extra Field Project
target_url: https://example.com
unexpected_key: not_allowed
""",
        encoding="utf-8",
    )

    with pytest.raises(ProjectConfigError, match="extra_forbidden|extra fields not permitted"):
        load_project("extra-field", projects_dir=tmp_path)


def test_malformed_yaml_raises(tmp_path: Path):
    """Test that invalid YAML syntax raises ProjectConfigError."""
    proj_dir = tmp_path / "malformed"
    proj_dir.mkdir()
    (proj_dir / "project.yaml").write_text(
        """
name: Broken Project
target_url: [unclosed list
""",
        encoding="utf-8",
    )

    with pytest.raises(ProjectConfigError, match="Malformed YAML"):
        load_project("malformed", projects_dir=tmp_path)


def test_list_projects_ignores_folders_without_project_yaml(tmp_path: Path):
    """Test list_projects filters and returns sorted valid project directories."""
    # Project 1: valid
    p1 = tmp_path / "proj-b"
    p1.mkdir()
    (p1 / "project.yaml").write_text("name: B\ntarget_url: https://b.com\n", encoding="utf-8")

    # Project 2: valid
    p2 = tmp_path / "proj-a"
    p2.mkdir()
    (p2 / "project.yaml").write_text("name: A\ntarget_url: https://a.com\n", encoding="utf-8")

    # Folder without project.yaml
    p3 = tmp_path / "not-a-project"
    p3.mkdir()
    (p3 / "other.txt").write_text("some note", encoding="utf-8")

    # A file in the projects directory
    (tmp_path / "regular_file.txt").write_text("not a folder", encoding="utf-8")

    result = list_projects(projects_dir=tmp_path)
    assert result == ["proj-a", "proj-b"]


def test_bundled_example_project_loads():
    """Test that the bundled example project loads successfully."""
    config = load_project("example")
    assert config.id == "example"
    assert config.name == "Example QA Project"
    assert config.target_url == "https://example.com"
    assert config.browser.engine == "chromium"
    assert len(config.goals) >= 2
