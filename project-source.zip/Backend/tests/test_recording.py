"""Run/result/event recording tests (FEAT-003).

Covers the persistence seam behind dashboard counts:
- create_run writes a Run; complete_run persists linked TestResult rows with the
  right passed/failed counts.
- record_event persists a RunEvent and is idempotent on (run_id, type,
  step_number) — a duplicate yields exactly one row and never double counts.
- get_run_detail surfaces the recorded events.
- Driving run_kiro_agent with the Kiro binary absent writes a Run + TestResult +
  RunEvent + DashboardMetric and leaves artifact files on disk.
"""
from __future__ import annotations

import os
import shutil
import uuid

import pytest_asyncio

from app.agent import kiro_agent
from app.core.config import settings
from app.models.dashboard_metric import DashboardMetric
from app.models.run import Run, RunStatus
from app.models.run_event import RunEvent
from app.models.test_result import TestResult, TestResultStatus
from app.schemas.dashboard import RunCompleteIn, RunCreateIn, TestResultIn
from app.schemas.kiro import KiroExecuteRequest
from app.services import dashboard_service


# --- create_run / complete_run persistence ---------------------------------
async def test_create_run_persists_run(client):
    run = await dashboard_service.create_run(
        RunCreateIn(subproject_id="x", test_suite="Smoke")
    )
    stored = await Run.find_one(Run.run_id == run.run_id)
    assert stored is not None
    assert stored.status == RunStatus.RUNNING.value
    assert stored.test_suite == "Smoke"


async def test_complete_run_persists_linked_results(client):
    run = await dashboard_service.create_run(
        RunCreateIn(subproject_id="x", test_suite="Smoke")
    )
    await dashboard_service.complete_run(
        run.run_id,
        RunCompleteIn(
            status=RunStatus.FAILED.value,
            results=[
                TestResultIn(status=TestResultStatus.PASSED.value),
                TestResultIn(status=TestResultStatus.PASSED.value),
                TestResultIn(status=TestResultStatus.FAILED.value),
            ],
        ),
    )

    results = await TestResult.find(TestResult.run_id == run.run_id).to_list()
    assert len(results) == 3

    completed = await Run.find_one(Run.run_id == run.run_id)
    assert completed.status == RunStatus.FAILED.value
    assert completed.passed_count == 2
    assert completed.failed_count == 1
    assert completed.duration_ms is not None


async def test_complete_run_idempotent_on_terminal(client):
    run = await dashboard_service.create_run(
        RunCreateIn(subproject_id="x", test_suite="Smoke")
    )
    await dashboard_service.complete_run(
        run.run_id,
        RunCompleteIn(
            status=RunStatus.PASSED.value,
            results=[TestResultIn(status=TestResultStatus.PASSED.value)],
        ),
    )
    # Second completion is a no-op: counts are not doubled, no extra results.
    again = await dashboard_service.complete_run(
        run.run_id,
        RunCompleteIn(
            status=RunStatus.FAILED.value,
            results=[TestResultIn(status=TestResultStatus.FAILED.value)],
        ),
    )
    assert again.status == RunStatus.PASSED.value
    assert again.passed_count == 1
    assert again.failed_count == 0
    assert await TestResult.find(TestResult.run_id == run.run_id).count() == 1


# --- record_event idempotency ---------------------------------------------
async def test_record_event_persists(client):
    run = await dashboard_service.create_run(
        RunCreateIn(subproject_id="x", test_suite="Smoke")
    )
    await dashboard_service.record_event(
        run.run_id, "step.1", "Planner Agent", step_number=1, status="completed"
    )
    events = await RunEvent.find(RunEvent.run_id == run.run_id).to_list()
    assert len(events) == 1
    assert events[0].type == "step.1"
    assert events[0].message == "Planner Agent"


async def test_record_event_idempotent_no_double_count(client):
    run = await dashboard_service.create_run(
        RunCreateIn(subproject_id="x", test_suite="Smoke")
    )
    # Same (run_id, type, step_number) recorded twice -> exactly one row.
    await dashboard_service.record_event(
        run.run_id, "step.1", "Planner Agent", step_number=1, status="completed"
    )
    await dashboard_service.record_event(
        run.run_id, "step.1", "Planner Agent (retry)", step_number=1, status="completed"
    )
    events = await RunEvent.find(
        RunEvent.run_id == run.run_id, RunEvent.type == "step.1"
    ).to_list()
    assert len(events) == 1


async def test_get_run_detail_includes_events(client):
    run = await dashboard_service.create_run(
        RunCreateIn(subproject_id="x", test_suite="Smoke")
    )
    await dashboard_service.record_event(
        run.run_id, "execution.started", "Execution started", step_number=0, status="completed"
    )
    await dashboard_service.record_event(
        run.run_id, "step.1", "Planner Agent", step_number=1, status="completed"
    )

    detail = await dashboard_service.get_run_detail(run.run_id)
    assert detail is not None
    types = [e.type for e in detail.events]
    assert "execution.started" in types
    assert "step.1" in types


# --- run_kiro_agent end-to-end (Kiro binary absent) ------------------------
@pytest_asyncio.fixture
async def temp_workspace():
    """A unique workspace folder inside the allowlisted default root.

    run_kiro_agent resolves a relative workspace_path against
    resolved_workspace_root, so a relative name keeps artifacts inside the
    allowlist. The folder (and its generated artifacts) is removed afterward.
    """
    rel = f"test_rec_{uuid.uuid4().hex}"
    abs_path = os.path.join(settings.resolved_workspace_root, rel)
    try:
        yield rel, abs_path
    finally:
        shutil.rmtree(abs_path, ignore_errors=True)


async def test_run_kiro_agent_records_and_writes_artifacts(
    client, monkeypatch, temp_workspace
):
    rel, abs_path = temp_workspace
    # Force the synthesis path (no real Kiro binary required).
    monkeypatch.setattr(kiro_agent, "find_kiro_binary", lambda: None)

    resp = await kiro_agent.run_kiro_agent(
        KiroExecuteRequest(
            prompt="Generate Playwright tests for the login authentication flow",
            workspace_path=rel,
            subproject_id="",
        )
    )
    assert resp.status == "SUCCESS"

    # A Run reached a terminal status.
    runs = await Run.find().to_list()
    assert len(runs) == 1
    run = runs[0]
    assert run.status in {RunStatus.PASSED.value, RunStatus.FAILED.value}

    # Linked test results (execute agent stub currently yields 3 passed / 0 failed).
    results = await TestResult.find(TestResult.run_id == run.run_id).to_list()
    assert len(results) == run.passed_count + run.failed_count
    assert len(results) >= 1

    # Lifecycle events recorded, including start + per-step + completion.
    events = await RunEvent.find(RunEvent.run_id == run.run_id).to_list()
    event_types = {e.type for e in events}
    assert "execution.started" in event_types
    assert any(t.startswith("step.") for t in event_types)
    assert "execution.completed" in event_types or "execution.blocked" in event_types

    # A DashboardMetric current snapshot and at least one history row exist.
    assert await DashboardMetric.find(DashboardMetric.kind == "current").count() == 1
    assert await DashboardMetric.find(DashboardMetric.kind == "history").count() >= 1

    # Artifact files were created on disk under the temp workspace.
    assert os.path.exists(os.path.join(abs_path, "Reports", "results.json"))
    assert os.path.isdir(os.path.join(abs_path, "Scripts"))
