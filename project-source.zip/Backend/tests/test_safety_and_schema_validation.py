"""Unit test suite for testcase/script schema validation and static safety checks before execution.

Acceptance:
- Invalid testcase schemas (missing steps, illegal category/priority, empty expected result) are blocked.
- Invalid script contracts (outside Scripts/, illegal extension, missing Playwright structure) are blocked.
- Unsafe script patterns (child_process, eval, destructive filesystem ops, SSRF to cloud metadata, process.exit) are detected and blocked.
- ExecuteAgent pre-execution gate blocks invalid or unsafe outputs before running.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

# Add Backend root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.config import settings
from app.agent.safety import (
    run_static_safety_checks,
    validate_pre_execution_safety,
    validate_script_contract,
    validate_testcase_schema,
)
from app.agent.execute_agent import run_execute_agent
from app.schemas.agent_contracts import ExecuteAgentInput, TestCaseItem


class TestSafetyAndSchemaValidation(unittest.TestCase):
    """Test suite verifying schema validation and static safety inspection before test execution."""

    @classmethod
    def setUpClass(cls):
        os.makedirs(settings.resolved_workspace_root, exist_ok=True)

    # =========================================================================
    # 1. TESTCASE SCHEMA VALIDATION TESTS
    # =========================================================================

    def test_valid_testcase_schema_accepted(self):
        """Standard valid testcase items must pass schema validation."""
        valid_cases = [
            {
                "id": "TC-101",
                "title": "Verify user authentication",
                "description": "Happy path login verification",
                "category": "Smoke",
                "priority": "High",
                "steps": ["Navigate to login", "Fill username and password", "Click submit"],
                "expectedResult": "User dashboard is displayed with 200 OK state.",
            },
            {
                "id": "TC-102",
                "title": "Boundary rejection of oversized inputs",
                "description": "Validates form input boundaries",
                "category": "Boundary",
                "priority": "Medium",
                "steps": ["Enter 5000 characters", "Click submit"],
                "expectedResult": "Validation notice appears.",
            },
        ]
        is_valid, errors = validate_testcase_schema(valid_cases)
        self.assertTrue(is_valid, f"Valid testcases were incorrectly rejected: {errors}")
        self.assertEqual(len(errors), 0)

    def test_invalid_testcase_missing_steps_blocked(self):
        """Testcase with empty steps list must be blocked."""
        invalid_case = {
            "id": "TC-101",
            "title": "Invalid testcase with no steps",
            "description": "Missing steps",
            "category": "Smoke",
            "priority": "High",
            "steps": [],
            "expectedResult": "Should fail",
        }
        is_valid, errors = validate_testcase_schema([invalid_case])
        self.assertFalse(is_valid)
        self.assertTrue(any("step" in e.lower() for e in errors), f"Expected steps error, got: {errors}")

    def test_invalid_testcase_illegal_category_blocked(self):
        """Testcase with an unrecognized category must be blocked."""
        invalid_case = {
            "id": "TC-101",
            "title": "Invalid category test",
            "description": "Bad category",
            "category": "UnrecognizedCategoryXYZ",
            "priority": "High",
            "steps": ["Step 1"],
            "expectedResult": "Passes",
        }
        is_valid, errors = validate_testcase_schema([invalid_case])
        self.assertFalse(is_valid)
        self.assertTrue(any("category" in e.lower() for e in errors), f"Expected category error, got: {errors}")

    def test_invalid_testcase_illegal_priority_blocked(self):
        """Testcase with an unrecognized priority must be blocked."""
        invalid_case = {
            "id": "TC-101",
            "title": "Invalid priority test",
            "description": "Bad priority",
            "category": "Smoke",
            "priority": "UltraHighUrgent",
            "steps": ["Step 1"],
            "expectedResult": "Passes",
        }
        is_valid, errors = validate_testcase_schema([invalid_case])
        self.assertFalse(is_valid)
        self.assertTrue(any("priority" in e.lower() for e in errors), f"Expected priority error, got: {errors}")

    def test_empty_testcase_dataset_blocked(self):
        """Empty list of test cases must be rejected."""
        is_valid, errors = validate_testcase_schema([])
        self.assertFalse(is_valid)
        self.assertIn("empty", errors[0].lower())

    # =========================================================================
    # 2. SCRIPT CONTRACT & PATH VALIDATION TESTS
    # =========================================================================

    def test_valid_script_contract_accepted(self):
        """Playwright spec located under Scripts/ with test structure must pass."""
        script_path = "Scripts/auth.spec.ts"
        content = """import { test, expect } from '@playwright/test';
test.describe('Auth Suite', () => {
  test('[@TC-101] Login user', async ({ page }) => {
    await page.goto('https://demo.qagentix.io');
    await expect(page).toHaveTitle(/Demo/);
  });
});
"""
        is_valid, errors = validate_script_contract(script_path, content)
        self.assertTrue(is_valid, f"Valid script contract failed: {errors}")

    def test_script_outside_scripts_directory_blocked(self):
        """Script located outside Scripts/ directory contract must be blocked."""
        is_valid, errors = validate_script_contract("src/tests/test.spec.ts")
        self.assertFalse(is_valid)
        self.assertTrue(any("Scripts/" in e for e in errors))

    def test_script_path_traversal_blocked(self):
        """Script path containing .. path traversal must be blocked."""
        is_valid, errors = validate_script_contract("Scripts/../../etc/passwd.spec.ts")
        self.assertFalse(is_valid)
        self.assertTrue(any("traversal" in e.lower() for e in errors))

    def test_script_invalid_extension_blocked(self):
        """Script with non-test extension must be blocked."""
        is_valid, errors = validate_script_contract("Scripts/payload.exe")
        self.assertFalse(is_valid)
        self.assertTrue(any("extension" in e.lower() for e in errors))

    def test_spec_missing_playwright_structure_blocked(self):
        """Spec file without Playwright test blocks or imports must be blocked."""
        script_path = "Scripts/empty_test.spec.ts"
        content = "// Just a comment, no tests defined here"
        is_valid, errors = validate_script_contract(script_path, content)
        self.assertFalse(is_valid)
        self.assertTrue(any("structure" in e.lower() or "test" in e.lower() for e in errors))

    # =========================================================================
    # 3. STATIC SAFETY CHECKS (BLOCKING DANGEROUS CODE)
    # =========================================================================

    def test_safe_playwright_code_passes(self):
        """Standard safe Playwright actions, POM methods, and assertions must pass."""
        safe_code = """import { test, expect } from '@playwright/test';
import { AuthPage } from './pages/AuthPage';

test.describe('Standard Flow', () => {
  test('[@TC-101] Form submission and alert validation', async ({ page }) => {
    const auth = new AuthPage(page);
    await auth.goto();
    await page.getByRole('textbox').fill('testuser');
    await page.getByRole('button', { name: 'Submit' }).click();
    await expect(page.locator('.toast')).toBeVisible();
  });
});
"""
        is_safe, violations = run_static_safety_checks(safe_code, "Scripts/safe.spec.ts")
        self.assertTrue(is_safe, f"Safe script was falsely flagged: {violations}")
        self.assertEqual(len(violations), 0)

    def test_block_child_process_and_exec(self):
        """Scripts invoking child_process or exec/spawn must be blocked."""
        malicious_samples = [
            "import { exec } from 'child_process'; exec('dir');",
            "const cp = require('child_process'); cp.spawnSync('powershell.exe');",
            "import * as cp from 'child_process';",
            "execSync('whoami');",
            "execFile('/bin/sh', ['-c', 'id']);",
        ]
        for idx, code in enumerate(malicious_samples):
            is_safe, violations = run_static_safety_checks(code, f"Scripts/malicious_{idx}.spec.ts")
            self.assertFalse(is_safe, f"Failed to block dangerous code: {code}")
            self.assertTrue(any("DANGEROUS_SUBPROCESS" in v for v in violations), f"Violations: {violations}")

    def test_block_eval_and_function_constructor(self):
        """Dynamic code evaluation via eval() or Function() must be blocked."""
        eval_samples = [
            "eval('console.log(process.mainModule)');",
            "const fn = new Function('return process'); fn();",
            "const res = Function('return this')();",
            "vm.runInNewContext('1 + 1');",
        ]
        for code in eval_samples:
            is_safe, violations = run_static_safety_checks(code, "Scripts/eval_test.spec.ts")
            self.assertFalse(is_safe, f"Failed to block dynamic eval: {code}")
            self.assertTrue(any("DYNAMIC_EVALUATION" in v for v in violations))

    def test_block_destructive_filesystem_operations(self):
        """Destructive fs methods (rmSync, unlink, rimraf) must be blocked."""
        destructive_samples = [
            "import fs from 'fs'; fs.rmSync('/var/log', { recursive: true });",
            "fs.unlinkSync('./workspace_data.db');",
            "rimraf.sync('C:/Windows');",
        ]
        for code in destructive_samples:
            is_safe, violations = run_static_safety_checks(code, "Scripts/destroy.spec.ts")
            self.assertFalse(is_safe, f"Failed to block destructive fs op: {code}")
            self.assertTrue(any("DESTRUCTIVE_FILESYSTEM" in v for v in violations))

    def test_block_process_exit_and_kill(self):
        """Tampering with runner process (process.exit, process.kill) must be blocked."""
        tampering_samples = [
            "process.exit(1);",
            "process.kill(process.pid);",
            "delete process.env;",
        ]
        for code in tampering_samples:
            is_safe, violations = run_static_safety_checks(code, "Scripts/tamper.spec.ts")
            self.assertFalse(is_safe, f"Failed to block process tampering: {code}")
            self.assertTrue(any("PROCESS_TAMPERING" in v for v in violations))

    def test_block_ssrf_and_cloud_metadata_endpoints(self):
        """Attempts to query link-local cloud metadata (169.254.169.254) must be blocked."""
        ssrf_samples = [
            "await page.goto('http://169.254.169.254/latest/meta-data/');",
            "await page.goto('http://metadata.google.internal/computeMetadata/v1/');",
            "await page.goto('http://100.100.100.200/latest/meta-data/');",
        ]
        for code in ssrf_samples:
            is_safe, violations = run_static_safety_checks(code, "Scripts/ssrf.spec.ts")
            self.assertFalse(is_safe, f"Failed to block SSRF cloud metadata access: {code}")
            self.assertTrue(any("SSRF_CLOUD_METADATA" in v for v in violations))

    def test_block_file_and_javascript_pseudo_protocols(self):
        """Navigation via file:// or javascript: URLs must be blocked."""
        unsafe_uris = [
            "await page.goto('file:///etc/passwd');",
            "await page.goto('javascript:void(document.cookie)');",
        ]
        for code in unsafe_uris:
            is_safe, violations = run_static_safety_checks(code, "Scripts/unsafe_uri.spec.ts")
            self.assertFalse(is_safe, f"Failed to block disallowed protocol: {code}")
            self.assertTrue(any("DISALLOWED_PROTOCOL" in v for v in violations))

    # =========================================================================
    # 4. PRE-EXECUTION GATE IN EXECUTE AGENT (END-TO-END BLOCKING)
    # =========================================================================

    def test_execute_agent_blocks_unsafe_script(self):
        """ExecuteAgent must block execution when a script contains unsafe code, setting status=ERROR."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            scripts_dir = os.path.join(tmpdir, "Scripts")
            os.makedirs(scripts_dir, exist_ok=True)

            malicious_spec = os.path.join(scripts_dir, "attack.spec.ts")
            malicious_content = """import { test, expect } from '@playwright/test';
const cp = require('child_process');

test('[@TC-999] Injected test', async ({ page }) => {
  cp.execSync('calc.exe');
  await expect(page).toBeDefined();
});
"""
            with open(malicious_spec, "w", encoding="utf-8") as f:
                f.write(malicious_content)

            payload = ExecuteAgentInput(
                workspace_path=tmpdir,
                script_paths=["Scripts/attack.spec.ts"],
            )

            # Run execute agent
            output = run_execute_agent(payload)

            # Execution MUST be blocked
            self.assertEqual(output.status, "ERROR")
            self.assertEqual(output.passed_count, 0)
            self.assertEqual(output.failed_count, 0)

            # Check execution.log records blocked state
            log_path = os.path.join(tmpdir, output.log_path)
            self.assertTrue(os.path.isfile(log_path))
            with open(log_path, "r", encoding="utf-8") as f:
                log_text = f.read()
            self.assertIn("Execution Blocked", log_text)
            self.assertIn("DANGEROUS_SUBPROCESS", log_text)

            # Check results.json records blocked flag
            results_path = os.path.join(tmpdir, output.results_json_path)
            self.assertTrue(os.path.isfile(results_path))
            with open(results_path, "r", encoding="utf-8") as f:
                results_json = json.load(f)
            self.assertEqual(results_json["status"], "ERROR")
            self.assertTrue(results_json["blocked"])

    def test_execute_agent_blocks_invalid_testcase_schema(self):
        """ExecuteAgent must block execution if workspace contains invalid testcases.json."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            tc_dir = os.path.join(tmpdir, "Test_cases")
            os.makedirs(tc_dir, exist_ok=True)
            scripts_dir = os.path.join(tmpdir, "Scripts")
            os.makedirs(scripts_dir, exist_ok=True)

            # Write corrupt testcase (missing steps and expected result)
            corrupt_tc = [
                {"id": "TC-101", "title": "Missing required fields"}
            ]
            with open(os.path.join(tc_dir, "testcases.json"), "w", encoding="utf-8") as f:
                json.dump(corrupt_tc, f)

            # Write standard safe spec
            safe_spec = """import { test, expect } from '@playwright/test';
test('[@TC-101] Sample test', async ({ page }) => {
  await page.goto('https://demo.qagentix.io');
});
"""
            with open(os.path.join(scripts_dir, "sample.spec.ts"), "w", encoding="utf-8") as f:
                f.write(safe_spec)

            payload = ExecuteAgentInput(
                workspace_path=tmpdir,
                script_paths=["Scripts/sample.spec.ts"],
            )

            output = run_execute_agent(payload)

            # Blocked due to schema defect
            self.assertEqual(output.status, "ERROR")
            self.assertEqual(output.passed_count, 0)

            # Log records schema error
            with open(os.path.join(tmpdir, output.log_path), "r", encoding="utf-8") as f:
                log_text = f.read()
            self.assertIn("Testcase Schema Error", log_text)

    def test_execute_agent_allows_valid_and_safe_suite(self):
        """ExecuteAgent executes normally (PASS) when testcases and scripts are valid and safe."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            tc_dir = os.path.join(tmpdir, "Test_cases")
            scripts_dir = os.path.join(tmpdir, "Scripts")
            pages_dir = os.path.join(scripts_dir, "pages")
            os.makedirs(tc_dir, exist_ok=True)
            os.makedirs(pages_dir, exist_ok=True)

            # Valid testcases
            valid_tc = [
                {
                    "id": "TC-101",
                    "title": "Primary flow",
                    "description": "Happy path",
                    "category": "Smoke",
                    "priority": "High",
                    "steps": ["Step 1", "Step 2"],
                    "expectedResult": "200 OK",
                }
            ]
            with open(os.path.join(tc_dir, "testcases.json"), "w", encoding="utf-8") as f:
                json.dump(valid_tc, f)

            # Valid page object
            pom_code = """import { type Page } from '@playwright/test';
export class AppFlowPage {
  readonly page: Page;
  constructor(page: Page) { this.page = page; }
  async goto() { await this.page.goto('https://demo.qagentix.io'); }
}
"""
            with open(os.path.join(pages_dir, "AppFlowPage.ts"), "w", encoding="utf-8") as f:
                f.write(pom_code)

            # Valid safe spec
            safe_spec = """import { test, expect } from '@playwright/test';
import { AppFlowPage } from './pages/AppFlowPage';

test.describe('App Suite', () => {
  test('[@TC-101] Verify primary flow', async ({ page }) => {
    const appPage = new AppFlowPage(page);
    await appPage.goto();
    await expect(page).toBeDefined();
  });
});
"""
            with open(os.path.join(scripts_dir, "app_flow.spec.ts"), "w", encoding="utf-8") as f:
                f.write(safe_spec)

            payload = ExecuteAgentInput(
                workspace_path=tmpdir,
                script_paths=["Scripts/app_flow.spec.ts"],
            )

            output = run_execute_agent(payload)

            self.assertEqual(output.status, "PASS")
            self.assertGreater(output.passed_count, 0)
            self.assertEqual(output.failed_count, 0)

            # Log confirms verification passed
            with open(os.path.join(tmpdir, output.log_path), "r", encoding="utf-8") as f:
                log_text = f.read()
            self.assertIn("Pre-execution verification: PASSED", log_text)


if __name__ == "__main__":
    unittest.main()
