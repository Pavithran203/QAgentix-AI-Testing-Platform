"""Pytest fixtures for the dashboard/runs backend tests.

Each test runs against a fresh in-memory Mongo (mongomock-motor). If that package
cannot be imported (e.g. install failed with no network), the suite falls back to
a reachable MongoDB via the MONGODB_URI env var with identical assertions. The
`get_current_user` dependency is overridden with a fake active User so the tests
exercise the auth-protected handlers without issuing real JWTs; a dedicated
`unauth_client` leaves auth in place to assert 401s.
"""
from __future__ import annotations

import os
import uuid

import pytest_asyncio
from beanie import init_beanie
from httpx import ASGITransport, AsyncClient

from app.api.deps import get_current_user
from app.core.roles import Role
from app.db.mongodb import DOCUMENT_MODELS
from app.main import app
from app.models.user import User

def _fake_user() -> User:
    """A fake active user. Built lazily (after init_beanie) to satisfy Beanie."""
    return User(
        full_name="Test User",
        username="tester",
        email="tester@example.com",
        hashed_password="x",
        role=Role.ADMIN,
        is_active=True,
    )


async def _init_db():
    """Init Beanie against mongomock-motor, or a real test Mongo as a fallback.

    A unique database name per call isolates tests from one another.
    """
    db_name = f"qagenticx_test_{uuid.uuid4().hex}"
    try:
        from mongomock_motor import AsyncMongoMockClient

        client = AsyncMongoMockClient()
    except Exception:  # noqa: BLE001 - fall back to a real test Mongo
        from motor.motor_asyncio import AsyncIOMotorClient

        uri = os.environ.get("MONGODB_URI")
        if not uri:
            raise RuntimeError(
                "mongomock-motor is unavailable and MONGODB_URI is not set; "
                "cannot run the backend tests."
            )
        client = AsyncIOMotorClient(uri)

    await init_beanie(database=client[db_name], document_models=DOCUMENT_MODELS)
    return client, db_name


@pytest_asyncio.fixture
async def db():
    client, db_name = await _init_db()
    try:
        yield client
    finally:
        # Each test uses a unique db name, so simply closing the client is enough
        # isolation. (drop_database is a coroutine on motor; avoid awaiting here.)
        client.close()


@pytest_asyncio.fixture
async def client(db):
    """Auth-protected ASGI client (get_current_user overridden with a fake user)."""
    fake_user = _fake_user()
    app.dependency_overrides[get_current_user] = lambda: fake_user
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.pop(get_current_user, None)


@pytest_asyncio.fixture
async def unauth_client(db):
    """ASGI client WITHOUT the auth override, to assert 401 on protected routes."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
