"""Unit tests for Playwright Script Agent contract:
- Playwright spec and Page Object Model generation under Scripts/
- Bidirectional linkage to Test Case IDs ([@TC-XXX])
- Structured locator references with resilient strategies & healing candidates
- Automatic synchronization with Test_cases/testcases.json
- Self-healing mode using fallback selectors
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

# Add Backend root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.agent.script_agent import run_script_agent, _default_locators_for_subject
from app.core.config import settings
from app.schemas.agent_contracts import (
    LocatorReference,
    ScriptAgentInput,
    ScriptAgentOutput,
    TestCaseItem,
    TestCaseScriptLink,
)


class TestPlaywrightScriptContract(unittest.TestCase):
    """Test suite for Playwright script contract linked to testcase IDs and locator references."""

    def setUp(self):
        self.sample_cases = [
            TestCaseItem(
                id="TC-101",
                title="Verify user login and navigation",
                description="Validates primary login path",
                category="Smoke",
                priority="High",
                steps=["Navigate to login", "Enter credentials", "Click submit"],
                expectedResult="User is redirected to dashboard with 200 OK status.",
            ),
            TestCaseItem(
                id="TC-102",
                title="Filter channel list by voice type",
                description="Validates table filtering for voice channels",
                category="E2E",
                priority="High",
                steps=["Open channel table", "Apply voice filter", "Click next page"],
                expectedResult="Table updates to show active voice channels.",
            ),
            TestCaseItem(
                id="TC-103",
                title="Reject malformed payload gracefully",
                description="Tests SQL/XSS input sanitization",
                category="Boundary",
                priority="Medium",
                steps=["Enter injection string", "Submit form"],
                expectedResult="Error alert is displayed; application does not crash.",
            ),
        ]

    def test_script_creation_and_paths(self):
        """Playwright scripts must be saved strictly under Scripts/ and Scripts/pages/."""
        os.makedirs(settings.resolved_workspace_root, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            payload = ScriptAgentInput(
                mode="create",
                subject="channels",
                testcases=self.sample_cases,
                workspace_path=tmpdir,
            )
            output = run_script_agent(payload)

            self.assertIsInstance(output, ScriptAgentOutput)
            self.assertEqual(output.spec_path, "Scripts/channels.spec.ts")
            self.assertEqual(output.page_object_path, "Scripts/pages/ChannelsPage.ts")

            # Check files exist on disk in workspace
            spec_full = os.path.join(tmpdir, output.spec_path)
            pom_full = os.path.join(tmpdir, output.page_object_path)
            self.assertTrue(os.path.isfile(spec_full), f"Spec file missing: {spec_full}")
            self.assertTrue(os.path.isfile(pom_full), f"POM file missing: {pom_full}")

    def test_testcase_id_linkage(self):
        """Each test block and case_link must explicitly link to testcase IDs."""
        os.makedirs(settings.resolved_workspace_root, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            payload = ScriptAgentInput(
                mode="create",
                subject="channels",
                testcases=self.sample_cases,
                workspace_path=tmpdir,
            )
            output = run_script_agent(payload)

            # Check linked_testcase_ids contains all input IDs
            self.assertEqual(output.linked_testcase_ids, ["TC-101", "TC-102", "TC-103"])
            self.assertEqual(len(output.case_links), 3)

            for link in output.case_links:
                self.assertIsInstance(link, TestCaseScriptLink)
                self.assertIn(link.testcase_id, ["TC-101", "TC-102", "TC-103"])
                self.assertTrue(link.test_block_name.startswith(f"[@{link.testcase_id}]"))
                self.assertIn(link.test_block_name, output.spec_content)
                self.assertGreater(len(link.locators_used), 0)

    def test_locator_references_and_page_object(self):
        """Page Object must define typed Locator references with resilient strategies."""
        os.makedirs(settings.resolved_workspace_root, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            payload = ScriptAgentInput(
                mode="create",
                subject="channels",
                testcases=self.sample_cases,
                workspace_path=tmpdir,
            )
            output = run_script_agent(payload)

            self.assertGreater(len(output.locator_references), 0)
            loc_names = {loc.name for loc in output.locator_references}

            # Check core semantic locators exist
            self.assertIn("submitButton", loc_names)
            self.assertIn("inputField", loc_names)
            self.assertIn("filterCheckbox", loc_names)

            # Check POM content defines them
            for loc in output.locator_references:
                self.assertIn(f"readonly {loc.name}: Locator;", output.page_object_content)
                self.assertGreater(len(loc.healing_candidates), 0)

    def test_testcases_json_synchronization(self):
        """When Test_cases/testcases.json exists, scriptPath and testMethod must be synced."""
        os.makedirs(settings.resolved_workspace_root, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            tc_dir = os.path.join(tmpdir, "Test_cases")
            os.makedirs(tc_dir, exist_ok=True)
            tc_path = os.path.join(tc_dir, "testcases.json")

            raw_cases = [c.model_dump() for c in self.sample_cases]
            with open(tc_path, "w", encoding="utf-8") as f:
                json.dump(raw_cases, f)

            payload = ScriptAgentInput(
                mode="create",
                subject="channels",
                testcases=self.sample_cases,
                workspace_path=tmpdir,
            )
            output = run_script_agent(payload)

            with open(tc_path, "r", encoding="utf-8") as f:
                synced = json.load(f)

            for item in synced:
                self.assertEqual(item["scriptPath"], output.spec_path)
                self.assertEqual(item["testMethod"], f"[@{item['id']}] {item['title']}")

    def test_self_healing_fix_mode(self):
        """Fix mode replaces broken selector with resilient fallback candidate."""
        os.makedirs(settings.resolved_workspace_root, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            locators = [
                LocatorReference(
                    name="submitButton",
                    strategy="role",
                    selector="button.broken-class",
                    healing_candidates=["[data-testid='submit-btn']"],
                    linked_testcase_ids=["TC-101"],
                )
            ]
            payload = ScriptAgentInput(
                mode="fix",
                subject="channels",
                testcases=self.sample_cases[:1],
                workspace_path=tmpdir,
                locators=locators,
                failure_log="Timeout waiting for locator submitButton with selector button.broken-class",
            )
            output = run_script_agent(payload)

            healed_loc = next(loc for loc in output.locator_references if loc.name == "submitButton")
            self.assertEqual(healed_loc.selector, "[data-testid='submit-btn']")


if __name__ == "__main__":
    unittest.main()
