"""Tests for qagenticx.structured Pydantic structured output helper."""

from unittest.mock import MagicMock
from pydantic import BaseModel
from qagenticx.structured import structured_call


class PlanSchema(BaseModel):
    title: str
    steps_count: int
    is_automated: bool


def test_structured_call_native():
    """Verify structured_call uses model.with_structured_output when available."""
    mock_model = MagicMock()
    mock_runnable = MagicMock()
    mock_model.with_structured_output.return_value = mock_runnable

    expected_output = PlanSchema(
        title="Automated Login Test",
        steps_count=5,
        is_automated=True,
    )
    mock_runnable.invoke.return_value = expected_output

    result = structured_call(mock_model, PlanSchema, "Generate test plan")

    assert isinstance(result, PlanSchema)
    assert result.title == "Automated Login Test"
    assert result.steps_count == 5
    assert result.is_automated is True
    mock_model.with_structured_output.assert_called_once_with(PlanSchema)


def test_structured_call_native_dict_return():
    """Verify structured_call validates dict returned by runnable."""
    mock_model = MagicMock()
    mock_runnable = MagicMock()
    mock_model.with_structured_output.return_value = mock_runnable

    mock_runnable.invoke.return_value = {
        "title": "Dict Return Test",
        "steps_count": 3,
        "is_automated": False,
    }

    result = structured_call(mock_model, PlanSchema, "Generate test plan")
    assert isinstance(result, PlanSchema)
    assert result.title == "Dict Return Test"
    assert result.steps_count == 3
    assert result.is_automated is False


def test_structured_call_fallback():
    """Verify structured_call falls back to prompt instructions + JSON extraction."""
    mock_model = MagicMock()
    # Simulate a model without with_structured_output
    del mock_model.with_structured_output

    mock_response = MagicMock()
    mock_response.content = """Here is the response:
```json
{
  "title": "Fallback Smoke Test",
  "steps_count": 2,
  "is_automated": true
}
```
Hope this helps!"""
    mock_model.invoke.return_value = mock_response

    result = structured_call(mock_model, PlanSchema, "Generate smoke plan")
    assert isinstance(result, PlanSchema)
    assert result.title == "Fallback Smoke Test"
    assert result.steps_count == 2
    assert result.is_automated is True
