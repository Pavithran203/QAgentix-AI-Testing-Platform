"""Dashboard metrics-snapshot persistence tests (FEAT-003).

Covers the snapshot invariants added for DB-backed dashboard counts:
- refresh_metrics_snapshot() upserts a single kind='current' doc and appends a
  kind='history' row on every call.
- create_run and complete_run each trigger a snapshot refresh.
- GET /api/dashboard/summary is served from the stored snapshot and recomputes
  on refresh=true (or when no snapshot exists).
- GET /api/dashboard/metrics-history returns history rows newest-first and
  requires auth (mirroring test_dashboard.test_unauthenticated_endpoints_401).
"""
from __future__ import annotations

from datetime import datetime, timezone

from app.models.dashboard_metric import DashboardMetric
from app.models.run import RunStatus
from app.models.subproject import SubProject
from app.models.test_result import TestResult, TestResultStatus
from app.schemas.dashboard import RunCompleteIn, RunCreateIn, TestResultIn
from app.services import dashboard_service


def _utc(year, month, day):
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


async def _make_subproject(name="Alpha") -> SubProject:
    proj = SubProject(
        code=f"PRJ-{name}",
        subscription_id="sub1",
        name=name,
        type="web",
        description="desc",
        accent_gradient="g",
    )
    await proj.insert()
    return proj


async def _make_result(status, executed_at, subproject_id="sub1"):
    tr = TestResult(
        run_id="RUN-x",
        subproject_id=subproject_id,
        status=status,
        executed_at=executed_at,
    )
    await tr.insert()
    return tr


# --- refresh_metrics_snapshot upsert + history append ----------------------
async def test_refresh_snapshot_single_current_and_history_append(client):
    # First refresh: one current + one history.
    await dashboard_service.refresh_metrics_snapshot()
    assert await DashboardMetric.find(DashboardMetric.kind == "current").count() == 1
    assert await DashboardMetric.find(DashboardMetric.kind == "history").count() == 1

    # A changed world then a second refresh updates current (still one) and
    # appends a second history row.
    await _make_subproject("Alpha")
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 2))

    await dashboard_service.refresh_metrics_snapshot()
    assert await DashboardMetric.find(DashboardMetric.kind == "current").count() == 1
    assert await DashboardMetric.find(DashboardMetric.kind == "history").count() == 2

    current = await DashboardMetric.find_one(DashboardMetric.kind == "current")
    assert current.total_projects == 1
    assert current.failed_tests == 1
    assert current.pass_rate == 50.0


# --- create_run / complete_run each refresh the snapshot -------------------
async def test_create_run_refreshes_snapshot(client):
    run = await dashboard_service.create_run(
        RunCreateIn(subproject_id="x", test_suite="Smoke")
    )
    current = await DashboardMetric.find_one(DashboardMetric.kind == "current")
    assert current is not None
    assert current.total_runs == 1
    # A history row was appended by the create_run refresh.
    assert await DashboardMetric.find(DashboardMetric.kind == "history").count() == 1
    assert run.status == RunStatus.RUNNING.value


async def test_complete_run_refreshes_snapshot(client):
    run = await dashboard_service.create_run(
        RunCreateIn(subproject_id="x", test_suite="Smoke")
    )
    history_after_create = await DashboardMetric.find(
        DashboardMetric.kind == "history"
    ).count()

    await dashboard_service.complete_run(
        run.run_id,
        RunCompleteIn(
            status=RunStatus.PASSED.value,
            results=[
                TestResultIn(status=TestResultStatus.PASSED.value),
                TestResultIn(status=TestResultStatus.PASSED.value),
                TestResultIn(status=TestResultStatus.FAILED.value),
            ],
        ),
    )

    current = await DashboardMetric.find_one(DashboardMetric.kind == "current")
    assert current.total_runs == 1
    assert current.failed_tests == 1
    # 2 passed / 3 completed = 66.7
    assert current.pass_rate == 66.7
    # complete_run appended another history row.
    history_after_complete = await DashboardMetric.find(
        DashboardMetric.kind == "history"
    ).count()
    assert history_after_complete == history_after_create + 1


# --- summary served from stored snapshot ----------------------------------
async def test_summary_served_from_stored_snapshot(client):
    # Seed a current snapshot with known values that do NOT match the live
    # collections (which are empty). The endpoint must echo the snapshot.
    snap = DashboardMetric(
        kind="current",
        total_projects=7,
        total_test_cases=None,
        total_runs=42,
        pass_rate=88.5,
        failed_tests=3,
        locator_issues=None,
        snapshot_at=_utc(2024, 5, 1),
    )
    await snap.insert()

    data = (await client.get("/api/dashboard/summary")).json()
    assert data["totalProjects"] == 7
    assert data["totalRuns"] == 42
    assert data["passRate"] == 88.5
    assert data["failedTests"] == 3


async def test_summary_refresh_recomputes_snapshot(client):
    # Seed a stale current snapshot, then assert refresh=true recomputes from
    # the live (empty) collections.
    snap = DashboardMetric(
        kind="current",
        total_projects=7,
        total_runs=42,
        pass_rate=88.5,
        failed_tests=3,
        snapshot_at=_utc(2024, 5, 1),
    )
    await snap.insert()

    data = (await client.get("/api/dashboard/summary", params={"refresh": "true"})).json()
    assert data["totalProjects"] == 0
    assert data["totalRuns"] == 0
    assert data["passRate"] is None
    assert data["failedTests"] == 0

    # The stored current snapshot was updated in place (still exactly one).
    assert await DashboardMetric.find(DashboardMetric.kind == "current").count() == 1
    current = await DashboardMetric.find_one(DashboardMetric.kind == "current")
    assert current.total_runs == 0


async def test_summary_recomputes_when_no_snapshot_exists(client):
    await _make_subproject("Alpha")
    await _make_result(TestResultStatus.PASSED.value, _utc(2024, 1, 1))
    await _make_result(TestResultStatus.FAILED.value, _utc(2024, 1, 2))

    # No current snapshot yet -> the endpoint recomputes and persists one.
    assert await DashboardMetric.find(DashboardMetric.kind == "current").count() == 0
    data = (await client.get("/api/dashboard/summary")).json()
    assert data["totalProjects"] == 1
    assert data["failedTests"] == 1
    assert data["passRate"] == 50.0
    assert await DashboardMetric.find(DashboardMetric.kind == "current").count() == 1


# --- metrics-history endpoint ---------------------------------------------
async def test_metrics_history_newest_first(client):
    # Three refreshes produce three history rows; snapshot values grow as the
    # world changes, and the endpoint returns them newest-first.
    await dashboard_service.refresh_metrics_snapshot()  # total_runs 0
    await dashboard_service.create_run(RunCreateIn(subproject_id="x", test_suite="S"))  # refresh -> 1
    await dashboard_service.create_run(RunCreateIn(subproject_id="x", test_suite="S"))  # refresh -> 2

    rows = (await client.get("/api/dashboard/metrics-history")).json()
    assert len(rows) == 3
    totals = [r["totalRuns"] for r in rows]
    # Newest-first: most recent (total_runs == 2) comes first.
    assert totals == [2, 1, 0]


async def test_metrics_history_respects_limit(client):
    for _ in range(3):
        await dashboard_service.refresh_metrics_snapshot()
    rows = (await client.get("/api/dashboard/metrics-history", params={"limit": 2})).json()
    assert len(rows) == 2


# --- auth required ---------------------------------------------------------
async def test_metrics_endpoints_unauthenticated_401(unauth_client):
    headers = {"Authorization": "Bearer not-a-real-token"}
    for path in ["/api/dashboard/summary", "/api/dashboard/metrics-history"]:
        resp = await unauth_client.get(path, headers=headers)
        assert resp.status_code == 401, path
