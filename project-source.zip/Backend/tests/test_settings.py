"""Tests for qagenticx.settings and config.yaml loading."""

from pathlib import Path
import os
import pytest

from qagenticx.config import LLMConfig, ProjectConfig
from qagenticx.settings import LLMSettings, SettingsError, load_settings


def test_valid_load_from_repo_config():
    """Verify loading the repository root config.yaml."""
    settings = load_settings()
    assert settings.default_provider == "openai"
    assert "openai" in settings.providers
    assert "claude" in settings.providers
    assert "gemini" in settings.providers
    assert "ollama" in settings.providers

    name, p_settings = settings.get_provider_settings("openai")
    assert name == "openai"
    assert p_settings.default_model == "gpt-4o"
    assert p_settings.max_retries == 3
    assert p_settings.api_key_env == "OPENAI_API_KEY"


def test_invalid_provider_rejected(tmp_path: Path):
    """Verify requesting an unconfigured provider raises SettingsError."""
    cfg_file = tmp_path / "config.yaml"
    cfg_file.write_text(
        """
default_provider: openai
providers:
  openai:
    default_model: gpt-4o
    api_key_env: OPENAI_API_KEY
""",
        encoding="utf-8",
    )
    settings = load_settings(cfg_file)
    with pytest.raises(SettingsError, match="Unknown LLM provider 'unknown_provider'"):
        settings.get_provider_settings("unknown_provider")


def test_env_var_indirection(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Verify API keys are read indirectly by the env var name configured in YAML."""
    cfg_file = tmp_path / "config.yaml"
    cfg_file.write_text(
        """
default_provider: custom_ai
providers:
  custom_ai:
    default_model: custom-1
    api_key_env: CUSTOM_SECRET_KEY
""",
        encoding="utf-8",
    )
    monkeypatch.setenv("CUSTOM_SECRET_KEY", "sk-secret-test-token-12345")
    settings = load_settings(cfg_file)
    assert settings.get_api_key("custom_ai") == "sk-secret-test-token-12345"


def test_project_level_override_applies():
    """Verify that a project.yaml LLM block overrides default provider and model."""
    settings = load_settings()
    project = ProjectConfig(
        id="test-proj",
        name="Test",
        target_url="https://example.com",
        llm=LLMConfig(provider="claude", model="claude-3-haiku-20240307", temperature=0.7),
    )

    prov_name, p_settings = settings.get_provider_settings(project.llm.provider)
    assert prov_name == "claude"
    # Project-level model overrides the default provider model
    effective_model = project.llm.model or p_settings.default_model
    effective_temp = project.llm.temperature
    assert effective_model == "claude-3-haiku-20240307"
    assert effective_temp == 0.7
