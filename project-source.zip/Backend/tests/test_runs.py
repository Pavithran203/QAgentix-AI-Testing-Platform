"""Run recording/detail API tests (spec §12 items 10-12, 15)."""
from __future__ import annotations

from app.models.run import Run, RunStatus
from app.models.subproject import SubProject
from app.models.test_result import FailureCategory, TestResult, TestResultStatus


async def _make_subproject(name="Alpha") -> SubProject:
    proj = SubProject(
        code=f"PRJ-{name}",
        subscription_id="sub1",
        name=name,
        type="web",
        description="desc",
        accent_gradient="g",
    )
    await proj.insert()
    return proj


async def _create_run(client, subproject_id, suite="Smoke"):
    resp = await client.post(
        "/api/runs",
        json={"subprojectId": subproject_id, "testSuite": suite},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


# --- create + project resolution ------------------------------------------
async def test_create_run_resolves_project_name(client):
    proj = await _make_subproject("Payments")
    row = await _create_run(client, str(proj.id), suite="Regression")
    assert row["id"].startswith("RUN-")
    assert row["project"] == "Payments"
    assert row["suite"] == "Regression"
    assert row["status"] == RunStatus.RUNNING.value
    assert row["passed"] == 0 and row["failed"] == 0


# --- §12.10 duration from started->completed; Running elapsed -------------
async def test_running_run_shows_elapsed_not_completed(client):
    proj = await _make_subproject()
    row = await _create_run(client, str(proj.id))
    # Still Running: duration is an elapsed estimate, completed_at is absent.
    detail = (await client.get(f"/api/runs/{row['id']}")).json()
    assert detail["status"] == RunStatus.RUNNING.value
    assert detail["completed"] is None
    assert detail["duration"] is not None  # elapsed display


async def test_complete_computes_duration_and_counts(client):
    proj = await _make_subproject()
    row = await _create_run(client, str(proj.id))
    run_id = row["id"]

    resp = await client.post(
        f"/api/runs/{run_id}/complete",
        json={
            "status": RunStatus.PASSED.value,
            "results": [
                {"status": "passed", "testcaseRef": "TC-1"},
                {"status": "passed", "testcaseRef": "TC-2"},
                {"status": "failed", "testcaseRef": "TC-3", "failureCategory": "Product Bug"},
            ],
        },
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == RunStatus.PASSED.value
    assert body["passed"] == 2
    assert body["failed"] == 1
    assert body["duration"] is not None

    run = await Run.find_one(Run.run_id == run_id)
    assert run.completed_at is not None
    assert run.duration_ms is not None and run.duration_ms >= 0
    # Results persisted.
    assert await TestResult.find(TestResult.run_id == run_id).count() == 3


# --- §12.11 idempotent duplicate completion -------------------------------
async def test_duplicate_completion_is_idempotent(client):
    proj = await _make_subproject()
    run_id = (await _create_run(client, str(proj.id)))["id"]
    body = {
        "status": RunStatus.PASSED.value,
        "results": [{"status": "passed"}, {"status": "failed"}],
    }
    first = (await client.post(f"/api/runs/{run_id}/complete", json=body)).json()
    assert first["passed"] == 1 and first["failed"] == 1

    # Repeat the same completion: counts must not double, results not duplicated.
    second = (await client.post(f"/api/runs/{run_id}/complete", json=body)).json()
    assert second["passed"] == 1 and second["failed"] == 1
    assert await TestResult.find(TestResult.run_id == run_id).count() == 2


# --- §12.12 unknown run_id -> 404 -----------------------------------------
async def test_unknown_run_id_404(client):
    resp = await client.get("/api/runs/RUN-9999")
    assert resp.status_code == 404
    assert resp.json()["detail"] == "Run not found"

    resp = await client.post("/api/runs/RUN-9999/complete", json={"status": "Passed"})
    assert resp.status_code == 404


# --- run detail sanitizes artifacts (no absolute path/workspace_base) -----
async def test_run_detail_sanitized_artifacts(client):
    proj = await _make_subproject()
    run_id = (await _create_run(client, str(proj.id)))["id"]
    await client.post(
        f"/api/runs/{run_id}/complete",
        json={
            "status": RunStatus.PASSED.value,
            "results": [{"status": "passed"}],
            "artifactRefs": [{"kind": "report", "filename": "results.json", "relPath": "Reports/results.json"}],
        },
    )
    detail = (await client.get(f"/api/runs/{run_id}")).json()
    assert "workspace_base" not in detail
    assert "workspaceBase" not in detail
    assert len(detail["artifacts"]) == 1
    art = detail["artifacts"][0]
    assert art == {"kind": "report", "filename": "results.json", "ref": "Reports/results.json"}


# --- §12.15 record -> read round-trip reflects in summary/trend/table -----
async def test_record_then_read_round_trip(client):
    proj = await _make_subproject("RoundTrip")
    # Baseline: no runs.
    assert (await client.get("/api/dashboard/summary")).json()["totalRuns"] == 0

    run_id = (await _create_run(client, str(proj.id)))["id"]
    await client.post(
        f"/api/runs/{run_id}/complete",
        json={
            "status": RunStatus.FAILED.value,
            "results": [
                {"status": "passed"},
                {"status": "failed", "failureCategory": "Environment"},
            ],
        },
    )

    summary = (await client.get("/api/dashboard/summary")).json()
    assert summary["totalRuns"] == 1
    assert summary["failedTests"] == 1
    assert summary["passRate"] == 50.0

    # Appears in the recent-runs table.
    table = (await client.get("/api/dashboard/recent-runs")).json()
    assert table["total"] == 1
    assert table["items"][0]["id"] == run_id
    assert table["items"][0]["status"] == RunStatus.FAILED.value

    # Appears in the failure-categories chart.
    cats = (await client.get("/api/dashboard/failure-categories")).json()
    assert {c["category"]: c["count"] for c in cats}.get("Environment") == 1
