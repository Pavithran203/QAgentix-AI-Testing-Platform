"""Unit and integration test suite for Kiro IDE connection & conversational greetings:
1. Conversational prompt detection ('hi', 'hello', 'ping') vs requirement prompts vs invalid queries.
2. Kiro CLI binary discovery and status reporting.
3. Direct execution of 'hi' through the /api/agent/kiro/execute API.
4. Verification that non-conversational, non-test queries ('recipe for pizza') are rejected.
5. Verification of MCP server configuration and endpoints for Kiro integration.
"""
from __future__ import annotations

import json
import os
import sys
import unittest
from unittest.mock import MagicMock, patch

# Add Backend root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from app.main import app
from app.api.deps import get_current_user
from app.agent.kiro_agent import (
    find_kiro_binary,
    get_kiro_status,
    is_conversational_prompt,
    run_kiro_agent,
    validate_requirements_prompt,
)
from app.schemas.kiro import KiroExecuteRequest


class TestKiroConnection(unittest.TestCase):
    """Test suite covering Kiro connection, conversational greetings, and MCP readiness."""

    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)
        cls.dummy_user = MagicMock()
        cls.dummy_user.id = "test-user-id"
        cls.dummy_user.email = "test@qagentix.ai"
        app.dependency_overrides[get_current_user] = lambda: cls.dummy_user

    @classmethod
    def tearDownClass(cls):
        app.dependency_overrides.pop(get_current_user, None)

    # =========================================================================
    # 1. CONVERSATIONAL PROMPT DETECTION
    # =========================================================================

    def test_conversational_prompt_recognition(self):
        """Greetings and connection check keywords must be recognized."""
        test_greetings = ["hi", "HI", "  hi!  ", "hello", "hey", "ping", "test", "hello kiro"]
        for greeting in test_greetings:
            self.assertTrue(
                is_conversational_prompt(greeting),
                f"'{greeting}' should be recognized as a conversational connection prompt.",
            )

    def test_non_conversational_prompts(self):
        """Non-greetings should not be recognized as conversational."""
        non_greetings = [
            "Verify user login workflow",
            "tell me a recipe for pizza",
            "write code for quantum computing",
            "",
        ]
        for prompt in non_greetings:
            self.assertFalse(
                is_conversational_prompt(prompt),
                f"'{prompt}' should NOT be recognized as conversational.",
            )

    # =========================================================================
    # 2. KIRO BINARY DISCOVERY AND STATUS
    # =========================================================================

    def test_find_kiro_binary(self):
        """Kiro binary should be discovered if installed on system."""
        binary = find_kiro_binary()
        # Binary should be found on this development machine
        if binary:
            self.assertTrue(os.path.exists(binary))
            self.assertTrue("kiro" in binary.lower())

    def test_get_kiro_status(self):
        """Kiro status response should report installed status accurately."""
        status = get_kiro_status()
        self.assertIsNotNone(status.message)
        if status.installed:
            self.assertIsNotNone(status.version)
            self.assertTrue(len(status.version) > 0)

    # =========================================================================
    # 3. ENDPOINT EXECUTION: SENDING 'hi' TO API
    # =========================================================================

    def test_execute_hi_prompt_success(self):
        """Sending 'hi' to /api/agent/kiro/execute must succeed and process through Kiro integration."""
        response = self.client.post(
            "/api/agent/kiro/execute",
            json={"prompt": "hi"},
        )
        self.assertEqual(response.status_code, 200, f"Expected 200 OK, got {response.status_code}: {response.text}")
        data = response.json()
        self.assertEqual(data.get("status"), "SUCCESS")
        self.assertIn("Kiro", data.get("connected_surface", ""))
        self.assertIn("hi", data.get("response", "").lower())
        self.assertIsInstance(data.get("steps"), list)
        self.assertTrue(len(data.get("steps")) > 0)

    def test_execute_empty_prompt_rejected(self):
        """Sending an empty prompt must return 400 Bad Request."""
        response = self.client.post(
            "/api/agent/kiro/execute",
            json={"prompt": "   "},
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("prompt", response.json().get("detail", "").lower())

    def test_execute_task_prompt_delivered_to_kiro(self):
        """Whatever task prompt is entered must be dispatched directly to Kiro IDE."""
        response = self.client.post(
            "/api/agent/kiro/execute",
            json={"prompt": "Refactor user authentication service and generate test suite"},
        )
        self.assertEqual(response.status_code, 200, f"Expected 200 OK, got {response.status_code}: {response.text}")
        data = response.json()
        self.assertEqual(data.get("status"), "SUCCESS")
        self.assertIn("Kiro", data.get("connected_surface", ""))
        self.assertIn("Refactor user authentication service", data.get("response", ""))
        self.assertIsInstance(data.get("steps"), list)

    # =========================================================================
    # 4. MCP INTEGRATION READINESS
    # =========================================================================

    def test_mcp_configuration_file_exists(self):
        """The .kiro/settings/mcp.json file must exist and configure the QAgentix MCP server."""
        workspace_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        mcp_path = os.path.join(workspace_root, ".kiro", "settings", "mcp.json")
        self.assertTrue(os.path.exists(mcp_path), f"MCP config not found at {mcp_path}")

        with open(mcp_path, "r", encoding="utf-8") as f:
            config = json.load(f)

        self.assertIn("mcpServers", config)
        self.assertIn("qagentix", config["mcpServers"])
        qagentix_server = config["mcpServers"]["qagentix"]
        self.assertIn("command", qagentix_server)
        self.assertIn("args", qagentix_server)

    def test_mcp_server_module_tools(self):
        """Backend MCP module must define standard tools for Kiro IDE connection."""
        from app.mcp.server import MCP_TOOLS
        tool_names = [t["name"] for t in MCP_TOOLS]
        self.assertIn("qagentix_status", tool_names)
        self.assertIn("qagentix_execute_prompt", tool_names)
        self.assertIn("qagentix_read_workspace_file", tool_names)
        self.assertIn("qagentix_verify_script_safety", tool_names)


if __name__ == "__main__":
    unittest.main()
