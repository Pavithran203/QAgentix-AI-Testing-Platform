"""Negative boundary test suite:
1. Workspace allowlist enforcement
2. Path traversal and symlink breach prevention
3. Input size limits (prompt length, file write payload, file read limit)
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch
from pydantic import ValidationError

# Add Backend root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from app.main import app
from app.core.config import settings
from app.agent.common import (
    _safe_workspace_read,
    _safe_workspace_write,
    validate_input_size,
    validate_safe_path,
    validate_workspace_path,
)
from app.schemas.kiro import KiroExecuteRequest, KiroReadFileRequest
from app.api.deps import get_current_user


class TestSecurityBoundaries(unittest.TestCase):
    """Test suite covering workspace allowlist, path/symlink checks, and input size limits."""

    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)
        os.makedirs(settings.resolved_workspace_root, exist_ok=True)

    def setUp(self):
        # Setup mock user for authenticated API endpoints
        self.mock_user = MagicMock()
        self.mock_user.id = "mock_sec_user"
        self.mock_user.username = "sec_tester"
        app.dependency_overrides[get_current_user] = lambda: self.mock_user

    def tearDown(self):
        app.dependency_overrides.pop(get_current_user, None)

    # =========================================================================
    # 1. WORKSPACE ALLOWLIST TESTS
    # =========================================================================

    def test_workspace_inside_allowlist_accepted(self):
        """Workspace path strictly within settings.workspace_allowlist must be accepted."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            validated = validate_workspace_path(tmpdir)
            self.assertEqual(validated, os.path.realpath(tmpdir))

    def test_workspace_outside_allowlist_rejected(self):
        """Workspace path outside settings.workspace_allowlist must raise PermissionError."""
        # Use an outside system temp dir or an unapproved folder
        outside_dir = os.path.abspath(os.path.join(settings.resolved_workspace_root, "..", "..", "unapproved_folder"))
        with self.assertRaises(PermissionError) as ctx:
            validate_workspace_path(outside_dir)
        self.assertIn("outside approved workspace allowlist", str(ctx.exception))

    def test_workspace_null_byte_rejected(self):
        """Workspace path with null byte must raise ValueError."""
        with self.assertRaises(ValueError) as ctx:
            validate_workspace_path(f"{settings.resolved_workspace_root}\0evil")
        self.assertIn("null byte", str(ctx.exception).lower())

    def test_api_execute_outside_allowlist_rejected(self):
        """POST /api/agent/kiro/execute with unapproved workspace_path must return 403."""
        outside_path = os.path.abspath(os.path.join(settings.resolved_workspace_root, "..", "forbidden_ws"))
        res = self.client.post(
            "/api/agent/kiro/execute",
            json={
                "prompt": "Verify login and navigation with Playwright",
                "workspace_path": outside_path,
            },
        )
        self.assertEqual(res.status_code, 403, f"Expected 403 Forbidden, got {res.status_code}: {res.text}")
        self.assertIn("allowlist", res.json().get("detail", "").lower())

    def test_api_read_file_outside_allowlist_rejected(self):
        """POST /api/agent/kiro/read-file with unapproved workspace_path must return 403."""
        outside_path = os.path.abspath(os.path.join(settings.resolved_workspace_root, "..", "forbidden_ws"))
        res = self.client.post(
            "/api/agent/kiro/read-file",
            json={
                "workspace_path": outside_path,
                "relative_path": "README.md",
            },
        )
        self.assertEqual(res.status_code, 403)
        self.assertIn("allowlist", res.json().get("detail", "").lower())

    # =========================================================================
    # 2. PATH TRAVERSAL & SYMLINK CHECKS
    # =========================================================================

    def test_path_traversal_dot_dot_rejected(self):
        """Path traversal patterns with .. must raise PermissionError."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            bad_paths = [
                "../secret.txt",
                "..\\secret.txt",
                "folder/../../outside.txt",
                "folder/sub/../../../etc/passwd",
            ]
            for bad_path in bad_paths:
                with self.assertRaises(PermissionError, msg=f"Should reject {bad_path}"):
                    validate_safe_path(tmpdir, bad_path)

                with self.assertRaises(PermissionError, msg=f"Write should reject {bad_path}"):
                    _safe_workspace_write(tmpdir, bad_path, "content")

    def test_relative_path_null_byte_rejected(self):
        """Relative path with null byte must raise ValueError."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            with self.assertRaises(ValueError):
                validate_safe_path(tmpdir, "valid_name\0.txt")

    def test_symlink_pointing_outside_workspace_rejected(self):
        """Symlink that resolves outside workspace boundary must be blocked with PermissionError."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            fake_symlink_rel = "symlinks/external_link.txt"
            fake_external_target = os.path.abspath("C:/Windows/System32/drivers/etc/hosts")

            # Simulate symlink behavior via realpath
            orig_realpath = os.path.realpath

            def mocked_realpath(path):
                norm = os.path.normpath(str(path))
                if "external_link.txt" in norm:
                    return fake_external_target
                return orig_realpath(path)

            with patch("os.path.realpath", side_effect=mocked_realpath):
                with self.assertRaises(PermissionError) as ctx:
                    validate_safe_path(tmpdir, fake_symlink_rel)
                self.assertIn("breach", str(ctx.exception).lower())

    def test_symlink_overwrite_outside_workspace_rejected(self):
        """Attempting to write through an existing symlink pointing outside must raise PermissionError."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            symlink_rel = "external_link.txt"
            fake_external_target = os.path.abspath("C:/Windows/System32/config.ini")
            orig_realpath = os.path.realpath

            def mocked_realpath(path):
                if "external_link.txt" in os.path.normpath(str(path)):
                    return fake_external_target
                return orig_realpath(path)

            with patch("os.path.islink", return_value=True), \
                 patch("os.path.realpath", side_effect=mocked_realpath):
                with self.assertRaises(PermissionError) as ctx:
                    _safe_workspace_write(tmpdir, symlink_rel, "malicious payload")
                self.assertIn("breach", str(ctx.exception).lower())

    def test_api_read_file_symlink_breach_rejected(self):
        """POST /api/agent/kiro/read-file attempting to read symlink pointing outside must return 400."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            fake_external_target = os.path.abspath("C:/Windows/System32/drivers/etc/hosts")
            orig_realpath = os.path.realpath

            def mocked_realpath(path):
                if "symlink_outside.txt" in os.path.normpath(str(path)):
                    return fake_external_target
                return orig_realpath(path)

            with patch("os.path.realpath", side_effect=mocked_realpath):
                res = self.client.post(
                    "/api/agent/kiro/read-file",
                    json={
                        "workspace_path": tmpdir,
                        "relative_path": "symlink_outside.txt",
                    },
                )
                self.assertEqual(res.status_code, 400)
                self.assertIn("traversal", res.json().get("detail", "").lower())


    # =========================================================================
    # 3. INPUT SIZE LIMITS
    # =========================================================================

    def test_validate_input_size_exact_boundary(self):
        """Exact boundary tests: size <= max_size passes, size > max_size raises ValueError."""
        # Exact limit passes
        validate_input_size("a" * 100, max_size=100, label="Test payload")
        validate_input_size(b"x" * 100, max_size=100, label="Test payload")
        validate_input_size(100, max_size=100, label="Test payload")

        # Exceeding by 1 byte fails
        with self.assertRaises(ValueError) as ctx:
            validate_input_size("a" * 101, max_size=100, label="Test payload")
        self.assertIn("exceeds maximum allowed limit of 100 bytes", str(ctx.exception))

        with self.assertRaises(ValueError):
            validate_input_size(b"x" * 101, max_size=100, label="Test payload")

        with self.assertRaises(ValueError):
            validate_input_size(101, max_size=100, label="Test payload")

    def test_pydantic_schema_prompt_size_limit(self):
        """KiroExecuteRequest prompt exceeding max_length (50,000) must raise ValidationError."""
        oversized_prompt = "Verify login flow " + ("A" * 50_000)
        with self.assertRaises(ValidationError):
            KiroExecuteRequest(prompt=oversized_prompt)

    def test_api_execute_prompt_oversized_rejected(self):
        """POST /api/agent/kiro/execute with prompt exceeding max_input_prompt_chars must return 400/422."""
        oversized_prompt = "Verify user login with Playwright " + ("X" * 50_000)
        res = self.client.post(
            "/api/agent/kiro/execute",
            json={"prompt": oversized_prompt},
        )
        self.assertIn(res.status_code, (400, 422))

    def test_file_write_size_limit_rejected(self):
        """_safe_workspace_write exceeding max_bytes limit must raise ValueError."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            oversized_content = "X" * 1000
            # Test custom small limit
            with self.assertRaises(ValueError) as ctx:
                _safe_workspace_write(tmpdir, "Scripts/test.ts", oversized_content, max_bytes=500)
            self.assertIn("exceeds maximum allowed limit", str(ctx.exception))

    def test_file_read_size_limit_rejected(self):
        """_safe_workspace_read on file exceeding max_bytes limit must raise ValueError."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            file_path = _safe_workspace_write(tmpdir, "Reports/large.log", "A" * 1000, max_bytes=2000)
            self.assertTrue(os.path.isfile(file_path))

            # Reading with max_bytes=500 should raise ValueError
            with self.assertRaises(ValueError) as ctx:
                _safe_workspace_read(tmpdir, "Reports/large.log", max_bytes=500)
            self.assertIn("exceeds maximum allowed limit", str(ctx.exception))

    def test_api_read_file_size_limit_rejected(self):
        """POST /api/agent/kiro/read-file exceeding max_file_read_bytes must return 413."""
        with tempfile.TemporaryDirectory(dir=settings.resolved_workspace_root) as tmpdir:
            _safe_workspace_write(tmpdir, "large.txt", "B" * 200, max_bytes=500)

            # Temporarily set max_file_read_bytes to 100
            with patch.object(settings, "max_file_read_bytes", 100):
                res = self.client.post(
                    "/api/agent/kiro/read-file",
                    json={
                        "workspace_path": tmpdir,
                        "relative_path": "large.txt",
                    },
                )
                self.assertEqual(res.status_code, 413)
                self.assertIn("exceeds maximum allowed read limit", res.json().get("detail", "").lower())


if __name__ == "__main__":
    unittest.main()
