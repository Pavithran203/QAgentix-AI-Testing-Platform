"""Tests for qagenticx.graph 2-node hello-world LangGraph."""

from qagenticx.config import BrowserConfig, LLMConfig, ProjectConfig, load_project
from qagenticx.graph import build_graph, run_project


def test_graph_runs_both_nodes_in_order():
    """Verify that the compiled LangGraph executes plan then greet."""
    graph = build_graph()
    initial_state = {
        "project_id": "test-run",
        "target_url": "https://example.org",
        "steps": [],
        "message": "",
    }
    result = graph.invoke(initial_state)

    assert result["steps"] == ["plan", "greet"]
    assert "test-run" in result["message"]
    assert "https://example.org" in result["message"]


def test_run_project_with_example():
    """Verify run_project works end-to-end with the bundled example configuration."""
    config = load_project("example")
    result = run_project(config)

    assert result["steps"] == ["plan", "greet"]
    assert result["project_id"] == "example"
    assert result["target_url"] == "https://example.com"
    assert "Hello from QAgenticx!" in result["message"]
    assert "example" in result["message"]
    assert "https://example.com" in result["message"]


def test_run_project_custom_config():
    """Verify run_project works with an arbitrary ProjectConfig object."""
    config = ProjectConfig(
        id="custom-qa",
        name="Custom QA",
        target_url="https://qa.local",
        browser=BrowserConfig(engine="firefox"),
        llm=LLMConfig(provider="claude", model="claude-3-5-sonnet-20241022"),
        goals=["Goal 1"],
    )
    result = run_project(config)

    assert result["steps"] == ["plan", "greet"]
    assert result["project_id"] == "custom-qa"
    assert result["target_url"] == "https://qa.local"
    assert "custom-qa" in result["message"]
