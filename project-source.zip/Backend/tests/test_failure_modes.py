"""Unit and integration test suite for Kiro Agent failure modes:
1. Missing CLI & Missing Auth
2. Invalid Requests (empty prompt, irrelevant prompt, path traversal)
3. Timeout handling
4. Malformed output & corrupted JSON recovery
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

# Add Backend root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from app.main import app
from app.agent.kiro_agent import (
    execute_with_kiro_cli,
    find_kiro_binary,
    get_kiro_status,
    run_kiro_agent,
    validate_requirements_prompt,
)
from app.agent.common import extract_json_payload
from app.schemas.kiro import KiroExecuteRequest


class TestFailureModes(unittest.TestCase):
    """Test suite covering missing CLI/auth, invalid request, timeout, and malformed output."""

    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)

    # =========================================================================
    # 1. MISSING AUTH & MISSING CLI
    # =========================================================================

    def test_missing_auth_on_execute(self):
        """Request without Authorization header must return 401/403."""
        response = self.client.post(
            "/api/agent/kiro/execute",
            json={"prompt": "Verify login and dashboard assertion flow"},
        )
        self.assertIn(response.status_code, (401, 403), f"Expected 401/403, got {response.status_code}")
        self.assertIn("detail", response.json())

    def test_invalid_auth_token_on_execute(self):
        """Request with malformed or fake token must return 401 Unauthorized."""
        response = self.client.post(
            "/api/agent/kiro/execute",
            json={"prompt": "Verify login and dashboard assertion flow"},
            headers={"Authorization": "Bearer fake.invalid.jwt.token"},
        )
        self.assertEqual(response.status_code, 401)
        self.assertIn("credentials", response.json().get("detail", "").lower())

    def test_missing_auth_on_read_file(self):
        """Unauthenticated file read must be rejected."""
        response = self.client.post(
            "/api/agent/kiro/read-file",
            json={"relative_path": "Features/auth.feature"},
        )
        self.assertIn(response.status_code, (401, 403))

    def test_missing_cli_binary_fallback(self):
        """When Kiro CLI binary is not installed, system must report installed=False."""
        with patch("app.agent.kiro_agent.find_kiro_binary", return_value=None):
            status = get_kiro_status()
            self.assertFalse(status.installed)
            self.assertIsNone(status.version)
            self.assertIn("not found", status.message.lower())

    # =========================================================================
    # 2. INVALID REQUESTS
    # =========================================================================

    def test_invalid_request_empty_prompt(self):
        """Empty prompt must fail requirements validation."""
        self.assertFalse(validate_requirements_prompt("", has_document=False))
        self.assertFalse(validate_requirements_prompt("   ", has_document=False))

    def test_invalid_request_lacks_testing_intent(self):
        """Prompts with no QA/test engineering intent must be rejected."""
        non_test_prompts = [
            "hello world",
            "write me a poem about the sea",
            "what is the capital of France?",
            "tell me a recipe for pizza",
        ]
        for p in non_test_prompts:
            self.assertFalse(
                validate_requirements_prompt(p, has_document=False),
                f"Prompt '{p}' should have been rejected as lacking test intent.",
            )

    def test_valid_request_with_test_intent(self):
        """Prompts with QA terms should be accepted."""
        valid_prompts = [
            "Verify user login with valid credentials",
            "Test checkout payment flow and assert cart totals",
            "Create playwright spec for api endpoints",
            "Generate gherkin feature and testcases for auth",
        ]
        for p in valid_prompts:
            self.assertTrue(
                validate_requirements_prompt(p, has_document=False),
                f"Prompt '{p}' should have been accepted.",
            )

    def test_path_traversal_on_read_file(self):
        """Path traversal patterns in relative_path must be blocked with 400 Bad Request."""
        # Use a mock user to bypass auth and test route input validation
        from app.api.deps import get_current_user

        dummy_user = MagicMock()
        dummy_user.id = "mock_id"
        dummy_user.username = "testuser"
        app.dependency_overrides[get_current_user] = lambda: dummy_user

        try:
            bad_paths = [
                "../../etc/passwd",
                "..\\..\\windows\\win.ini",
                "folder/../../../secret.txt",
            ]
            for p in bad_paths:
                res = self.client.post(
                    "/api/agent/kiro/read-file",
                    json={"relative_path": p},
                )
                self.assertEqual(res.status_code, 400, f"Path traversal '{p}' should return 400.")
                self.assertIn("traversal", res.json().get("detail", "").lower())
        finally:
            app.dependency_overrides.pop(get_current_user, None)

    # =========================================================================
    # 3. TIMEOUT HANDLING
    # =========================================================================

    def test_cli_execution_timeout(self):
        """Subprocess that exceeds timeout_seconds must raise TimeoutError."""
        async def run_timeout():
            # Run command that sleeps longer than timeout_seconds
            dummy_bin = sys.executable
            # Pass a python snippet that sleeps for 2 seconds with timeout 0.1s
            prompt = "-c 'import time; time.sleep(2)'"
            return await execute_with_kiro_cli(
                binary=dummy_bin,
                prompt=prompt,
                workspace_path=".",
                timeout_seconds=1,  # 1s timeout
            )

        with patch("asyncio.create_subprocess_exec") as mock_exec:
            # Create a mock process whose communicate() times out
            mock_proc = MagicMock()
            mock_proc.communicate = AsyncMock(side_effect=asyncio.TimeoutError())
            mock_proc.kill = MagicMock()
            mock_exec.return_value = mock_proc

            with self.assertRaises(TimeoutError) as ctx:
                asyncio.run(execute_with_kiro_cli(
                    binary="mock-kiro",
                    prompt="test",
                    workspace_path=".",
                    timeout_seconds=1,
                ))
            self.assertIn("timed out", str(ctx.exception))
            mock_proc.kill.assert_called_once()

    def test_run_kiro_agent_graceful_timeout_fallback(self):
        """When CLI execution times out, run_kiro_agent records error and falls back to orchestrator."""
        req = KiroExecuteRequest(
            prompt="Verify checkout payment gateway response and receipt",
            timeout_seconds=1,
        )

        with patch("app.agent.kiro_agent.find_kiro_binary", return_value="fake-kiro.exe"), \
             patch("app.agent.kiro_agent.execute_with_kiro_cli", side_effect=TimeoutError("Kiro agent execution timed out after 1s.")), \
             patch("app.agent.kiro_agent.settings.kiro_mode", "cli"):

            resp = asyncio.run(run_kiro_agent(req))
            self.assertEqual(resp.status, "SUCCESS")
            self.assertIn("timed out", str(resp.error))
            self.assertTrue(len(resp.artifacts) > 0)
            self.assertTrue(any("plan.md" in a.relative_path for a in resp.artifacts))

    # =========================================================================
    # 4. MALFORMED OUTPUT & JSON RECOVERY
    # =========================================================================

    def test_cli_nonzero_exit_code_malformed_stderr(self):
        """Subprocess returning non-zero exit code must raise RuntimeError with stderr."""
        with patch("asyncio.create_subprocess_exec") as mock_exec:
            mock_proc = MagicMock()
            mock_proc.returncode = 1
            mock_proc.communicate = AsyncMock(return_value=(b"", b"Error: SyntaxError: Unexpected token < in JSON at position 0"))
            mock_exec.return_value = mock_proc

            with self.assertRaises(RuntimeError) as ctx:
                asyncio.run(execute_with_kiro_cli(
                    binary="mock-kiro",
                    prompt="test",
                    workspace_path=".",
                    timeout_seconds=5,
                ))
            self.assertIn("exited with code 1", str(ctx.exception))
            self.assertIn("Unexpected token <", str(ctx.exception))

    def test_extract_json_block_from_malformed_markdown(self):
        """Extracts JSON successfully from messy LLM responses with markdown fences and prose."""
        raw_output = """
        Here is the test plan you requested:
        ```json
        {
            "plan_path": ".qagentix/plan.md",
            "summary": "Plan generated successfully",
            "steps": ["Step 1", "Step 2"],
            "risk_assessment": "Low"
        }
        ```
        Hope this helps!
        """
        parsed = extract_json_payload(raw_output)
        self.assertIsInstance(parsed, dict)
        self.assertEqual(parsed.get("plan_path"), ".qagentix/plan.md")
        self.assertEqual(parsed.get("risk_assessment"), "Low")

    def test_extract_json_block_corrupted_fallback(self):
        """Completely corrupted output with no valid JSON returns empty dict rather than crashing."""
        corrupted = "Total garbage without braces <<>> !!!"
        parsed = extract_json_payload(corrupted)
        self.assertEqual(parsed, {})


if __name__ == "__main__":
    unittest.main()
