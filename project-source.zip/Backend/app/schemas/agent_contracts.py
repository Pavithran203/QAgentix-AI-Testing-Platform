"""Pydantic schemas enforcing the Multi-Agent JSON Input/Output contract.

Rules:
1. Every agent speaks strict JSON in and out, validated by these Pydantic schemas.
2. Writes are restricted strictly inside the workspace folder contract.
3. Sub-agents NEVER call each other directly; Kiro Main Agent is the sole caller.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Literal
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# 1. Prompt Optimizer Agent
# ---------------------------------------------------------------------------
class PromptOptimizerAction(str, Enum):
    PROCEED = "PROCEED"      # Score >= 80
    APPROVE = "APPROVE"      # Score 50 - 79
    CLARIFY = "CLARIFY"      # Score < 50


class PromptOptimizerInput(BaseModel):
    raw_prompt: str = Field(..., description="Raw user input prompt")
    context: dict[str, Any] | None = Field(default=None, description="Active session or file context")


class PromptOptimizerOutput(BaseModel):
    score: int = Field(..., ge=0, le=100, description="Quality score 0-100")
    issues: list[str] = Field(default_factory=list, description="Identified deficiencies in prompt")
    missing_info: list[str] = Field(default_factory=list, description="Missing requirements or data signals")
    optimized_prompt: str = Field(..., description="Engineered high-signal instruction for agents")
    action: PromptOptimizerAction = Field(..., description="Decision gate based on score threshold")


# ---------------------------------------------------------------------------
# 2. Prompt Suggestion Agent
# ---------------------------------------------------------------------------
class PromptSuggestionItem(BaseModel):
    id: str
    label: str
    prompt: str
    badge: str
    color: str = "teal"


class PromptSuggestionInput(BaseModel):
    session_id: str
    current_artifacts: list[str] = Field(default_factory=list, description="List of files generated so far")
    last_result: str | None = Field(default=None, description="Summary of last agent output")


class PromptSuggestionOutput(BaseModel):
    suggestions: list[PromptSuggestionItem] = Field(..., description="3-5 recommended next actions as chips")


# ---------------------------------------------------------------------------
# 3. Planner Agent
# ---------------------------------------------------------------------------
class PlannerInput(BaseModel):
    prompt: str
    workspace_path: str
    context: dict[str, Any] | None = None


class PlannerOutput(BaseModel):
    plan_path: str = Field(..., description="Relative path: .qagentix/plan.md")
    steps: list[str] = Field(..., description="Ordered list of execution steps")
    agents_involved: list[str] = Field(..., description="Sub-agents to be invoked by Kiro Main Agent")
    files_to_touch: list[str] = Field(..., description="Planned files to create or modify")
    risks: list[str] = Field(default_factory=list, description="Identified testing or environment risks")
    approval_needed: bool = Field(default=False, description="True if destructive or large change")


# ---------------------------------------------------------------------------
# 4. Feature Agent
# ---------------------------------------------------------------------------
class FeatureAgentInput(BaseModel):
    requirements: str
    workspace_path: str
    feature_name: str | None = None


class FeatureAgentOutput(BaseModel):
    feature_file_path: str = Field(..., description="Relative path: Features/*.feature")
    feature_name: str
    scenarios_count: int
    gherkin_content: str


# ---------------------------------------------------------------------------
# 5. Testcase Analysis Agent
# ---------------------------------------------------------------------------
class TestCaseItem(BaseModel):
    id: str = Field(..., min_length=1)
    title: str = Field(..., min_length=1)
    description: str = Field(default="")
    category: Literal["Smoke", "Boundary", "Regression", "Security", "E2E"]
    priority: Literal["High", "Medium", "Low"]
    steps: list[str] = Field(..., min_length=1)
    expectedResult: str = Field(..., min_length=1)



class TestcaseAgentInput(BaseModel):
    requirements: str
    workspace_path: str
    feature_content: str | None = None


class TestcaseAgentOutput(BaseModel):
    json_path: str = Field(..., description="Relative path: Test_cases/*_testcases.json")
    csv_path: str = Field(..., description="Relative path: Test_cases/*_testcases.csv")
    total_cases: int
    cases: list[TestCaseItem]
    coverage_score: str = "100%"


# ---------------------------------------------------------------------------
# 6. Data-Driven Agent
# ---------------------------------------------------------------------------
class DataDrivenAgentInput(BaseModel):
    workspace_path: str
    subject: str
    sample_data: dict[str, Any] | None = None


class DataDrivenAgentOutput(BaseModel):
    testdata_path: str = Field(..., description="Relative path: Test_data/*_fixtures.json")
    dataset_mapping: dict[str, str] = Field(default_factory=dict, description="Fixture keys to test mapping")
    fixtures_content: str


# ---------------------------------------------------------------------------
# 7. Script Agent & Playwright Script Contract
# ---------------------------------------------------------------------------
class LocatorReference(BaseModel):
    name: str = Field(..., description="Semantic locator identifier in Page Object, e.g. submitButton")
    strategy: str = Field(default="role", description="Strategy: role, testId, label, text, css, xpath")
    selector: str = Field(..., description="Playwright selector string or role name")
    options: dict[str, Any] = Field(default_factory=dict, description="Options e.g. {'name': 'Submit'}")
    description: str = Field(default="", description="Human-readable description of element")
    linked_testcase_ids: list[str] = Field(default_factory=list, description="IDs of testcases interacting with this locator")
    healing_candidates: list[str] = Field(default_factory=list, description="Resilient fallback selectors for self-healing")


class TestCaseScriptLink(BaseModel):
    testcase_id: str = Field(..., description="Linked Test Case ID e.g. TC-101")
    title: str = Field(..., description="Title of the test case")
    test_block_name: str = Field(..., description="Title of test block in Playwright spec")
    spec_path: str = Field(..., description="Relative path under Scripts/*.spec.ts")
    page_class: str = Field(..., description="Associated Page Object class")
    locators_used: list[str] = Field(default_factory=list, description="Locator names used in this test block")
    expected_result: str = Field(default="", description="Expected outcome asserted by this test")


class ScriptAgentInput(BaseModel):
    mode: Literal["create", "update", "analyse", "fix"] = "create"
    subject: str
    testcases: list[TestCaseItem] = Field(default_factory=list)
    workspace_path: str
    data_mapping: dict[str, str] | None = None
    locators: list[LocatorReference] | None = None
    existing_spec_path: str | None = None
    failure_log: str | None = None


class ScriptAgentOutput(BaseModel):
    spec_path: str = Field(..., description="Relative path: Scripts/*.spec.ts")
    page_object_path: str = Field(..., description="Relative path: Scripts/pages/*Page.ts")
    linked_testcase_ids: list[str] = Field(default_factory=list, description="All Test Case IDs linked to this script")
    case_links: list[TestCaseScriptLink] = Field(default_factory=list, description="Contract linking each testcase ID to test blocks & locators")
    locator_references: list[LocatorReference] = Field(default_factory=list, description="All locator definitions in the Page Object")
    spec_content: str
    page_object_content: str
    git_commit_summary: str


# ---------------------------------------------------------------------------
# 8. Execute Agent
# ---------------------------------------------------------------------------
class ExecuteAgentInput(BaseModel):
    workspace_path: str
    script_paths: list[str]
    timeout_seconds: int = 60


class ExecuteAgentOutput(BaseModel):
    status: Literal["PASS", "FAIL", "ERROR"]
    passed_count: int
    failed_count: int
    results_json_path: str = Field(..., description="Relative path: Reports/results.json")
    log_path: str = Field(..., description="Relative path: Reports/logs/execution.log")
    screenshots: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# 9. Report Agent
# ---------------------------------------------------------------------------
class ReportAgentInput(BaseModel):
    workspace_path: str
    results_json_path: str
    subject: str


class ReportAgentOutput(BaseModel):
    report_html_path: str = Field(..., description="Relative path: Reports/*.html")
    report_json_path: str = Field(..., description="Relative path: Reports/*.json")
    summary: dict[str, Any]
    failure_reasons: list[str] = Field(default_factory=list)
