"""Schemas for project membership management."""

from datetime import datetime
from pydantic import BaseModel
from app.core.roles import Role


class ProjectMemberItem(BaseModel):
    id: str
    project_id: str
    user_id: str
    username: str
    role: str
    created_at: datetime
    updated_at: datetime


class AddProjectMemberRequest(BaseModel):
    user_id: str
    role: Role = Role.TESTER


class UpdateProjectMemberRoleRequest(BaseModel):
    role: Role
