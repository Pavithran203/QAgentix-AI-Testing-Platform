"""Schemas for dynamic AI test suite generation."""
from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class AgentFileAttachment(BaseModel):
    name: str
    size: str | None = None
    type: str | None = None
    content: str | None = None


class AgentGenerateRequest(BaseModel):
    prompt: str
    project_name: str = Field(default="Rammas", alias="projectName")
    files: list[AgentFileAttachment] = Field(default_factory=list)
    provider: str | None = None
    model: str | None = None

    model_config = {"populate_by_name": True}


class GeneratedTestCase(BaseModel):
    id: str
    title: str
    description: str
    steps: list[str]
    expectedResult: str
    priority: Literal["High", "Medium", "Low"]
    category: Literal["E2E", "Regression", "Boundary", "Security", "Smoke"]


class GeneratedFile(BaseModel):
    path: str
    name: str
    language: str
    description: str
    content: str


class BundleSummary(BaseModel):
    totalCases: int
    positiveCount: int
    negativeCount: int
    edgeCount: int
    coverage: str


class AgentAnswerResponse(BaseModel):
    """Returned instead of a bundle when the message is a question, not a test request."""

    kind: Literal["answer"] = "answer"
    message: str


class GeneratedBundleResponse(BaseModel):
    kind: Literal["bundle"] = "bundle"
    # What the user asked for: whole suite, just the test cases, the script, or edge cases.
    focus: Literal["suite", "cases", "script", "edge"] = "suite"
    title: str
    description: str
    summary: BundleSummary
    testCases: list[GeneratedTestCase]
    files: list[GeneratedFile]
    provider: str = "qagentix-model"
    model: str = "dynamic-synthesizer"
    generatedAt: str = ""
    accepted: bool = False
    acceptedAt: str | None = None
