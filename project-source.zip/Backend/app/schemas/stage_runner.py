"""Schemas for the generic pipeline stage runner.

A single request/response contract that lets the frontend run ANY pipeline stage
(process, user_story, feature, testcase, test_data, script, execute, report)
through one LLM-backed endpoint, using the system prompts in app.agent.prompts.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

# Keep in sync with app.agent.prompts.STAGE_PROMPTS keys.
StageKey = Literal[
    "process",
    "user_story",
    "feature",
    "testcase",
    "test_data",
    "script",
    "execute",
    "report",
]


class StageRunRequest(BaseModel):
    """Run one pipeline stage against a block of input with its system prompt."""

    stage: StageKey
    #: The user-facing input for this stage (requirements, prior-stage output, logs, ...).
    input: str = Field(min_length=1)
    #: Optional run-specific context appended to the system prompt (subject, framework, ...).
    context: dict[str, str] | None = None
    provider: str | None = None
    model: str | None = None
    api_key: str | None = Field(default=None, alias="apiKey")

    model_config = {"populate_by_name": True}


class StageHealingStep(BaseModel):
    attempt: int
    status: str
    detail: str


class StageRunResponse(BaseModel):
    stage: StageKey
    output: str
    provider: str
    model: str
    final_status: str
    healing_attempts: int
    healing_log: list[StageHealingStep]
