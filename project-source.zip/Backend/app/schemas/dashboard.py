"""Request/response schemas for the dashboard + runs APIs (camelCase JSON aliases).

All timestamps are UTC ISO-8601 strings (serialized via `.isoformat()`), matching
the subscriptions schema convention. UNAVAILABLE metrics are `null` / `[]`.
"""
from pydantic import BaseModel, Field


# --- Summary ---------------------------------------------------------------
class TimeRangeOut(BaseModel):
    start: str | None = None
    end: str | None = None

    model_config = {"populate_by_name": True}


class SummaryOut(BaseModel):
    total_projects: int = Field(alias="totalProjects")
    total_test_cases: int | None = Field(default=None, alias="totalTestCases")
    total_runs: int = Field(alias="totalRuns")
    pass_rate: float | None = Field(default=None, alias="passRate")
    failed_tests: int = Field(alias="failedTests")
    locator_issues: int | None = Field(default=None, alias="locatorIssues")
    time_range: TimeRangeOut = Field(alias="timeRange")
    last_updated: str | None = Field(default=None, alias="lastUpdated")

    model_config = {"populate_by_name": True}


# --- Trends / charts -------------------------------------------------------
class PassRatePointOut(BaseModel):
    period: str
    passed: int
    failed: int
    pass_rate: float | None = Field(default=None, alias="passRate")

    model_config = {"populate_by_name": True}


class ExecutionPointOut(BaseModel):
    period: str
    execution_count: int = Field(alias="executionCount")

    model_config = {"populate_by_name": True}


class FailureCategoryOut(BaseModel):
    category: str
    count: int

    model_config = {"populate_by_name": True}


class LocatorHealthOut(BaseModel):
    status: str
    count: int
    percentage: float
    population_count: int = Field(alias="populationCount")

    model_config = {"populate_by_name": True}


# --- Recent runs / run detail ---------------------------------------------
class RunRowOut(BaseModel):
    id: str
    project: str
    suite: str
    started: str
    duration: str | None = None
    passed: int
    failed: int
    status: str

    model_config = {"populate_by_name": True}


class RecentRunsOut(BaseModel):
    items: list[RunRowOut]
    total: int
    page: int
    page_size: int = Field(alias="pageSize")

    model_config = {"populate_by_name": True}


class ArtifactRefOut(BaseModel):
    kind: str
    filename: str
    ref: str

    model_config = {"populate_by_name": True}


class TestResultOut(BaseModel):
    testcase_ref: str | None = Field(default=None, alias="testcaseRef")
    status: str
    failure_category: str | None = Field(default=None, alias="failureCategory")
    duration_ms: int | None = Field(default=None, alias="durationMs")
    executed_at: str = Field(alias="executedAt")

    model_config = {"populate_by_name": True}


class RunEventOut(BaseModel):
    type: str
    message: str
    step_number: int | None = Field(default=None, alias="stepNumber")
    status: str | None = None
    timestamp: str

    model_config = {"populate_by_name": True}


class RunDetailOut(BaseModel):
    id: str
    project: str
    suite: str
    started: str
    completed: str | None = None
    duration: str | None = None
    passed: int
    failed: int
    status: str
    results: list[TestResultOut]
    artifacts: list[ArtifactRefOut]
    events: list[RunEventOut] = []

    model_config = {"populate_by_name": True}


# --- Metrics snapshot / history -------------------------------------------
class MetricSnapshotOut(BaseModel):
    total_projects: int = Field(alias="totalProjects")
    total_test_cases: int | None = Field(default=None, alias="totalTestCases")
    total_runs: int = Field(alias="totalRuns")
    pass_rate: float | None = Field(default=None, alias="passRate")
    failed_tests: int = Field(alias="failedTests")
    locator_issues: int | None = Field(default=None, alias="locatorIssues")
    snapshot_at: str = Field(alias="snapshotAt")

    model_config = {"populate_by_name": True}


# --- Recording request bodies ---------------------------------------------
class RunCreateIn(BaseModel):
    subproject_id: str = Field(alias="subprojectId")
    test_suite: str = Field(alias="testSuite")
    workspace_base: str | None = Field(default=None, alias="workspaceBase")

    model_config = {"populate_by_name": True}


class ArtifactRefIn(BaseModel):
    kind: str
    filename: str
    rel_path: str = Field(alias="relPath")

    model_config = {"populate_by_name": True}


class TestResultIn(BaseModel):
    testcase_ref: str | None = Field(default=None, alias="testcaseRef")
    status: str
    failure_category: str | None = Field(default=None, alias="failureCategory")
    duration_ms: int | None = Field(default=None, alias="durationMs")
    executed_at: str | None = Field(default=None, alias="executedAt")

    model_config = {"populate_by_name": True}


class RunCompleteIn(BaseModel):
    status: str
    results: list[TestResultIn] = Field(default_factory=list)
    artifact_refs: list[ArtifactRefIn] = Field(default_factory=list, alias="artifactRefs")

    model_config = {"populate_by_name": True}
