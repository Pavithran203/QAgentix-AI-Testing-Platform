"""Request/response schemas for authentication."""
from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, alias="fullName")
    email: EmailStr
    username: str = Field(min_length=3)
    password: str = Field(min_length=6)

    model_config = {"populate_by_name": True}


class LoginRequest(BaseModel):
    username: str = Field(min_length=3)
    password: str = Field(min_length=6)


class RefreshRequest(BaseModel):
    refresh_token: str = Field(alias="refreshToken")

    model_config = {"populate_by_name": True}


class UserOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    username: str
    role: str
    avatar: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: UserOut
