"""Schemas for the Process Agent (Phase 1: multi-modal input -> response)."""
from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class PipelineMode(str, Enum):
    DOCUMENT_BRD = "DOCUMENT_BRD"
    LIVE_WEB_APP = "LIVE_WEB_APP"
    HYBRID = "HYBRID"
    DIRECT_PROMPT = "DIRECT_PROMPT"


class WebCredentials(BaseModel):
    username: str | None = None
    password: str | None = None
    auth_type: str = Field(default="form_login", alias="authType")

    model_config = {"populate_by_name": True}


class ProcessRequest(BaseModel):
    text: str | None = None
    document_content: str | None = Field(default=None, alias="documentContent")
    document_name: str | None = Field(default=None, alias="documentName")
    target_url: str | None = Field(default=None, alias="targetUrl")
    credentials: WebCredentials | None = None
    provider: str | None = None
    model: str | None = None
    api_key: str | None = Field(default=None, alias="apiKey")

    model_config = {"populate_by_name": True}


class HealingStep(BaseModel):
    attempt: int
    status: str
    detail: str


class ProcessResponse(BaseModel):
    session_id: str
    pipeline_mode: PipelineMode
    authenticated: bool
    response: str
    provider: str
    model: str
    healing_attempts: int
    healing_log: list[HealingStep]
    final_status: str
