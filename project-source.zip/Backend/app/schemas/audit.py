"""Schemas for audit log querying."""

from datetime import datetime
from typing import Any
from pydantic import BaseModel


class AuditLogItem(BaseModel):
    id: str
    user_id: str | None
    username: str
    action: str
    resource_type: str
    resource_id: str
    details: dict[str, Any]
    ip_address: str | None
    timestamp: datetime
