"""Testcase schemas and traceability models for QAgentix test design."""
from __future__ import annotations

import re
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator

from app.schemas.feature import Feature, Priority


class TestCaseCategory(str, Enum):
    """Test classification category (aligned with QAgentix frontend and standard QA suites)."""
    __test__ = False
    SMOKE = "Smoke"
    E2E = "E2E"
    REGRESSION = "Regression"
    BOUNDARY = "Boundary"
    SECURITY = "Security"
    PERFORMANCE = "Performance"
    INTEGRATION = "Integration"
    UNIT = "Unit"

    @classmethod
    def _missing_(cls, value: object) -> TestCaseCategory | None:
        if isinstance(value, str):
            val_lower = value.strip().lower()
            for member in cls:
                if member.value.lower() == val_lower or member.name.lower() == val_lower:
                    return member
        return None


class TestCaseStatus(str, Enum):
    """Review and lifecycle status of a Test Case."""
    __test__ = False
    APPROVED = "Approved"
    DRAFT = "Draft"
    NEEDS_REVIEW = "Needs review"
    DEPRECATED = "Deprecated"

    @classmethod
    def _missing_(cls, value: object) -> TestCaseStatus | None:
        if isinstance(value, str):
            val_norm = value.strip().lower().replace("_", " ").replace("-", " ")
            for member in cls:
                if member.value.lower() == val_norm or member.name.lower() == val_norm:
                    return member
        return None


class AutomationStatus(str, Enum):
    """Automation execution status for traceability."""
    AUTOMATED = "Automated"
    MANUAL = "Manual"
    CANDIDATE = "Candidate"
    OBSOLETE = "Obsolete"

    @classmethod
    def _missing_(cls, value: object) -> AutomationStatus | None:
        if isinstance(value, str):
            val_norm = value.strip().lower().replace("_", " ")
            for member in cls:
                if member.value.lower() == val_norm or member.name.lower() == val_norm:
                    return member
        return None


class TestStep(BaseModel):
    """Individual execution step within a test case."""
    __test__ = False
    step_number: int = Field(
        ge=1,
        alias="stepNumber",
        description="Sequential step index starting from 1",
    )
    action: str = Field(
        ...,
        min_length=1,
        description="Action performed by user, agent, or system",
    )
    expected_result: str | None = Field(
        default=None,
        alias="expectedResult",
        description="Expected intermediate outcome after this specific step",
    )
    test_data: Any | None = Field(
        default=None,
        alias="testData",
        description="Input values, parameters, or payloads for this step",
    )

    model_config = {"populate_by_name": True}


class TraceabilityInfo(BaseModel):
    """Traceability links mapping a testcase to requirements, features, and automation code."""
    feature_id: str | None = Field(
        default=None,
        alias="featureId",
        description="ID of the parent Feature (e.g. FEAT-101)",
    )
    requirement_ids: list[str] = Field(
        default_factory=list,
        alias="requirementIds",
        description="Business / specification requirement IDs covered by this test case",
    )
    user_story_ids: list[str] = Field(
        default_factory=list,
        alias="userStoryIds",
        description="Agile user story IDs linked to this test case",
    )
    source_documents: list[str] = Field(
        default_factory=list,
        alias="sourceDocuments",
        description="Source document names (e.g. BRD, OpenAPI spec, PRD)",
    )
    target_url: str | None = Field(
        default=None,
        alias="targetUrl",
        description="Target web URL or route tested by this scenario",
    )
    script_path: str | None = Field(
        default=None,
        alias="scriptPath",
        description="Relative path to test script in workspace (e.g. Scripts/rammas.spec.ts)",
    )
    test_method: str | None = Field(
        default=None,
        alias="testMethod",
        description="Function or test block name in the automated script",
    )
    automation_status: AutomationStatus = Field(
        default=AutomationStatus.CANDIDATE,
        alias="automationStatus",
        description="Current automation state (Manual, Automated, Candidate, Obsolete)",
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Categorization and search labels",
    )

    model_config = {"populate_by_name": True}


class TestCase(BaseModel):
    """Schema representing a Test Case in QAgentix.

    Supports IDs, priority, structured steps, expected results, and traceability.
    Maintains compatibility with existing QAgentix frontend and workspace artifacts.
    """
    __test__ = False
    id: str = Field(
        ...,
        pattern=r"^[A-Za-z0-9_-]+$",
        description="Unique Test Case ID (e.g. TC-101, TC-2101)",
    )
    title: str = Field(
        ...,
        min_length=3,
        max_length=300,
        description="Concise description of the test purpose and scenario",
    )
    description: str = Field(
        default="",
        description="Detailed context and objective of the test",
    )
    priority: Priority = Field(
        default=Priority.MEDIUM,
        description="Priority level: Critical, High, Medium, Low",
    )
    category: TestCaseCategory = Field(
        default=TestCaseCategory.E2E,
        description="Test category: Smoke, E2E, Regression, Boundary, Security, etc.",
    )
    status: TestCaseStatus = Field(
        default=TestCaseStatus.DRAFT,
        description="Lifecycle status: Approved, Draft, Needs review, Deprecated",
    )
    preconditions: list[str] = Field(
        default_factory=list,
        description="Prerequisites that must be satisfied before test execution",
    )
    steps: list[TestStep] = Field(
        ...,
        min_length=1,
        description="Ordered sequence of test execution steps",
    )
    expected_result: str = Field(
        ...,
        min_length=1,
        alias="expectedResult",
        description="Final expected system state or validation condition",
    )
    traceability: TraceabilityInfo = Field(
        default_factory=TraceabilityInfo,
        description="Traceability mapping to feature, requirements, and scripts",
    )

    model_config = {"populate_by_name": True}

    @field_validator("id")
    @classmethod
    def validate_id_format(cls, v: str) -> str:
        cleaned = v.strip()
        if not cleaned:
            raise ValueError("Test Case ID cannot be empty.")
        return cleaned

    @field_validator("steps", mode="before")
    @classmethod
    def normalize_steps(cls, v: Any) -> list[dict[str, Any] | TestStep]:
        """Normalize various step input formats:

        1. list of strings -> list of TestStep dicts (stepNumber 1..N)
        2. single string -> parsed by numbering (1. ... 2. ...) or newlines
        3. list of dicts / TestStep -> pass through for model validation
        """
        if isinstance(v, list):
            if not v:
                raise ValueError("Test case must contain at least one step.")
            normalized: list[dict[str, Any] | TestStep] = []
            for idx, item in enumerate(v, start=1):
                if isinstance(item, str):
                    cleaned = item.strip()
                    # Strip leading numbering like "1. ", "Step 1: " if present
                    cleaned = re.sub(r"^(?:step\s*)?\d+[\.:\)]\s*", "", cleaned, flags=re.IGNORECASE).strip()
                    normalized.append({"step_number": idx, "action": cleaned or item})
                elif isinstance(item, (dict, TestStep)):
                    normalized.append(item)
                else:
                    normalized.append({"step_number": idx, "action": str(item)})
            return normalized

        if isinstance(v, str):
            text = v.strip()
            if not text:
                raise ValueError("Test case steps cannot be empty.")
            # Check for numbered steps like "1. Step A 2. Step B" or newline-separated steps
            numbered_matches = re.split(r"(?:^|\s+)(?:\d+[\.:\)]|(?:step\s*\d+[\.:\)]))\s*", text, flags=re.IGNORECASE)
            items = [m.strip() for m in numbered_matches if m.strip()]
            if not items:
                # Fallback to lines
                items = [line.strip() for line in text.splitlines() if line.strip()]
            if not items:
                items = [text]
            return [{"step_number": i, "action": act} for i, act in enumerate(items, start=1)]

        return v

    @model_validator(mode="before")
    @classmethod
    def extract_top_level_traceability(cls, data: Any) -> Any:
        """Allow convenience top-level fields (feature_id, requirement_ids) to merge into traceability."""
        if isinstance(data, dict):
            traceability = data.get("traceability") or {}
            if isinstance(traceability, dict):
                # If featureId / feature_id passed at top level and missing in traceability:
                feat_id = data.get("feature_id") or data.get("featureId")
                if feat_id and not traceability.get("feature_id") and not traceability.get("featureId"):
                    traceability["feature_id"] = feat_id

                req_ids = data.get("requirement_ids") or data.get("requirementIds")
                if req_ids and not traceability.get("requirement_ids") and not traceability.get("requirementIds"):
                    traceability["requirement_ids"] = req_ids

                data["traceability"] = traceability
        return data

    @property
    def step_actions(self) -> list[str]:
        """Convenience property returning actions as a list of strings."""
        return [step.action for step in self.steps]

    @property
    def steps_text(self) -> str:
        """Convenience property returning steps as a numbered string."""
        return " ".join(f"{s.step_number}. {s.action}" for s in self.steps)

    def to_csv_row(self) -> dict[str, str]:
        """Convert test case to flat dictionary compatible with CSV export."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "steps": self.steps_text,
            "expectedResult": self.expected_result,
            "priority": self.priority.value,
            "category": self.category.value,
            "status": self.status.value,
            "featureId": self.traceability.feature_id or "",
            "requirementIds": ";".join(self.traceability.requirement_ids),
            "scriptPath": self.traceability.script_path or "",
            "automationStatus": self.traceability.automation_status.value,
        }

    def to_gherkin(self) -> str:
        """Render this test case as a BDD Scenario in standard Gherkin syntax."""
        tags = [f"@{self.id}", f"@{self.priority.value}", f"@{self.category.value}"]
        if self.traceability.feature_id:
            tags.append(f"@{self.traceability.feature_id}")
        for req in self.traceability.requirement_ids:
            tags.append(f"@{req}")
        for t in self.traceability.tags:
            tags.append(f"@{t}")

        lines = ["  " + " ".join(tags), f"  Scenario: {self.title}"]
        if self.description:
            lines.append(f"    # {self.description}")

        for p in self.preconditions:
            lines.append(f"    Given {p}")

        for idx, step in enumerate(self.steps):
            prefix = "Given" if idx == 0 and not self.preconditions else ("When" if idx == 0 else "And")
            lines.append(f"    {prefix} {step.action}")
            if step.expected_result:
                lines.append(f"    Then {step.expected_result}")

        lines.append(f"    Then {self.expected_result}")
        return "\n".join(lines)

    def to_markdown(self) -> str:
        """Render test case as structured Markdown document."""
        lines = [
            f"# Test Case {self.id}: {self.title}",
            "",
            f"- **Priority**: {self.priority.value}",
            f"- **Category**: {self.category.value}",
            f"- **Status**: {self.status.value}",
            f"- **Automation Status**: {self.traceability.automation_status.value}",
        ]
        if self.traceability.feature_id:
            lines.append(f"- **Feature ID**: {self.traceability.feature_id}")
        if self.traceability.requirement_ids:
            lines.append(f"- **Requirements**: {', '.join(self.traceability.requirement_ids)}")
        if self.traceability.script_path:
            lines.append(f"- **Script Path**: `{self.traceability.script_path}`")
        if self.traceability.target_url:
            lines.append(f"- **Target URL**: {self.traceability.target_url}")

        lines.append("")
        if self.description:
            lines.extend(["## Description", self.description, ""])

        if self.preconditions:
            lines.extend(["## Preconditions", *(f"- {p}" for p in self.preconditions), ""])

        lines.extend([
            "## Execution Steps",
            "",
            "| # | Action | Expected Step Result |",
            "|---|--------|----------------------|",
        ])
        for s in self.steps:
            exp = s.expected_result or "-"
            lines.append(f"| {s.step_number} | {s.action} | {exp} |")

        lines.extend([
            "",
            "## Expected Final Result",
            self.expected_result,
            "",
        ])
        return "\n".join(lines)


class TraceabilityMatrix(BaseModel):
    """Bidirectional Traceability Matrix connecting Features, Requirements, and Test Cases."""
    feature: Feature
    test_cases: list[TestCase] = Field(
        default_factory=list,
        alias="testCases",
        description="Collection of test cases validating the feature",
    )

    model_config = {"populate_by_name": True}

    def verify_traceability(self) -> dict[str, Any]:
        """Perform bidirectional traceability verification and generate coverage analytics.

        Returns:
            Dictionary with coverage percentages, orphaned testcases, uncovered requirements,
            and automation readiness metrics.
        """
        feature_reqs = set(self.feature.traceability.requirement_ids)
        test_case_reqs: set[str] = set()
        unlinked_test_cases: list[str] = []
        automated_cases: list[str] = []
        req_to_cases: dict[str, list[str]] = {r: [] for r in feature_reqs}

        for tc in self.test_cases:
            # Check link to feature
            if tc.traceability.feature_id != self.feature.id:
                unlinked_test_cases.append(tc.id)

            # Check automated status
            if tc.traceability.automation_status == AutomationStatus.AUTOMATED:
                automated_cases.append(tc.id)

            # Map requirements
            for req in tc.traceability.requirement_ids:
                test_case_reqs.add(req)
                if req in req_to_cases:
                    req_to_cases[req].append(tc.id)
                else:
                    req_to_cases[req] = [tc.id]

        covered_reqs = feature_reqs.intersection(test_case_reqs)
        uncovered_reqs = feature_reqs - test_case_reqs

        req_coverage_pct = (
            round((len(covered_reqs) / len(feature_reqs)) * 100, 1)
            if feature_reqs
            else 100.0
        )
        total_tc = len(self.test_cases)
        auto_coverage_pct = (
            round((len(automated_cases) / total_tc) * 100, 1)
            if total_tc > 0
            else 0.0
        )

        return {
            "feature_id": self.feature.id,
            "feature_title": self.feature.title,
            "total_requirements": len(feature_reqs),
            "covered_requirements_count": len(covered_reqs),
            "uncovered_requirements": sorted(list(uncovered_reqs)),
            "requirement_coverage_pct": req_coverage_pct,
            "total_test_cases": total_tc,
            "automated_test_cases_count": len(automated_cases),
            "automation_coverage_pct": auto_coverage_pct,
            "unlinked_test_cases": unlinked_test_cases,
            "requirement_to_test_cases": req_to_cases,
            "is_fully_traced": len(uncovered_reqs) == 0 and len(unlinked_test_cases) == 0,
        }
