"""Pydantic schemas for Kiro IDE / CLI agent integration."""
from __future__ import annotations

from typing import Any
from pydantic import BaseModel, Field


class KiroStatusResponse(BaseModel):
    installed: bool
    version: str | None = None
    cli_path: str
    mode: str
    message: str
    install_guide: str = "irm 'https://cli.kiro.dev/install.ps1' | iex"


class KiroModelItem(BaseModel):
    id: str
    name: str
    badge: str
    provider: str
    description: str
    context_window: str = "200k"
    latency: str = "Fast"
    icon: str = "sparkles"


class KiroModelsResponse(BaseModel):
    connected: bool = True
    harness: str = "Kiro IDE Agent Gateway (Gemini 3.8 Flash Medium)"
    active_model: str = "auto"
    models: list[KiroModelItem] = Field(default_factory=list)


class KiroExecuteRequest(BaseModel):
    prompt: str = Field(..., max_length=50_000, description="User prompt or instructions for the agent")
    workspace_path: str | None = Field(default=None, max_length=1000, description="Target workspace path for execution")
    document_content: str | None = Field(default=None, max_length=1_000_000, description="Extracted document / PRD / spec content")
    document_name: str | None = Field(default=None, max_length=255, description="Name of uploaded document if any")
    session_id: str | None = Field(default=None, max_length=100, description="Chat or workflow session ID")
    timeout_seconds: int | None = Field(default=None, ge=1, le=3600, description="Max execution timeout in seconds")
    trust_all_tools: bool | None = Field(default=True, description="Pass --trust-all-tools to kiro-cli")
    model: str | None = Field(default="auto", max_length=100, description="Selected AI model for execution")
    subproject_id: str | None = Field(default=None, max_length=100, description="Owning SubProject id for run linkage")


class KiroStepLog(BaseModel):
    step_number: int
    title: str
    detail: str
    status: str = "completed"  # pending, in_progress, completed, failed


class KiroGeneratedArtifact(BaseModel):
    file_path: str
    relative_path: str
    category: str = "script"  # script, testcase, feature, report
    content: str | None = None


class KiroExecuteResponse(BaseModel):
    session_id: str
    status: str  # SUCCESS, REPAIRED, FAILED, FALLBACK
    connected_surface: str  # "Kiro CLI", "Kiro Gateway", "Fallback Engine"
    response: str
    steps: list[KiroStepLog] = Field(default_factory=list)
    artifacts: list[KiroGeneratedArtifact] = Field(default_factory=list)
    execution_time_seconds: float = 0.0
    error: str | None = None
    model_used: str | None = None


class KiroReadFileRequest(BaseModel):
    workspace_path: str | None = Field(default=None, max_length=1000)
    relative_path: str = Field(..., max_length=1000)



class KiroReadFileResponse(BaseModel):
    relative_path: str
    content: str
    size: int
