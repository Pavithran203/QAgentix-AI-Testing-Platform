"""Schemas for admin user management (RBAC)."""

from datetime import datetime
from pydantic import BaseModel, EmailStr, Field

from app.core.roles import DEFAULT_ROLE, Role


class UserListItem(BaseModel):
    id: str
    name: str
    email: EmailStr
    username: str
    role: str
    is_active: bool
    created_at: datetime
    avatar: str


class CreateUserRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    username: str = Field(min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_\-\.]+$")
    password: str = Field(min_length=8, max_length=128)
    role: Role = DEFAULT_ROLE


class UpdateRoleRequest(BaseModel):
    role: Role


class UpdateStatusRequest(BaseModel):
    is_active: bool
