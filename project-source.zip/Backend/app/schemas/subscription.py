"""Request/response schemas for subscriptions (camelCase JSON aliases)."""
from pydantic import BaseModel, Field


class SubscriptionCreate(BaseModel):
    name: str = Field(min_length=1)
    category: str
    plan: str
    status: str
    description: str

    model_config = {"populate_by_name": True}


class SubscriptionOut(BaseModel):
    id: str
    code: str
    name: str
    category: str
    status: str
    plan: str
    description: str
    projects_count: int = Field(alias="projectsCount")
    active_agents: int = Field(alias="activeAgents")
    total_runs: int = Field(alias="totalRuns")
    created_at: str = Field(alias="createdAt")
    accent_gradient: str = Field(alias="accentGradient")

    model_config = {"populate_by_name": True}


class SubscriptionSummary(BaseModel):
    subscription_count: int = Field(alias="subscriptionCount")
    subproject_count: int = Field(alias="subprojectCount")

    model_config = {"populate_by_name": True}
