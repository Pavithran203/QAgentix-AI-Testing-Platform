"""Schemas for the workspace (local filesystem project storage)."""
from __future__ import annotations

from pydantic import BaseModel, Field


class BrowseRequest(BaseModel):
    # Absolute path to list. Empty string => return drive roots.
    path: str = ""


class MakeDirRequest(BaseModel):
    # Create a new folder `name` inside this existing parent directory.
    parent: str = Field(min_length=1)
    name: str = Field(min_length=1, max_length=120)


class ReadFileRequest(BaseModel):
    base: str = Field(min_length=1)
    folder: str = Field(min_length=1)
    filename: str = Field(min_length=1, max_length=200)


class CreateStructureRequest(BaseModel):
    # Absolute path of the folder the user selected in the picker. The
    # predefined structure is created INSIDE this folder.
    base: str = Field(min_length=1)


class WriteFileRequest(BaseModel):
    base: str = Field(min_length=1)
    # kind routes the file into the right subfolder:
    # feature | script | testcase | testdata | report
    kind: str
    filename: str = Field(min_length=1, max_length=200)
    content: str = ""


class WriteManyItem(BaseModel):
    kind: str
    filename: str = Field(min_length=1, max_length=200)
    content: str = ""


class WriteManyRequest(BaseModel):
    base: str = Field(min_length=1)
    files: list[WriteManyItem]
