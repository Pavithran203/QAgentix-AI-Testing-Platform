"""Request/response schemas for subprojects (camelCase JSON aliases)."""
from pydantic import BaseModel, Field


class SubProjectCreate(BaseModel):
    subscription_id: str = Field(alias="subscriptionId")
    name: str = Field(min_length=1)
    type: str
    endpoints_count: int = Field(alias="endpointsCount")
    endpoints: list[str]
    description: str

    model_config = {"populate_by_name": True}


class SubProjectOut(BaseModel):
    id: str
    code: str
    subscription_id: str = Field(alias="subscriptionId")
    name: str
    type: str
    endpoints_count: int = Field(alias="endpointsCount")
    endpoints: list[str]
    description: str
    stories_count: int = Field(alias="storiesCount")
    test_cases_count: int = Field(alias="testCasesCount")
    scripts_count: int = Field(alias="scriptsCount")
    created_at: str = Field(alias="createdAt")
    accent_gradient: str = Field(alias="accentGradient")

    model_config = {"populate_by_name": True}
