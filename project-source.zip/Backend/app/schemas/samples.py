"""Sample Feature, TestCase, and Traceability models for QAgentix demonstration and testing."""
from __future__ import annotations

from app.schemas.feature import Feature, FeatureStatus, FeatureTraceability, Priority
from app.schemas.testcase import (
    AutomationStatus,
    TestCase,
    TestCaseCategory,
    TestCaseStatus,
    TestStep,
    TraceabilityInfo,
    TraceabilityMatrix,
)

# Canonical Sample Feature based on QAgentix Rammas project
SAMPLE_FEATURE_RAMMAS = Feature(
    id="FEAT-RAMMAS-01",
    title="Operations Portal Channel & Voice Management",
    description="Provide authenticated operations agents with ability to browse, filter, and configure communication channels and voice options.",
    user_story="As an Operations Lead, I want to manage Rammas communication channels and configure voice models so that customer inquiries are routed accurately.",
    priority=Priority.HIGH,
    status=FeatureStatus.ACTIVE,
    traceability=FeatureTraceability(
        requirement_ids=["REQ-RAMMAS-CH-01", "REQ-RAMMAS-VOICE-02", "REQ-RAMMAS-RBAC-03"],
        user_story_ids=["US-RAMMAS-201", "US-RAMMAS-202"],
        source_documents=["Rammas_Operations_BRD_v2.pdf", "spec-channel-api.json"],
        target_url="https://demo.rammas.ai/dashboard",
        epic_id="EPIC-RAMMAS-OPS",
    ),
    test_case_ids=["TC-101", "TC-102", "TC-104"],
    tags=["rammas", "channels", "voice", "e2e"],
)

# Canonical Sample TestCase based on QAgentix Rammas TC-101
SAMPLE_TESTCASE_RAMMAS = TestCase(
    id="TC-101",
    title="Verify authenticated user can access channel overview and select source 'Rammas'",
    description="Ensures the root operations portal loads and source selector defaults to Rammas with active badge display.",
    priority=Priority.HIGH,
    category=TestCaseCategory.SMOKE,
    status=TestCaseStatus.APPROVED,
    preconditions=[
        "User is authenticated with valid Operations Agent credentials",
        "Target environment demo.rammas.ai is reachable",
    ],
    steps=[
        TestStep(
            step_number=1,
            action="Navigate to operations portal at /dashboard",
            expected_result="Dashboard overview renders with status 200 OK",
        ),
        TestStep(
            step_number=2,
            action="Locate source selection dropdown element [data-testid=\"source-select\"]",
            expected_result="Source selection dropdown is visible and interactable",
        ),
        TestStep(
            step_number=3,
            action="Choose 'Rammas' from options list",
            expected_result="Option 'Rammas' is selected",
        ),
        TestStep(
            step_number=4,
            action="Assert active badge text equals 'Rammas'",
            expected_result="Active badge text equals 'Rammas'",
        ),
    ],
    expected_result="System displays Rammas channels and sets global context with status 200 OK.",
    traceability=TraceabilityInfo(
        feature_id="FEAT-RAMMAS-01",
        requirement_ids=["REQ-RAMMAS-CH-01"],
        user_story_ids=["US-RAMMAS-201"],
        source_documents=["Rammas_Operations_BRD_v2.pdf"],
        target_url="https://demo.rammas.ai/dashboard",
        script_path="Scripts/rammas_channel_overview.spec.ts",
        test_method="test_select_source_rammas",
        automation_status=AutomationStatus.AUTOMATED,
        tags=["smoke", "ui", "channel-select"],
    ),
)

# Secondary testcase from QAgentix Rammas suite (TC-102)
SAMPLE_TESTCASE_RAMMAS_102 = TestCase(
    id="TC-102",
    title="Voice filter persists across pagination state and itemized summary count",
    description="Validates that applying voice filters maintains selected state when advancing through paginated tables.",
    priority=Priority.HIGH,
    category=TestCaseCategory.E2E,
    status=TestCaseStatus.APPROVED,
    preconditions=["Navigated to /channels page"],
    steps=[
        TestStep(step_number=1, action="Filter channel table by voice type 'Outbound Voice'"),
        TestStep(step_number=2, action="Advance to page 2 using table pagination button"),
        TestStep(step_number=3, action="Verify voice filter checkbox remains selected"),
        TestStep(step_number=4, action="Assert summary counter matches count of visible filtered rows"),
    ],
    expected_result="Pagination maintains active filters without resetting user query parameters.",
    traceability=TraceabilityInfo(
        feature_id="FEAT-RAMMAS-01",
        requirement_ids=["REQ-RAMMAS-VOICE-02"],
        user_story_ids=["US-RAMMAS-202"],
        source_documents=["Rammas_Operations_BRD_v2.pdf"],
        target_url="https://demo.rammas.ai/dashboard/channels",
        script_path="Scripts/rammas_voice_filter.spec.ts",
        test_method="test_voice_filter_pagination",
        automation_status=AutomationStatus.AUTOMATED,
        tags=["e2e", "pagination", "voice-filter"],
    ),
)

# Sample Traceability Matrix combining the Feature and Test Cases
SAMPLE_TRACEABILITY_MATRIX = TraceabilityMatrix(
    feature=SAMPLE_FEATURE_RAMMAS,
    test_cases=[SAMPLE_TESTCASE_RAMMAS, SAMPLE_TESTCASE_RAMMAS_102],
)
