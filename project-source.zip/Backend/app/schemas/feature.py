"""Feature schemas and traceability models for QAgentix test design."""
from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class Priority(str, Enum):
    """Priority level for Features and Test Cases."""
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

    @classmethod
    def _missing_(cls, value: object) -> Priority | None:
        if isinstance(value, str):
            val_lower = value.strip().lower()
            for member in cls:
                if member.value.lower() == val_lower or member.name.lower() == val_lower:
                    return member
        return None


class FeatureStatus(str, Enum):
    """Lifecycle status for a Feature."""
    DRAFT = "Draft"
    IN_REVIEW = "In Review"
    APPROVED = "Approved"
    ACTIVE = "Active"
    DEPRECATED = "Deprecated"

    @classmethod
    def _missing_(cls, value: object) -> FeatureStatus | None:
        if isinstance(value, str):
            val_norm = value.strip().lower().replace("_", " ").replace("-", " ")
            for member in cls:
                if member.value.lower() == val_norm or member.name.lower() == val_norm:
                    return member
        return None


class FeatureTraceability(BaseModel):
    """Traceability references originating from business/product requirements."""
    requirement_ids: list[str] = Field(
        default_factory=list,
        alias="requirementIds",
        description="BRD / PRD requirement IDs (e.g. REQ-AUTH-01)",
    )
    user_story_ids: list[str] = Field(
        default_factory=list,
        alias="userStoryIds",
        description="Agile / Jira story IDs (e.g. US-101)",
    )
    source_documents: list[str] = Field(
        default_factory=list,
        alias="sourceDocuments",
        description="Source document filenames or spec references (e.g. Rammas_BRD.pdf)",
    )
    target_url: str | None = Field(
        default=None,
        alias="targetUrl",
        description="Target web application URL or root path",
    )
    epic_id: str | None = Field(
        default=None,
        alias="epicId",
        description="Optional parent Epic ID",
    )

    model_config = {"populate_by_name": True}


class Feature(BaseModel):
    """Schema representing a functional Feature in QAgentix."""
    id: str = Field(
        ...,
        pattern=r"^[A-Za-z0-9_-]+$",
        description="Unique Feature ID (e.g. FEAT-101, FEAT_AUTH_01)",
    )
    title: str = Field(
        ...,
        min_length=3,
        max_length=200,
        description="Clear, concise feature title",
    )
    description: str = Field(
        default="",
        description="Detailed description or scope of the feature",
    )
    priority: Priority = Field(
        default=Priority.MEDIUM,
        description="Feature priority (Critical, High, Medium, Low)",
    )
    status: FeatureStatus = Field(
        default=FeatureStatus.DRAFT,
        description="Feature review/lifecycle status",
    )
    user_story: str | None = Field(
        default=None,
        alias="userStory",
        description="User story narrative (e.g. As a... I want... So that...)",
    )
    traceability: FeatureTraceability = Field(
        default_factory=FeatureTraceability,
        description="Traceability links to requirements, documents, and epics",
    )
    test_case_ids: list[str] = Field(
        default_factory=list,
        alias="testCaseIds",
        description="IDs of test cases implementing/validating this feature",
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Categorization tags (e.g. ['auth', 'rbac', 'ui'])",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Custom extensible metadata",
    )

    model_config = {"populate_by_name": True}

    @field_validator("id")
    @classmethod
    def validate_id_format(cls, v: str) -> str:
        cleaned = v.strip()
        if not cleaned:
            raise ValueError("Feature ID cannot be empty.")
        return cleaned

    def to_gherkin(self) -> str:
        """Render this feature into standard Gherkin syntax for BDD."""
        tags_line = f"@{self.priority.value} " + " ".join(f"@{t}" for t in self.tags)
        lines = [tags_line.strip(), f"Feature: {self.title} ({self.id})", ""]
        if self.description:
            lines.append(f"  {self.description}")
        if self.user_story:
            lines.append(f"  {self.user_story}")
        lines.append("")
        return "\n".join(lines)

    def to_markdown(self) -> str:
        """Render feature specification in Markdown format."""
        lines = [
            f"# Feature {self.id}: {self.title}",
            "",
            f"- **Priority**: {self.priority.value}",
            f"- **Status**: {self.status.value}",
        ]
        if self.traceability.requirement_ids:
            lines.append(f"- **Requirements**: {', '.join(self.traceability.requirement_ids)}")
        if self.traceability.source_documents:
            lines.append(f"- **Source Documents**: {', '.join(self.traceability.source_documents)}")
        if self.traceability.target_url:
            lines.append(f"- **Target URL**: {self.traceability.target_url}")
        if self.tags:
            lines.append(f"- **Tags**: {', '.join(self.tags)}")
        lines.append("")
        if self.description:
            lines.extend(["## Description", self.description, ""])
        if self.user_story:
            lines.extend(["## User Story", f"> {self.user_story}", ""])
        if self.test_case_ids:
            lines.extend(["## Linked Test Cases", *(f"- {tc_id}" for tc_id in self.test_case_ids), ""])
        return "\n".join(lines)
