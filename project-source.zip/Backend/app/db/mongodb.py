"""MongoDB connection lifecycle using Motor + Beanie."""
import logging

import certifi
from beanie import init_beanie
from motor.motor_asyncio import AsyncIOMotorClient

from app.core.config import settings
from app.models.audit_log import AuditLog
from app.models.dashboard_metric import DashboardMetric
from app.models.project_membership import ProjectMembership
from app.models.run import Run
from app.models.run_event import RunEvent
from app.models.subproject import SubProject
from app.models.subscription import Subscription
from app.models.test_result import TestResult
from app.models.user import User

logger = logging.getLogger("uvicorn.error")

_client: AsyncIOMotorClient | None = None

# Register every Beanie document model here.
DOCUMENT_MODELS = [
    User,
    ProjectMembership,
    AuditLog,
    Subscription,
    SubProject,
    Run,
    TestResult,
    RunEvent,
    DashboardMetric,
]


def _is_atlas(uri: str) -> bool:
    return uri.startswith("mongodb+srv://") or "mongodb.net" in uri


async def connect_to_mongo() -> None:
    """Open the Motor client and init Beanie.

    The server starts even if MongoDB is momentarily unreachable; requests
    reconnect automatically once the database becomes reachable.
    """
    global _client
    # Do not log the full URI (it may contain credentials).
    logger.info("Connecting to MongoDB (db=%s)", settings.mongodb_db_name)

    kwargs: dict = {"serverSelectionTimeoutMS": 15000}
    if _is_atlas(settings.mongodb_uri):
        kwargs["tls"] = True
        kwargs["tlsCAFile"] = certifi.where()

    _client = AsyncIOMotorClient(settings.mongodb_uri, **kwargs)
    database = _client[settings.mongodb_db_name]

    try:
        await init_beanie(database=database, document_models=DOCUMENT_MODELS)
        logger.info("MongoDB connected and indexes ensured (db=%s)", settings.mongodb_db_name)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "MongoDB not reachable at startup (%s). The server will start anyway; "
            "requests needing the DB will fail until it is reachable.",
            type(exc).__name__,
        )


async def close_mongo_connection() -> None:
    global _client
    if _client is not None:
        _client.close()
        _client = None
        logger.info("MongoDB connection closed")


def get_client() -> AsyncIOMotorClient | None:
    return _client
