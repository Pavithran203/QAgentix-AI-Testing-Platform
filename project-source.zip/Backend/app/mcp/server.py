"""Standard JSON-RPC 2.0 stdio MCP Server for QAgenticx.

Exposes QAgentix test generation, locator inspection, and Playwright execution
capabilities to Kiro (or any MCP host).
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

# Allow `python app/mcp/server.py` to import the backend's `app` package.
_BACKEND_DIR = Path(__file__).resolve().parents[2]
if str(_BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(_BACKEND_DIR))

SERVER_INFO = {
    "name": "qagentix-mcp",
    "version": "1.0.0",
}

AVAILABLE_TOOLS = [
    {
        "name": "qagentix_generate_playwright",
        "description": "Generate an automated Playwright TypeScript test suite, Page Object Model, and test cases matrix for a user story or specification.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "User requirement or scenario to generate tests for (e.g., 'User authentication and checkout flow').",
                },
                "project_name": {
                    "type": "string",
                    "description": "Target project name (defaults to 'Rammas').",
                    "default": "Rammas",
                },
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "qagentix_save_scenario_to_disk",
        "description": "Save or update a test scenario JSON & Markdown file directly into the user's local directory.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "folder_path": {
                    "type": "string",
                    "description": "Absolute directory path on the local computer to save into.",
                },
                "scenario_title": {
                    "type": "string",
                    "description": "Title of the scenario.",
                },
                "content": {
                    "type": "string",
                    "description": "Markdown or JSON content of the test scenario.",
                },
            },
            "required": ["folder_path", "scenario_title", "content"],
        },
    },
    {
        "name": "qagentix_run_playwright_tests",
        "description": "Execute Playwright automated tests on the local computer and return execution report.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "test_dir": {
                    "type": "string",
                    "description": "Working directory containing the playwright.config.ts.",
                },
                "spec_file": {
                    "type": "string",
                    "description": "Optional specific spec file path to run (e.g. 'tests/auth.spec.ts').",
                },
            },
            "required": ["test_dir"],
        },
    },
]


def handle_initialize(req_id: Any) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "result": {
            "protocolVersion": "2024-11-05",
            "serverInfo": SERVER_INFO,
            "capabilities": {
                "tools": {},
            },
        },
    }


def handle_tools_list(req_id: Any) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "result": {
            "tools": AVAILABLE_TOOLS,
        },
    }


def handle_tools_call(req_id: Any, params: dict[str, Any]) -> dict[str, Any]:
    tool_name = params.get("name")
    args = params.get("arguments", {})

    if tool_name == "qagentix_generate_playwright":
        prompt = args.get("prompt", "")
        project = args.get("project_name", "Rammas")
        try:
            # Same synthesizer that powers POST /api/agent/generate in the web app.
            from app.agent.test_synthesizer import synthesize_test_bundle
            from app.schemas.agent_generator import AgentGenerateRequest

            bundle = synthesize_test_bundle(AgentGenerateRequest(prompt=prompt, projectName=project))
            lines = [
                f"# {bundle.title}",
                f"Project: {project} | Test cases: {len(bundle.testCases)} | Files: {len(bundle.files)}",
                "",
                "## Test cases",
            ]
            for tc in bundle.testCases:
                lines.append(f"- {tc.id} [{tc.category}/{tc.priority}] {tc.title}")
            lines.append("")
            lines.append("## Files (write each to the given path)")
            for f in bundle.files:
                lines.append(f"\n### {f.path}\n```{f.language}\n{f.content}\n```")
            result = "\n".join(lines)
        except Exception as exc:  # noqa: BLE001
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Generation failed: {exc}"}],
                    "isError": True,
                },
            }
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [{"type": "text", "text": result}],
            },
        }

    if tool_name == "qagentix_save_scenario_to_disk":
        folder = args.get("folder_path")
        title = args.get("scenario_title", "scenario")
        content = args.get("content", "")

        os.makedirs(folder, exist_ok=True)
        filename = f"scenario_{title.replace(' ', '_').lower()[:30]}.md"
        target_file = os.path.join(folder, filename)
        with open(target_file, "w", encoding="utf-8") as f:
            f.write(content)

        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [{"type": "text", "text": f"Successfully written to {target_file}"}],
            },
        }

    if tool_name == "qagentix_run_playwright_tests":
        test_dir = args.get("test_dir")
        spec = args.get("spec_file")
        cmd = ["npx", "playwright", "test"]
        if spec:
            cmd.append(spec)

        try:
            proc = subprocess.run(cmd, cwd=test_dir, capture_output=True, text=True, timeout=60, check=False)
            output = proc.stdout or proc.stderr or "Completed with exit code 0"
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": output}],
                },
            }
        except Exception as exc:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Execution failed: {exc}"}],
                    "isError": True,
                },
            }

    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {
            "code": -32601,
            "message": f"Method or tool '{tool_name}' not found",
        },
    }


def main():
    """Main loop reading JSON-RPC messages from stdin and writing to stdout."""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue

        method = req.get("method")
        req_id = req.get("id")

        if method == "initialize":
            resp = handle_initialize(req_id)
        elif method == "tools/list":
            resp = handle_tools_list(req_id)
        elif method == "tools/call":
            resp = handle_tools_call(req_id, req.get("params", {}))
        elif method == "notifications/initialized":
            continue
        else:
            resp = {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {
                    "code": -32601,
                    "message": f"Unsupported method: {method}",
                },
            }

        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
