"""QAgenticx Model Context Protocol (MCP) Server.

Enables Kiro and other MCP-compliant agents to discover and invoke
QAgentix testing tools directly from within the Kiro IDE.
"""
