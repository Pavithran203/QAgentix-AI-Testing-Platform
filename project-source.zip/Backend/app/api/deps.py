"""Shared API dependencies (current authenticated user + RBAC)."""
from collections.abc import Callable, Coroutine
from typing import Any

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError

from app.core.roles import Role
from app.core.security import ACCESS_TOKEN_TYPE, decode_token
from app.models.user import User

bearer_scheme = HTTPBearer(auto_error=True)

_credentials_exc = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Could not validate credentials",
    headers={"WWW-Authenticate": "Bearer"},
)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> User:
    token = credentials.credentials
    try:
        payload = decode_token(token, expected_type=ACCESS_TOKEN_TYPE)
    except JWTError:
        raise _credentials_exc

    user_id = payload.get("sub")
    user = await User.get(user_id)
    if user is None or not user.is_active:
        raise _credentials_exc
    return user


optional_bearer_scheme = HTTPBearer(auto_error=False)


async def get_optional_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(optional_bearer_scheme),
) -> User | None:
    if not credentials:
        return None
    try:
        payload = decode_token(credentials.credentials, expected_type=ACCESS_TOKEN_TYPE)
        user_id = payload.get("sub")
        if not user_id:
            return None
        return await User.get(user_id)
    except Exception:
        return None


def require_role(*allowed: Role) -> Callable[..., Coroutine[Any, Any, User]]:
    """Dependency factory: allow only users whose role is in `allowed`."""

    async def _checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in allowed:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to perform this action.",
            )
        return current_user

    return _checker


# Convenience dependencies for RBAC routes.
require_admin = require_role(Role.ADMIN)
require_test_lead = require_role(Role.ADMIN, Role.TEST_LEAD)
require_tester = require_role(Role.ADMIN, Role.TEST_LEAD, Role.TESTER)
require_viewer = require_role(Role.ADMIN, Role.TEST_LEAD, Role.TESTER, Role.VIEWER)
