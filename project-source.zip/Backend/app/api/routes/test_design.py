"""API routes for Feature and TestCase schema validation and traceability verification."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, status

from app.schemas.feature import Feature
from app.schemas.samples import (
    SAMPLE_FEATURE_RAMMAS,
    SAMPLE_TESTCASE_RAMMAS,
    SAMPLE_TESTCASE_RAMMAS_102,
    SAMPLE_TRACEABILITY_MATRIX,
)
from app.schemas.testcase import TestCase, TraceabilityMatrix

router = APIRouter(prefix="/test-design", tags=["test-design"])


@router.get("/samples")
async def get_samples() -> dict[str, Any]:
    """Return pre-validated sample Feature, Testcases, and Traceability Matrix."""
    matrix = SAMPLE_TRACEABILITY_MATRIX.verify_traceability()
    return {
        "feature": SAMPLE_FEATURE_RAMMAS.model_dump(by_alias=True),
        "testCases": [
            SAMPLE_TESTCASE_RAMMAS.model_dump(by_alias=True),
            SAMPLE_TESTCASE_RAMMAS_102.model_dump(by_alias=True),
        ],
        "traceabilityReport": matrix,
    }


@router.post("/testcase/validate")
async def validate_testcase(payload: dict[str, Any]) -> dict[str, Any]:
    """Validate a Test Case against the schema and return normalized representations."""
    try:
        tc = TestCase.model_validate(payload)
    except Exception as exc:
        raise HTTPException(
            status_code=422,
            detail=f"Testcase validation failed: {exc}",
        )

    return {
        "status": "VALID",
        "testCase": tc.model_dump(by_alias=True),
        "gherkin": tc.to_gherkin(),
        "markdown": tc.to_markdown(),
        "csvRow": tc.to_csv_row(),
    }


@router.post("/feature/validate")
async def validate_feature(payload: dict[str, Any]) -> dict[str, Any]:
    """Validate a Feature against the schema and return rendered Gherkin and Markdown."""
    try:
        feat = Feature.model_validate(payload)
    except Exception as exc:
        raise HTTPException(
            status_code=422,
            detail=f"Feature validation failed: {exc}",
        )

    return {
        "status": "VALID",
        "feature": feat.model_dump(by_alias=True),
        "gherkin": feat.to_gherkin(),
        "markdown": feat.to_markdown(),
    }


@router.post("/traceability/verify")
async def verify_traceability(payload: dict[str, Any]) -> dict[str, Any]:
    """Validate a Feature and its Test Cases together and verify bidirectional traceability."""
    try:
        matrix = TraceabilityMatrix.model_validate(payload)
    except Exception as exc:
        raise HTTPException(
            status_code=422,
            detail=f"Traceability matrix validation failed: {exc}",
        )

    report = matrix.verify_traceability()
    return {
        "status": "VALID",
        "traceabilityReport": report,
    }
