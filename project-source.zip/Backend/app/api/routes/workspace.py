"""Workspace routes — browse the local filesystem and store artifacts.

Flow:
  1. UI browses the local filesystem (GET drives / list a folder).
  2. User selects any folder.
  3. Backend creates the predefined structure INSIDE that folder.
  4. Generated artifacts are routed into the matching subfolder.

Backend-only: the server owns all filesystem access.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from app.api.deps import get_current_user
from app.core import workspace as ws
from app.core.workspace import SUBFOLDERS, WorkspaceError
from app.models.user import User
from app.schemas.workspace import (
    BrowseRequest,
    CreateStructureRequest,
    MakeDirRequest,
    ReadFileRequest,
    WriteFileRequest,
    WriteManyRequest,
)

router = APIRouter(prefix="/workspace", tags=["workspace"])


@router.get("/structure")
async def get_structure(_user: User = Depends(get_current_user)) -> dict:
    """Return the predefined folder names the backend will create."""
    return {"subfolders": SUBFOLDERS}


@router.post("/browse")
async def browse(payload: BrowseRequest, _user: User = Depends(get_current_user)) -> dict:
    """List subfolders of a path (empty path => drive roots) for the picker."""
    try:
        return ws.browse(payload.path)
    except WorkspaceError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.post("/mkdir", status_code=status.HTTP_201_CREATED)
async def make_dir(payload: MakeDirRequest, _user: User = Depends(get_current_user)) -> dict:
    """Create a new folder inside an existing directory (from the picker)."""
    try:
        return ws.make_dir(payload.parent, payload.name)
    except WorkspaceError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.post("/read")
async def read_file(payload: ReadFileRequest, _user: User = Depends(get_current_user)) -> dict:
    """Read a file's content from a project subfolder (for editing)."""
    try:
        content = ws.read_file(payload.base, payload.folder, payload.filename)
    except WorkspaceError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    return {"folder": payload.folder, "name": payload.filename, "content": content}


@router.post("/structure", status_code=status.HTTP_201_CREATED)
async def create_structure(
    payload: CreateStructureRequest,
    _user: User = Depends(get_current_user),
) -> dict:
    """Create the predefined structure inside the chosen folder."""
    try:
        return ws.create_structure(payload.base)
    except WorkspaceError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.post("/tree")
async def get_tree(payload: CreateStructureRequest, _user: User = Depends(get_current_user)) -> dict:
    """Return the predefined subfolders + files inside the chosen folder."""
    try:
        return ws.get_tree(payload.base)
    except WorkspaceError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.post("/files", status_code=status.HTTP_201_CREATED)
async def write_file(payload: WriteFileRequest, _user: User = Depends(get_current_user)) -> dict:
    try:
        return ws.write_file(payload.base, payload.kind, payload.filename, payload.content)
    except WorkspaceError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.post("/files/batch", status_code=status.HTTP_201_CREATED)
async def write_many(payload: WriteManyRequest, _user: User = Depends(get_current_user)) -> dict:
    written = []
    try:
        for f in payload.files:
            written.append(ws.write_file(payload.base, f.kind, f.filename, f.content))
    except WorkspaceError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    return {"count": len(written), "files": written}
