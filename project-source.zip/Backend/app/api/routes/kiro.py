"""API routes for Kiro Gateway and Model Context Protocol (MCP) integration."""
from __future__ import annotations

import asyncio
import os
import sys
import time
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.deps import get_current_user
from app.core.kiro_gateway import (
    MCP_SERVER_SCRIPT,
    check_kiro_gateway_health,
    execute_kiro_chat,
    get_kiro_status,
    get_mcp_registration,
    open_in_kiro,
    probe_mcp_server,
    register_mcp_with_kiro,
    start_kiro_gateway,
)
from app.models.user import User

router = APIRouter(prefix="/kiro", tags=["kiro-integration"])


@router.post("/start-gateway")
async def start_gateway() -> dict[str, Any]:
    """Start local Kiro Gateway daemon on port 39275."""
    success = start_kiro_gateway()
    return {"status": "started" if success else "failed", "gateway_url": "http://127.0.0.1:39275"}


class KiroChatRequest(BaseModel):
    prompt: str
    context_files: list[str] | None = None
    mode: str = "agent"
    working_dir: str | None = None


class KiroOpenRequest(BaseModel):
    path: str


class McpRegisterRequest(BaseModel):
    server_name: str = "qagentix"


_probe_cache: dict[str, Any] = {"key": None, "at": 0.0, "result": None}
_PROBE_TTL_SECONDS = 30


async def _cached_probe(command: str, args: list[str]) -> dict[str, Any]:
    key = f"{command}|{'|'.join(args)}"
    now = time.monotonic()
    if _probe_cache["key"] == key and now - _probe_cache["at"] < _PROBE_TTL_SECONDS:
        return _probe_cache["result"]
    result = await asyncio.to_thread(probe_mcp_server, command, args)
    _probe_cache.update(key=key, at=now, result=result)
    return result


@router.get("/status")
async def kiro_status() -> dict[str, Any]:
    """Report the real Kiro connection state.

    connection_state:
      not_installed          - Kiro executable not found
      not_registered         - Kiro is installed but its mcp.json doesn't list our server
      registered_unreachable - listed in mcp.json, but the server fails the MCP handshake
      connected              - listed in mcp.json AND the server answers initialize + tools/list
    """
    status = get_kiro_status()
    status["gateway_active"] = await check_kiro_gateway_health(status["gateway_url"])

    status["mcp_server_available"] = MCP_SERVER_SCRIPT.exists()
    status["mcp_server_path"] = str(MCP_SERVER_SCRIPT)

    reg = get_mcp_registration()
    status["mcp_registered"] = reg["registered"]
    status["mcp_config_path"] = reg["config_path"]
    status["mcp_handshake_ok"] = False
    status["mcp_tool_count"] = 0
    status["mcp_error"] = None

    if not status["installed"]:
        state = "not_installed"
    elif not reg["registered"]:
        state = "not_registered"
    else:
        probe = await _cached_probe(reg["command"] or "", reg["args"])
        status["mcp_handshake_ok"] = probe["ok"]
        status["mcp_tool_count"] = probe["tool_count"]
        status["mcp_error"] = probe["error"]
        state = "connected" if probe["ok"] else "registered_unreachable"

    status["connection_state"] = state
    return status


@router.post("/register-mcp")
async def register_mcp(
    req: McpRegisterRequest,
    _user: User = Depends(get_current_user),
) -> dict[str, Any]:
    """Register QAgentix MCP server with the local Kiro IDE via `kiro --add-mcp`."""
    if not MCP_SERVER_SCRIPT.exists():
        raise HTTPException(status_code=404, detail="QAgentix MCP server script not found.")

    try:
        result = register_mcp_with_kiro(
            server_name=req.server_name,
            command=sys.executable,
            args=[str(MCP_SERVER_SCRIPT)],
            env={"PYTHONUNBUFFERED": "1"},
        )
        _probe_cache.update(key=None, at=0.0, result=None)  # force a fresh handshake
        return result
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to register MCP with Kiro: {exc}") from exc


@router.post("/chat")
async def kiro_chat(
    req: KiroChatRequest,
    _user: User = Depends(get_current_user),
) -> dict[str, Any]:
    """Forward a prompt to the local Kiro CLI / Agent session."""
    try:
        response_text = execute_kiro_chat(
            prompt=req.prompt,
            context_files=req.context_files,
            mode=req.mode,
            working_dir=req.working_dir,
        )
        return {
            "status": "success",
            "prompt": req.prompt,
            "response": response_text,
            "source": "kiro_local",
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Kiro chat execution failed: {exc}") from exc


@router.post("/open")
async def kiro_open(
    req: KiroOpenRequest,
    _user: User = Depends(get_current_user),
) -> dict[str, Any]:
    """Launch Kiro to open a local project folder or test spec file."""
    if not os.path.exists(req.path):
        raise HTTPException(status_code=404, detail=f"Target path does not exist: {req.path}")

    success = open_in_kiro(req.path)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to launch Kiro.")

    return {"status": "opened", "path": req.path}
