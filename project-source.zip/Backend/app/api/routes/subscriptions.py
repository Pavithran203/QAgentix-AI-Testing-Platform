"""Subscription routes (DB-backed, global/shared, auth-protected).

A subscription's `projectsCount` is computed on read from the subprojects
collection. Deleting a subscription cascade-deletes its subprojects.
"""
from __future__ import annotations

import random

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException, status
from pymongo.errors import DuplicateKeyError

from app.api.deps import get_current_user
from app.models.subproject import SubProject
from app.models.subscription import SUBSCRIPTION_GRADIENTS, Subscription
from app.models.user import User
from app.schemas.subscription import (
    SubscriptionCreate,
    SubscriptionOut,
    SubscriptionSummary,
)
from app.schemas.subproject import SubProjectOut

router = APIRouter(prefix="/subscriptions", tags=["subscriptions"])


def _to_sub_out(sub: Subscription, projects_count: int) -> SubscriptionOut:
    return SubscriptionOut(
        id=str(sub.id),
        code=sub.code,
        name=sub.name,
        category=sub.category,
        status=sub.status,
        plan=sub.plan,
        description=sub.description,
        projects_count=projects_count,
        active_agents=sub.active_agents,
        total_runs=sub.total_runs,
        created_at=sub.created_at.isoformat(),
        accent_gradient=sub.accent_gradient,
    )


def _to_proj_out(proj: SubProject) -> SubProjectOut:
    return SubProjectOut(
        id=str(proj.id),
        code=proj.code,
        subscription_id=proj.subscription_id,
        name=proj.name,
        type=proj.type,
        endpoints_count=proj.endpoints_count,
        endpoints=proj.endpoints,
        description=proj.description,
        stories_count=proj.stories_count,
        test_cases_count=proj.test_cases_count,
        scripts_count=proj.scripts_count,
        created_at=proj.created_at.isoformat(),
        accent_gradient=proj.accent_gradient,
    )


async def _projects_count(sub_id: str) -> int:
    return await SubProject.find(SubProject.subscription_id == sub_id).count()


async def _get_sub_or_404(sub_id: str) -> Subscription:
    try:
        oid = PydanticObjectId(sub_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Subscription not found")
    sub = await Subscription.get(oid)
    if sub is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Subscription not found")
    return sub


@router.get("", response_model=list[SubscriptionOut])
async def list_subscriptions(_user: User = Depends(get_current_user)) -> list[SubscriptionOut]:
    subs = await Subscription.find_all().sort("+created_at").to_list()
    return [_to_sub_out(s, await _projects_count(str(s.id))) for s in subs]


@router.post("", response_model=SubscriptionOut, status_code=status.HTTP_201_CREATED)
async def create_subscription(
    payload: SubscriptionCreate,
    _user: User = Depends(get_current_user),
) -> SubscriptionOut:
    # Generate a unique SUB-#### code. The DB unique index is the source of
    # truth; on a duplicate we regenerate and retry so creation never fails.
    for _ in range(10):
        code = f"SUB-{random.randint(1000, 9999)}"
        sub = Subscription(
            code=code,
            name=payload.name,
            category=payload.category,
            status=payload.status,
            plan=payload.plan,
            description=payload.description,
            active_agents=0,
            total_runs=0,
            accent_gradient=random.choice(SUBSCRIPTION_GRADIENTS),
        )
        try:
            await sub.insert()
        except DuplicateKeyError:
            continue
        return _to_sub_out(sub, 0)
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Could not generate a unique subscription code",
    )


@router.get("/summary", response_model=SubscriptionSummary)
async def get_summary(_user: User = Depends(get_current_user)) -> SubscriptionSummary:
    return SubscriptionSummary(
        subscription_count=await Subscription.count(),
        subproject_count=await SubProject.count(),
    )


@router.get("/{sub_id}", response_model=SubscriptionOut)
async def get_subscription(sub_id: str, _user: User = Depends(get_current_user)) -> SubscriptionOut:
    sub = await _get_sub_or_404(sub_id)
    return _to_sub_out(sub, await _projects_count(str(sub.id)))


@router.delete("/{sub_id}")
async def delete_subscription(sub_id: str, _user: User = Depends(get_current_user)) -> dict:
    sub = await _get_sub_or_404(sub_id)
    # Cascade: remove the subscription's subprojects first.
    await SubProject.find(SubProject.subscription_id == str(sub.id)).delete()
    await sub.delete()
    return {}


@router.get("/{sub_id}/subprojects", response_model=list[SubProjectOut])
async def list_subscription_subprojects(
    sub_id: str,
    _user: User = Depends(get_current_user),
) -> list[SubProjectOut]:
    sub = await _get_sub_or_404(sub_id)
    projects = (
        await SubProject.find(SubProject.subscription_id == str(sub.id))
        .sort("+created_at")
        .to_list()
    )
    return [_to_proj_out(p) for p in projects]
