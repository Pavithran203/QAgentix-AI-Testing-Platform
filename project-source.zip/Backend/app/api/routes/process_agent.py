"""Process Agent routes (Phase 1)."""
from __future__ import annotations

import io
import logging

from fastapi import APIRouter, Depends, File, UploadFile

from fastapi import HTTPException

from app.agent.process_agent import MAX_HEALING_ATTEMPTS, run_process_agent
from app.agent.intent import build_answer, is_question
from app.agent.prompts import render
from app.agent.test_synthesizer import synthesize_test_bundle
from app.api.deps import get_current_user, get_optional_current_user
from app.core.config import settings
from app.core.llm import DEFAULT_MODELS, LLMError, _normalize_provider, generate
from app.models.user import User
from app.schemas.agent_generator import AgentAnswerResponse, AgentGenerateRequest, GeneratedBundleResponse
from app.schemas.process_agent import ProcessRequest, ProcessResponse
from app.schemas.stage_runner import StageHealingStep, StageRunRequest, StageRunResponse

logger = logging.getLogger("uvicorn.error")

router = APIRouter(prefix="/agent", tags=["process-agent"])


@router.post("/generate", response_model=GeneratedBundleResponse | AgentAnswerResponse)
async def generate_test_suite(
    req: AgentGenerateRequest,
    _user: User | None = Depends(get_optional_current_user),
) -> GeneratedBundleResponse | AgentAnswerResponse:
    """Generate a Playwright test suite, or answer briefly when the message is only a question."""
    if is_question(req.prompt, has_files=bool(req.files)):
        return AgentAnswerResponse(message=build_answer(req.prompt))
    return synthesize_test_bundle(req)


@router.post("/process", response_model=ProcessResponse)
async def process(
    req: ProcessRequest,
    _user: User = Depends(get_current_user),
) -> ProcessResponse:
    return run_process_agent(req)


@router.post("/run-stage", response_model=StageRunResponse)
async def run_stage(
    req: StageRunRequest,
    _user: User = Depends(get_current_user),
) -> StageRunResponse:
    """Run any pipeline stage through its central system prompt and return the LLM output.

    Maps the requested stage (process, user_story, feature, testcase, test_data,
    script, execute, report) to its prompt in app.agent.prompts, calls the LLM
    with a bounded self-healing retry loop, and returns the output so the user
    can see each stage's result.
    """
    provider = _normalize_provider(req.provider or settings.llm_provider)
    model = req.model or settings.llm_model or DEFAULT_MODELS.get(provider, next(iter(DEFAULT_MODELS.values())))
    api_key = req.api_key or settings.llm_api_key or ""

    try:
        system_prompt = render(req.stage, **(req.context or {}))
    except KeyError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    healing_log: list[StageHealingStep] = []
    output = ""
    final_status = "FAILED"

    for attempt in range(1, MAX_HEALING_ATTEMPTS + 1):
        try:
            output = generate(
                provider=provider,
                api_key=api_key,
                system_prompt=system_prompt,
                user_prompt=req.input,
                model=model,
            )
            if not output or not output.strip():
                raise LLMError("Empty response from the model.")
            final_status = "SUCCESS" if attempt == 1 else "REPAIRED"
            healing_log.append(
                StageHealingStep(attempt=attempt, status="OK", detail="Generation succeeded.")
            )
            break
        except LLMError as exc:
            is_last = attempt == MAX_HEALING_ATTEMPTS
            healing_log.append(
                StageHealingStep(
                    attempt=attempt,
                    status="FAILED" if is_last else "RETRYING",
                    detail=str(exc),
                )
            )
            logger.warning("[StageRunner:%s] attempt %d failed: %s", req.stage, attempt, exc)
            if is_last:
                final_status = "FAILED"
                output = (
                    f"The '{req.stage}' stage could not generate a response after "
                    f"{MAX_HEALING_ATTEMPTS} attempts. Last error: {exc}"
                )

    return StageRunResponse(
        stage=req.stage,
        output=output,
        provider=provider,
        model=model,
        final_status=final_status,
        healing_attempts=len(healing_log),
        healing_log=healing_log,
    )


@router.post("/extract")
async def extract_document(
    file: UploadFile = File(...),
    _user: User = Depends(get_current_user),
) -> dict:
    raw = await file.read()
    name = (file.filename or "document").lower()

    if name.endswith(".pdf"):
        try:
            from pypdf import PdfReader

            reader = PdfReader(io.BytesIO(raw))
            text = "\n\n".join((page.extract_text() or "") for page in reader.pages)
        except Exception as exc:  # noqa: BLE001
            logger.warning("[ProcessAgent] PDF extract failed: %s", exc)
            text = ""
        return {"name": file.filename, "chars": len(text), "content": text}

    text = raw.decode("utf-8", errors="ignore")
    return {"name": file.filename, "chars": len(text), "content": text}
