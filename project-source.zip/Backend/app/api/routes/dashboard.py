"""Dashboard aggregation + run recording/detail routes (auth-protected).

Two routers live here (mirroring how the app keeps related routers together):
`dashboard_router` (prefix `/dashboard`) and `runs_router` (prefix `/runs`).
Both are mounted in `main.py` under `settings.api_prefix`.

Every handler requires `get_current_user`. No LLM/filesystem work on reads.
Unavailable metrics return `null`/`[]`. All timestamps are UTC ISO-8601.
"""
from __future__ import annotations

from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.api.deps import get_current_user
from app.models.user import User
from app.schemas.dashboard import (
    ExecutionPointOut,
    FailureCategoryOut,
    LocatorHealthOut,
    MetricSnapshotOut,
    PassRatePointOut,
    RecentRunsOut,
    RunCompleteIn,
    RunCreateIn,
    RunDetailOut,
    RunRowOut,
    SummaryOut,
)
from app.services import dashboard_service

dashboard_router = APIRouter(prefix="/dashboard", tags=["dashboard"])
runs_router = APIRouter(prefix="/runs", tags=["runs"])


def _parse_date(value: str | None) -> datetime | None:
    if value is None:
        return None
    return dashboard_service._parse_dt(value)


def _validate_range(start: datetime | None, end: datetime | None) -> None:
    if start is not None and end is not None and start > end:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="start_date must not be after end_date",
        )


# --- Dashboard aggregation endpoints --------------------------------------
@dashboard_router.get("/summary", response_model=SummaryOut)
async def get_summary(
    refresh: bool = Query(default=False),
    _user: User = Depends(get_current_user),
) -> SummaryOut:
    return await dashboard_service.get_summary(refresh=refresh)


@dashboard_router.get("/metrics-history", response_model=list[MetricSnapshotOut])
async def get_metrics_history(
    limit: int = Query(default=30, ge=1, le=365),
    _user: User = Depends(get_current_user),
) -> list[MetricSnapshotOut]:
    return await dashboard_service.get_metrics_history(limit)


@dashboard_router.get("/pass-rate-trend", response_model=list[PassRatePointOut])
async def get_pass_rate_trend(
    start_date: str | None = Query(default=None),
    end_date: str | None = Query(default=None),
    interval: Literal["day", "week", "month"] = Query(default="month"),
    _user: User = Depends(get_current_user),
) -> list[PassRatePointOut]:
    start, end = _parse_date(start_date), _parse_date(end_date)
    _validate_range(start, end)
    return await dashboard_service.get_pass_rate_trend(start, end, interval)


@dashboard_router.get("/execution-trend", response_model=list[ExecutionPointOut])
async def get_execution_trend(
    start_date: str | None = Query(default=None),
    end_date: str | None = Query(default=None),
    interval: Literal["day", "week", "month"] = Query(default="day"),
    _user: User = Depends(get_current_user),
) -> list[ExecutionPointOut]:
    start, end = _parse_date(start_date), _parse_date(end_date)
    _validate_range(start, end)
    return await dashboard_service.get_execution_trend(start, end, interval)


@dashboard_router.get("/failure-categories", response_model=list[FailureCategoryOut])
async def get_failure_categories(
    start_date: str | None = Query(default=None),
    end_date: str | None = Query(default=None),
    _user: User = Depends(get_current_user),
) -> list[FailureCategoryOut]:
    start, end = _parse_date(start_date), _parse_date(end_date)
    _validate_range(start, end)
    return await dashboard_service.get_failure_categories(start, end)


@dashboard_router.get("/locator-health", response_model=list[LocatorHealthOut])
async def get_locator_health(_user: User = Depends(get_current_user)) -> list[LocatorHealthOut]:
    # UNAVAILABLE: returns [] until a locator analysis source is implemented.
    return await dashboard_service.get_locator_health()


@dashboard_router.get("/recent-runs", response_model=RecentRunsOut)
async def get_recent_runs(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=10, ge=1, le=100),
    project_id: str | None = Query(default=None),
    status: str | None = Query(default=None),  # noqa: A002 - matches API contract
    start_date: str | None = Query(default=None),
    end_date: str | None = Query(default=None),
    _user: User = Depends(get_current_user),
) -> RecentRunsOut:
    start, end = _parse_date(start_date), _parse_date(end_date)
    _validate_range(start, end)
    return await dashboard_service.get_recent_runs(
        page=page,
        page_size=page_size,
        project_id=project_id,
        status=status,
        start=start,
        end=end,
    )


# --- Run detail + recording endpoints -------------------------------------
@runs_router.get("/{run_id}", response_model=RunDetailOut)
async def get_run(run_id: str, _user: User = Depends(get_current_user)) -> RunDetailOut:
    detail = await dashboard_service.get_run_detail(run_id)
    if detail is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found")
    return detail


@runs_router.post("", response_model=RunRowOut, status_code=status.HTTP_201_CREATED)
async def create_run(
    payload: RunCreateIn,
    _user: User = Depends(get_current_user),
) -> RunRowOut:
    run = await dashboard_service.create_run(payload)
    return dashboard_service._to_run_row(run)


@runs_router.post("/{run_id}/complete", response_model=RunRowOut)
async def complete_run(
    run_id: str,
    payload: RunCompleteIn,
    _user: User = Depends(get_current_user),
) -> RunRowOut:
    run = await dashboard_service.complete_run(run_id, payload)
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found")
    return dashboard_service._to_run_row(run)
