"""Authentication routes: register, login, refresh, me, logout.

Only user records are stored in MongoDB. No generated scripts/artifacts
are ever persisted to the database.
"""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from jose import JWTError
from pymongo.errors import DuplicateKeyError

from app.api.deps import get_current_user
from app.core.roles import Role
from app.core.security import (
    REFRESH_TOKEN_TYPE,
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.models.user import User
from app.schemas.auth import (
    LoginRequest,
    RefreshRequest,
    RegisterRequest,
    TokenResponse,
    UserOut,
)

router = APIRouter(prefix="/auth", tags=["auth"])


def _user_out(user: User) -> UserOut:
    role_value = user.role.value if hasattr(user.role, "value") else str(user.role)
    return UserOut(
        id=str(user.id),
        name=user.full_name,
        email=user.email,
        username=user.username,
        role=role_value,
        avatar=user.avatar,
    )


def _token_response(user: User) -> TokenResponse:
    subject = str(user.id)
    role_value = user.role.value if hasattr(user.role, "value") else str(user.role)
    return TokenResponse(
        access_token=create_access_token(subject, role=role_value),
        refresh_token=create_refresh_token(subject),
        user=_user_out(user),
    )


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest) -> TokenResponse:
    existing = await User.find_one(
        {"$or": [{"username": payload.username}, {"email": payload.email}]}
    )
    if existing is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this username or email already exists",
        )

    # Bootstrap: the very first registered user becomes Admin; everyone else
    # starts as Viewer. Admins can later promote users via the admin API.
    is_first_user = await User.find_one({}) is None
    role = Role.ADMIN if is_first_user else Role.VIEWER

    user = User(
        full_name=payload.full_name,
        username=payload.username,
        email=payload.email,
        hashed_password=hash_password(payload.password),
        role=role,
    )
    try:
        await user.insert()
    except DuplicateKeyError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this username or email already exists",
        )

    return _token_response(user)


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest) -> TokenResponse:
    query_val = payload.username.strip()
    user = await User.find_one(
        {"$or": [
            {"username": query_val},
            {"email": query_val.lower()},
            {"username": {"$regex": f"^{query_val}$", "$options": "i"}},
            {"email": {"$regex": f"^{query_val}$", "$options": "i"}},
        ]}
    )
    if user is None or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is disabled",
        )
    return _token_response(user)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(payload: RefreshRequest) -> TokenResponse:
    try:
        token_payload = decode_token(payload.refresh_token, expected_type=REFRESH_TOKEN_TYPE)
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
        )

    user = await User.get(token_payload["sub"])
    if user is None or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or disabled",
        )
    return _token_response(user)


@router.get("/me", response_model=UserOut)
async def me(current_user: User = Depends(get_current_user)) -> UserOut:
    return _user_out(current_user)


@router.post("/logout", status_code=status.HTTP_200_OK)
async def logout(current_user: User = Depends(get_current_user)) -> dict:
    # Stateless JWT: client discards tokens. Endpoint exists for symmetry and
    # future token-revocation support.
    _ = current_user
    _ = datetime.now(timezone.utc)
    return {"detail": "Logged out"}
