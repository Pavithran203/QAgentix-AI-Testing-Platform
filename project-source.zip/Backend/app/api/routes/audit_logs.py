"""Audit log query routes (RBAC).

Allows Admins and Test Leads to inspect the governance audit trail.
"""

from fastapi import APIRouter, Depends, Query
from app.api.deps import require_test_lead
from app.models.audit_log import AuditLog
from app.models.user import User
from app.schemas.audit import AuditLogItem

router = APIRouter(prefix="/audit-logs", tags=["audit-logs"])


def _to_item(log: AuditLog) -> AuditLogItem:
    return AuditLogItem(
        id=str(log.id),
        user_id=log.user_id,
        username=log.username,
        action=log.action,
        resource_type=log.resource_type,
        resource_id=log.resource_id,
        details=log.details,
        ip_address=log.ip_address,
        timestamp=log.timestamp,
    )


@router.get("", response_model=list[AuditLogItem])
async def list_audit_logs(
    action: str | None = Query(default=None, description="Filter by event action"),
    resource_type: str | None = Query(default=None, description="Filter by resource type"),
    user_id: str | None = Query(default=None, description="Filter by initiator user ID"),
    limit: int = Query(default=50, ge=1, le=200, description="Max entries to return"),
    skip: int = Query(default=0, ge=0, description="Entries to skip for pagination"),
    _manager: User = Depends(require_test_lead),
) -> list[AuditLogItem]:
    """Retrieve audit trail logs with filtering and pagination (Admin & Test Lead)."""
    filters = []
    if action:
        filters.append(AuditLog.action == action)
    if resource_type:
        filters.append(AuditLog.resource_type == resource_type)
    if user_id:
        filters.append(AuditLog.user_id == user_id)

    if filters:
        query = AuditLog.find(*filters)
    else:
        query = AuditLog.find_all()

    logs = await query.sort("-timestamp").skip(skip).limit(limit).to_list()
    return [_to_item(log) for log in logs]
