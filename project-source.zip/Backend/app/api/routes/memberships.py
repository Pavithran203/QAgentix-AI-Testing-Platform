"""Project membership management routes (RBAC).

Allows Admins and Test Leads to assign users to QA projects, manage project
roles, and remove members, recording all changes to the audit log.
"""

from datetime import datetime, timezone
from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pymongo.errors import DuplicateKeyError

from app.api.deps import get_current_user, require_test_lead
from app.core.audit import log_audit_event
from app.models.project_membership import ProjectMembership
from app.models.user import User
from app.schemas.membership import (
    AddProjectMemberRequest,
    ProjectMemberItem,
    UpdateProjectMemberRoleRequest,
)

router = APIRouter(prefix="/projects/{project_id}/members", tags=["project-memberships"])


def _to_item(m: ProjectMembership) -> ProjectMemberItem:
    role_value = m.role.value if hasattr(m.role, "value") else str(m.role)
    return ProjectMemberItem(
        id=str(m.id),
        project_id=m.project_id,
        user_id=str(m.user_id),
        username=m.username,
        role=role_value,
        created_at=m.created_at,
        updated_at=m.updated_at,
    )


@router.get("", response_model=list[ProjectMemberItem])
async def list_project_members(
    project_id: str,
    _current_user: User = Depends(get_current_user),
) -> list[ProjectMemberItem]:
    """List all members assigned to a QA project."""
    members = await ProjectMembership.find(ProjectMembership.project_id == project_id).to_list()
    return [_to_item(m) for m in members]


@router.post("", response_model=ProjectMemberItem, status_code=status.HTTP_201_CREATED)
async def add_project_member(
    project_id: str,
    payload: AddProjectMemberRequest,
    request: Request,
    manager: User = Depends(require_test_lead),
) -> ProjectMemberItem:
    """Add a user to a QA project with an assigned role (Test Lead or Admin)."""
    try:
        target_oid = PydanticObjectId(payload.user_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user_id")

    target_user = await User.get(target_oid)
    if target_user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Target user not found")

    existing = await ProjectMembership.find_one(
        ProjectMembership.project_id == project_id,
        ProjectMembership.user_id == target_oid,
    )
    if existing is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="User is already a member of this project",
        )

    membership = ProjectMembership(
        project_id=project_id,
        user_id=target_oid,
        username=target_user.username,
        role=payload.role,
    )

    try:
        await membership.insert()
    except DuplicateKeyError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="User is already a member of this project",
        )

    await log_audit_event(
        action="PROJECT_MEMBER_ADDED",
        resource_type="project_membership",
        resource_id=f"{project_id}:{target_user.id}",
        user=manager,
        details={
            "project_id": project_id,
            "target_username": target_user.username,
            "role": str(payload.role),
        },
        request=request,
    )

    return _to_item(membership)


@router.patch("/{user_id}", response_model=ProjectMemberItem)
async def update_project_member_role(
    project_id: str,
    user_id: str,
    payload: UpdateProjectMemberRoleRequest,
    request: Request,
    manager: User = Depends(require_test_lead),
) -> ProjectMemberItem:
    """Update a user's role inside a QA project (Test Lead or Admin)."""
    try:
        target_oid = PydanticObjectId(user_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user_id")

    membership = await ProjectMembership.find_one(
        ProjectMembership.project_id == project_id,
        ProjectMembership.user_id == target_oid,
    )
    if membership is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project membership not found",
        )

    old_role = str(membership.role)
    membership.role = payload.role
    membership.updated_at = datetime.now(timezone.utc)
    await membership.save()

    await log_audit_event(
        action="PROJECT_MEMBER_ROLE_UPDATED",
        resource_type="project_membership",
        resource_id=f"{project_id}:{user_id}",
        user=manager,
        details={
            "project_id": project_id,
            "target_username": membership.username,
            "old_role": old_role,
            "new_role": str(payload.role),
        },
        request=request,
    )

    return _to_item(membership)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_project_member(
    project_id: str,
    user_id: str,
    request: Request,
    manager: User = Depends(require_test_lead),
) -> None:
    """Remove a user from a QA project (Test Lead or Admin)."""
    try:
        target_oid = PydanticObjectId(user_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user_id")

    membership = await ProjectMembership.find_one(
        ProjectMembership.project_id == project_id,
        ProjectMembership.user_id == target_oid,
    )
    if membership is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project membership not found",
        )

    target_username = membership.username
    await membership.delete()

    await log_audit_event(
        action="PROJECT_MEMBER_REMOVED",
        resource_type="project_membership",
        resource_id=f"{project_id}:{user_id}",
        user=manager,
        details={"project_id": project_id, "removed_username": target_username},
        request=request,
    )
