"""Admin user-management routes (RBAC).

All endpoints here require the Admin role. They let an administrator view the
user directory, create users, change a user's role, and enable/disable accounts,
with all critical actions recorded to the audit trail.
"""

from datetime import datetime, timezone
from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pymongo.errors import DuplicateKeyError

from app.api.deps import require_admin
from app.core.audit import log_audit_event
from app.core.roles import Role
from app.core.security import hash_password
from app.models.user import User
from app.schemas.users import (
    CreateUserRequest,
    UpdateRoleRequest,
    UpdateStatusRequest,
    UserListItem,
)

router = APIRouter(prefix="/users", tags=["users"])


def _to_item(user: User) -> UserListItem:
    role_value = user.role.value if hasattr(user.role, "value") else str(user.role)
    return UserListItem(
        id=str(user.id),
        name=user.full_name,
        email=user.email,
        username=user.username,
        role=role_value,
        is_active=user.is_active,
        created_at=user.created_at,
        avatar=user.avatar,
    )


@router.get("", response_model=list[UserListItem])
async def list_users(
    role: Role | None = Query(default=None, description="Filter users by RBAC role"),
    search: str | None = Query(default=None, description="Search by name, username, or email"),
    _admin: User = Depends(require_admin),
) -> list[UserListItem]:
    """List all registered users with optional role and keyword filtering."""
    query_conditions = []
    if role is not None:
        query_conditions.append(User.role == role)

    if query_conditions:
        users = await User.find(*query_conditions).sort("+created_at").to_list()
    else:
        users = await User.find_all().sort("+created_at").to_list()

    if search:
        s = search.lower()
        users = [
            u for u in users
            if s in u.full_name.lower() or s in u.username.lower() or s in u.email.lower()
        ]

    return [_to_item(u) for u in users]


async def _get_user_or_404(user_id: str) -> User:
    try:
        oid = PydanticObjectId(user_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    user = await User.get(oid)
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user


@router.post("", response_model=UserListItem, status_code=status.HTTP_201_CREATED)
async def create_user(
    payload: CreateUserRequest,
    request: Request,
    admin: User = Depends(require_admin),
) -> UserListItem:
    """Create a new user with an assigned RBAC role (Admin only)."""
    existing = await User.find_one(
        {"$or": [{"username": payload.username}, {"email": payload.email}]}
    )
    if existing is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this username or email already exists",
        )

    user = User(
        full_name=payload.full_name,
        username=payload.username,
        email=payload.email,
        hashed_password=hash_password(payload.password),
        role=payload.role,
        is_active=True,
    )
    try:
        await user.insert()
    except DuplicateKeyError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this username or email already exists",
        )

    await log_audit_event(
        action="USER_CREATED",
        resource_type="user",
        resource_id=str(user.id),
        user=admin,
        details={
            "created_username": user.username,
            "created_email": user.email,
            "assigned_role": str(user.role),
        },
        request=request,
    )

    return _to_item(user)


@router.get("/{user_id}", response_model=UserListItem)
async def get_user_detail(
    user_id: str,
    _admin: User = Depends(require_admin),
) -> UserListItem:
    """Get single user profile by ID."""
    user = await _get_user_or_404(user_id)
    return _to_item(user)


@router.patch("/{user_id}/role", response_model=UserListItem)
async def update_user_role(
    user_id: str,
    payload: UpdateRoleRequest,
    request: Request,
    admin: User = Depends(require_admin),
) -> UserListItem:
    """Change user role (e.g. Viewer -> Tester -> Test Lead -> Admin)."""
    user = await _get_user_or_404(user_id)
    old_role = str(user.role)
    user.role = payload.role
    user.updated_at = datetime.now(timezone.utc)
    await user.save()

    await log_audit_event(
        action="USER_ROLE_UPDATED",
        resource_type="user",
        resource_id=str(user.id),
        user=admin,
        details={
            "target_username": user.username,
            "old_role": old_role,
            "new_role": str(user.role),
        },
        request=request,
    )

    return _to_item(user)


@router.patch("/{user_id}/status", response_model=UserListItem)
async def update_user_status(
    user_id: str,
    payload: UpdateStatusRequest,
    request: Request,
    admin: User = Depends(require_admin),
) -> UserListItem:
    """Enable or disable user account access."""
    user = await _get_user_or_404(user_id)
    if str(user.id) == str(admin.id) and not payload.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You cannot disable your own account.",
        )
    old_status = user.is_active
    user.is_active = payload.is_active
    user.updated_at = datetime.now(timezone.utc)
    await user.save()

    await log_audit_event(
        action="USER_STATUS_UPDATED",
        resource_type="user",
        resource_id=str(user.id),
        user=admin,
        details={
            "target_username": user.username,
            "old_status": old_status,
            "new_status": user.is_active,
        },
        request=request,
    )

    return _to_item(user)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: str,
    request: Request,
    admin: User = Depends(require_admin),
) -> None:
    """Delete a user account (Admin only)."""
    user = await _get_user_or_404(user_id)
    if str(user.id) == str(admin.id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You cannot delete your own account.",
        )
    deleted_username = user.username
    await user.delete()

    await log_audit_event(
        action="USER_DELETED",
        resource_type="user",
        resource_id=user_id,
        user=admin,
        details={"deleted_username": deleted_username},
        request=request,
    )
