"""SubProject routes (DB-backed, global/shared, auth-protected).

Creating a subproject validates that the referenced subscription exists (404 if
not). `code` ("PRJ-####") is unique and regenerated on collision.
"""
from __future__ import annotations

import random

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException, Query, status
from pymongo.errors import DuplicateKeyError

from app.api.deps import get_current_user
from app.models.subproject import SUBPROJECT_GRADIENTS, SubProject
from app.models.subscription import Subscription
from app.models.user import User
from app.schemas.subproject import SubProjectCreate, SubProjectOut

router = APIRouter(prefix="/subprojects", tags=["subprojects"])


def _to_proj_out(proj: SubProject) -> SubProjectOut:
    return SubProjectOut(
        id=str(proj.id),
        code=proj.code,
        subscription_id=proj.subscription_id,
        name=proj.name,
        type=proj.type,
        endpoints_count=proj.endpoints_count,
        endpoints=proj.endpoints,
        description=proj.description,
        stories_count=proj.stories_count,
        test_cases_count=proj.test_cases_count,
        scripts_count=proj.scripts_count,
        created_at=proj.created_at.isoformat(),
        accent_gradient=proj.accent_gradient,
    )


async def _get_proj_or_404(proj_id: str) -> SubProject:
    try:
        oid = PydanticObjectId(proj_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="SubProject not found")
    proj = await SubProject.get(oid)
    if proj is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="SubProject not found")
    return proj


@router.get("", response_model=list[SubProjectOut])
async def list_subprojects(
    subscription_id: str | None = Query(default=None, alias="subscriptionId"),
    _user: User = Depends(get_current_user),
) -> list[SubProjectOut]:
    query = SubProject.find_all()
    if subscription_id is not None:
        query = SubProject.find(SubProject.subscription_id == subscription_id)
    projects = await query.sort("+created_at").to_list()
    return [_to_proj_out(p) for p in projects]


@router.post("", response_model=SubProjectOut, status_code=status.HTTP_201_CREATED)
async def create_subproject(
    payload: SubProjectCreate,
    _user: User = Depends(get_current_user),
) -> SubProjectOut:
    # Validate the referenced subscription exists.
    try:
        sub_oid = PydanticObjectId(payload.subscription_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Subscription not found")
    subscription = await Subscription.get(sub_oid)
    if subscription is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Subscription not found")

    # Generate a unique PRJ-#### code; regenerate on a DB duplicate-key clash.
    for _ in range(10):
        code = f"PRJ-{random.randint(1000, 9999)}"
        proj = SubProject(
            code=code,
            subscription_id=str(subscription.id),
            name=payload.name,
            type=payload.type,
            endpoints_count=payload.endpoints_count,
            endpoints=payload.endpoints,
            description=payload.description,
            stories_count=0,
            test_cases_count=0,
            scripts_count=0,
            accent_gradient=random.choice(SUBPROJECT_GRADIENTS),
        )
        try:
            await proj.insert()
        except DuplicateKeyError:
            continue
        return _to_proj_out(proj)
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Could not generate a unique subproject code",
    )


@router.get("/{proj_id}", response_model=SubProjectOut)
async def get_subproject(proj_id: str, _user: User = Depends(get_current_user)) -> SubProjectOut:
    proj = await _get_proj_or_404(proj_id)
    return _to_proj_out(proj)


@router.delete("/{proj_id}")
async def delete_subproject(proj_id: str, _user: User = Depends(get_current_user)) -> dict:
    proj = await _get_proj_or_404(proj_id)
    await proj.delete()
    return {}
