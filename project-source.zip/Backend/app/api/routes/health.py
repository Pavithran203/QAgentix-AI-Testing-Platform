"""Health check endpoint."""
from fastapi import APIRouter

from app.core.config import settings
from app.db.mongodb import get_client

router = APIRouter(tags=["health"])


@router.get("/health")
async def health() -> dict:
    db_ok = False
    client = get_client()
    if client is not None:
        try:
            await client.admin.command("ping")
            db_ok = True
        except Exception:  # noqa: BLE001 - report as unhealthy, don't crash
            db_ok = False

    return {
        "status": "ok" if db_ok else "degraded",
        "app": settings.app_name,
        "environment": settings.environment,
        "database": "connected" if db_ok else "unavailable",
    }
