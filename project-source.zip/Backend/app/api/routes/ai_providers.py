"""AI provider selection & connection routes (Claude + Google only)."""
from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.core import ai_providers
from app.core.llm import LLMError

logger = logging.getLogger("uvicorn.error")

router = APIRouter(prefix="/ai", tags=["ai-providers"])


class ConnectRequest(BaseModel):
    provider: str = Field(..., description="claude/anthropic or gemini/google")
    api_key: str = Field(..., alias="apiKey")
    model: str | None = Field(default=None)

    model_config = {"populate_by_name": True}


@router.get("/providers")
async def get_providers() -> dict:
    return {"providers": ai_providers.list_providers()}


@router.get("/status")
async def get_status() -> dict:
    return ai_providers.get_active_public()


@router.post("/connect")
async def connect(req: ConnectRequest) -> dict:
    try:
        result = ai_providers.connect(req.provider, req.api_key, req.model)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except LLMError as exc:
        raise HTTPException(status_code=502, detail=f"Connection failed: {exc}") from exc
    return {"status": "connected", "connection": result}


@router.post("/disconnect")
async def disconnect() -> dict:
    ai_providers.disconnect()
    return {"status": "disconnected"}
