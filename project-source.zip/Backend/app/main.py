"""FastAPI application entrypoint for QAgenticx."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import (
    ai_providers,
    audit_logs,
    auth,
    dashboard,
    health,
    memberships,
    process_agent,
    subprojects,
    subscriptions,
    test_design,
    users,
    workspace,
)
from app.core.config import settings
from app.db.mongodb import close_mongo_connection, connect_to_mongo


@asynccontextmanager
async def lifespan(_app: FastAPI):
    await connect_to_mongo()
    yield
    await close_mongo_connection()


app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    lifespan=lifespan,
)

# CORS: wildcard origins cannot be combined with allow_credentials=True,
# so credentials are disabled. Auth uses the Authorization: Bearer header.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers mounted under the API prefix (default: /api).
app.include_router(health.router, prefix=settings.api_prefix)
app.include_router(auth.router, prefix=settings.api_prefix)
app.include_router(users.router, prefix=settings.api_prefix)
app.include_router(memberships.router, prefix=settings.api_prefix)
app.include_router(audit_logs.router, prefix=settings.api_prefix)
app.include_router(subscriptions.router, prefix=settings.api_prefix)
app.include_router(subprojects.router, prefix=settings.api_prefix)
app.include_router(process_agent.router, prefix=settings.api_prefix)
app.include_router(ai_providers.router, prefix=settings.api_prefix)
app.include_router(workspace.router, prefix=settings.api_prefix)
app.include_router(test_design.router, prefix=settings.api_prefix)
app.include_router(dashboard.dashboard_router, prefix=settings.api_prefix)
app.include_router(dashboard.runs_router, prefix=settings.api_prefix)


@app.get("/")
async def root() -> dict:
    return {"service": settings.app_name, "docs": "/docs", "health": f"{settings.api_prefix}/health"}
