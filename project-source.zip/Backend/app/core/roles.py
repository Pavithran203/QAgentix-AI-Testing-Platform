"""Role definitions for Role-Based Access Control (RBAC)."""

from enum import Enum


class Role(str, Enum):
    ADMIN = "Admin"
    TEST_LEAD = "Test Lead"
    TESTER = "Tester"
    VIEWER = "Viewer"
    EMPLOYEE = "Employee"  # Backward compatibility for legacy accounts


# All assignable roles (used for validation in the admin API).
ALL_ROLES = [Role.ADMIN.value, Role.TEST_LEAD.value, Role.TESTER.value, Role.VIEWER.value]

DEFAULT_ROLE = Role.VIEWER
