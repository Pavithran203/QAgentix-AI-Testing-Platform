"""Audit logging service helper."""

from __future__ import annotations

from typing import Any
from fastapi import Request

from app.models.audit_log import AuditLog
from app.models.user import User


async def log_audit_event(
    action: str,
    resource_type: str,
    resource_id: str,
    user: User | None = None,
    details: dict[str, Any] | None = None,
    request: Request | None = None,
) -> AuditLog:
    """Record an audit trail event in MongoDB."""
    ip_address = None
    if request is not None:
        ip_address = request.client.host if request.client else None

    entry = AuditLog(
        user_id=str(user.id) if user else None,
        username=user.username if user else "system",
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details or {},
        ip_address=ip_address,
    )
    await entry.insert()
    return entry
