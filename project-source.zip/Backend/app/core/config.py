"""Application configuration using pydantic-settings.

Values are loaded from environment variables and an optional `.env` file.
"""
import os
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # App
    app_name: str = "QAgenticx Backend"
    environment: str = "development"
    api_prefix: str = "/api"

    # Server
    host: str = "0.0.0.0"
    port: int = 8000

    # MongoDB
    mongodb_uri: str = "mongodb://localhost:27017"
    mongodb_db_name: str = "qagenticx"

    # CORS: stored as a comma-separated string in env (CORS_ORIGINS); parsed
    # into a list via the `cors_origins` property below.
    cors_origins_raw: str = Field(
        default="http://localhost:3000,http://localhost:5173",
        validation_alias="CORS_ORIGINS",
    )

    # JWT
    jwt_secret_key: str = "change-me-to-a-long-random-secret"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    # LLM (Process Agent) - only Claude (Anthropic) and Google (Gemini) are supported.
    llm_provider: str = "claude"
    llm_model: str | None = "claude-3-5-sonnet-20241022"
    llm_api_key: str | None = None

    # Workspace: root folder on the local filesystem under which QAgentix
    # project folders (Features/Scripts/Test_cases/Test_data/Reports) are
    # created and where generated artifacts are stored. Backend-only.
    workspace_root: str = ""
    workspace_allowlist_raw: str = Field(
        default="",
        validation_alias="WORKSPACE_ALLOWLIST",
        description="Comma-separated list of additional allowed workspace directory roots",
    )

    # Security & Boundary Limits
    max_input_prompt_chars: int = 50_000
    max_file_write_bytes: int = 5 * 1024 * 1024  # 5 MB
    max_file_read_bytes: int = 10 * 1024 * 1024  # 10 MB

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins_raw.split(",") if origin.strip()]

    @property
    def resolved_workspace_root(self) -> str:
        """Absolute workspace root; defaults to <Backend>/workspaces."""
        if self.workspace_root.strip():
            return os.path.abspath(self.workspace_root.strip())
        backend_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        return os.path.join(backend_dir, "workspaces")

    @property
    def workspace_allowlist(self) -> list[str]:
        """List of normalized absolute directory paths allowed for workspaces."""
        roots = [self.resolved_workspace_root]
        if self.workspace_allowlist_raw.strip():
            for p in self.workspace_allowlist_raw.split(","):
                p = p.strip()
                if p:
                    roots.append(os.path.abspath(p))
        return [os.path.realpath(r) for r in roots]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
