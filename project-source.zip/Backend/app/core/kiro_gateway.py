"""Kiro Gateway & Local Integration Service for QAgenticx.

Provides bidirectional connectivity between QAgenticx Backend and the local Kiro
installation (C:\\Users\\Pro-Admin\\AppData\\Local\\Programs\\Kiro\\bin\\kiro.cmd):
1. Detects local Kiro installation & status.
2. Interacts with Kiro Gateway (http://127.0.0.1:39275) or headless Kiro CLI.
3. Configures Model Context Protocol (MCP) server registration in Kiro.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger("uvicorn.error")

DEFAULT_KIRO_GATEWAY_URL = "http://127.0.0.1:39275"
DEFAULT_KIRO_PORT = 39275


def find_kiro_executable() -> str | None:
    """Locate the kiro CLI command or executable on the system."""
    cmd = shutil.which("kiro") or shutil.which("kiro.cmd")
    if cmd and os.path.exists(cmd):
        return cmd

    # Common Windows install path
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    if local_app_data:
        candidate = Path(local_app_data) / "Programs" / "Kiro" / "bin" / "kiro.cmd"
        if candidate.exists():
            return str(candidate)
        candidate_exe = Path(local_app_data) / "Programs" / "Kiro" / "Kiro.exe"
        if candidate_exe.exists():
            return str(candidate_exe)

    return None


async def check_kiro_gateway_health(url: str = DEFAULT_KIRO_GATEWAY_URL) -> bool:
    """Check if the local Kiro Gateway is listening and responsive."""
    try:
        async with httpx.AsyncClient(timeout=1.5) as client:
            resp = await client.get(f"{url}/")
            return resp.status_code < 500
    except Exception:
        return False


def get_kiro_status() -> dict[str, Any]:
    """Inspect local machine for Kiro installation and gateway connectivity."""
    exe_path = find_kiro_executable()
    is_installed = exe_path is not None
    version: str | None = None

    if is_installed and exe_path:
        try:
            res = subprocess.run(
                [exe_path, "--version"],
                capture_output=True,
                text=True,
                timeout=2,
                shell=True,
                check=False,
            )
            if res.returncode == 0:
                version = res.stdout.strip().splitlines()[-1] if res.stdout.strip() else None
        except Exception as exc:
            logger.debug("Failed to query kiro --version: %s", exc)

    return {
        "installed": is_installed,
        "executable": exe_path,
        "version": version,
        "gateway_url": DEFAULT_KIRO_GATEWAY_URL,
        "gateway_port": DEFAULT_KIRO_PORT,
    }


def start_kiro_gateway(port: int = DEFAULT_KIRO_PORT) -> bool:
    """Launch the Kiro Gateway daemon in the background on localhost."""
    exe_path = find_kiro_executable()
    if not exe_path:
        return False
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen(
            [exe_path, "gateway", "--port", str(port), "--host", "127.0.0.1"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=flags,
            shell=True,
        )
        return True
    except Exception as exc:
        logger.error("[Kiro] Failed to launch gateway daemon: %s", exc)
        return False


def execute_kiro_chat(
    prompt: str,
    context_files: list[str] | None = None,
    mode: str = "agent",
    working_dir: str | None = None,
    timeout: int = 60,
) -> str:
    """Execute a prompt through local Kiro CLI in headless agent mode."""
    exe_path = find_kiro_executable()
    if not exe_path:
        raise RuntimeError("Kiro is not installed or not found in PATH.")

    args = [exe_path, "chat", "--mode", mode]
    if context_files:
        for f in context_files:
            if os.path.exists(f):
                args.extend(["--add-file", f])

    args.append(prompt)

    try:
        res = subprocess.run(
            args,
            cwd=working_dir or os.getcwd(),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        if res.returncode != 0:
            err = res.stderr.strip() or f"Process exited with code {res.returncode}"
            logger.warning("[Kiro] Execution error: %s", err)
            # Return stdout if available, otherwise raise
            if res.stdout.strip():
                return res.stdout.strip()
            raise RuntimeError(f"Kiro execution failed: {err}")
        return res.stdout.strip()
    except subprocess.TimeoutExpired as exc:
        raise TimeoutError(f"Kiro chat timed out after {timeout} seconds.") from exc


MCP_SERVER_NAME = "qagentix"
_WORKSPACE_ROOT = Path(__file__).resolve().parents[3]
MCP_SERVER_SCRIPT = Path(__file__).resolve().parents[1] / "mcp" / "server.py"


def mcp_config_paths() -> list[Path]:
    """Kiro MCP config files, workspace first (it overrides the user-level one)."""
    return [
        _WORKSPACE_ROOT / ".kiro" / "settings" / "mcp.json",
        Path.home() / ".kiro" / "settings" / "mcp.json",
    ]


def get_mcp_registration(server_name: str = MCP_SERVER_NAME) -> dict[str, Any]:
    """Look for our MCP server in Kiro's config files (no side effects)."""
    for path in mcp_config_paths():
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            logger.debug("Unreadable Kiro MCP config %s: %s", path, exc)
            continue
        entry = (data.get("mcpServers") or {}).get(server_name)
        if entry:
            return {
                "registered": not entry.get("disabled", False),
                "config_path": str(path),
                "command": entry.get("command"),
                "args": entry.get("args") or [],
            }
    return {"registered": False, "config_path": None, "command": None, "args": []}


def probe_mcp_server(command: str, args: list[str], timeout: int = 20) -> dict[str, Any]:
    """Start the MCP server exactly as Kiro would and run the real handshake."""
    payload = "\n".join(
        [
            json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}),
            json.dumps({"jsonrpc": "2.0", "id": 2, "method": "tools/list"}),
        ]
    ) + "\n"
    try:
        res = subprocess.run(
            [command, *args],
            input=payload,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "tool_count": 0, "error": str(exc)}

    tool_count = 0
    initialized = False
    for line in res.stdout.splitlines():
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        if msg.get("id") == 1 and "result" in msg:
            initialized = True
        if msg.get("id") == 2 and "result" in msg:
            tool_count = len(msg["result"].get("tools", []))
    ok = initialized and tool_count > 0
    return {
        "ok": ok,
        "tool_count": tool_count,
        "error": None if ok else (res.stderr.strip()[-300:] or "No valid MCP response"),
    }


def register_mcp_with_kiro(
    server_name: str,
    command: str,
    args: list[str] | None = None,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Register an MCP server in the workspace Kiro config (.kiro/settings/mcp.json).

    This Kiro build has no `--add-mcp` flag; MCP servers are declared in mcp.json,
    so we merge our entry into that file and keep any servers already there.
    """
    if not find_kiro_executable():
        raise RuntimeError("Kiro is not installed or not found in PATH.")

    config_path = mcp_config_paths()[0]
    config_path.parent.mkdir(parents=True, exist_ok=True)

    data: dict[str, Any] = {}
    if config_path.exists():
        try:
            data = json.loads(config_path.read_text(encoding="utf-8")) or {}
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Existing {config_path} is not valid JSON; not overwriting it.") from exc

    definition = {
        "command": command,
        "args": args or [],
        "env": env or {},
        "disabled": False,
    }
    data.setdefault("mcpServers", {})[server_name] = definition
    config_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

    return {
        "success": True,
        "server_name": server_name,
        "config_path": str(config_path),
        "definition": definition,
    }


def open_in_kiro(target_path: str) -> bool:
    """Open a folder or file directly in the local Kiro editor."""
    exe_path = find_kiro_executable()
    if not exe_path or not os.path.exists(target_path):
        return False

    try:
        subprocess.Popen([exe_path, target_path], close_fds=True)
        return True
    except Exception as exc:
        logger.error("[Kiro] Failed to launch editor on %s: %s", target_path, exc)
        return False
