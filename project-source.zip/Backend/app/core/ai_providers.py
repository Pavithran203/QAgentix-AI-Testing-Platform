"""AI provider registry, model selection, and connection management.

Supports exactly two providers: Claude (Anthropic) and Google (Gemini).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from threading import Lock

from app.core.llm import SUPPORTED_PROVIDERS, _normalize_provider, generate, LLMError

logger = logging.getLogger("uvicorn.error")


@dataclass(frozen=True)
class ModelInfo:
    id: str
    name: str
    description: str = ""


@dataclass(frozen=True)
class ProviderInfo:
    id: str
    name: str
    models: list[ModelInfo] = field(default_factory=list)

    @property
    def default_model(self) -> str:
        return self.models[0].id if self.models else ""


PROVIDERS: dict[str, ProviderInfo] = {
    "claude": ProviderInfo(
        id="claude",
        name="Claude (Anthropic)",
        models=[
            ModelInfo("claude-3-5-sonnet-20241022", "Claude 3.5 Sonnet", "Balanced speed and quality."),
            ModelInfo("claude-3-haiku-20240307", "Claude 3 Haiku", "Fastest, for simple scripts."),
            ModelInfo("claude-3-opus-20240229", "Claude 3 Opus", "Most capable for complex generation."),
        ],
    ),
    "gemini": ProviderInfo(
        id="gemini",
        name="Google (Gemini)",
        models=[
            ModelInfo("gemini-1.5-pro", "Gemini 1.5 Pro", "High-capability Google model."),
            ModelInfo("gemini-1.5-flash", "Gemini 1.5 Flash", "Fast, cost-efficient model."),
        ],
    ),
}


def list_providers() -> list[dict]:
    return [
        {
            "id": p.id,
            "name": p.name,
            "defaultModel": p.default_model,
            "models": [{"id": m.id, "name": m.name, "description": m.description} for m in p.models],
        }
        for p in PROVIDERS.values()
    ]


def resolve_provider(provider: str) -> ProviderInfo:
    key = _normalize_provider(provider)
    if key not in PROVIDERS:
        supported = ", ".join(SUPPORTED_PROVIDERS)
        raise ValueError(f"Unsupported provider {provider!r}. Supported: {supported}.")
    return PROVIDERS[key]


def validate_model(provider: str, model: str | None) -> str:
    info = resolve_provider(provider)
    if not model:
        return info.default_model
    valid_ids = {m.id for m in info.models}
    if model not in valid_ids:
        raise ValueError(f"Model {model!r} not available for {info.id!r}. Available: {sorted(valid_ids)}.")
    return model


@dataclass
class ActiveConnection:
    provider: str
    model: str
    api_key: str

    def public(self) -> dict:
        return {"provider": self.provider, "model": self.model, "apiKeyMasked": _mask_key(self.api_key), "connected": True}


_active: ActiveConnection | None = None
_lock = Lock()


def _mask_key(key: str) -> str:
    if not key:
        return ""
    if len(key) <= 8:
        return "*" * len(key)
    return key[:4] + ("*" * (len(key) - 8)) + key[-4:]


def verify_connection(provider: str, api_key: str, model: str | None = None) -> str:
    info = resolve_provider(provider)
    resolved_model = validate_model(provider, model)
    if not api_key or not api_key.strip():
        raise LLMError(f"An API key is required for provider {info.id!r}.")
    generate(
        provider=info.id,
        api_key=api_key.strip(),
        system_prompt="You are a connectivity check. Reply with the single word: OK.",
        user_prompt="ping",
        model=resolved_model,
    )
    return resolved_model


def connect(provider: str, api_key: str, model: str | None = None) -> dict:
    resolved_model = verify_connection(provider, api_key, model)
    info = resolve_provider(provider)
    with _lock:
        global _active
        _active = ActiveConnection(provider=info.id, model=resolved_model, api_key=api_key.strip())
        logger.info("AI provider connected: provider=%s model=%s", info.id, resolved_model)
        return _active.public()


def get_active() -> ActiveConnection | None:
    with _lock:
        return _active


def get_active_public() -> dict:
    with _lock:
        if _active is None:
            return {"connected": False}
        return _active.public()


def disconnect() -> None:
    with _lock:
        global _active
        _active = None
        logger.info("AI provider disconnected")
