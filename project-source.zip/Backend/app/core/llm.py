"""Two-provider LLM router: Claude (Anthropic) and Google (Gemini)."""
from __future__ import annotations

import logging

import httpx

logger = logging.getLogger("uvicorn.error")

DEFAULT_MODELS = {
    "claude": "claude-3-5-sonnet-20241022",
    "gemini": "gemini-1.5-flash",
}

DEFAULT_PROVIDER = "claude"
SUPPORTED_PROVIDERS = ("claude", "gemini")

_TIMEOUT = httpx.Timeout(60.0, connect=10.0)


class LLMError(Exception):
    """Raised when an LLM provider call fails."""


def _normalize_provider(provider: str) -> str:
    p = (provider or "").strip().lower()
    if p in ("claude", "anthropic"):
        return "claude"
    if p in ("gemini", "google", "google-genai", "google_genai"):
        return "gemini"
    return p


def generate(*, provider: str, api_key: str, system_prompt: str, user_prompt: str, model: str | None = None) -> str:
    provider = _normalize_provider(provider) or DEFAULT_PROVIDER
    if provider not in SUPPORTED_PROVIDERS:
        raise LLMError(f"Unsupported provider {provider!r}. Supported: {chr(44).join(SUPPORTED_PROVIDERS)}.")
    if not api_key:
        raise LLMError(f"An API key is required for provider {provider!r}.")
    model = model or DEFAULT_MODELS[provider]
    try:
        if provider == "claude":
            return _call_claude(api_key, model, system_prompt, user_prompt)
        return _call_gemini(api_key, model, system_prompt, user_prompt)
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:500] if exc.response is not None else str(exc)
        raise LLMError(f"{provider} API error ({exc.response.status_code}): {detail}") from exc
    except httpx.HTTPError as exc:
        raise LLMError(f"{provider} request failed: {exc}") from exc


def _call_claude(api_key: str, model: str, system_prompt: str, user_prompt: str) -> str:
    resp = httpx.post(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"},
        json={
            "model": model,
            "max_tokens": 4096,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        },
        timeout=_TIMEOUT,
    )
    resp.raise_for_status()
    return resp.json()["content"][0]["text"]


def _call_gemini(api_key: str, model: str, system_prompt: str, user_prompt: str) -> str:
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    resp = httpx.post(
        url,
        params={"key": api_key},
        json={
            "system_instruction": {"parts": [{"text": system_prompt}]},
            "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
            "generationConfig": {"temperature": 0.2},
        },
        timeout=_TIMEOUT,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["candidates"][0]["content"]["parts"][0]["text"]
