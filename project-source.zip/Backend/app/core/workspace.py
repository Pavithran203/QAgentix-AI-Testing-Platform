"""Local filesystem workspace manager (backend-only).

The UI browses the local filesystem (drives + folders), picks ANY folder, and
the backend creates the predefined QAgentix structure INSIDE that folder, then
routes generated artifacts into the matching subfolder.

Predefined structure created inside the chosen folder:

    <chosen-folder>/
      Features/      -> BDD .feature files
      Scripts/       -> automation scripts (.py / .spec.ts / .ts)
      Test_cases/    -> test case docs (.json / .md / .csv)
      Test_data/     -> test data (.json / .csv / .xlsx)
      Reports/       -> run reports (.html / .xml / .json)

Browsing is read-only; writes only ever happen inside a chosen base folder's
predefined subfolders. Paths are validated to prevent traversal.
"""
from __future__ import annotations

import os
import re
import string
from datetime import datetime, timezone

# Canonical subfolders of the predefined structure.
SUBFOLDERS = ["Features", "Scripts", "Test_cases", "Test_data", "Reports"]

# Map an artifact "kind" to its target subfolder.
KIND_TO_FOLDER = {
    "feature": "Features",
    "features": "Features",
    "script": "Scripts",
    "scripts": "Scripts",
    "testcase": "Test_cases",
    "testcases": "Test_cases",
    "test_case": "Test_cases",
    "testdata": "Test_data",
    "test_data": "Test_data",
    "report": "Reports",
    "reports": "Reports",
}

_SAFE_NAME = re.compile(r"[^A-Za-z0-9._ -]+")


class WorkspaceError(Exception):
    """Raised for invalid workspace operations (bad path, traversal, etc.)."""


# ---------------------------------------------------------------------------
# Filesystem browsing (read-only)
# ---------------------------------------------------------------------------

def list_drives() -> list[str]:
    """Return available drive roots (Windows: C:\\, D:\\ ...; POSIX: /)."""
    if os.name == "nt":
        drives = []
        for letter in string.ascii_uppercase:
            root = f"{letter}:\\"
            if os.path.exists(root):
                drives.append(root)
        return drives
    return ["/"]


def _norm(path: str) -> str:
    return os.path.abspath(os.path.expanduser((path or "").strip()))


def browse(path: str | None) -> dict:
    """List subdirectories of `path` for the folder picker.

    If `path` is empty, returns drive roots (and the user's home as a shortcut).
    """
    if not path or not path.strip():
        return {
            "path": "",
            "parent": None,
            "drives": list_drives(),
            "home": os.path.expanduser("~"),
            "folders": [],
        }

    target = _norm(path)
    if not os.path.isdir(target):
        raise WorkspaceError(f"Not a directory: {target}")

    folders = []
    try:
        for entry in sorted(os.listdir(target), key=str.lower):
            full = os.path.join(target, entry)
            try:
                if os.path.isdir(full) and not entry.startswith("$"):
                    folders.append({"name": entry, "path": full})
            except OSError:
                continue  # skip unreadable entries
    except PermissionError:
        raise WorkspaceError(f"Permission denied: {target}")

    parent = os.path.dirname(target.rstrip("\\/"))
    if parent == target:  # at a drive root
        parent = None

    return {
        "path": target,
        "parent": parent,
        "drives": list_drives(),
        "home": os.path.expanduser("~"),
        "folders": folders,
    }


def make_dir(parent: str, name: str) -> dict:
    """Create a new folder named `name` inside the existing `parent` directory."""
    parent_abs = _norm(parent)
    if not os.path.isdir(parent_abs):
        raise WorkspaceError(f"Parent is not a directory: {parent_abs}")

    safe = (name or "").strip().replace("\\", "/").split("/")[-1]
    safe = _SAFE_NAME.sub("_", safe).strip()
    if not safe or safe in (".", ".."):
        raise WorkspaceError("Invalid folder name.")

    target = os.path.abspath(os.path.join(parent_abs, safe))
    # Containment: must stay inside the parent.
    if os.path.commonpath([parent_abs, target]) != parent_abs:
        raise WorkspaceError("Folder path escapes the parent directory.")

    # Report whether the folder was already present so the UI can decide to
    # create it fresh or open the existing one.
    existed = os.path.isdir(target)
    os.makedirs(target, exist_ok=True)
    return {"name": safe, "path": target, "existed": existed}


# ---------------------------------------------------------------------------
# Structure creation + artifact storage (operate on an absolute base folder)
# ---------------------------------------------------------------------------

def _base_dir(base: str) -> str:
    base = _norm(base)
    if not base or not os.path.isdir(base):
        raise WorkspaceError(f"Base folder does not exist: {base}")
    return base


def _safe_name(name: str) -> str:
    name = (name or "").strip().replace("\\", "/").split("/")[-1]
    cleaned = _SAFE_NAME.sub("_", name).strip()
    if not cleaned or cleaned in (".", ".."):
        raise WorkspaceError("Invalid file name.")
    return cleaned


def has_structure(base: str) -> bool:
    base = _norm(base)
    return all(os.path.isdir(os.path.join(base, s)) for s in SUBFOLDERS)


def create_structure(base: str) -> dict:
    """Create the predefined subfolders INSIDE the chosen base folder."""
    base = _base_dir(base)
    for sub in SUBFOLDERS:
        os.makedirs(os.path.join(base, sub), exist_ok=True)
    return {"name": os.path.basename(base), "path": base, "subfolders": SUBFOLDERS}


def get_tree(base: str) -> dict:
    """Return the predefined subfolders inside the base and their files."""
    base = _base_dir(base)
    tree: dict = {"name": os.path.basename(base), "path": base, "folders": {}}
    for sub in SUBFOLDERS:
        sub_path = os.path.join(base, sub)
        files = []
        if os.path.isdir(sub_path):
            for f in sorted(os.listdir(sub_path), key=str.lower):
                fp = os.path.join(sub_path, f)
                if os.path.isfile(fp):
                    files.append(
                        {
                            "name": f,
                            "size": os.path.getsize(fp),
                            "modified": datetime.fromtimestamp(
                                os.path.getmtime(fp), tz=timezone.utc
                            ).isoformat(),
                        }
                    )
        tree["folders"][sub] = files
    return tree


def folder_for_kind(kind: str) -> str:
    raw = (kind or "").strip()
    # Accept an exact predefined subfolder name (e.g. "Scripts") directly,
    # so the UI can target a folder without mapping through a kind.
    for sub in SUBFOLDERS:
        if raw.lower() == sub.lower():
            return sub
    folder = KIND_TO_FOLDER.get(raw.lower())
    if folder is None:
        raise WorkspaceError(
            f"Unknown kind '{kind}'. Use a subfolder name "
            f"({', '.join(SUBFOLDERS)}) or: feature, script, testcase, testdata, report."
        )
    return folder


def write_file(base: str, kind: str, filename: str, content: str) -> dict:
    """Write an artifact into the subfolder (by kind) inside the base folder."""
    base = _base_dir(base)
    folder = folder_for_kind(kind)
    safe_name = _safe_name(filename)

    target_dir = os.path.join(base, folder)
    os.makedirs(target_dir, exist_ok=True)
    target = os.path.abspath(os.path.join(target_dir, safe_name))

    # Containment: the resolved file must stay inside target_dir.
    if os.path.commonpath([os.path.abspath(target_dir), target]) != os.path.abspath(target_dir):
        raise WorkspaceError("Resolved file path escapes its folder.")

    with open(target, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(content)

    return {
        "base": base,
        "folder": folder,
        "name": safe_name,
        "path": target,
        "size": os.path.getsize(target),
    }


def read_file(base: str, folder: str, filename: str) -> str:
    base = _base_dir(base)
    if folder not in SUBFOLDERS:
        raise WorkspaceError(f"Unknown folder '{folder}'.")
    safe_name = _safe_name(filename)
    target = os.path.join(base, folder, safe_name)
    if not os.path.isfile(target):
        raise WorkspaceError("File not found.")
    with open(target, "r", encoding="utf-8") as fh:
        return fh.read()
