"""RunEvent document for MongoDB (Beanie ODM).

One row per lifecycle event within a run. `run_id` links to the parent
`Run.run_id` (indexed, NOT unique). `event_key` (`run_id:type:step_number`) is
unique so retried/duplicate events never create a second row.
"""
from datetime import datetime, timezone

import pymongo
from beanie import Document, Indexed
from pydantic import Field


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class RunEvent(Document):
    run_id: Indexed(str)  # type: ignore[valid-type]  # NOT unique
    event_key: Indexed(str, unique=True)  # type: ignore[valid-type]
    type: str
    message: str
    step_number: int | None = None
    status: str | None = None
    timestamp: datetime = Field(default_factory=_utcnow)
    created_at: datetime = Field(default_factory=_utcnow)

    class Settings:
        name = "run_events"
        indexes = [
            pymongo.IndexModel([("run_id", pymongo.ASCENDING)]),
            pymongo.IndexModel([("event_key", pymongo.ASCENDING)], unique=True),
            pymongo.IndexModel([("timestamp", pymongo.DESCENDING)]),
        ]
