"""Audit Log document for MongoDB (Beanie ODM).

Records critical governance, RBAC, membership, and test execution events.
"""

from datetime import datetime, timezone
from typing import Any

import pymongo
from beanie import Document, Indexed
from pydantic import Field


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class AuditLog(Document):
    user_id: Indexed(str) | None = None  # type: ignore[valid-type]
    username: str = "system"
    action: Indexed(str)  # type: ignore[valid-type]
    resource_type: Indexed(str)  # type: ignore[valid-type]
    resource_id: str
    details: dict[str, Any] = Field(default_factory=dict)
    ip_address: str | None = None
    timestamp: Indexed(datetime) = Field(default_factory=_utcnow)  # type: ignore[valid-type]

    class Settings:
        name = "audit_logs"
        indexes = [
            pymongo.IndexModel([("timestamp", pymongo.DESCENDING)]),
            pymongo.IndexModel([("action", pymongo.ASCENDING)]),
            pymongo.IndexModel([("resource_type", pymongo.ASCENDING)]),
            pymongo.IndexModel([("user_id", pymongo.ASCENDING)]),
        ]
