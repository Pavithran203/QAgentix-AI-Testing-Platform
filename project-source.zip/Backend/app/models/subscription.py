"""Subscription document for MongoDB (Beanie ODM).

Global (shared) ownership: there is NO owner field. Access is gated by auth only.
`code` ("SUB-####") is unique and enforced by a DB index; `projects_count` is
NEVER stored (it is computed on read from the subprojects collection).
"""
from datetime import datetime, timezone

import pymongo
from beanie import Document, Indexed
from pydantic import Field


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


# Accent gradient palette (mirrors SubscriptionProvider.addSubscription in App.tsx)
# so cards keep the same look whether created client- or server-side.
SUBSCRIPTION_GRADIENTS = [
    "from-amber-400 via-teal-500 to-emerald-500",
    "from-teal-400 via-cyan-500 to-blue-500",
    "from-emerald-400 via-teal-500 to-indigo-500",
    "from-cyan-400 via-blue-500 to-teal-500",
    "from-purple-400 via-pink-500 to-teal-500",
]


class Subscription(Document):
    code: Indexed(str, unique=True)  # type: ignore[valid-type]
    name: str
    category: str
    status: str
    plan: str
    description: str
    active_agents: int = 0
    total_runs: int = 0
    accent_gradient: str
    created_at: datetime = Field(default_factory=_utcnow)

    class Settings:
        name = "subscriptions"
        indexes = [
            pymongo.IndexModel([("code", pymongo.ASCENDING)], unique=True),
        ]
