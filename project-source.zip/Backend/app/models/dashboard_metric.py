"""DashboardMetric document for MongoDB (Beanie ODM).

Stores dashboard summary snapshots. `kind='current'` holds the single latest
snapshot (upserted); `kind='history'` rows are appended over time for trend and
tracking purposes. Unavailable metrics are stored as `None`.
"""
from datetime import datetime, timezone

import pymongo
from beanie import Document, Indexed
from pydantic import Field


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class DashboardMetric(Document):
    kind: Indexed(str)  # type: ignore[valid-type]  # 'current' | 'history'
    total_projects: int
    total_test_cases: int | None = None
    total_runs: int
    pass_rate: float | None = None
    failed_tests: int
    locator_issues: int | None = None
    snapshot_at: datetime = Field(default_factory=_utcnow)
    created_at: datetime = Field(default_factory=_utcnow)

    class Settings:
        name = "dashboard_metrics"
        indexes = [
            pymongo.IndexModel([("kind", pymongo.ASCENDING)]),
            pymongo.IndexModel([("snapshot_at", pymongo.DESCENDING)]),
        ]
