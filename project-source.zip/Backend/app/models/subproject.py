"""SubProject document for MongoDB (Beanie ODM).

Global (shared) ownership: access is gated by auth only. `code` ("PRJ-####")
is unique and enforced by a DB index; `subscription_id` stores the owning
subscription's `_id` string and is indexed for per-subscription queries.
"""
from datetime import datetime, timezone

import pymongo
from beanie import Document, Indexed
from pydantic import Field


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


# Accent gradient palette (mirrors ProjectListProvider.addProject in App.tsx).
SUBPROJECT_GRADIENTS = [
    "from-teal-400 via-cyan-500 to-blue-500",
    "from-blue-400 via-indigo-500 to-teal-500",
    "from-emerald-400 via-teal-500 to-cyan-500",
    "from-amber-400 via-amber-500 to-teal-500",
    "from-purple-400 via-pink-500 to-teal-500",
]


class SubProject(Document):
    code: Indexed(str, unique=True)  # type: ignore[valid-type]
    subscription_id: str
    name: str
    type: str
    endpoints_count: int = 0
    endpoints: list[str] = Field(default_factory=list)
    description: str
    stories_count: int = 0
    test_cases_count: int = 0
    scripts_count: int = 0
    accent_gradient: str
    created_at: datetime = Field(default_factory=_utcnow)

    class Settings:
        name = "subprojects"
        indexes = [
            pymongo.IndexModel([("code", pymongo.ASCENDING)], unique=True),
            pymongo.IndexModel([("subscription_id", pymongo.ASCENDING)]),
        ]
