"""User document for MongoDB (Beanie ODM).

IMPORTANT: This is the ONLY collection persisted to the database for auth.
Generated Python script files / test artifacts are NEVER stored in MongoDB.
They stay on the local filesystem (and, when applicable, object/cloud storage),
but never in the database.
"""
from datetime import datetime, timezone

import pymongo
from beanie import Document, Indexed
from pydantic import EmailStr, Field

from app.core.roles import DEFAULT_ROLE, Role


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Document):
    full_name: str
    username: Indexed(str, unique=True)  # type: ignore[valid-type]
    email: Indexed(EmailStr, unique=True)  # type: ignore[valid-type]
    hashed_password: str
    role: Role = DEFAULT_ROLE
    is_active: bool = True
    created_at: datetime = Field(default_factory=_utcnow)
    updated_at: datetime = Field(default_factory=_utcnow)

    class Settings:
        name = "users"
        # Startup indexes (also enforced by the Indexed() annotations above).
        indexes = [
            pymongo.IndexModel([("username", pymongo.ASCENDING)], unique=True),
            pymongo.IndexModel([("email", pymongo.ASCENDING)], unique=True),
        ]

    @property
    def avatar(self) -> str:
        parts = [p for p in self.full_name.strip().split(" ") if p]
        initials = "".join(p[0] for p in parts[:2]).upper()
        return initials or "QA"
