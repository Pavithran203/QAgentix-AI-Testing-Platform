"""Project Membership document for MongoDB (Beanie ODM).

Manages project-level access and roles (Admin, Test Lead, Tester, Viewer).
"""

from datetime import datetime, timezone
from typing import Any

import pymongo
from beanie import Document, Indexed, PydanticObjectId
from pydantic import Field

from app.core.roles import DEFAULT_ROLE, Role


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ProjectMembership(Document):
    project_id: Indexed(str)  # type: ignore[valid-type]
    user_id: Indexed(PydanticObjectId)  # type: ignore[valid-type]
    username: str
    role: Role = DEFAULT_ROLE
    created_at: datetime = Field(default_factory=_utcnow)
    updated_at: datetime = Field(default_factory=_utcnow)

    class Settings:
        name = "project_memberships"
        indexes = [
            pymongo.IndexModel(
                [("project_id", pymongo.ASCENDING), ("user_id", pymongo.ASCENDING)],
                unique=True,
            ),
            pymongo.IndexModel([("project_id", pymongo.ASCENDING)]),
            pymongo.IndexModel([("user_id", pymongo.ASCENDING)]),
        ]
