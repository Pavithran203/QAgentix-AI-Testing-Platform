"""Run document for MongoDB (Beanie ODM).

A `Run` is the persisted record of one test execution. `run_id` ("RUN-####") is
the external/display id and is unique (enforced by a DB index), regenerated on
collision like `SUB-####`. The Mongo `_id` remains the internal id.

`workspace_base` and absolute paths are NEVER serialized to the browser; only
the embedded `ArtifactRef` (kind/filename/rel_path) is stored and the rel_path
is resolved through the workspace service when a run detail is served.
"""
from datetime import datetime, timezone
from enum import Enum

import pymongo
from beanie import Document, Indexed
from pydantic import BaseModel, Field


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class RunStatus(str, Enum):
    QUEUED = "Queued"
    RUNNING = "Running"
    PASSED = "Passed"
    FAILED = "Failed"
    CANCELLED = "Cancelled"


class ArtifactRef(BaseModel):
    """Sanitized reference to a run artifact. Never stores absolute paths."""

    kind: str
    filename: str
    rel_path: str


class Run(Document):
    run_id: Indexed(str, unique=True)  # type: ignore[valid-type]
    subproject_id: str
    project_name: str
    test_suite: str
    status: str
    started_at: datetime = Field(default_factory=_utcnow)
    completed_at: datetime | None = None
    duration_ms: int | None = None
    passed_count: int = 0
    failed_count: int = 0
    artifact_refs: list[ArtifactRef] = Field(default_factory=list)
    workspace_base: str = ""  # server-only; never serialized to the browser
    created_at: datetime = Field(default_factory=_utcnow)

    class Settings:
        name = "runs"
        indexes = [
            pymongo.IndexModel([("run_id", pymongo.ASCENDING)], unique=True),
            pymongo.IndexModel([("subproject_id", pymongo.ASCENDING)]),
            pymongo.IndexModel([("status", pymongo.ASCENDING)]),
            pymongo.IndexModel([("started_at", pymongo.DESCENDING)]),
        ]
