"""TestResult document for MongoDB (Beanie ODM).

One row per test-case result within a run. `run_id` links to the parent
`Run.run_id` (indexed, NOT unique). `executed_at` is the EXECUTION timestamp
(never "now") and drives the trend aggregations.
"""
from datetime import datetime, timezone
from enum import Enum

import pymongo
from beanie import Document, Indexed
from pydantic import Field


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class TestResultStatus(str, Enum):
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    QUEUED = "queued"
    RUNNING = "running"
    CANCELLED = "cancelled"


class FailureCategory(str, Enum):
    PRODUCT_BUG = "Product Bug"
    LOCATOR_CHANGED = "Locator Changed"
    TIMING_FLAKY = "Timing Flaky"
    TEST_DATA = "Test Data"
    ENVIRONMENT = "Environment"
    OTHER = "Other"


class TestResult(Document):
    run_id: Indexed(str)  # type: ignore[valid-type]  # NOT unique
    subproject_id: str
    testcase_ref: str | None = None
    status: str
    failure_category: str | None = None
    duration_ms: int | None = None
    executed_at: datetime = Field(default_factory=_utcnow)
    created_at: datetime = Field(default_factory=_utcnow)

    class Settings:
        name = "test_results"
        indexes = [
            pymongo.IndexModel([("run_id", pymongo.ASCENDING)]),
            pymongo.IndexModel([("subproject_id", pymongo.ASCENDING)]),
            pymongo.IndexModel([("status", pymongo.ASCENDING)]),
            pymongo.IndexModel([("executed_at", pymongo.DESCENDING)]),
            pymongo.IndexModel([("failure_category", pymongo.ASCENDING)]),
        ]
