"""Dashboard aggregation + idempotent run recording service.

This module is the SINGLE owner of the counting invariants so cards, charts, and
the Recent Runs table always agree (spec §12, design §5.4):

- Pass rate = passed / (passed + failed) * 100 over COMPLETED results only
  (status in {passed, failed}); skipped/queued/running/cancelled are excluded
  from BOTH numerator and denominator. `None` when the denominator is 0.
- No LLM or filesystem work happens on reads. Failure categories are persisted
  at record time; uncategorized failures fold into "Other".
- Run recording is idempotent on `run_id`: a repeated completion for a terminal
  run is a no-op that returns the existing record (counts are not doubled).

All datetimes are UTC. Timestamps are serialized by the router via `.isoformat()`.
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone

from beanie import PydanticObjectId
from pymongo.errors import DuplicateKeyError

from app.models.dashboard_metric import DashboardMetric
from app.models.run import ArtifactRef, Run, RunStatus
from app.models.run_event import RunEvent
from app.models.subproject import SubProject
from app.models.test_result import FailureCategory, TestResult, TestResultStatus
from app.schemas.dashboard import (
    ArtifactRefOut,
    ExecutionPointOut,
    FailureCategoryOut,
    MetricSnapshotOut,
    PassRatePointOut,
    RecentRunsOut,
    RunCompleteIn,
    RunCreateIn,
    RunDetailOut,
    RunEventOut,
    RunRowOut,
    SummaryOut,
    TestResultOut,
    TimeRangeOut,
)

_TERMINAL_STATUSES = {RunStatus.PASSED.value, RunStatus.FAILED.value, RunStatus.CANCELLED.value}
_FAILURE_CATEGORY_ORDER = [c.value for c in FailureCategory]


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _parse_dt(value: str | None) -> datetime | None:
    """Parse an ISO-8601 string into an aware UTC datetime (None passthrough)."""
    if value is None:
        return None
    dt = datetime.fromisoformat(value)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _ensure_aware(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _format_duration(duration_ms: int | None) -> str | None:
    """Format a duration in ms as a compact human string (e.g. '1m 5s', '820ms')."""
    if duration_ms is None:
        return None
    if duration_ms < 1000:
        return f"{duration_ms}ms"
    total_seconds = duration_ms // 1000
    minutes, seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}h {minutes}m {seconds}s"
    if minutes:
        return f"{minutes}m {seconds}s"
    return f"{seconds}s"


def _period_key(dt: datetime, interval: str) -> str:
    """Truncate a datetime to the start of its interval; return an ISO date key."""
    dt = _ensure_aware(dt)
    if interval == "month":
        return f"{dt.year:04d}-{dt.month:02d}-01"
    if interval == "week":
        # ISO week start (Monday).
        monday = dt - timedelta(days=dt.weekday())
        return f"{monday.year:04d}-{monday.month:02d}-{monday.day:02d}"
    # day (default)
    return f"{dt.year:04d}-{dt.month:02d}-{dt.day:02d}"


def _period_start(dt: datetime, interval: str) -> datetime:
    dt = _ensure_aware(dt)
    if interval == "month":
        return dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if interval == "week":
        monday = dt - timedelta(days=dt.weekday())
        return monday.replace(hour=0, minute=0, second=0, microsecond=0)
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


def _next_period(start: datetime, interval: str) -> datetime:
    if interval == "month":
        year, month = start.year, start.month
        if month == 12:
            return start.replace(year=year + 1, month=1)
        return start.replace(month=month + 1)
    if interval == "week":
        return start + timedelta(weeks=1)
    return start + timedelta(days=1)


def _iter_periods(start: datetime, end: datetime, interval: str) -> list[str]:
    """Chronological list of period keys covering [start, end] inclusive."""
    keys: list[str] = []
    cursor = _period_start(start, interval)
    end_start = _period_start(end, interval)
    while cursor <= end_start:
        keys.append(_period_key(cursor, interval))
        cursor = _next_period(cursor, interval)
    return keys


def _compute_pass_rate(passed: int, failed: int) -> float | None:
    denom = passed + failed
    if denom == 0:
        return None
    return round(passed / denom * 100, 1)


# --- Summary ---------------------------------------------------------------
async def _compute_summary_values() -> dict:
    """Compute the raw summary metrics from the live collections.

    Returns the invariant numbers that back both the SummaryOut contract and the
    persisted DashboardMetric snapshots. UNAVAILABLE metrics are `None`.
    """
    total_projects = await SubProject.count()
    total_runs = await Run.count()

    passed = await TestResult.find(TestResult.status == TestResultStatus.PASSED.value).count()
    failed = await TestResult.find(TestResult.status == TestResultStatus.FAILED.value).count()

    return {
        "total_projects": total_projects,
        "total_test_cases": None,  # UNAVAILABLE (no test-case registry)
        "total_runs": total_runs,
        "pass_rate": _compute_pass_rate(passed, failed),
        "failed_tests": failed,
        "locator_issues": None,  # UNAVAILABLE (no locator-issue source)
    }


def _summary_from_values(values: dict, last_updated: str) -> SummaryOut:
    return SummaryOut(
        total_projects=values["total_projects"],
        total_test_cases=values["total_test_cases"],
        total_runs=values["total_runs"],
        pass_rate=values["pass_rate"],
        failed_tests=values["failed_tests"],
        locator_issues=values["locator_issues"],
        time_range=TimeRangeOut(start=None, end=None),
        last_updated=last_updated,
    )


async def refresh_metrics_snapshot() -> DashboardMetric:
    """Recompute the summary metrics and persist them.

    Upserts the single `kind='current'` snapshot and ALWAYS appends a new
    `kind='history'` row with the same values. Returns the current snapshot.
    """
    values = await _compute_summary_values()
    now = _utcnow()

    current = await DashboardMetric.find_one(DashboardMetric.kind == "current")
    if current is None:
        current = DashboardMetric(kind="current", snapshot_at=now, **values)
        await current.insert()
    else:
        current.total_projects = values["total_projects"]
        current.total_test_cases = values["total_test_cases"]
        current.total_runs = values["total_runs"]
        current.pass_rate = values["pass_rate"]
        current.failed_tests = values["failed_tests"]
        current.locator_issues = values["locator_issues"]
        current.snapshot_at = now
        await current.save()

    history = DashboardMetric(kind="history", snapshot_at=now, **values)
    await history.insert()

    return current


def _summary_from_snapshot(snapshot: DashboardMetric) -> SummaryOut:
    values = {
        "total_projects": snapshot.total_projects,
        "total_test_cases": snapshot.total_test_cases,
        "total_runs": snapshot.total_runs,
        "pass_rate": snapshot.pass_rate,
        "failed_tests": snapshot.failed_tests,
        "locator_issues": snapshot.locator_issues,
    }
    return _summary_from_values(values, _ensure_aware(snapshot.snapshot_at).isoformat())


async def get_summary(refresh: bool = False) -> SummaryOut:
    if not refresh:
        current = await DashboardMetric.find_one(DashboardMetric.kind == "current")
        if current is not None:
            return _summary_from_snapshot(current)
    current = await refresh_metrics_snapshot()
    return _summary_from_snapshot(current)


async def get_metrics_history(limit: int) -> list[MetricSnapshotOut]:
    rows = (
        await DashboardMetric.find(DashboardMetric.kind == "history")
        .sort("-snapshot_at")
        .limit(limit)
        .to_list()
    )
    return [
        MetricSnapshotOut(
            total_projects=r.total_projects,
            total_test_cases=r.total_test_cases,
            total_runs=r.total_runs,
            pass_rate=r.pass_rate,
            failed_tests=r.failed_tests,
            locator_issues=r.locator_issues,
            snapshot_at=_ensure_aware(r.snapshot_at).isoformat(),
        )
        for r in rows
    ]


# --- Trends ----------------------------------------------------------------
def _result_time_match(start: datetime | None, end: datetime | None) -> dict:
    match: dict = {}
    if start is not None or end is not None:
        rng: dict = {}
        if start is not None:
            rng["$gte"] = start
        if end is not None:
            rng["$lte"] = end
        match["executed_at"] = rng
    return match


async def get_pass_rate_trend(
    start: datetime | None, end: datetime | None, interval: str
) -> list[PassRatePointOut]:
    match = {"status": {"$in": [TestResultStatus.PASSED.value, TestResultStatus.FAILED.value]}}
    match.update(_result_time_match(start, end))

    docs = await TestResult.find(match).to_list()
    buckets: dict[str, dict[str, int]] = {}
    for doc in docs:
        key = _period_key(doc.executed_at, interval)
        bucket = buckets.setdefault(key, {"passed": 0, "failed": 0})
        if doc.status == TestResultStatus.PASSED.value:
            bucket["passed"] += 1
        elif doc.status == TestResultStatus.FAILED.value:
            bucket["failed"] += 1

    keys = sorted(buckets.keys())
    return [
        PassRatePointOut(
            period=k,
            passed=buckets[k]["passed"],
            failed=buckets[k]["failed"],
            pass_rate=_compute_pass_rate(buckets[k]["passed"], buckets[k]["failed"]),
        )
        for k in keys
    ]


async def get_execution_trend(
    start: datetime | None, end: datetime | None, interval: str
) -> list[ExecutionPointOut]:
    match: dict = {}
    if start is not None or end is not None:
        rng: dict = {}
        if start is not None:
            rng["$gte"] = start
        if end is not None:
            rng["$lte"] = end
        match["started_at"] = rng

    runs = await Run.find(match).to_list()
    if not runs:
        return []

    counts: dict[str, int] = {}
    for run in runs:
        key = _period_key(run.started_at, interval)
        counts[key] = counts.get(key, 0) + 1

    # Zero-fill the full range, chronologically.
    started_values = [_ensure_aware(r.started_at) for r in runs]
    range_start = start if start is not None else min(started_values)
    range_end = end if end is not None else max(started_values)
    period_keys = _iter_periods(range_start, range_end, interval)

    return [ExecutionPointOut(period=k, execution_count=counts.get(k, 0)) for k in period_keys]


async def get_failure_categories(
    start: datetime | None, end: datetime | None
) -> list[FailureCategoryOut]:
    match = {"status": TestResultStatus.FAILED.value}
    match.update(_result_time_match(start, end))

    docs = await TestResult.find(match).to_list()
    if not docs:
        return []

    counts: dict[str, int] = {}
    for doc in docs:
        category = doc.failure_category or FailureCategory.OTHER.value
        counts[category] = counts.get(category, 0) + 1

    # Stable enum order; only emit categories that actually have counts.
    ordered = [
        FailureCategoryOut(category=cat, count=counts[cat])
        for cat in _FAILURE_CATEGORY_ORDER
        if cat in counts
    ]
    # Any non-enum category (defensive) folds into Other already via the default.
    return ordered


async def get_locator_health() -> list:
    # UNAVAILABLE: no locator population is persisted (design §10).
    return []


# --- Recent runs / detail --------------------------------------------------
def _run_duration_display(run: Run) -> str | None:
    if run.status == RunStatus.RUNNING.value and run.completed_at is None:
        elapsed_ms = int((_utcnow() - _ensure_aware(run.started_at)).total_seconds() * 1000)
        return _format_duration(max(elapsed_ms, 0))
    return _format_duration(run.duration_ms)


def _to_run_row(run: Run) -> RunRowOut:
    return RunRowOut(
        id=run.run_id,
        project=run.project_name,
        suite=run.test_suite,
        started=_ensure_aware(run.started_at).isoformat(),
        duration=_run_duration_display(run),
        passed=run.passed_count,
        failed=run.failed_count,
        status=run.status,
    )


async def get_recent_runs(
    page: int,
    page_size: int,
    project_id: str | None = None,
    status: str | None = None,
    start: datetime | None = None,
    end: datetime | None = None,
) -> RecentRunsOut:
    match: dict = {}
    if project_id is not None:
        # An invalid ObjectId means no match (empty page), not a 500. The run's
        # subproject_id is stored as a plain string, so match by string value;
        # if it cannot be a valid ObjectId we simply return an empty page.
        try:
            PydanticObjectId(project_id)
        except Exception:
            return RecentRunsOut(items=[], total=0, page=page, page_size=page_size)
        match["subproject_id"] = project_id
    if status is not None:
        match["status"] = status
    if start is not None or end is not None:
        rng: dict = {}
        if start is not None:
            rng["$gte"] = start
        if end is not None:
            rng["$lte"] = end
        match["started_at"] = rng

    total = await Run.find(match).count()
    skip = (page - 1) * page_size
    runs = (
        await Run.find(match)
        .sort("-started_at")
        .skip(skip)
        .limit(page_size)
        .to_list()
    )
    return RecentRunsOut(
        items=[_to_run_row(r) for r in runs],
        total=total,
        page=page,
        page_size=page_size,
    )


async def _get_run(run_id: str) -> Run | None:
    return await Run.find_one(Run.run_id == run_id)


async def get_run_detail(run_id: str) -> RunDetailOut | None:
    run = await _get_run(run_id)
    if run is None:
        return None

    results = await TestResult.find(TestResult.run_id == run_id).sort("+executed_at").to_list()
    result_out = [
        TestResultOut(
            testcase_ref=r.testcase_ref,
            status=r.status,
            failure_category=r.failure_category,
            duration_ms=r.duration_ms,
            executed_at=_ensure_aware(r.executed_at).isoformat(),
        )
        for r in results
    ]
    # Sanitized artifact metadata — never expose workspace_base or absolute path.
    artifacts = [
        ArtifactRefOut(kind=a.kind, filename=a.filename, ref=a.rel_path)
        for a in run.artifact_refs
    ]

    events = await list_events(run_id)
    event_out = [
        RunEventOut(
            type=e.type,
            message=e.message,
            step_number=e.step_number,
            status=e.status,
            timestamp=_ensure_aware(e.timestamp).isoformat(),
        )
        for e in events
    ]

    return RunDetailOut(
        id=run.run_id,
        project=run.project_name,
        suite=run.test_suite,
        started=_ensure_aware(run.started_at).isoformat(),
        completed=_ensure_aware(run.completed_at).isoformat() if run.completed_at else None,
        duration=_run_duration_display(run),
        passed=run.passed_count,
        failed=run.failed_count,
        status=run.status,
        results=result_out,
        artifacts=artifacts,
        events=event_out,
    )


# --- Run events ------------------------------------------------------------
async def record_event(
    run_id: str,
    type: str,  # noqa: A002 - matches event field name
    message: str,
    step_number: int | None = None,
    status: str | None = None,
) -> None:
    """Record a run lifecycle event idempotently.

    `event_key` (`run_id:type:step_number`) is unique, so a retried/duplicate
    event is a no-op (the DuplicateKeyError is swallowed) and never creates a
    second row.
    """
    event = RunEvent(
        run_id=run_id,
        event_key=f"{run_id}:{type}:{step_number}",
        type=type,
        message=message,
        step_number=step_number,
        status=status,
    )
    try:
        await event.insert()
    except DuplicateKeyError:
        return


async def list_events(run_id: str) -> list[RunEvent]:
    return await RunEvent.find(RunEvent.run_id == run_id).sort("+timestamp").to_list()


# --- Recording -------------------------------------------------------------
async def _resolve_project_name(subproject_id: str) -> str:
    try:
        oid = PydanticObjectId(subproject_id)
    except Exception:
        return ""
    proj = await SubProject.get(oid)
    return proj.name if proj is not None else ""


async def create_run(payload: RunCreateIn) -> Run:
    project_name = await _resolve_project_name(payload.subproject_id)
    for _ in range(10):
        run = Run(
            run_id=f"RUN-{random.randint(1000, 9999)}",
            subproject_id=payload.subproject_id,
            project_name=project_name,
            test_suite=payload.test_suite,
            status=RunStatus.RUNNING.value,
            passed_count=0,
            failed_count=0,
            workspace_base=payload.workspace_base or "",
        )
        try:
            await run.insert()
        except DuplicateKeyError:
            continue
        await refresh_metrics_snapshot()
        return run
    raise RuntimeError("Could not generate a unique run id")


async def complete_run(run_id: str, payload: RunCompleteIn) -> Run | None:
    run = await _get_run(run_id)
    if run is None:
        return None

    # Idempotent: a repeated completion for a terminal run is a no-op.
    if run.status in _TERMINAL_STATUSES:
        return run

    now = _utcnow()
    started = _ensure_aware(run.started_at)
    duration_ms = int((now - started).total_seconds() * 1000)

    passed = sum(1 for r in payload.results if r.status == TestResultStatus.PASSED.value)
    failed = sum(1 for r in payload.results if r.status == TestResultStatus.FAILED.value)

    # Persist the batch of test_results. executed_at defaults to the run's
    # completion time when a result omits its own execution timestamp.
    docs: list[TestResult] = []
    for r in payload.results:
        executed_at = _parse_dt(r.executed_at) or now
        docs.append(
            TestResult(
                run_id=run_id,
                subproject_id=run.subproject_id,
                testcase_ref=r.testcase_ref,
                status=r.status,
                failure_category=r.failure_category,
                duration_ms=r.duration_ms,
                executed_at=executed_at,
            )
        )
    if docs:
        await TestResult.insert_many(docs)

    run.status = payload.status
    run.completed_at = now
    run.duration_ms = max(duration_ms, 0)
    run.passed_count = passed
    run.failed_count = failed
    run.artifact_refs = [
        ArtifactRef(kind=a.kind, filename=a.filename, rel_path=a.rel_path)
        for a in payload.artifact_refs
    ]
    await run.save()
    await refresh_metrics_snapshot()
    return run
