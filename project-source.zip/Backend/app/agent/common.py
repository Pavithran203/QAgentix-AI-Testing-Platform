"""Common utilities and workspace protection guards for QAgentix agents."""
from __future__ import annotations

import os
from typing import Any

from app.core.config import settings


def validate_input_size(
    data: str | bytes | int,
    max_size: int,
    label: str = "Input",
) -> None:
    """Validate that input data does not exceed the maximum allowed size in bytes/characters.

    Raises:
        ValueError: When payload length exceeds max_size.
    """
    if isinstance(data, int):
        size = data
    elif isinstance(data, str):
        size = len(data.encode("utf-8"))
    elif isinstance(data, (bytes, bytearray)):
        size = len(data)
    else:
        size = len(str(data).encode("utf-8"))

    if size > max_size:
        raise ValueError(
            f"{label} size ({size} bytes) exceeds maximum allowed limit of {max_size} bytes."
        )


def validate_workspace_path(
    workspace_path: str | None = None,
    allowlist: list[str] | None = None,
) -> str:
    """Validate that the workspace directory resides within the configured allowlist.

    Guarantees:
    - Rejects null bytes (\\0).
    - Resolves relative paths against settings.resolved_workspace_root.
    - Resolves realpath (evaluating symlinks).
    - Ensures path resides inside at least one directory in the allowlist.
    - Raises PermissionError if workspace is outside allowlist.
    """
    raw = (workspace_path or "").strip()
    if not raw:
        target = settings.resolved_workspace_root
    elif os.path.isabs(raw):
        target = raw
    else:
        target = os.path.join(settings.resolved_workspace_root, raw)

    if "\0" in target:
        raise ValueError("Illegal null byte in workspace path.")

    real_target = os.path.realpath(os.path.abspath(target))
    allowed_roots = allowlist if allowlist is not None else settings.workspace_allowlist

    is_allowed = False
    for root in allowed_roots:
        real_root = os.path.realpath(root)
        try:
            if os.path.commonpath([real_root, real_target]) == real_root:
                is_allowed = True
                break
        except ValueError:
            # Cross-drive on Windows
            continue

    if not is_allowed:
        raise PermissionError(
            f"Workspace path '{workspace_path}' is outside approved workspace allowlist: {allowed_roots}"
        )

    return real_target


def validate_safe_path(
    base_dir: str,
    relative_path: str,
    must_exist: bool = False,
) -> str:
    """Ensure relative path does not escape base_dir lexically or via symlinks.

    Guarantees:
    - Rejects null bytes (\\0).
    - Rejects '..' traversal components.
    - Lexical containment check via os.path.commonpath.
    - Realpath / symlink containment check (target and all components must stay within base_dir).
    - Raises PermissionError on breach attempt.
    - Raises FileNotFoundError if must_exist is True and file is missing.
    """
    if "\0" in relative_path:
        raise ValueError("Illegal null byte in relative path.")

    clean_rel = relative_path.replace("\\", "/").strip()
    clean_rel = clean_rel.lstrip("/")

    # Check for traversal components
    parts = clean_rel.split("/")
    if ".." in parts:
        raise PermissionError(f"Path traversal (..) is strictly prohibited: '{relative_path}'")

    abs_base = os.path.abspath(base_dir)
    target = os.path.abspath(os.path.join(abs_base, clean_rel))

    # Lexical containment
    try:
        if os.path.commonpath([abs_base, target]) != abs_base:
            raise PermissionError(f"Workspace breach attempt: '{relative_path}' escapes '{base_dir}'")
    except ValueError:
        raise PermissionError(f"Cross-drive path breach attempt: '{relative_path}' escapes '{base_dir}'")

    # Realpath / Symlink check
    real_base = os.path.realpath(abs_base)
    real_target = os.path.realpath(target)

    try:
        if os.path.commonpath([real_base, real_target]) != real_base:
            raise PermissionError(
                f"Symlink traversal breach: '{relative_path}' resolves outside workspace boundary to '{real_target}'"
            )
    except ValueError:
        raise PermissionError(
            f"Symlink cross-drive breach: '{relative_path}' resolves to '{real_target}'"
        )

    # Walk each component from abs_base down to target to catch symlink components
    current = abs_base
    for part in parts:
        if not part:
            continue
        current = os.path.join(current, part)
        if os.path.islink(current):
            real_comp = os.path.realpath(current)
            try:
                if os.path.commonpath([real_base, real_comp]) != real_base:
                    raise PermissionError(
                        f"Symlink component breach: '{part}' in '{relative_path}' points outside workspace to '{real_comp}'"
                    )
            except ValueError:
                raise PermissionError(
                    f"Symlink component cross-drive breach: '{part}' points to '{real_comp}'"
                )

    if must_exist and not os.path.exists(target):
        raise FileNotFoundError(f"Target file not found: '{clean_rel}' in '{base_dir}'")

    return target


def _safe_workspace_write(
    workspace_path: str,
    relative_path: str,
    content: str,
    max_bytes: int | None = None,
    allowlist: list[str] | None = None,
) -> str:
    """Ensure safe write strictly inside the workspace boundary with allowlist and size limits.

    Guarantees:
    - Workspace must be in configured allowlist.
    - Content must not exceed max_bytes limit.
    - Relative path must not escape workspace lexically or via symlinks.
    - Directories are automatically provisioned.
    - Returns absolute file path.
    """
    valid_ws = validate_workspace_path(workspace_path, allowlist=allowlist)

    limit = max_bytes if max_bytes is not None else settings.max_file_write_bytes
    validate_input_size(content, limit, label="File write payload")

    target = validate_safe_path(valid_ws, relative_path)

    if os.path.islink(target):
        real_target = os.path.realpath(target)
        try:
            if os.path.commonpath([valid_ws, real_target]) != valid_ws:
                raise PermissionError(
                    f"Symlink overwrite breach attempt: '{relative_path}' points to '{real_target}'"
                )
        except ValueError:
            raise PermissionError(f"Symlink overwrite cross-drive breach attempt: '{relative_path}'")

    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(content)
    return target


def _safe_workspace_read(
    workspace_path: str,
    relative_path: str,
    max_bytes: int | None = None,
    allowlist: list[str] | None = None,
) -> str:
    """Ensure safe read strictly inside the workspace boundary with allowlist and size limits."""
    valid_ws = validate_workspace_path(workspace_path, allowlist=allowlist)
    target = validate_safe_path(valid_ws, relative_path, must_exist=True)

    limit = max_bytes if max_bytes is not None else settings.max_file_read_bytes
    file_size = os.path.getsize(target)
    validate_input_size(file_size, limit, label="File read")

    with open(target, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()



def extract_json_payload(raw_text: str) -> dict:
    """Extract and parse JSON dictionary from LLM or CLI output.

    Handles:
    - Pure JSON strings
    - Markdown fenced blocks (```json ... ``` or ``` ...)
    - Embedded JSON blocks within prose
    - Returns empty dict {} on unparseable / malformed input without raising exceptions.
    """
    import json
    import re

    if not raw_text or not raw_text.strip():
        return {}

    text = raw_text.strip()

    # 1. Direct parse attempt
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    # 2. Extract from ```json ... ``` or ``` ... ```
    fence_pattern = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if fence_pattern:
        try:
            data = json.loads(fence_pattern.group(1))
            if isinstance(data, dict):
                return data
        except Exception:
            pass

    # 3. Search for outermost { ... }
    brace_pattern = re.search(r"(\{.*\})", text, re.DOTALL)
    if brace_pattern:
        try:
            data = json.loads(brace_pattern.group(1))
            if isinstance(data, dict):
                return data
        except Exception:
            pass

    return {}
