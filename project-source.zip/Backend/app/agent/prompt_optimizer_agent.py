"""Prompt Optimizer Agent for QAgentix.

Why: User prompts are incomplete, ambiguous, or lack testing boundary constraints.
When it runs: Before every task (Backend Prompt Gate) and on each re-prompt.
Integrates: Lightweight LLM/Kiro call returning strict schema JSON: score, issues, missing_info, optimized_prompt.
Contract: JSON in/out (PromptOptimizerInput -> PromptOptimizerOutput). Does NOT call other agents.
"""
from __future__ import annotations

from app.schemas.agent_contracts import (
    PromptOptimizerAction,
    PromptOptimizerInput,
    PromptOptimizerOutput,
)


def run_prompt_optimizer(payload: PromptOptimizerInput) -> PromptOptimizerOutput:
    """Analyzes raw user prompt, computes quality score, and refines the requirement specification."""
    raw = payload.raw_prompt.strip()
    words = raw.split()
    lower = raw.lower()

    action_words = ["generate", "create", "write", "build", "test", "validate", "verify", "automate"]
    artifact_words = ["playwright", "test case", "script", "spec", "csv", "json", "suite", "pom"]
    detail_words = ["boundary", "negative", "edge", "smoke", "security", "rbac", "latency"]

    score = 0
    issues: list[str] = []
    missing_info: list[str] = []

    if len(words) >= 10:
        score += 25
    else:
        issues.append("Prompt is too brief (less than 10 words).")
        missing_info.append("Detailed functional requirements")

    if any(k in lower for k in action_words):
        score += 25
    else:
        issues.append("Missing explicit testing action verb.")
        missing_info.append("Action verb (e.g. generate, verify, automate)")

    if any(k in lower for k in artifact_words):
        score += 25
    else:
        missing_info.append("Target artifact format (Playwright, BDD feature, or test case matrix)")

    if any(k in lower for k in detail_words):
        score += 25
    else:
        missing_info.append("Scenario coverage depth (boundary, negative, or security edge cases)")

    # Decide Gate Action: >=80 proceed, 50-79 user approves, <50 clarify
    if score >= 80:
        action = PromptOptimizerAction.PROCEED
    elif score >= 50:
        action = PromptOptimizerAction.APPROVE
    else:
        action = PromptOptimizerAction.CLARIFY

    optimized = [
        f"Act as Senior QA Automation Architect. Requirement: {raw}.",
        "Scope & Deliverables:",
        "1. BDD Gherkin acceptance criteria in Features/.",
        "2. Complete Playwright TypeScript test suite using Page Object Model in Scripts/.",
        "3. Structured test case matrix with positive, boundary, and negative scenarios in Test_cases/.",
        "4. Data fixtures and parameterization in Test_data/.",
        "Constraint: Ensure tests are runnable, modular, and use resilient locators.",
    ]

    return PromptOptimizerOutput(
        score=score,
        issues=issues,
        missing_info=missing_info,
        optimized_prompt="\n".join(optimized),
        action=action,
    )
