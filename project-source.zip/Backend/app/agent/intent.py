"""Decide whether a chat message is a request to generate tests or just a question.

This is a transparent rule-based check, not an LLM. It errs towards generating
tests, because that is the product's purpose; only clear questions are diverted.
"""
from __future__ import annotations

import re

_GENERATE_VERBS = re.compile(
    r"\b(generate|create|write|build|automate|synthesi[sz]e|produce|make|scaffold|cover|draft)\b"
)
_QUESTION_START = re.compile(
    r"^(what|what's|whats|why|when|where|who|which|explain|define|describe|tell me|"
    r"can you explain|is|are|do|does|did)\b"
)
# "how to test the login page" asks for tests of a specific thing, so it is a generate request.
_HOW_TO_TEST = re.compile(r"^how (to|do i|can i|do we|should i|should we)\b.*\btest")


def is_question(prompt: str, has_files: bool = False) -> bool:
    """True when the message is a general question rather than a feature to test."""
    if has_files:
        return False
    p = " ".join(prompt.lower().split())
    if not p:
        return False
    if _GENERATE_VERBS.search(p) or _HOW_TO_TEST.match(p):
        return False
    return bool(_QUESTION_START.match(p))


_TOPIC_PATTERNS = [
    re.compile(r'^based on "(.+?)",', re.IGNORECASE | re.DOTALL),  # Based on "<topic>", generate ...
    re.compile(r'\bbased on:\s*(.+)$', re.IGNORECASE | re.DOTALL),  # ... based on: <topic>
    re.compile(r'\bfocus on:\s*"?(.+?)"?\.?\s*$', re.IGNORECASE | re.DOTALL),
    re.compile(r'\bfor:\s*(.+)$', re.IGNORECASE | re.DOTALL),  # ... for: <topic>
]


def extract_topic(prompt: str) -> str | None:
    """Pull the user's own topic out of a suggestion-card prompt.

    Cards wrap the user's text in instruction wording ("Extract functional ... based on: X").
    The instruction wording must not become the suite title, only X should.
    Returns None when the prompt has no such wrapper (typed prompts are used as they are).
    """
    for pattern in _TOPIC_PATTERNS:
        match = pattern.search(prompt.strip())
        if match and match.group(1).strip():
            return " ".join(match.group(1).split())
    return None


def detect_focus(prompt: str) -> str:
    """What the user asked to receive: suite | cases | script | edge."""
    p = prompt.lower()
    if re.search(r"project folder|project bundle|project for|test project|test suite|quality suite|complete", p):
        return "suite"
    if re.search(r"\bextract\b|matrix|spreadsheet|test cases", p):
        return "cases"
    if re.search(r"playwright script|locators|page object", p):
        return "script"
    if re.search(r"negative|boundary|edge", p):
        return "edge"
    return "suite"


def build_answer(prompt: str) -> str:
    """Reply for questions. No LLM is configured, so we say what we can and cannot do."""
    lines = [
        "That looks like a question rather than a feature to test, so I did not generate a test suite.",
        "",
        "I build Playwright test suites from a feature description or an uploaded spec. "
        "I can't answer open-ended questions yet, because no LLM provider is configured.",
    ]
    if "process" in prompt.lower():
        lines += [
            "",
            "The process in QAgentix runs in this order:",
            "1. Features: your input (a prompt, Excel or a spec file).",
            "2. Test script: the Playwright scenario for what should happen in the web app.",
            "3. Test cases: the steps and expected results, based on the script.",
            "4. Test data: the fixtures the scripts use.",
            "5. Report: results after the cases are executed.",
        ]
    lines += [
        "",
        "To get tests, describe what to test, for example: "
        "\"Test the login page with a wrong password and an expired session\".",
    ]
    return "\n".join(lines)
