"""Static safety checks and schema validation for QAgentix test execution.

Why: Ensure generated testcases, Playwright scripts, and Page Objects are schema-valid
and free of dangerous code patterns (RCE, subprocess spawn, eval, SSRF to cloud metadata,
destructive filesystem ops, process kill) BEFORE execution in the runner sandbox.

Integrates:
- TestCase & TestCaseItem schema validation
- Script contract and path validation (under Scripts/)
- Static AST/regex safety pattern inspection
- Pre-execution gate in execute_agent and kiro_agent
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

from pydantic import ValidationError

from app.agent.common import _safe_workspace_read, validate_safe_path, validate_workspace_path
from app.schemas.agent_contracts import TestCaseItem
from app.schemas.testcase import TestCase


class SafetyViolation:
    """Represents a static safety violation or schema failure."""

    def __init__(self, rule: str, message: str, line_number: int | None = None, snippet: str | None = None):
        self.rule = rule
        self.message = message
        self.line_number = line_number
        self.snippet = snippet

    def __repr__(self) -> str:
        loc = f":{self.line_number}" if self.line_number is not None else ""
        return f"[{self.rule}{loc}] {self.message}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule": self.rule,
            "message": self.message,
            "line_number": self.line_number,
            "snippet": self.snippet,
        }


# =============================================================================
# 1. STATIC SAFETY CHECK RULES (PLAYWRIGHT / NODE SCRIPTS)
# =============================================================================

DANGEROUS_PATTERNS: list[tuple[str, str, re.Pattern]] = [
    # Subprocess & Shell Command Execution
    (
        "DANGEROUS_SUBPROCESS",
        "Subprocess execution or shell command spawning is strictly prohibited.",
        re.compile(
            r"\b(child_process|execSync|spawnSync|execFile|execFileSync)\b|\b(exec|spawn|fork)\s*\(",
            re.IGNORECASE,
        ),
    ),
    # Dynamic Code Evaluation
    (
        "DYNAMIC_EVALUATION",
        "Dynamic evaluation via eval(), Function(), or vm context is prohibited.",
        re.compile(
            r"\b(eval|Function)\s*\(|\bvm\.(?:runInContext|runInNewContext|runInThisContext)\b",
        ),
    ),
    # Destructive Filesystem Operations
    (
        "DESTRUCTIVE_FILESYSTEM",
        "Destructive raw filesystem operations (rm, unlink, rimraf) are prohibited.",
        re.compile(
            r"\bfs\.(?:rmSync|rmdirSync|unlinkSync|rm|unlink)\b|\b(?:rm\s+-[rRfF]+|rimraf|del\s+/[fF])\b",
        ),
    ),
    # Process / Environment Tampering
    (
        "PROCESS_TAMPERING",
        "Process manipulation (process.exit, process.kill, delete process.env) is prohibited.",
        re.compile(
            r"\bprocess\.(?:exit|kill)\s*\(|\bdelete\s+process\.env\b",
        ),
    ),
    # SSRF & Cloud Metadata / Local File Exfiltration
    (
        "SSRF_CLOUD_METADATA",
        "Navigation to cloud instance metadata or loopback exfiltration endpoints is prohibited.",
        re.compile(
            r"169\.254\.169\.254|metadata\.google\.internal|100\.100\.100\.200",
            re.IGNORECASE,
        ),
    ),
    (
        "DISALLOWED_PROTOCOL",
        "Navigation via file:// or javascript: pseudo-protocols is prohibited.",
        re.compile(
            r"['\"`](?:file://|javascript:)",
            re.IGNORECASE,
        ),
    ),
    # Raw Network / Socket Modules
    (
        "DISALLOWED_NETWORK_MODULE",
        "Raw network socket modules (net, dgram, cluster) are prohibited.",
        re.compile(
            r"(?:require\s*\(\s*['\"]|import\s+.*from\s+['\"])(?:net|dgram|cluster|dns)['\"]",
        ),
    ),
]


def run_static_safety_checks(script_content: str, script_name: str = "") -> tuple[bool, list[str]]:
    """Scan script content statically for dangerous patterns before execution.

    Args:
        script_content: Source code of the Playwright spec or Page Object.
        script_name: Optional script path/name for reporting context.

    Returns:
        (is_safe, list_of_violations)
    """
    if not script_content or not script_content.strip():
        return False, [f"Script '{script_name}' is empty."]

    violations: list[str] = []
    lines = script_content.splitlines()

    for line_idx, line in enumerate(lines, start=1):
        stripped = line.strip()

        # Skip comment lines
        if stripped.startswith("//") or stripped.startswith("/*") or stripped.startswith("*"):
            continue

        for rule_id, description, pattern in DANGEROUS_PATTERNS:
            match = pattern.search(line)
            if match:
                matched_token = match.group(0)
                snippet = stripped[:80]
                violation = SafetyViolation(
                    rule=rule_id,
                    message=f"{description} (matched: '{matched_token}')",
                    line_number=line_idx,
                    snippet=snippet,
                )
                loc_info = f"{script_name}:{line_idx}" if script_name else f"line {line_idx}"
                violations.append(f"{loc_info} - {violation}")

    return len(violations) == 0, violations


# =============================================================================
# 2. SCRIPT SCHEMA & CONTRACT VALIDATION
# =============================================================================

def validate_script_contract(
    script_path: str,
    script_content: str | None = None,
) -> tuple[bool, list[str]]:
    """Verify that a script path adheres to workspace conventions and Playwright structure.

    Rules:
    - Path must be located under Scripts/
    - Extension must be .spec.ts, .spec.js, .test.ts, or .ts
    - Content must define a Playwright test or Page Object class
    """
    errors: list[str] = []
    clean_path = script_path.replace("\\", "/").strip().lstrip("/")

    if ".." in clean_path.split("/"):
        errors.append(f"Script path '{script_path}' contains illegal path traversal.")
        return False, errors

    if not clean_path.startswith("Scripts/"):
        errors.append(f"Script path '{script_path}' must reside under 'Scripts/' directory contract.")

    allowed_exts = (".spec.ts", ".spec.js", ".test.ts", ".test.js", ".ts", ".js")
    if not any(clean_path.endswith(ext) for ext in allowed_exts):
        errors.append(f"Script path '{script_path}' must have a valid TypeScript/JavaScript test extension.")

    if script_content is not None:
        if not script_content.strip():
            errors.append(f"Script file '{script_path}' content is empty.")
        else:
            # If it's a spec file, verify test assertions/blocks
            if ".spec." in clean_path or ".test." in clean_path:
                if "@playwright/test" not in script_content and "test(" not in script_content and "test.describe" not in script_content:
                    errors.append(f"Spec file '{script_path}' lacks Playwright test structure (test, test.describe, or @playwright/test import).")
            # If it's a page object, verify class definition
            elif "pages/" in clean_path:
                if "class " not in script_content:
                    errors.append(f"Page Object '{script_path}' must export a Page Object class definition.")

    return len(errors) == 0, errors


# =============================================================================
# 3. TESTCASE SCHEMA VALIDATION
# =============================================================================

def validate_testcase_schema(data: Any) -> tuple[bool, list[str]]:
    """Validate test case items against TestCase and TestCaseItem schemas.

    Supports:
    - Single dict or list of dicts
    - TestCase or TestCaseItem instances
    - Raw JSON string
    """
    errors: list[str] = []

    # If raw JSON string passed
    if isinstance(data, str):
        try:
            parsed = json.loads(data)
            data = parsed
        except Exception as exc:
            return False, [f"Malformed testcases JSON: {exc}"]

    # List of test cases
    if isinstance(data, list):
        if not data:
            return False, ["Testcases dataset is empty; at least one test case is required."]
        for idx, item in enumerate(data):
            ok, item_errors = _validate_single_testcase(item, index=idx)
            if not ok:
                errors.extend(item_errors)
        return len(errors) == 0, errors

    # Single test case
    return _validate_single_testcase(data)


def _validate_single_testcase(item: Any, index: int | None = None) -> tuple[bool, list[str]]:
    """Validate a single test case object."""
    prefix = f"Testcase #{index + 1}" if index is not None else "Testcase"

    if isinstance(item, (TestCase, TestCaseItem)):
        # Already validated Pydantic model
        tc_dict = item.model_dump()
    elif isinstance(item, dict):
        tc_dict = item
    else:
        return False, [f"{prefix}: Expected dict or TestCase model, got {type(item).__name__}."]

    # Step validation check
    steps = tc_dict.get("steps")
    if steps is None or (isinstance(steps, (list, tuple)) and len(steps) == 0) or (isinstance(steps, str) and not steps.strip()):
        return False, [f"{prefix}: Test case must contain at least one step."]

    # Expected result check
    exp = tc_dict.get("expectedResult") or tc_dict.get("expected_result")
    if not exp or (isinstance(exp, str) and not exp.strip()):
        return False, [f"{prefix}: Test case must contain an expected result."]

    # Try full QAgentix TestCase schema validation
    try:
        TestCase.model_validate(tc_dict)
        return True, []
    except ValidationError:
        pass

    # Fallback to TestCaseItem schema validation
    try:
        TestCaseItem.model_validate(tc_dict)
        return True, []
    except ValidationError as val_err:
        errors: list[str] = []
        for err in val_err.errors():
            loc = ".".join(str(p) for p in err.get("loc", []))
            msg = err.get("msg", "Invalid field")
            errors.append(f"{prefix} [{loc}]: {msg}")
        return False, errors

    return False, [f"{prefix}: Schema validation failed."]



# =============================================================================
# 4. PRE-EXECUTION COMPREHENSIVE SAFETY & SCHEMA GATE
# =============================================================================

def validate_pre_execution_safety(
    workspace_path: str,
    script_paths: list[str],
) -> tuple[bool, list[str]]:
    """Perform pre-execution validation on workspace, testcase schemas, and scripts.

    Guarantees:
    1. Workspace is allowlisted.
    2. If Test_cases/testcases.json exists, its schema is thoroughly validated.
    3. Each script in script_paths satisfies script contract and contains no static safety violations.
    4. Blocks execution on any schema defect or safety breach.

    Returns:
        (is_safe, list_of_issues)
    """
    issues: list[str] = []

    # 1. Validate Workspace Allowlist
    try:
        valid_ws = validate_workspace_path(workspace_path)
    except Exception as exc:
        return False, [f"Workspace allowlist violation: {exc}"]

    # 2. Validate Testcase Schemas if testcases.json exists in workspace
    tc_file = os.path.join(valid_ws, "Test_cases", "testcases.json")
    if os.path.isfile(tc_file):
        try:
            with open(tc_file, "r", encoding="utf-8") as fh:
                tc_data = json.load(fh)
            tc_ok, tc_errors = validate_testcase_schema(tc_data)
            if not tc_ok:
                issues.extend([f"Testcase Schema Error: {err}" for err in tc_errors])
        except Exception as exc:
            issues.append(f"Failed to load or parse Test_cases/testcases.json: {exc}")

    # 3. Validate Each Script & Page Object
    if not script_paths:
        issues.append("No script paths provided for execution.")
        return False, issues

    for script_rel in script_paths:
        # Contract validation
        contract_ok, contract_errors = validate_script_contract(script_rel)
        if not contract_ok:
            issues.extend(contract_errors)
            continue

        # File containment and existence
        try:
            script_abs = validate_safe_path(valid_ws, script_rel, must_exist=True)
        except Exception as exc:
            issues.append(f"Invalid script path '{script_rel}': {exc}")
            continue

        # Read script content safely
        try:
            content = _safe_workspace_read(valid_ws, script_rel)
        except Exception as exc:
            issues.append(f"Failed to read script '{script_rel}': {exc}")
            continue

        # Contract structure check
        contract_content_ok, content_errors = validate_script_contract(script_rel, script_content=content)
        if not contract_content_ok:
            issues.extend(content_errors)

        # Static Safety Checks (blocking unsafe patterns)
        safe_ok, safety_violations = run_static_safety_checks(content, script_name=script_rel)
        if not safe_ok:
            issues.extend(safety_violations)

        # Also check referenced Page Object under Scripts/pages/ if imported
        for pom_match in re.findall(r"['\"](?:\./pages/|pages/)([^'\"]+Page)['\"]", content):
            pom_rel = f"Scripts/pages/{pom_match}.ts"
            pom_abs = os.path.join(valid_ws, pom_rel)
            if os.path.isfile(pom_abs):
                try:
                    pom_content = _safe_workspace_read(valid_ws, pom_rel)
                    pom_safe, pom_violations = run_static_safety_checks(pom_content, script_name=pom_rel)
                    if not pom_safe:
                        issues.extend(pom_violations)
                except Exception as exc:
                    issues.append(f"Failed reading referenced Page Object '{pom_rel}': {exc}")

    return len(issues) == 0, issues
