"""Script Agent for QAgentix.

Why: Create, update, analyse, and fix automated Playwright test scripts.
When it runs: After testcases/data are generated, and on each failed run to heal selectors.
Integrates: Uses Page Object Model (POM) + locator conventions; edits as diffs inside Scripts/ and Scripts/pages/.
Contract: JSON in/out (ScriptAgentInput -> ScriptAgentOutput). Writes only inside workspace folder contract (Scripts/). Does NOT call other agents.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

from app.agent.common import _safe_workspace_write
from app.schemas.agent_contracts import (
    LocatorReference,
    ScriptAgentInput,
    ScriptAgentOutput,
    TestCaseItem,
    TestCaseScriptLink,
)


def _default_locators_for_subject(slug: str, testcases: list[TestCaseItem]) -> list[LocatorReference]:
    """Derive semantic locator references based on testcases and subject context."""
    case_ids = [tc.id for tc in testcases]
    locators: list[LocatorReference] = [
        LocatorReference(
            name="submitButton",
            strategy="role",
            selector="button",
            options={"name": "/submit|login|confirm|execute|apply/i"},
            description="Primary action submission button",
            linked_testcase_ids=case_ids,
            healing_candidates=[
                "[data-testid='submit-btn']",
                "button[type='submit']",
                ".btn-primary",
                "button:has-text('Submit')",
            ],
        ),
        LocatorReference(
            name="inputField",
            strategy="role",
            selector="textbox",
            options={},
            description="Primary text input or search field",
            linked_testcase_ids=case_ids,
            healing_candidates=[
                "input[type='text']",
                "[data-testid='main-input']",
                ".form-control",
            ],
        ),
        LocatorReference(
            name="toastAlert",
            strategy="css",
            selector="[role='alert'], .toast, .notification",
            options={},
            description="Feedback toast alert or notification popup",
            linked_testcase_ids=case_ids,
            healing_candidates=[
                ".alert-success",
                "[data-testid='toast-notification']",
                ".ant-notification-notice",
            ],
        ),
        LocatorReference(
            name="sourceSelect",
            strategy="testId",
            selector="source-select",
            options={},
            description="Dropdown menu for source/channel selection",
            linked_testcase_ids=[tc.id for tc in testcases if "source" in tc.title.lower() or "channel" in tc.title.lower()],
            healing_candidates=[
                "select[name='source']",
                "[aria-label='Select Source']",
                ".source-dropdown",
            ],
        ),
        LocatorReference(
            name="activeBadge",
            strategy="css",
            selector="[data-testid='active-badge'], .badge-active, .status-badge",
            options={},
            description="Indicator badge displaying active selection state",
            linked_testcase_ids=[tc.id for tc in testcases if "badge" in tc.expectedResult.lower() or "active" in tc.expectedResult.lower()],
            healing_candidates=[
                ".badge",
                "[role='status']",
                ".selection-badge",
            ],
        ),
        LocatorReference(
            name="filterCheckbox",
            strategy="role",
            selector="checkbox",
            options={"name": "/filter|voice|status/i"},
            description="Table column filtering checkbox",
            linked_testcase_ids=[tc.id for tc in testcases if "filter" in tc.title.lower() or "voice" in tc.title.lower()],
            healing_candidates=[
                "input[type='checkbox']",
                "[data-testid='filter-checkbox']",
                ".filter-option",
            ],
        ),
        LocatorReference(
            name="paginationNext",
            strategy="role",
            selector="button",
            options={"name": "/next|page 2/i"},
            description="Table pagination next page button",
            linked_testcase_ids=[tc.id for tc in testcases if "pagination" in tc.title.lower() or "page" in tc.title.lower()],
            healing_candidates=[
                "[data-testid='pagination-next']",
                ".pagination-next",
                "button[aria-label='Next Page']",
            ],
        ),
    ]
    return locators


def run_script_agent(payload: ScriptAgentInput) -> ScriptAgentOutput:
    """Generates Playwright scripts + POM classes in Scripts/ and Scripts/pages/ linked to testcase IDs."""
    slug = re.sub(r"[^a-z0-9]+", "_", payload.subject.lower()).strip("_") or "suite"
    page_class = f"{slug.title().replace('_', '')}Page"

    spec_rel = f"Scripts/{slug}.spec.ts"
    pom_rel = f"Scripts/pages/{page_class}.ts"

    # 1. Resolve testcases to link
    cases: list[TestCaseItem] = list(payload.testcases)
    if not cases:
        cases = [
            TestCaseItem(
                id="TC-101",
                title="Primary workflow execution",
                description="Executes core workflow with valid test inputs.",
                category="Smoke",
                priority="High",
                steps=["Navigate to application", "Input test parameters", "Submit form", "Assert toast confirmation"],
                expectedResult="Operation completes successfully with 200 OK state.",
            ),
            TestCaseItem(
                id="TC-102",
                title="Reject malformed payload",
                description="Rejects malformed or unsafe input injection.",
                category="Boundary",
                priority="High",
                steps=["Input invalid payload '<script>alert(1)</script>'", "Click submit", "Assert error banner"],
                expectedResult="Application safely rejects invalid input without crashing.",
            ),
            TestCaseItem(
                id="TC-104",
                title="Timeout and retry resilience",
                description="Handles network timeout and latency degradation gracefully.",
                category="Boundary",
                priority="Medium",
                steps=["Trigger action under simulated latency", "Observe retry container"],
                expectedResult="UI displays retry container with valid page state.",
            ),
        ]

    linked_ids = [c.id for c in cases]

    # 2. Resolve Locator References
    locators = payload.locators or _default_locators_for_subject(slug, cases)

    # If mode is "fix" and failure_log mentions broken locator, apply self-healing candidate
    if payload.mode == "fix" and payload.failure_log:
        for loc in locators:
            if loc.name in payload.failure_log and loc.healing_candidates:
                loc.selector = loc.healing_candidates[0]

    locator_map = {loc.name: loc for loc in locators}

    # 3. Build Case Links
    case_links: list[TestCaseScriptLink] = []
    for tc in cases:
        title_lower = (tc.title + " " + " ".join(tc.steps)).lower()
        used_locators: list[str] = ["submitButton", "inputField"]
        if "source" in title_lower or "channel" in title_lower:
            used_locators.append("sourceSelect")
        if "badge" in title_lower or "active" in title_lower:
            used_locators.append("activeBadge")
        if "filter" in title_lower or "voice" in title_lower:
            used_locators.append("filterCheckbox")
        if "page" in title_lower or "pagination" in title_lower:
            used_locators.append("paginationNext")
        if "alert" in title_lower or "toast" in title_lower or "success" in title_lower:
            used_locators.append("toastAlert")

        case_links.append(
            TestCaseScriptLink(
                testcase_id=tc.id,
                title=tc.title,
                test_block_name=f"[@{tc.id}] {tc.title}",
                spec_path=spec_rel,
                page_class=page_class,
                locators_used=used_locators,
                expected_result=tc.expectedResult,
            )
        )

    # 4. Generate Page Object Model TypeScript Code
    pom_locator_declarations = "\n".join(
        f"  /** Locator linked to: {', '.join(loc.linked_testcase_ids) or 'Suite'} */\n"
        f"  readonly {loc.name}: Locator;"
        for loc in locators
    )

    pom_constructor_inits = []
    for loc in locators:
        if loc.strategy == "role":
            opts_str = json.dumps(loc.options)
            opts_formatted = re.sub(r'"/([^"]+)/([a-z]*)"', r'/\1/\2', opts_str)
            pom_constructor_inits.append(
                f"    this.{loc.name} = page.getByRole('{loc.selector}', {opts_formatted}).first();"
            )
        elif loc.strategy == "testId":
            pom_constructor_inits.append(
                f"    this.{loc.name} = page.getByTestId('{loc.selector}').first();"
            )
        else:
            pom_constructor_inits.append(
                f"    this.{loc.name} = page.locator('{loc.selector}').first();"
            )
    pom_inits_code = "\n".join(pom_constructor_inits)

    pom_code = f"""import {{ type Page, type Locator, expect }} from '@playwright/test';

/**
 * Page Object Model for {payload.subject.title()}
 * Linked Test Cases: {', '.join(linked_ids)}
 */
export class {page_class} {{
  readonly page: Page;
{pom_locator_declarations}

  constructor(page: Page) {{
    this.page = page;
{pom_inits_code}
  }}

  /** Navigate to target application root */
  async goto(): Promise<void> {{
    await this.page.goto(process.env.APP_URL || 'https://demo.qagentix.io');
    await this.page.waitForLoadState('domcontentloaded');
  }}

  /** Fill input and trigger primary execution */
  async executeAction(text?: string): Promise<void> {{
    if (text && await this.inputField.isVisible()) {{
      await this.inputField.fill(text);
    }}
    if (await this.submitButton.isVisible()) {{
      await this.submitButton.click();
    }}
  }}

  /** Select channel source from dropdown */
  async selectSource(sourceName: string = 'Rammas'): Promise<void> {{
    if (await this.sourceSelect.isVisible()) {{
      await this.sourceSelect.click();
      await this.page.getByRole('option', {{ name: sourceName }}).first().click();
    }}
  }}

  /** Apply table filter option */
  async applyFilter(optionName?: string): Promise<void> {{
    if (await this.filterCheckbox.isVisible()) {{
      await this.filterCheckbox.check();
    }}
  }}

  /** Navigate through paginated tables */
  async advancePage(): Promise<void> {{
    if (await this.paginationNext.isVisible()) {{
      await this.paginationNext.click();
      await this.page.waitForTimeout(200);
    }}
  }}

  /** Assert toast alert visibility */
  async expectSuccess(): Promise<void> {{
    await expect(this.toastAlert).toBeVisible({{ timeout: 5000 }});
  }}

  /** Assert active selection badge text */
  async expectBadgeText(expected: string): Promise<void> {{
    if (await this.activeBadge.isVisible()) {{
      await expect(this.activeBadge).toContainText(expected);
    }}
  }}
}}
"""

    # 5. Generate Playwright Spec TypeScript Code
    spec_tests = []
    for link in case_links:
        tc_item = next((c for c in cases if c.id == link.testcase_id), None)
        priority_label = tc_item.priority if tc_item else "High"
        category_label = tc_item.category if tc_item else "Smoke"

        # Specialized assertion steps per scenario
        action_statements = []
        if "source" in link.title.lower() or "channel" in link.title.lower():
            action_statements = [
                "    await pageObject.selectSource('Rammas');",
                "    await pageObject.expectBadgeText('Rammas');",
                "    await expect(page.locator('body')).not.toBeEmpty();",
            ]
        elif "filter" in link.title.lower() or "pagination" in link.title.lower():
            action_statements = [
                "    await pageObject.applyFilter();",
                "    await pageObject.advancePage();",
                "    await expect(pageObject.filterCheckbox).toBeChecked();",
            ]
        elif "malformed" in link.title.lower() or "reject" in link.title.lower() or "boundary" in link.title.lower():
            action_statements = [
                "    await pageObject.executeAction('<script>alert(1)</script>');",
                "    await expect(page.locator('.critical-crash')).toHaveCount(0);",
            ]
        elif "timeout" in link.title.lower() or "latency" in link.title.lower():
            action_statements = [
                "    await page.waitForTimeout(300);",
                "    expect(await page.title()).toBeDefined();",
            ]
        else:
            action_statements = [
                "    await pageObject.executeAction('test-payload');",
                "    await pageObject.expectSuccess();",
                "    await expect(page.locator('body')).not.toBeEmpty();",
            ]

        actions_code = "\n".join(action_statements)

        spec_tests.append(f"""  /**
   * Test Case ID: {link.testcase_id}
   * Priority: {priority_label} | Category: {category_label}
   * Expected: {link.expected_result}
   * Locators: {", ".join(link.locators_used)}
   */
  test('{link.test_block_name}', async ({{ page }}) => {{
{actions_code}
  }});""")

    all_tests_code = "\n\n".join(spec_tests)

    spec_code = f"""import {{ test, expect }} from '@playwright/test';
import {{ {page_class} }} from './pages/{page_class}';

/**
 * Automated Playwright Suite for {payload.subject.title()}
 * Linked Test Cases: {', '.join(linked_ids)}
 */
test.describe('{payload.subject.title()} Automated Suite', () => {{
  let pageObject: {page_class};

  test.beforeEach(async ({{ page }}) => {{
    pageObject = new {page_class}(page);
    await pageObject.goto();
  }});

{all_tests_code}
}});
"""

    # 6. Write files safely inside workspace contract
    _safe_workspace_write(payload.workspace_path, pom_rel, pom_code)
    _safe_workspace_write(payload.workspace_path, spec_rel, spec_code)

    # 7. Update Test_cases/testcases.json if it exists to link script_path & test_method
    tc_json_abs = os.path.join(payload.workspace_path, "Test_cases", "testcases.json")
    if os.path.isfile(tc_json_abs):
        try:
            with open(tc_json_abs, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict) and item.get("id") in linked_ids:
                        item["scriptPath"] = spec_rel
                        item["testMethod"] = f"[@{item['id']}] {item.get('title', '')}"
                with open(tc_json_abs, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, indent=2)
        except Exception:
            pass

    return ScriptAgentOutput(
        spec_path=spec_rel,
        page_object_path=pom_rel,
        linked_testcase_ids=linked_ids,
        case_links=case_links,
        locator_references=locators,
        spec_content=spec_code,
        page_object_content=pom_code,
        git_commit_summary=f"feat(scripts): add Playwright spec and {page_class} linked to {len(linked_ids)} test cases ({', '.join(linked_ids)})",
    )
