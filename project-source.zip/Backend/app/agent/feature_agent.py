"""Feature Agent for QAgentix.

Why: Turn BRD / prompt / user requirement into testable BDD features.
When it runs: When the user supplies requirements or specifies a new application capability.
Integrates: Writes Gherkin acceptance criteria (.feature) inside Features/.
Contract: JSON in/out (FeatureAgentInput -> FeatureAgentOutput). Writes only inside workspace folder contract (Features/). Does NOT call other agents.
"""
from __future__ import annotations

import re

from app.agent.common import _safe_workspace_write
from app.schemas.agent_contracts import (
    FeatureAgentInput,
    FeatureAgentOutput,
)


def run_feature_agent(payload: FeatureAgentInput) -> FeatureAgentOutput:
    """Turns requirements into BDD Gherkin specifications and writes Features/*.feature."""
    name = payload.feature_name or "feature"
    clean_name = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    rel_path = f"Features/{clean_name}.feature"

    gherkin = f"""Feature: {name.title()} Verification
  As a quality assurance engineer
  I want to verify {name}
  So that user workflows operate reliably without regression defects

  Background:
    Given the user navigates to the target application
    And the application has loaded successfully

  @smoke @critical
  Scenario: TC-101 Verify primary workflow happy path
    When the user submits valid parameters from test data
    Then the system accepts the operation
    And a confirmation notification is visible

  @boundary
  Scenario: TC-102 Verify boundary and invalid input handling
    When the user submits malformed or boundary characters
    Then the application rejects the payload
    And an inline validation warning is displayed

  @security
  Scenario: TC-103 Verify authorization and access control
    Given the user is authenticated with standard privileges
    When an administrative action is attempted
    Then access is denied with a 403 status code
"""

    _safe_workspace_write(payload.workspace_path, rel_path, gherkin)

    return FeatureAgentOutput(
        feature_file_path=rel_path,
        feature_name=name.title(),
        scenarios_count=3,
        gherkin_content=gherkin,
    )
