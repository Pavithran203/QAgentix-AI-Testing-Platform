"""Data-driven Agent for QAgentix.

Why: Parameterise tests from local files / requirements into structured fixtures.
When it runs: When the user supplies local files, CSV/Excel/JSON, or requests fixture datasets.
Integrates: Reads files only inside the workspace allowlist; writes parameterization fixtures to Test_data/.
Contract: JSON in/out (DataDrivenAgentInput -> DataDrivenAgentOutput). Writes only inside workspace folder contract (Test_data/). Does NOT call other agents.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import re

from app.agent.common import _safe_workspace_write
from app.schemas.agent_contracts import (
    DataDrivenAgentInput,
    DataDrivenAgentOutput,
)


def run_data_driven_agent(payload: DataDrivenAgentInput) -> DataDrivenAgentOutput:
    """Parameterizes tests and writes Test_data/*_fixtures.json."""
    slug = re.sub(r"[^a-z0-9]+", "_", payload.subject.lower()).strip("_") or "data"
    rel_path = f"Test_data/{slug}_fixtures.json"

    fixtures = {
        "validUser": {
            "username": "qa-tester@qagentix.io",
            "role": "Admin",
            "actionTimeoutMs": 5000,
        },
        "boundaryInputs": {
            "empty": "",
            "maxLength": "A" * 255,
            "specialChars": "!@#$%^&*()_+{}[]:;<>,.?",
            "scriptInjection": "<script>alert('XSS')</script>",
        },
        "metadata": {
            "dataset": slug,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
        },
    }

    content = json.dumps(fixtures, indent=2)
    _safe_workspace_write(payload.workspace_path, rel_path, content)

    return DataDrivenAgentOutput(
        testdata_path=rel_path,
        dataset_mapping={"userCredentials": "validUser", "boundaryPayloads": "boundaryInputs"},
        fixtures_content=content,
    )
