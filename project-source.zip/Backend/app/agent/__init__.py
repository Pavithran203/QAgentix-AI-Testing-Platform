"""QAgentix Multi-Agent Architecture Package.

Every agent speaks JSON in and out (schema-validated by the backend),
writes only inside the workspace folder contract, and never calls another agent directly.
Kiro Main Agent is the only caller.
"""
from app.agent.common import (
    _safe_workspace_read,
    _safe_workspace_write,
    extract_json_payload,
    validate_input_size,
    validate_safe_path,
    validate_workspace_path,
)
from app.agent.kiro_agent import run_kiro_agent
from app.agent.prompt_optimizer_agent import run_prompt_optimizer
from app.agent.prompt_suggestion_agent import run_prompt_suggestion
from app.agent.planner_agent import run_planner
from app.agent.feature_agent import run_feature_agent
from app.agent.testcase_agent import run_testcase_agent
from app.agent.data_driven_agent import run_data_driven_agent
from app.agent.script_agent import run_script_agent
from app.agent.execute_agent import run_execute_agent
from app.agent.report_agent import run_report_agent

from app.agent.safety import (
    run_static_safety_checks,
    validate_pre_execution_safety,
    validate_script_contract,
    validate_testcase_schema,
)

__all__ = [
    "run_kiro_agent",
    "run_prompt_optimizer",
    "run_prompt_suggestion",
    "run_planner",
    "run_feature_agent",
    "run_testcase_agent",
    "run_data_driven_agent",
    "run_script_agent",
    "run_execute_agent",
    "run_report_agent",
    "_safe_workspace_write",
    "_safe_workspace_read",
    "validate_workspace_path",
    "validate_safe_path",
    "validate_input_size",
    "extract_json_payload",
    "run_static_safety_checks",
    "validate_script_contract",
    "validate_testcase_schema",
    "validate_pre_execution_safety",
]


