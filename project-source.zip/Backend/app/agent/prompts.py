# Test Script Generation Prompt

You are generating a test script for this project. First inspect the repository's existing code and conventions. Do not assume the framework, language, test runner, or execution flow.

## Before writing the script

1. Inspect `Features`, `Scripts`, `Test_cases`, `Test_data`, and `Reports`, along with relevant configuration and existing tests.
2. Trace how an existing test moves from its feature or test case through script execution and reporting.
3. Identify the language, framework, naming conventions, setup and teardown patterns, selectors or APIs, data-loading approach, and reporting format.
4. Reuse existing helpers and patterns where appropriate. Do not duplicate utilities or introduce a new framework.
5. If required details are missing or contradictory, list them and state your assumptions before generating code.

## Generate

Create a test script for this scenario:

[Describe the scenario, inputs, expected outcomes, and important edge cases.]

Follow the repository's conventions. Use test data from the project's established location when appropriate. Include clear assertions for expected behavior and useful failure messages. Keep the script focused on the requested scenario.

## Output

Return:
- The proposed file path.
- The complete script.
- Any test data or supporting changes required.
- The command or project-specific method to run it.
- Assumptions or unresolved details.

Do not claim the script was executed unless it actually was.