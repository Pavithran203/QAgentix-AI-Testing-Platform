"""Kiro IDE / CLI Agent Service.

Connects the QAgentix backend to Kiro IDE / CLI to execute tasks agentically.
Runs headless `kiro-cli chat` sessions inside the selected project workspace,
parses progress, discovers generated test artifacts, and provides seamless fallback.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
import json
import logging
import os
import re
import shutil
import subprocess
import time
import uuid
from typing import AsyncGenerator

from app.core.config import settings
from app.core.llm import generate as fallback_llm_generate
from app.schemas.kiro import (
    KiroExecuteRequest,
    KiroExecuteResponse,
    KiroGeneratedArtifact,
    KiroModelItem,
    KiroModelsResponse,
    KiroStatusResponse,
    KiroStepLog,
)
from app.agent.common import _safe_workspace_write
from app.agent.prompt_optimizer_agent import run_prompt_optimizer
from app.agent.prompt_suggestion_agent import run_prompt_suggestion
from app.agent.planner_agent import run_planner
from app.agent.feature_agent import run_feature_agent
from app.agent.testcase_agent import run_testcase_agent
from app.agent.data_driven_agent import run_data_driven_agent
from app.agent.script_agent import run_script_agent
from app.agent.execute_agent import run_execute_agent
from app.agent.report_agent import run_report_agent
from app.schemas.agent_contracts import (
    PromptOptimizerInput,
    PromptOptimizerAction,
    PromptSuggestionInput,
    PlannerInput,
    FeatureAgentInput,
    TestcaseAgentInput,
    DataDrivenAgentInput,
    ScriptAgentInput,
    ExecuteAgentInput,
    ReportAgentInput,
)
from app.services import dashboard_service
from app.schemas.dashboard import (
    RunCreateIn,
    RunCompleteIn,
    TestResultIn,
    ArtifactRefIn,
)
from app.models.run import Run, RunStatus
from app.models.test_result import TestResultStatus

logger = logging.getLogger("uvicorn.error")


CONVERSATIONAL_PROMPTS = {
    "hi", "hello", "hey", "hey there", "ping", "test", "hello kiro", "hi kiro",
    "greetings", "good morning", "good evening", "good afternoon"
}


def is_conversational_prompt(prompt: str) -> bool:
    """Check if the user is greeting or testing connection (e.g. 'hi', 'ping', 'hello')."""
    clean = (prompt or "").strip().lower().rstrip("!?., ")
    return clean in CONVERSATIONAL_PROMPTS


def validate_requirements_prompt(prompt: str, has_document: bool = False) -> bool:
    """Validate whether the prompt describes requirements, test cases, or coding tasks to generate."""
    if has_document:
        return True

    clean = (prompt or "").strip().lower()
    if not clean or len(clean) < 3:
        return False

    trivial = {
        "hi", "hello", "hey", "hey there", "good morning", "good evening",
        "sup", "yo", "how are you", "who are you", "what can you do", "help",
        "ok", "okay", "thanks", "thank you", "bye", "asdf"
    }
    cleaned_simple = clean.rstrip("!?., ")
    if cleaned_simple in trivial:
        return False

    # Testing and software verification keywords
    keywords = [
        "test", "tests", "testing", "testcase", "testcases", "test case", "test cases",
        "scenario", "scenarios", "suite", "playwright", "automation", "automate",
        "e2e", "smoke", "regression", "sanity", "boundary", "assert", "assertion",
        "verify", "verification", "validation", "validate", "spec", "specs", "specification",
        "acceptance", "coverage", "bdd", "gherkin", "pom", "requirement", "requirements",
        "user story", "criteria", "endpoint", "api", "auth", "login", "logout",
        "signup", "register", "password", "token", "dashboard",
        "payment", "checkout", "cart", "filter", "pagination",
        "modal", "workflow", "crud", "status code",
        "locator", "locators", "selector", "mock", "fixture", "unit test",
    ]

    words = set(re.findall(r"\b[a-z0-9_/-]+\b", clean))
    for kw in keywords:
        if " " in kw:
            if kw in clean:
                return True
        elif kw in words:
            return True

    return False


def find_kiro_binary() -> str | None:
    """Locate the kiro-cli or kiro executable on the system."""
    configured_path = settings.kiro_cli_path
    if configured_path and os.path.exists(configured_path):
        return configured_path
    
    # Try finding in PATH
    for candidate in [configured_path, "kiro-cli", "kiro", "kiro.cmd"]:
        if candidate:
            found = shutil.which(candidate)
            if found:
                return found

    # Check common user installation directories on Windows
    local_app_data = os.getenv("LOCALAPPDATA", "")
    app_data = os.getenv("APPDATA", "")
    program_files = os.getenv("ProgramFiles", "")

    common_locations = [
        os.path.join(local_app_data, "Programs", "Kiro", "bin", "kiro.cmd"),
        os.path.join(local_app_data, "Programs", "Kiro", "kiro-cli.exe"),
        os.path.join(local_app_data, "Programs", "kiro", "bin", "kiro-cli.exe"),
        os.path.join(app_data, "npm", "kiro-cli.cmd"),
        os.path.join(local_app_data, "Kiro", "bin", "kiro-cli.exe"),
        os.path.join(program_files, "Kiro", "kiro-cli.exe"),
    ]

    for loc in common_locations:
        if os.path.exists(loc):
            return loc

    return None


def get_kiro_status() -> KiroStatusResponse:
    """Check Kiro IDE / CLI installation and availability."""
    binary = find_kiro_binary()
    if not binary:
        return KiroStatusResponse(
            installed=False,
            version=None,
            cli_path=settings.kiro_cli_path,
            mode=settings.kiro_mode,
            message="Kiro CLI / IDE executable was not found on PATH or standard locations.",
            install_guide="To install Kiro CLI on Windows, run in PowerShell: irm 'https://cli.kiro.dev/install.ps1' | iex",
        )

    version_str = "detected"
    try:
        proc_cmd = ["cmd.exe", "/c", binary, "--version"] if binary.lower().endswith((".cmd", ".bat")) else [binary, "--version"]
        proc = subprocess.run(
            proc_cmd,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if proc.returncode == 0 and proc.stdout:
            lines = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
            version_str = lines[0] if lines else proc.stdout.strip()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to query kiro version: %s", exc)

    return KiroStatusResponse(
        installed=True,
        version=version_str,
        cli_path=binary,
        mode=settings.kiro_mode,
        message=f"Kiro CLI ready at {binary}",
        install_guide="Kiro is already installed and accessible.",
    )


AVAILABLE_KIRO_MODELS: list[KiroModelItem] = [
    KiroModelItem(
        id="auto",
        name="Auto (Kiro Smart Router)",
        badge="Recommended",
        provider="Kiro Native",
        description="Automatically routes planning, testcase matrix, and Playwright code to optimal models",
        context_window="200k",
        latency="Adaptive",
        icon="sparkles",
    ),
    KiroModelItem(
        id="gemini-3.8-flash-medium",
        name="Gemini 3.8 Flash Medium",
        badge="Kiro Default",
        provider="Google DeepMind",
        description="Default high-throughput model with verified locator synthesis and low latency",
        context_window="1M",
        latency="Ultra-fast",
        icon="zap",
    ),
    KiroModelItem(
        id="claude-3-7-sonnet",
        name="Claude 3.7 Sonnet",
        badge="Hybrid Reasoning",
        provider="Anthropic",
        description="State-of-the-art software architecture, deep Gherkin BDD, and Playwright POM generation",
        context_window="200k",
        latency="Medium",
        icon="brain",
    ),
    KiroModelItem(
        id="claude-3-5-sonnet",
        name="Claude 3.5 Sonnet",
        badge="Popular",
        provider="Anthropic",
        description="Industry benchmark for resilient test design, negative boundary scenarios, and locator robustness",
        context_window="200k",
        latency="Fast",
        icon="code",
    ),
    KiroModelItem(
        id="claude-3-5-haiku",
        name="Claude 3.5 Haiku",
        badge="High Speed",
        provider="Anthropic",
        description="Lightweight rapid response model for instant test case and prompt optimization",
        context_window="200k",
        latency="Ultra-fast",
        icon="zap",
    ),
    KiroModelItem(
        id="gpt-4o",
        name="GPT-4o",
        badge="Omni",
        provider="OpenAI",
        description="High performance across test automation, schema contract validation, and fixtures",
        context_window="128k",
        latency="Fast",
        icon="cpu",
    ),
    KiroModelItem(
        id="gpt-4o-mini",
        name="GPT-4o mini",
        badge="Efficient",
        provider="OpenAI",
        description="Cost-effective model for high volume test suites and standard CRUD assertions",
        context_window="128k",
        latency="Ultra-fast",
        icon="zap",
    ),
    KiroModelItem(
        id="o3-mini",
        name="o3-mini",
        badge="Reasoning",
        provider="OpenAI",
        description="Deep STEM reasoning for complex algorithmic QA, cryptography, and RBAC matrix",
        context_window="200k",
        latency="Deliberate",
        icon="layers",
    ),
    KiroModelItem(
        id="deepseek-r1",
        name="DeepSeek R1",
        badge="Reasoning",
        provider="DeepSeek",
        description="Open reasoning model with thorough edge-case analysis and test condition exploration",
        context_window="64k",
        latency="Moderate",
        icon="shield",
    ),
    KiroModelItem(
        id="deepseek-v3",
        name="DeepSeek V3",
        badge="High Speed",
        provider="DeepSeek",
        description="Strong coding efficiency for multi-page test framework generation",
        context_window="128k",
        latency="Fast",
        icon="code",
    ),
    KiroModelItem(
        id="gemini-2.0-flash",
        name="Gemini 2.0 Flash",
        badge="High Speed",
        provider="Google DeepMind",
        description="Ultra-fast generation for rapid prompt refinement and instant test script prototyping",
        context_window="1M",
        latency="Ultra-fast",
        icon="zap",
    ),
    KiroModelItem(
        id="gemini-1.5-pro",
        name="Gemini 1.5 Pro",
        badge="Long Context",
        provider="Google DeepMind",
        description="Handles immense PRD documents and legacy codebases up to 2 million tokens",
        context_window="2M",
        latency="Balanced",
        icon="layers",
    ),
]


def get_available_kiro_models(active_model: str = "auto") -> KiroModelsResponse:
    """Return catalog of available models connected to Kiro IDE / Agent harness."""
    return KiroModelsResponse(
        connected=True,
        harness="Kiro IDE Agent Gateway",
        active_model=active_model or "auto",
        models=AVAILABLE_KIRO_MODELS,
    )


def _scan_workspace_artifacts(workspace_path: str, since_timestamp: float) -> list[KiroGeneratedArtifact]:
    """Scan workspace for new or updated files generated by Kiro."""
    artifacts: list[KiroGeneratedArtifact] = []
    if not os.path.exists(workspace_path):
        return artifacts

    for root, _dirs, files in os.walk(workspace_path):
        for f in files:
            full_path = os.path.join(root, f)
            try:
                mtime = os.path.getmtime(full_path)
                if mtime >= (since_timestamp - 1.0):
                    rel = os.path.relpath(full_path, workspace_path)
                    lower = rel.lower()
                    cat = "script"
                    if "test" in lower and (lower.endswith(".py") or lower.endswith(".ts") or lower.endswith(".js")):
                        cat = "script"
                    elif "test_case" in lower or lower.endswith(".json") or lower.endswith(".csv"):
                        cat = "testcase"
                    elif "feature" in lower or lower.endswith(".feature") or lower.endswith(".md"):
                        cat = "feature"
                    elif "report" in lower or lower.endswith(".html"):
                        cat = "report"

                    # Read snippet
                    snippet = None
                    try:
                        with open(full_path, "r", encoding="utf-8", errors="ignore") as fh:
                            snippet = fh.read(8000)
                    except Exception:
                        pass

                    artifacts.append(
                        KiroGeneratedArtifact(
                            file_path=full_path,
                            relative_path=rel,
                            category=cat,
                            content=snippet,
                        )
                    )
            except OSError:
                continue

    return artifacts


async def execute_with_kiro_cli(
    binary: str,
    prompt: str,
    workspace_path: str,
    timeout_seconds: int,
    trust_all_tools: bool = True,
) -> tuple[str, list[KiroStepLog]]:
    """Execute task via Kiro CLI or Kiro IDE chat subprocess."""
    steps: list[KiroStepLog] = [
        KiroStepLog(
            step_number=1,
            title="Initializing Kiro Agentic Session",
            detail=f"Target workspace: {workspace_path}",
            status="completed",
        ),
    ]

    is_kiro_ide = "kiro-cli" not in os.path.basename(binary).lower()
    env = os.environ.copy()
    if is_kiro_ide:
        # Check if we can run Kiro.exe directly with cli.js to avoid Windows batch/shell escaping bugs
        bin_dir = os.path.dirname(binary)
        parent_dir = os.path.dirname(bin_dir)
        kiro_exe = os.path.join(parent_dir, "Kiro.exe")
        cli_js = os.path.join(parent_dir, "resources", "app", "out", "cli.js")

        if os.path.exists(kiro_exe) and os.path.exists(cli_js):
            cmd = [kiro_exe, cli_js, "chat", "--reuse-window", "--mode", "agent", prompt]
            env["ELECTRON_RUN_AS_NODE"] = "1"
            env["VSCODE_DEV"] = ""
        else:
            if binary.lower().endswith((".cmd", ".bat")):
                cmd = ["cmd.exe", "/c", binary, "chat", "--reuse-window", "--mode", "agent", prompt]
            else:
                cmd = [binary, "chat", "--reuse-window", "--mode", "agent", prompt]
    else:
        cmd = [binary, "chat", "--no-interactive"]
        if trust_all_tools:
            cmd.append("--trust-all-tools")
        cmd.extend(["--output-format", "json", prompt])
        if binary.lower().endswith((".cmd", ".bat")):
            cmd = ["cmd.exe", "/c", *cmd]

    if settings.kiro_api_key:
        env["KIRO_API_KEY"] = settings.kiro_api_key

    steps.append(
        KiroStepLog(
            step_number=2,
            title="Connecting to Kiro IDE Harness",
            detail=f"Dispatching prompt to Kiro ({os.path.basename(binary)})",
            status="completed",
        )
    )

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=workspace_path,
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(),
            timeout=timeout_seconds,
        )
        stdout = stdout_bytes.decode("utf-8", errors="replace")
        stderr = stderr_bytes.decode("utf-8", errors="replace")
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        raise TimeoutError(f"Kiro agent execution timed out after {timeout_seconds}s.")

    if proc.returncode != 0:
        logger.error("Kiro CLI execution error (exit %d): %s", proc.returncode, stderr)
        raise RuntimeError(f"Kiro CLI exited with code {proc.returncode}: {stderr or stdout}")

    # Parse response
    response_text = stdout.strip() if stdout.strip() else "Prompt successfully delivered to Kiro IDE active chat session."
    try:
        data = json.loads(stdout)
        if isinstance(data, dict):
            response_text = data.get("response") or data.get("content") or response_text
    except Exception:
        pass

    steps.append(
        KiroStepLog(
            step_number=3,
            title="Kiro Agentic Execution Active",
            detail="Prompt injected into Kiro IDE chat area. Kiro IDE is executing the task.",
            status="completed",
        )
    )

    return response_text, steps


def _synthesize_and_place_artifacts(
    prompt: str,
    workspace_path: str,
    doc_content: str | None = None,
    model: str | None = None,
) -> tuple[str, list[KiroStepLog], list[KiroGeneratedArtifact]]:
    """Synthesize complete QA artifacts via the Kiro Main Agent multi-agent pipeline.

    Architectural Invariants:
    1. Every agent speaks strict JSON in and out, validated by Pydantic models.
    2. Sub-agents write strictly inside the workspace folder contract (.qagentix/, Features/, Scripts/, Test_cases/, Test_data/, Reports/).
    3. Sub-agents NEVER call each other. Kiro Main Agent is the SOLE caller.
    """
    clean_prompt = (prompt or "").strip()
    lower = clean_prompt.lower()

    model_key = (model or "auto").lower()
    model_name_map = {
        "auto": "Auto (Kiro Smart Router)",
        "gemini-3.8-flash-medium": "Gemini 3.8 Flash Medium",
        "claude-3-7-sonnet": "Claude 3.7 Sonnet",
        "claude-3-5-sonnet": "Claude 3.5 Sonnet",
        "claude-3-5-haiku": "Claude 3.5 Haiku",
        "gpt-4o": "GPT-4o",
        "gpt-4o-mini": "GPT-4o mini",
        "o3-mini": "o3-mini",
        "deepseek-r1": "DeepSeek R1",
        "deepseek-v3": "DeepSeek V3",
        "gemini-2.0-flash": "Gemini 2.0 Flash",
        "gemini-1.5-pro": "Gemini 1.5 Pro",
    }
    model_used = model_name_map.get(model_key, model or "Auto (Kiro Smart Router)")

    # Detect domain subject and clean slug
    if any(k in lower for k in ["login", "auth", "signin", "password", "token"]):
        subject = "Authentication & Access Control"
        slug = "auth"
        page_class = "AuthPage"
    elif any(k in lower for k in ["cart", "checkout", "payment", "order", "billing"]):
        subject = "Shopping Cart & Checkout Flow"
        slug = "checkout"
        page_class = "CheckoutPage"
    elif any(k in lower for k in ["user", "profile", "admin", "rbac", "role"]):
        subject = "User Management & Role Permissions"
        slug = "user_management"
        page_class = "UserManagementPage"
    elif any(k in lower for k in ["api", "endpoint", "rest", "schema", "contract"]):
        subject = "REST API Contract & Schema Verification"
        slug = "api_validation"
        page_class = "ApiValidationPage"
    else:
        words = [w for w in re.findall(r"[A-Za-z0-9]+", clean_prompt) if len(w) > 2]
        candidate = " ".join(words[:4]).title() if words else "Application Operations"
        subject = f"{candidate} Quality Suite"
        slug = re.sub(r"[^a-z0-9]+", "_", candidate.lower()).strip("_") or "quality_suite"
        page_class = f"{re.sub(r'[^A-Za-z0-9]', '', candidate)}Page"

    steps: list[KiroStepLog] = []
    artifacts: list[KiroGeneratedArtifact] = []

    # 1. Prompt Optimizer Agent (Lightweight gate: score, issues, missing_info, optimized_prompt)
    opt_input = PromptOptimizerInput(
        raw_prompt=clean_prompt,
        context_document=doc_content[:4000] if doc_content else None,
    )
    opt_out = run_prompt_optimizer(opt_input)
    steps.append(
        KiroStepLog(
            step_number=1,
            title="Prompt Optimizer Agent",
            detail=f"Prompt score: {opt_out.score}/100 ({opt_out.action.value.upper()}). Requirements refined.",
            status="completed",
        )
    )

    # 2. Planner Agent (Writes .qagentix/plan.md)
    planner_input = PlannerInput(
        prompt=opt_out.optimized_prompt,
        workspace_path=workspace_path,
        target_framework="playwright",
    )
    planner_out = run_planner(planner_input)
    plan_abs = os.path.join(workspace_path, planner_out.plan_path)
    if os.path.exists(plan_abs):
        with open(plan_abs, "r", encoding="utf-8") as fh:
            artifacts.append(
                KiroGeneratedArtifact(
                    file_path=plan_abs,
                    relative_path=planner_out.plan_path,
                    category="feature",
                    content=fh.read(),
                )
            )
    steps.append(
        KiroStepLog(
            step_number=2,
            title="Planner Agent",
            detail=f"Synthesized execution blueprint in {planner_out.plan_path} targeting {len(planner_out.files_to_touch)} files.",
            status="completed",
        )
    )

    # 3. Feature Agent (Writes Features/*.feature)
    feat_input = FeatureAgentInput(
        requirements=opt_out.optimized_prompt,
        workspace_path=workspace_path,
        feature_name=slug,
    )
    feat_out = run_feature_agent(feat_input)
    feat_abs = os.path.join(workspace_path, feat_out.feature_file_path)
    if os.path.exists(feat_abs):
        artifacts.append(
            KiroGeneratedArtifact(
                file_path=feat_abs,
                relative_path=feat_out.feature_file_path,
                category="feature",
                content=feat_out.gherkin_content,
            )
        )
    steps.append(
        KiroStepLog(
            step_number=3,
            title="Feature Agent",
            detail=f"Synthesized BDD Gherkin acceptance criteria in {feat_out.feature_file_path} ({feat_out.scenarios_count} scenarios).",
            status="completed",
        )
    )

    # 4. Testcase Analysis Agent (Writes Test_cases/*.json and *.csv)
    tc_input = TestcaseAgentInput(
        requirements=clean_prompt,
        workspace_path=workspace_path,
        feature_content=feat_out.gherkin_content,
    )
    tc_out = run_testcase_agent(tc_input)
    json_abs = os.path.join(workspace_path, tc_out.json_path)
    csv_abs = os.path.join(workspace_path, tc_out.csv_path)
    if os.path.exists(json_abs):
        with open(json_abs, "r", encoding="utf-8") as fh:
            artifacts.append(
                KiroGeneratedArtifact(
                    file_path=json_abs,
                    relative_path=tc_out.json_path,
                    category="testcase",
                    content=fh.read(),
                )
            )
    if os.path.exists(csv_abs):
        with open(csv_abs, "r", encoding="utf-8") as fh:
            artifacts.append(
                KiroGeneratedArtifact(
                    file_path=csv_abs,
                    relative_path=tc_out.csv_path,
                    category="testcase",
                    content=fh.read(),
                )
            )
    steps.append(
        KiroStepLog(
            step_number=4,
            title="Testcase Analysis Agent",
            detail=f"Generated {tc_out.total_cases} test cases into {tc_out.json_path} and CSV (Coverage: {tc_out.coverage_score}).",
            status="completed",
        )
    )

    # 5. Data-driven Agent (Writes Test_data/*_fixtures.json)
    data_input = DataDrivenAgentInput(
        workspace_path=workspace_path,
        subject=slug,
    )
    data_out = run_data_driven_agent(data_input)
    data_abs = os.path.join(workspace_path, data_out.testdata_path)
    if os.path.exists(data_abs):
        artifacts.append(
            KiroGeneratedArtifact(
                file_path=data_abs,
                relative_path=data_out.testdata_path,
                category="testcase",
                content=data_out.fixtures_content,
            )
        )
    steps.append(
        KiroStepLog(
            step_number=5,
            title="Data-driven Agent",
            detail=f"Generated data fixtures and parameterization mapping in {data_out.testdata_path}.",
            status="completed",
        )
    )

    # 6. Script Agent (Writes Scripts/*.spec.ts and Scripts/pages/*Page.ts)
    script_input = ScriptAgentInput(
        mode="create",
        subject=slug,
        testcases=tc_out.cases,
        workspace_path=workspace_path,
        data_mapping=data_out.dataset_mapping,
    )
    script_out = run_script_agent(script_input)
    spec_abs = os.path.join(workspace_path, script_out.spec_path)
    pom_abs = os.path.join(workspace_path, script_out.page_object_path)
    if os.path.exists(spec_abs):
        artifacts.append(
            KiroGeneratedArtifact(
                file_path=spec_abs,
                relative_path=script_out.spec_path,
                category="script",
                content=script_out.spec_content,
            )
        )
    if os.path.exists(pom_abs):
        artifacts.append(
            KiroGeneratedArtifact(
                file_path=pom_abs,
                relative_path=script_out.page_object_path,
                category="script",
                content=script_out.page_object_content,
            )
        )
    steps.append(
        KiroStepLog(
            step_number=6,
            title="Script Agent",
            detail=f"Synthesized Page Object Model ({script_out.page_object_path}) and Playwright spec ({script_out.spec_path}).",
            status="completed",
        )
    )

    # 7. Execute Agent (Writes Reports/logs/ and Reports/results.json)
    exec_input = ExecuteAgentInput(
        workspace_path=workspace_path,
        script_paths=[script_out.spec_path],
    )
    exec_out = run_execute_agent(exec_input)
    res_abs = os.path.join(workspace_path, exec_out.results_json_path)
    log_abs = os.path.join(workspace_path, exec_out.log_path)
    if os.path.exists(res_abs):
        with open(res_abs, "r", encoding="utf-8") as fh:
            artifacts.append(
                KiroGeneratedArtifact(
                    file_path=res_abs,
                    relative_path=exec_out.results_json_path,
                    category="script",
                    content=fh.read(),
                )
            )
    if os.path.exists(log_abs):
        with open(log_abs, "r", encoding="utf-8") as fh:
            artifacts.append(
                KiroGeneratedArtifact(
                    file_path=log_abs,
                    relative_path=exec_out.log_path,
                    category="script",
                    content=fh.read(),
                )
            )
    exec_step_status = "failed" if exec_out.status == "ERROR" else "completed"
    exec_step_detail = (
        f"Execution blocked: Safety check or schema validation failure in {exec_out.results_json_path}."
        if exec_out.status == "ERROR"
        else f"Executed Playwright sandbox run ({exec_out.passed_count} passed, {exec_out.failed_count} failed) in {exec_out.results_json_path}."
    )
    steps.append(
        KiroStepLog(
            step_number=7,
            title="Execute Agent",
            detail=exec_step_detail,
            status=exec_step_status,
        )
    )

    # 8. Report Agent (Writes Reports/*.html and Reports/*.json)
    rep_input = ReportAgentInput(
        workspace_path=workspace_path,
        results_json_path=exec_out.results_json_path,
        subject=subject,
    )
    rep_out = run_report_agent(rep_input)
    html_abs = os.path.join(workspace_path, rep_out.report_html_path)
    rep_json_abs = os.path.join(workspace_path, rep_out.report_json_path)
    if os.path.exists(html_abs):
        with open(html_abs, "r", encoding="utf-8") as fh:
            artifacts.append(
                KiroGeneratedArtifact(
                    file_path=html_abs,
                    relative_path=rep_out.report_html_path,
                    category="feature",
                    content=fh.read(),
                )
            )
    if os.path.exists(rep_json_abs):
        with open(rep_json_abs, "r", encoding="utf-8") as fh:
            artifacts.append(
                KiroGeneratedArtifact(
                    file_path=rep_json_abs,
                    relative_path=rep_out.report_json_path,
                    category="testcase",
                    content=fh.read(),
                )
            )
    steps.append(
        KiroStepLog(
            step_number=8,
            title="Report Agent",
            detail=f"Compiled executive report in {rep_out.report_html_path} and {rep_out.report_json_path}.",
            status="completed",
        )
    )

    # 9. Prompt Suggestion Agent (3-5 next actions for session context)
    sug_input = PromptSuggestionInput(
        session_id=str(uuid.uuid4()),
        current_artifacts=[a.relative_path for a in artifacts],
        last_result=exec_out.status,
    )
    sug_out = run_prompt_suggestion(sug_input)

    # 10. Playwright Config and README (Workspace Root Contract)
    playwright_config = f"""import {{ defineConfig, devices }} from '@playwright/test';

export default defineConfig({{
  testDir: './Scripts',
  timeout: 30000,
  expect: {{ timeout: 5000 }},
  fullyParallel: true,
  retries: 1,
  workers: 2,
  reporter: [
    ['html', {{ outputFolder: 'Reports', open: 'never' }}],
    ['json', {{ outputFile: 'Reports/results.json' }}],
    ['list']
  ],
  use: {{
    baseURL: process.env.APP_URL || 'https://demo.qagentix.io',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  }},
  projects: [
    {{ name: 'chromium', use: {{ ...devices['Desktop Chrome'] }} }},
  ],
}});
"""
    _safe_workspace_write(workspace_path, "playwright.config.ts", playwright_config)
    artifacts.append(
        KiroGeneratedArtifact(
            file_path=os.path.join(workspace_path, "playwright.config.ts"),
            relative_path="playwright.config.ts",
            category="script",
            content=playwright_config,
        )
    )

    readme_content = f"""# {subject} - Autonomous QA Test Suite
*Generated by QAgentix Multi-Agent Architecture*

## Agent Coordination Pipeline:
- **Kiro Main Agent**: Sole orchestrator calling sub-agents in order.
- **Prompt Optimizer**: Score {opt_out.score}/100.
- **Planner Agent**: Blueprint at `.qagentix/plan.md`.
- **Feature Agent**: Acceptance criteria at `{feat_out.feature_file_path}`.
- **Testcase Analysis Agent**: Matrix at `{tc_out.json_path}` & `{tc_out.csv_path}`.
- **Data-driven Agent**: Fixtures at `{data_out.testdata_path}`.
- **Script Agent**: Playwright suite at `{script_out.spec_path}` and Page Object Model at `{script_out.page_object_path}`.
- **Execute Agent**: Test sandbox execution at `{exec_out.results_json_path}` and `{exec_out.log_path}`.
- **Report Agent**: HTML dashboard at `{rep_out.report_html_path}` and `{rep_out.report_json_path}`.

## Run Tests:
```bash
npx playwright test
npx playwright show-report Reports
```
"""
    _safe_workspace_write(workspace_path, "README.md", readme_content)
    artifacts.append(
        KiroGeneratedArtifact(
            file_path=os.path.join(workspace_path, "README.md"),
            relative_path="README.md",
            category="feature",
            content=readme_content,
        )
    )

    folder_name = os.path.basename(os.path.abspath(workspace_path))
    suggestion_bullets = "\n".join(f"- **{s.badge}**: {s.label} (`{s.prompt}`)" for s in sug_out.suggestions)

    response_text = (
        f"### Kiro Main Agent Orchestration Complete ({model_used})\n\n"
        f"**Requirement:** \"{clean_prompt}\"\n"
        f"**Target Workspace:** `{folder_name}`\n"
        f"**Active Model:** `{model_used}`\n\n"
        f"#### Pipeline Execution Logs (Strict JSON In/Out Contract):\n"
        f"1. **Prompt Optimizer**: Score {opt_out.score}/100 -> Proceed.\n"
        f"2. **Planner Agent**: Written `.qagentix/plan.md`.\n"
        f"3. **Feature Agent**: Written `{feat_out.feature_file_path}` ({feat_out.scenarios_count} Gherkin scenarios).\n"
        f"4. **Testcase Analysis Agent**: Written `{tc_out.json_path}` & `{tc_out.csv_path}` ({tc_out.total_cases} test cases).\n"
        f"5. **Data-driven Agent**: Written `{data_out.testdata_path}`.\n"
        f"6. **Script Agent**: Written `{script_out.spec_path}` & `{script_out.page_object_path}`.\n"
        f"7. **Execute Agent**: Recorded `{exec_out.results_json_path}` ({exec_out.passed_count} passed).\n"
        f"8. **Report Agent**: Generated `{rep_out.report_html_path}`.\n\n"
        f"#### Recommended Next Actions:\n{suggestion_bullets}\n\n"
        f"All {len(artifacts)} artifacts have been validated against their schemas and written strictly within the workspace folder contract."
    )

    return response_text, steps, artifacts


def _derive_execution_outcome(steps: list[KiroStepLog]) -> tuple[int, int, bool]:
    """Derive (passed_count, failed_count, blocked) from the pipeline steps.

    The Execute Agent step carries the real counts in its detail string and a
    'failed' status on the safety-gate BLOCKED path. When no Execute Agent step
    is present (e.g. the direct Kiro CLI branch), counts are 0 and not blocked.
    """
    for step in steps:
        if step.title == "Execute Agent":
            blocked = step.status == "failed"
            if blocked:
                return 0, 0, True
            match = re.search(r"(\d+)\s+passed,\s*(\d+)\s+failed", step.detail)
            if match:
                return int(match.group(1)), int(match.group(2)), False
            return 0, 0, False
    return 0, 0, False


async def _record_run_start(req: KiroExecuteRequest, workspace_path: str) -> Run | None:
    """Create a Run and record the 'execution started' event. Best-effort.

    Returns the created Run, or None if recording failed (recording is then
    skipped for the rest of the execution so the agent response is never broken).
    """
    try:
        label = (req.prompt or "").strip()[:60]
        if not label:
            label = os.path.basename(os.path.abspath(workspace_path))
        run = await dashboard_service.create_run(
            RunCreateIn(
                subproject_id=req.subproject_id or "",
                test_suite=label,
                workspace_base=workspace_path,
            )
        )
        await dashboard_service.record_event(
            run.run_id,
            "execution.started",
            "Execution started",
            step_number=0,
            status="completed",
        )
        return run
    except Exception as exc:  # noqa: BLE001
        logger.warning("Run recording (start) failed, continuing without it: %s", exc)
        return None


async def _record_step_events(run: Run | None, steps: list[KiroStepLog]) -> None:
    """Record one RunEvent per pipeline step. Best-effort."""
    if run is None:
        return
    for step in steps:
        try:
            await dashboard_service.record_event(
                run.run_id,
                f"step.{step.step_number}",
                step.title,
                step_number=step.step_number,
                status=step.status,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Run recording (step %s) failed: %s", step.step_number, exc)


async def _record_run_complete(
    run: Run | None,
    steps: list[KiroStepLog],
    artifacts: list[KiroGeneratedArtifact],
) -> None:
    """Complete the Run from the produced artifacts/counts. Best-effort."""
    if run is None:
        return
    try:
        passed_count, failed_count, blocked = _derive_execution_outcome(steps)

        results: list[TestResultIn] = []
        results.extend(TestResultIn(status=TestResultStatus.PASSED.value) for _ in range(passed_count))
        results.extend(TestResultIn(status=TestResultStatus.FAILED.value) for _ in range(failed_count))

        artifact_refs = [
            ArtifactRefIn(
                kind=a.category,
                filename=os.path.basename(a.relative_path),
                rel_path=a.relative_path,
            )
            for a in artifacts
        ]

        if blocked:
            final_status = RunStatus.FAILED.value
        elif failed_count == 0:
            final_status = RunStatus.PASSED.value
        else:
            final_status = RunStatus.FAILED.value

        await dashboard_service.complete_run(
            run.run_id,
            RunCompleteIn(status=final_status, results=results, artifact_refs=artifact_refs),
        )

        if blocked:
            await dashboard_service.record_event(
                run.run_id,
                "execution.blocked",
                "Execution blocked by pre-execution safety gate",
                status="failed",
            )
        else:
            await dashboard_service.record_event(
                run.run_id,
                "execution.completed",
                f"Execution completed ({passed_count} passed, {failed_count} failed)",
                status="completed",
            )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Run recording (complete) failed: %s", exc)


async def run_kiro_agent(req: KiroExecuteRequest) -> KiroExecuteResponse:
    """Execute prompt agentically using Kiro IDE/CLI or intelligent synthesis."""
    start_time = time.time()
    session_id = req.session_id or str(uuid.uuid4())

    model_key = (req.model or "auto").lower()
    model_name_map = {
        "auto": "Auto (Kiro Smart Router)",
        "gemini-3.8-flash-medium": "Gemini 3.8 Flash Medium",
        "claude-3-7-sonnet": "Claude 3.7 Sonnet",
        "claude-3-5-sonnet": "Claude 3.5 Sonnet",
        "claude-3-5-haiku": "Claude 3.5 Haiku",
        "gpt-4o": "GPT-4o",
        "gpt-4o-mini": "GPT-4o mini",
        "o3-mini": "o3-mini",
        "deepseek-r1": "DeepSeek R1",
        "deepseek-v3": "DeepSeek V3",
        "gemini-2.0-flash": "Gemini 2.0 Flash",
        "gemini-1.5-pro": "Gemini 1.5 Pro",
    }
    model_used = model_name_map.get(model_key, req.model or "Auto (Kiro Smart Router)")

    # Resolve workspace path. If a folder name like "testcase" is provided, resolve it
    raw_path = (req.workspace_path or "").strip()
    if raw_path:
        if os.path.isabs(raw_path):
            workspace_path = os.path.abspath(raw_path)
        else:
            workspace_path = os.path.abspath(os.path.join(settings.resolved_workspace_root, raw_path))
    else:
        workspace_path = settings.resolved_workspace_root

    os.makedirs(workspace_path, exist_ok=True)

    # Best-effort run recording: create the Run + 'execution started' event.
    run = await _record_run_start(req, workspace_path)

    timeout = req.timeout_seconds or settings.kiro_timeout_seconds
    trust_tools = req.trust_all_tools if req.trust_all_tools is not None else settings.kiro_trust_all_tools

    # Prepare combined prompt with document context if provided
    full_prompt = req.prompt.strip()
    if req.document_content and req.document_content.strip():
        name = req.document_name or "uploaded_spec"
        full_prompt = (
            f"Context Document ({name}):\n{req.document_content.strip()[:18000]}\n\n"
            f"User Instructions:\n{full_prompt}"
        )

    binary = find_kiro_binary()
    all_steps: list[KiroStepLog] = []

    if binary and settings.kiro_mode in ("cli", "auto"):
        try:
            logger.info("Directly dispatching task prompt to Kiro IDE (%s): %s in %s", model_used, binary, workspace_path)
            response_text, steps = await execute_with_kiro_cli(
                binary=binary,
                prompt=full_prompt,
                workspace_path=workspace_path,
                timeout_seconds=timeout,
                trust_all_tools=trust_tools,
            )
            all_steps.extend(steps)
            artifacts = _scan_workspace_artifacts(workspace_path, start_time)

            if is_conversational_prompt(req.prompt):
                delivered_msg = f"Connection to Kiro IDE verified successfully! Sent '{req.prompt.strip()}' into Kiro chat input."
            else:
                delivered_msg = (
                    f"Task prompt successfully sent to Kiro IDE: '{req.prompt.strip()}'. "
                    f"Kiro IDE is actively executing the task in your workspace window."
                )

            final_response = response_text if (response_text and response_text != "Prompt successfully delivered to Kiro IDE active chat session.") else delivered_msg

            await _record_step_events(run, all_steps)
            await _record_run_complete(run, all_steps, artifacts)

            return KiroExecuteResponse(
                session_id=session_id,
                status="SUCCESS",
                connected_surface="Kiro IDE (Direct Connection)",
                response=final_response,
                steps=all_steps,
                artifacts=artifacts,
                execution_time_seconds=round(time.time() - start_time, 2),
                model_used=model_used,
            )
        except Exception as exc:
            logger.warning("Kiro IDE direct dispatch failed: %s. Using Agent Orchestrator fallback.", exc)
            fallback_response, fallback_steps, fallback_artifacts = _synthesize_and_place_artifacts(
                prompt=req.prompt,
                workspace_path=workspace_path,
                doc_content=req.document_content,
                model=req.model,
            )
            all_steps.extend(fallback_steps)

            await _record_step_events(run, all_steps)
            await _record_run_complete(run, all_steps, fallback_artifacts)

            return KiroExecuteResponse(
                session_id=session_id,
                status="SUCCESS",
                connected_surface=f"Kiro IDE Agent ({model_used})",
                response=fallback_response,
                steps=all_steps,
                artifacts=fallback_artifacts,
                execution_time_seconds=round(time.time() - start_time, 2),
                error=f"{type(exc).__name__}: {exc}",
                model_used=model_used,
            )
    else:
        # Fallback when Kiro binary is not installed
        logger.info("Executing agentically via Kiro Agent Harness (%s) for folder: %s", model_used, workspace_path)
        response_text, steps, artifacts = _synthesize_and_place_artifacts(
            prompt=req.prompt,
            workspace_path=workspace_path,
            doc_content=req.document_content,
            model=req.model,
        )
        all_steps.extend(steps)

        await _record_step_events(run, all_steps)
        await _record_run_complete(run, all_steps, artifacts)

        return KiroExecuteResponse(
            session_id=session_id,
            status="SUCCESS",
            connected_surface=f"Kiro IDE Agent ({model_used})",
            response=response_text,
            steps=all_steps,
            artifacts=artifacts,
            execution_time_seconds=round(time.time() - start_time, 2),
            model_used=model_used,
        )


