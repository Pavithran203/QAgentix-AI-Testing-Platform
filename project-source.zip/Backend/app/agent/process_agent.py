"""Process Agent — Phase 1 (multi-modal input ingestion & normalization).

Classifies the input (DOCUMENT_BRD / LIVE_WEB_APP / HYBRID / DIRECT_PROMPT),
normalizes it into a single prompt, calls the LLM, and returns the response
with a bounded self-healing retry loop. Does NOT generate user stories or
test cases. Nothing is persisted to the database.
"""
from __future__ import annotations

import logging
import re
import uuid

from app.agent.prompts import PROCESS_SYSTEM_PROMPT
from app.core.config import settings
from app.core.llm import LLMError, DEFAULT_MODELS, generate, _normalize_provider
from app.schemas.process_agent import (
    HealingStep,
    PipelineMode,
    ProcessRequest,
    ProcessResponse,
)

logger = logging.getLogger("uvicorn.error")

MAX_HEALING_ATTEMPTS = 3

# Phase 1 system prompt now lives in the central prompt registry (app.agent.prompts)
# so every pipeline stage shares one source of truth. Kept as a module-level alias
# for backwards compatibility with existing imports/tests.
ORCHESTRATOR_SYSTEM_PROMPT = PROCESS_SYSTEM_PROMPT

_URL_RE = re.compile(r"https?://[^\s]+", re.IGNORECASE)


def _detected_url(req: ProcessRequest) -> str | None:
    if req.target_url and req.target_url.strip():
        return req.target_url.strip()
    if req.text:
        m = _URL_RE.search(req.text)
        if m:
            return m.group(0)
    return None


def classify_pipeline_mode(req: ProcessRequest) -> PipelineMode:
    has_doc = bool(req.document_content and req.document_content.strip())
    has_url = _detected_url(req) is not None
    if has_doc and has_url:
        return PipelineMode.HYBRID
    if has_url:
        return PipelineMode.LIVE_WEB_APP
    if has_doc:
        return PipelineMode.DOCUMENT_BRD
    return PipelineMode.DIRECT_PROMPT


def _build_user_prompt(req: ProcessRequest, mode: PipelineMode) -> str:
    parts: list[str] = [f"DETECTED PIPELINE MODE: {mode.value}", ""]

    if req.text and req.text.strip():
        parts += ["== USER INSTRUCTION / PROMPT ==", req.text.strip(), ""]

    if req.document_content and req.document_content.strip():
        name = req.document_name or "document"
        content = req.document_content.strip()[:20000]
        parts += [f"== DOCUMENT CONTENT ({name}) ==", content, ""]

    detected_url = _detected_url(req)
    if detected_url:
        parts += ["== LIVE WEB APP TARGET ==", f"URL: {detected_url}"]
        if req.credentials and (req.credentials.username or req.credentials.password):
            parts.append(
                f"Auth: {req.credentials.auth_type} "
                f"(username provided: {bool(req.credentials.username)}, "
                f"password provided: {bool(req.credentials.password)})"
            )
        parts.append("")

    parts.append(
        "Produce the Phase 1 normalized ingestion response as instructed. "
        "Do not generate user stories or test cases."
    )
    return "\n".join(parts)


def run_process_agent(req: ProcessRequest) -> ProcessResponse:
    session_id = str(uuid.uuid4())
    mode = classify_pipeline_mode(req)

    provider = _normalize_provider(req.provider or settings.llm_provider)
    model = req.model or settings.llm_model or DEFAULT_MODELS.get(provider, DEFAULT_MODELS["huggingface"])
    api_key = req.api_key or settings.llm_api_key or ""

    user_prompt = _build_user_prompt(req, mode)
    authenticated = bool(
        req.credentials and req.credentials.username and req.credentials.password
    )

    healing_log: list[HealingStep] = []
    response_text = ""
    final_status = "FAILED"

    for attempt in range(1, MAX_HEALING_ATTEMPTS + 1):
        try:
            response_text = generate(
                provider=provider,
                api_key=api_key,
                system_prompt=ORCHESTRATOR_SYSTEM_PROMPT,
                user_prompt=user_prompt,
                model=model,
            )
            if not response_text or not response_text.strip():
                raise LLMError("Empty response from the model.")
            final_status = "SUCCESS" if attempt == 1 else "REPAIRED"
            healing_log.append(
                HealingStep(attempt=attempt, status="OK", detail="Generation succeeded.")
            )
            break
        except LLMError as exc:
            is_last = attempt == MAX_HEALING_ATTEMPTS
            healing_log.append(
                HealingStep(
                    attempt=attempt,
                    status="FAILED" if is_last else "RETRYING",
                    detail=str(exc),
                )
            )
            logger.warning("[ProcessAgent] attempt %d failed: %s", attempt, exc)
            if is_last:
                final_status = "FAILED"
                response_text = (
                    "The Process Agent could not generate a response after "
                    f"{MAX_HEALING_ATTEMPTS} attempts. Last error: {exc}"
                )

    return ProcessResponse(
        session_id=session_id,
        pipeline_mode=mode,
        authenticated=authenticated,
        response=response_text,
        provider=provider,
        model=model,
        healing_attempts=len(healing_log),
        healing_log=healing_log,
        final_status=final_status,
    )
