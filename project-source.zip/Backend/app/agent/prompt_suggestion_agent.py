"""Prompt Suggestion Agent for QAgentix.

Why: Guide users to the next useful action in their testing workflow.
When it runs: After each response and when the input is idle.
Integrates: Reads session context, current artifacts, and last result; returns 3-5 suggestions as JSON chips.
Contract: JSON in/out (PromptSuggestionInput -> PromptSuggestionOutput). Does NOT call other agents.
"""
from __future__ import annotations

from app.schemas.agent_contracts import (
    PromptSuggestionInput,
    PromptSuggestionItem,
    PromptSuggestionOutput,
)


def run_prompt_suggestion(payload: PromptSuggestionInput) -> PromptSuggestionOutput:
    """Reads session context and generated artifacts, returning 3-5 next action chips."""
    suggestions = [
        PromptSuggestionItem(
            id="sug-1",
            label="🎯 Run Automated Playwright Suite",
            prompt="Execute the synthesized Playwright test suite and record runtime results into Reports/.",
            badge="Execute",
            color="teal",
        ),
        PromptSuggestionItem(
            id="sug-2",
            label="🛡️ Synthesize Security & RBAC Scenarios",
            prompt="Add role-based authorization and privilege escalation test cases to the test suite.",
            badge="Security",
            color="purple",
        ),
        PromptSuggestionItem(
            id="sug-3",
            label="📊 Export Full Test Coverage Matrix",
            prompt="Compile test cases into an enterprise CSV/JSON matrix for Jira or TestRail traceability.",
            badge="Export",
            color="blue",
        ),
        PromptSuggestionItem(
            id="sug-4",
            label="⚡ Add Network Latency Degradation Test",
            prompt="Add simulated 504 gateway timeout and network latency failure tests to the script suite.",
            badge="Resilience",
            color="teal",
        ),
    ]
    return PromptSuggestionOutput(suggestions=suggestions)
