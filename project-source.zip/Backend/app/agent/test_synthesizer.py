"""Dynamic AI Test Suite Synthesizer.

Maintains model-driven generation of comprehensive Playwright test suites,
test cases matrix, Page Object Models, and configuration fixtures tailored
to user prompts, uploaded specifications, and active target locators.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import logging
import re
from typing import Any

from app.agent.intent import detect_focus, extract_topic
from app.schemas.agent_generator import (
    AgentGenerateRequest,
    BundleSummary,
    GeneratedBundleResponse,
    GeneratedFile,
    GeneratedTestCase,
)

logger = logging.getLogger("uvicorn.error")


def _sanitize_slug(text: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "-", text.strip().lower())
    return cleaned.strip("-") or "feature-suite"


def _to_pascal_case(text: str) -> str:
    words = re.findall(r"[a-zA-Z0-9]+", text)
    if not words:
        return "TargetFeature"
    return "".join(w.capitalize() for w in words)


def _detect_domain_context(prompt: str, files: list[Any]) -> dict[str, Any]:
    """Analyze the prompt and any attached files to extract domain entities and test requirements."""
    prompt_lower = prompt.lower()
    file_names = [f.name for f in files] if files else []
    file_context = " ".join(f.name + " " + (f.content or "") for f in files).lower() if files else ""
    combined = f"{prompt_lower} {file_context}"

    # Determine primary subject
    if any(k in combined for k in ["stripe", "payment", "checkout", "subscription", "credit card", "billing"]):
        domain = "Payment & Subscription Checkout"
        slug = "stripe-checkout"
        page_name = "Checkout"
        endpoint = "/checkout"
        action_verb = "complete checkout"
        boundaries = [
            "Test invalid card number with missing digits (e.g. 4242 4242 4242 42)",
            "Test expired card date (MM/YY in past)",
            "Test 3-digit CVV validation with alphabetic characters",
            "Test 3D Secure authentication challenge failure",
        ]
        sample_positive = {
            "cardNumber": "4242424242424242",
            "expDate": "12/28",
            "cvv": "999",
            "billingZip": "94103",
            "planId": "pro-monthly",
        }
        sample_negative = {
            "cardNumber": "4000000000000002",
            "expDate": "01/20",
            "cvv": "abc",
            "billingZip": "00000",
        }
    elif any(k in combined for k in ["auth", "login", "sso", "jwt", "password", "sign in", "mfa", "2fa"]):
        domain = "Authentication & Identity Management"
        slug = "user-auth"
        page_name = "Login"
        endpoint = "/login"
        action_verb = "authenticate user session"
        boundaries = [
            "Submit login with empty username and password fields",
            "Enter malformed email: 'admin@@qagentix..io'",
            "Exceed maximum failed login attempts to trigger rate limit (429)",
            "Attempt password with script payload: '<script>alert(1)</script>'",
        ]
        sample_positive = {
            "username": "qa.engineer@qagentix.io",
            "password": "ValidSuperSecret2026!",
        }
        sample_negative = {
            "username": "invalid.user@unknown.domain",
            "password": "WrongPassword999",
        }
    elif any(k in combined for k in ["rbac", "permission", "role", "admin", "privilege", "access control"]):
        domain = "Role-Based Access Control (RBAC)"
        slug = "rbac-permissions"
        page_name = "AdminRole"
        endpoint = "/admin/roles"
        action_verb = "verify access boundaries"
        boundaries = [
            "Non-admin role attempts to invoke DELETE /api/admin/users",
            "Impersonate Read-Only viewer and attempt to toggle system settings",
            "Manipulate user role parameter in HTTP payload to elevate privilege",
            "Verify session expiration immediately invalidates privileged tokens",
        ]
        sample_positive = {
            "targetRole": "Admin",
            "allowedActions": ["read", "write", "delete", "invite"],
        }
        sample_negative = {
            "targetRole": "Viewer",
            "disallowedActions": ["delete", "modify_roles"],
        }
    elif any(k in combined for k in ["cart", "e-commerce", "ecommerce", "catalog", "order", "inventory"]):
        domain = "E-Commerce Cart & Order Processing"
        slug = "cart-order-flow"
        page_name = "Cart"
        endpoint = "/cart"
        action_verb = "order items"
        boundaries = [
            "Attempt to add 0 or negative quantity of item to cart",
            "Add items exceeding real-time stock inventory threshold",
            "Apply expired promotional discount coupon code",
            "Abandon checkout session and verify cart restoration",
        ]
        sample_positive = {
            "itemSku": "SKU-98214",
            "quantity": 2,
            "couponCode": "SUMMER2026",
        }
        sample_negative = {
            "itemSku": "SKU-OUT-OF-STOCK",
            "quantity": -1,
            "couponCode": "EXPIRED-DEAL",
        }
    elif any(k in combined for k in ["filter", "search", "pagination", "table", "grid", "query"]):
        domain = "Data Grid Search & Pagination"
        slug = "grid-pagination"
        page_name = "DataGrid"
        endpoint = "/records"
        action_verb = "filter and paginate datasets"
        boundaries = [
            "Search with SQL wildcard and injection strings: \"' OR 1=1 --\"",
            "Navigate to out-of-range page index (e.g. page 999999)",
            "Apply 5 concurrent filter facets and verify URL query sync",
            "Toggle ascending/descending sorting across 10,000 row records",
        ]
        sample_positive = {
            "searchTerm": "Enterprise",
            "filterStatus": "Active",
            "page": 2,
            "pageSize": 25,
        }
        sample_negative = {
            "searchTerm": "' OR '1'='1",
            "page": -1,
            "pageSize": 0,
        }
    else:
        # Generic derived domain from prompt or files
        clean_words = [w for w in re.findall(r"[a-zA-Z0-9]+", prompt) if len(w) > 3][:4]
        subject_title = " ".join(w.capitalize() for w in clean_words) if clean_words else "Application Workflow"
        domain = subject_title
        slug = _sanitize_slug(domain)
        page_name = _to_pascal_case(domain)
        endpoint = f"/{slug}"
        action_verb = f"execute {domain.lower()}"
        boundaries = [
            "Input boundary: special characters, emojis, and maximum length input (4096 chars)",
            "Required fields omitted: verify inline validation triggers before submission",
            "Server timeout response: assert resilient retry handling without crashing page",
            "Rapid double-click on primary action button to ensure idempotency",
        ]
        sample_positive = {
            "name": f"Test {domain} Entry",
            "status": "active",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        sample_negative = {
            "name": "<script>alert('xss')</script>",
            "status": "invalid_status",
        }

    return {
        "domain": domain,
        "slug": slug,
        "page_name": page_name,
        "endpoint": endpoint,
        "action_verb": action_verb,
        "boundaries": boundaries,
        "sample_positive": sample_positive,
        "sample_negative": sample_negative,
        "file_names": file_names,
    }


def _extract_requested_count(prompt: str) -> int | None:
    """Extract explicit count requested by the user, e.g., 'generate 3 test cases', '5 scenarios'."""
    m = re.search(r"\b(\d+)\s*(?:test\s*cases?|scenarios?|tests?)\b", prompt, re.IGNORECASE)
    if m:
        try:
            val = int(m.group(1))
            if 1 <= val <= 25:
                return val
        except ValueError:
            pass
    return None


def _extract_scenarios_from_input(prompt: str, files: list[Any], ctx: dict[str, Any]) -> list[dict[str, Any]]:
    """Parse user prompt for numbered/bullet items, comma-separated lists, or swagger endpoints."""
    scenarios: list[dict[str, Any]] = []

    # 1. Check for Swagger / OpenAPI endpoints in attached files
    if files:
        for f in files:
            content = getattr(f, "content", "") or ""
            if not content:
                continue
            try:
                spec_json = json.loads(content)
                paths = spec_json.get("paths", {})
                for path, methods in list(paths.items())[:12]:
                    if isinstance(methods, dict):
                        for method, op in methods.items():
                            if method.lower() in ("get", "post", "put", "delete", "patch"):
                                op_id = op.get("summary") or op.get("operationId") or f"{method.upper()} {path}"
                                cat = "E2E" if method.lower() == "get" else "Regression"
                                pri = "High" if method.lower() in ("post", "delete") else "Medium"
                                scenarios.append({
                                    "title": f"{method.upper()} {path} - {op_id}",
                                    "category": cat,
                                    "priority": pri,
                                    "steps": [
                                        f"Prepare payload matching OpenAPI schema for {path}",
                                        f"Send HTTP {method.upper()} request to {path}",
                                        f"Assert HTTP status code and response schema integrity",
                                    ],
                                    "expectedResult": f"API responds with documented status and schema contract.",
                                })
            except Exception:
                pass

    if scenarios:
        return scenarios

    # 2. Check for numbered lines or bullet points (e.g. 1. ... 2. ... or - ... or * ...)
    lines = [l.strip() for l in prompt.splitlines() if l.strip()]
    bullet_items: list[str] = []
    for l in lines:
        cleaned = re.sub(r"^(\d+[\.\)]|\-|\*|\•)\s*", "", l).strip()
        if cleaned and len(cleaned) > 5 and not l.lower().startswith(("generate", "please", "based on", "synthesize")):
            bullet_items.append(cleaned)

    # If no multiline bullets, check for comma-separated or semicolon-separated items after trigger phrases
    if len(bullet_items) < 2:
        m = re.search(r"(?:including|covering|focus on|cases for|scenarios for|such as|tests for)\s*[:\-]?\s*(.+)", prompt, re.IGNORECASE)
        if m:
            parts = [p.strip() for p in re.split(r"[,;]+|\band\b", m.group(1)) if len(p.strip()) > 3]
            if len(parts) >= 2:
                bullet_items = parts

    for item in bullet_items[:12]:
        item_lower = item.lower()
        cat = "Regression"
        pri = "Medium"
        if any(w in item_lower for w in ["valid", "happy", "success", "smoke", "login", "auth"]):
            cat = "Smoke"
            pri = "High"
        elif any(w in item_lower for w in ["invalid", "boundary", "empty", "overflow", "limit", "wrong"]):
            cat = "Boundary"
            pri = "High"
        elif any(w in item_lower for w in ["security", "sql", "xss", "inject", "token", "privilege", "unauth"]):
            cat = "Security"
            pri = "High"
        elif any(w in item_lower for w in ["end to end", "journey", "flow", "checkout", "persist", "reload"]):
            cat = "E2E"
            pri = "Medium"

        scenarios.append({
            "title": f"Verify {item}",
            "category": cat,
            "priority": pri,
            "steps": [
                f"Navigate to {ctx['endpoint']}",
                f"Set up test precondition: {item}",
                f"Execute interaction on {ctx['page_name']} page",
                f"Assert target outcome for: {item}",
            ],
            "expectedResult": f"System behaves correctly under condition '{item}'.",
        })

    return scenarios


def synthesize_test_bundle(req: AgentGenerateRequest) -> GeneratedBundleResponse:
    """Generate dynamic, model-grade Playwright tests and test cases based on user prompt."""
    prompt = req.prompt.strip() or "Automated Quality Suite"
    # Name the suite after the user's own topic, not the suggestion card's instruction wording.
    topic = extract_topic(prompt) or prompt
    focus = detect_focus(prompt)
    ctx = _detect_domain_context(topic, req.files)

    domain = ctx["domain"]
    slug = ctx["slug"]
    page_name = ctx["page_name"]
    endpoint = ctx["endpoint"]
    boundaries = ctx["boundaries"]

    # 1. Synthesize Dynamic Test Cases according to user requirements
    custom_scenarios = _extract_scenarios_from_input(prompt, req.files, ctx)
    requested_count = _extract_requested_count(prompt)

    # Generate dynamic scenarios tailored to domain, focus, and requested count
    base_pool: list[dict[str, Any]] = [
            {
                "title": f"Verify primary {domain} happy path execution with valid inputs",
                "desc": f"Executes core successful workflow for {domain}. Ensures system completes {ctx['action_verb']}.",
                "steps": [
                    f"Navigate to {endpoint}",
                    f"Populate valid input fields using fixture data",
                    f"Click primary submission button",
                    f"Assert HTTP 200/201 response and visible success confirmation banner",
                ],
                "expected": "Transaction finishes successfully and target state is recorded without errors.",
                "pri": "High",
                "cat": "Smoke",
            },
            {
                "title": f"Reject invalid inputs and boundary violations in {domain}",
                "desc": f"Ensures client-side validation catches boundary and malformed data ({boundaries[0]}).",
                "steps": [
                    f"Navigate to {endpoint}",
                    f"Supply boundary edge data: {boundaries[0]}",
                    f"Attempt submission",
                    f"Assert form validation banners highlight defective fields and prevent submission",
                ],
                "expected": "System prevents submission, highlights invalid fields, and retains user input.",
                "pri": "High",
                "cat": "Boundary",
            },
            {
                "title": f"Graceful error handling and negative condition recovery in {domain}",
                "desc": f"Validates behavior when backend returns rejection ({boundaries[1] if len(boundaries) > 1 else 'invalid input'}).",
                "steps": [
                    f"Navigate to {endpoint}",
                    f"Supply invalid input: {boundaries[1] if len(boundaries) > 1 else 'invalid input'}",
                    f"Submit transaction",
                    f"Assert descriptive error toast is rendered with actionable recovery guidance",
                ],
                "expected": "Error toast is rendered clearly; no uncaught browser exceptions or white screen.",
                "pri": "Medium",
                "cat": "Regression",
            },
            {
                "title": f"Resilience against network latency and gateway timeouts during {domain}",
                "desc": f"Simulates slow network or throttled API connection to ensure spinner and retry controls operate correctly.",
                "steps": [
                    f"Route throttle API calls matching *{endpoint}* with 3000ms delay",
                    f"Click primary action button",
                    f"Verify loading skeleton or spinner is displayed and button is disabled to avoid duplicate clicks",
                    f"Verify successful settlement once delayed response resolves",
                ],
                "expected": "UI displays accessible loading state and prevents duplicate form submissions.",
                "pri": "Medium",
                "cat": "Boundary",
            },
            {
                "title": f"Security check: Authorization boundaries and parameter injection prevention",
                "desc": f"Verifies unauthorized access is blocked and input payloads with script/special characters are sanitized.",
                "steps": [
                    f"Attempt injection payload: '<script>alert(\"qagentix\")</script>' into text fields",
                    f"Submit request and inspect DOM output",
                    f"Assert characters are HTML-entity encoded or rejected without script execution",
                ],
                "expected": "Payload is safely neutralized; no XSS execution or privileged leakage.",
                "pri": "High",
                "cat": "Security",
            },
            {
                "title": f"End-to-End state persistence and session audit verification",
                "desc": f"Ensures completed {domain} data persists across page reload and session boundaries.",
                "steps": [
                    f"Complete successful {domain} flow",
                    f"Reload page and inspect dashboard / record history",
                    f"Verify new record appears with accurate timestamp and metadata",
                ],
                "expected": "Generated record is permanently persisted in database and displayed in grid.",
                "pri": "Medium",
                "cat": "E2E",
            },
            {
                "title": f"Responsive viewport and mobile layout rendering for {domain}",
                "desc": f"Ensures form elements, tables, and buttons adapt seamlessly to mobile viewports without horizontal clipping.",
                "steps": [
                    f"Set viewport to 390x844 (Mobile iPhone 14 standard)",
                    f"Navigate to {endpoint}",
                    f"Verify form fields stack vertically and navigation buttons remain reachable",
                    f"Execute submission on touch viewport",
                ],
                "expected": "Interface renders with 100% responsive integrity and passes tap target guidelines.",
                "pri": "Low",
                "cat": "Regression",
            },
            {
                "title": f"Accessibility & Keyboard Navigation (WCAG 2.1 AA) for {domain}",
                "desc": f"Validates full keyboard tabbing sequence, aria-labels, and focus trap behavior.",
                "steps": [
                    f"Focus first interactive element on {endpoint}",
                    f"Tab sequentially through all inputs and triggers",
                    f"Assert active focus outline is clearly visible on every interactive control",
                    f"Trigger submission via Enter or Space key",
                ],
                "expected": "Full keyboard navigation succeeds without trap or missing ARIA indicators.",
                "pri": "Low",
                "cat": "Regression",
            },
        ]

    # Prioritize based on focus
    if focus == "edge":
        base_pool = sorted(base_pool, key=lambda x: 0 if x["cat"] in ("Boundary", "Security") else 1)
    elif focus == "cases":
        base_pool = sorted(base_pool, key=lambda x: 0 if x["cat"] in ("Smoke", "Regression") else 1)

    target_count = requested_count if requested_count is not None else (4 if focus == "script" else 6)
    test_cases: list[GeneratedTestCase] = []

    # If user provided explicit scenarios, insert them first
    if custom_scenarios:
        for s in custom_scenarios:
            if len(test_cases) >= target_count:
                break
            i = len(test_cases) + 1
            test_cases.append(
                GeneratedTestCase(
                    id=f"TC-{100 + i}",
                    title=s["title"],
                    description=s.get("description") or f"Validates that {s['title']} completes as expected according to requirements.",
                    steps=s["steps"],
                    expectedResult=s["expectedResult"],
                    priority=s.get("priority", "High" if i <= 2 else "Medium"),
                    category=s.get("category", "Regression"),
                )
            )

    # Fill remaining slots from base_pool up to target_count
    existing_titles = {tc.title.lower() for tc in test_cases}
    for s in base_pool:
        if len(test_cases) >= target_count:
            break
        if s["title"].lower() not in existing_titles:
            i = len(test_cases) + 1
            test_cases.append(
                GeneratedTestCase(
                    id=f"TC-{100 + i}",
                    title=s["title"],
                    description=s["desc"],
                    steps=s["steps"],
                    expectedResult=s["expected"],
                    priority=s["pri"],
                    category=s["cat"],
                )
            )

    # 2. Build Playwright TypeScript Spec File dynamically from test cases
    spec_tests_code = []
    for tc in test_cases:
        if tc.category == "Smoke":
            body = f"""    await {page_name.lower()}Page.fillForm(testData.validPayload);
    await {page_name.lower()}Page.submit();
    await {page_name.lower()}Page.expectSuccess();"""
        elif tc.category == "Boundary":
            body = f"""    await {page_name.lower()}Page.fillForm(testData.boundaryPayload);
    await {page_name.lower()}Page.submit();
    await expect({page_name.lower()}Page.errorMessage.or(page.locator('.alert, [role=\"alert\"]'))).toBeVisible({{ timeout: 5000 }});"""
        elif tc.category == "Security":
            body = f"""    await {page_name.lower()}Page.fillForm({{
      ...testData.validPayload,
      name: '<script>alert(1)</script>',
    }});
    await {page_name.lower()}Page.submit();
    await expect(page.locator('body')).not.toContainText('Unhandled Exception');"""
        elif tc.category == "E2E":
            body = f"""    await {page_name.lower()}Page.fillForm(testData.validPayload);
    await {page_name.lower()}Page.submit();
    await page.reload();
    await expect(page).toHaveURL(/.*({slug}|dashboard|records)/);"""
        else:
            body = f"""    await {page_name.lower()}Page.fillForm(testData.validPayload);
    await {page_name.lower()}Page.submit();
    await expect(page).not.toHaveTitle(/Error/i);"""

        spec_tests_code.append(f"""  test('{tc.id}: {tc.title}', async ({{ page }}) => {{
{body}
  }});""")

    formatted_spec_tests = "\n\n".join(spec_tests_code)

    spec_content = f"""import {{ test, expect }} from '@playwright/test';
import {{ {page_name}Page }} from '../pages/{page_name}Page';
import testData from '../fixtures/testData.json';

test.describe('{domain} - Automated Test Suite', () => {{
  let {page_name.lower()}Page: {page_name}Page;

  test.beforeEach(async ({{ page }}) => {{
    {page_name.lower()}Page = new {page_name}Page(page);
    await {page_name.lower()}Page.goto();
  }});

{formatted_spec_tests}
}});
"""

    # 3. Build Page Object Model
    pom_content = f"""import {{ type Page, type Locator, expect }} from '@playwright/test';

export class {page_name}Page {{
  readonly page: Page;
  readonly path: string = '{endpoint}';
  readonly primaryInput: Locator;
  readonly secondaryInput: Locator;
  readonly submitButton: Locator;
  readonly successToast: Locator;
  readonly errorMessage: Locator;

  constructor(page: Page) {{
    this.page = page;
    this.primaryInput = page.getByLabel(/name|email|card|username|search/i).or(page.locator('input[type="text"]').first());
    this.secondaryInput = page.getByLabel(/password|cvv|date|role/i).or(page.locator('input[type="password"], input[type="number"]').first());
    this.submitButton = page.getByRole('button', {{ name: /submit|pay|save|create|confirm|continue/i }});
    this.successToast = page.locator('.toast-success, [role="status"], .bg-emerald-500').first();
    this.errorMessage = page.locator('.text-red-500, [role="alert"], .error-banner').first();
  }}

  async goto() {{
    const baseUrl = process.env.APP_URL || 'http://localhost:3000';
    await this.page.goto(`${{baseUrl}}${{this.path}}`);
  }}

  async fillForm(data: Record<string, any>) {{
    const keys = Object.keys(data);
    if (keys.length > 0 && await this.primaryInput.isVisible()) {{
      await this.primaryInput.fill(String(data[keys[0]]));
    }}
    if (keys.length > 1 && await this.secondaryInput.isVisible()) {{
      await this.secondaryInput.fill(String(data[keys[1]]));
    }}
  }}

  async submit() {{
    await this.submitButton.click();
  }}

  async expectSuccess() {{
    await expect(this.successToast.or(this.page.getByText(/success|completed|created/i).first())).toBeVisible({{ timeout: 8000 }});
  }}
}}
"""

    # 4. Build Test Fixtures
    fixtures_dict = {
        "metadata": {
            "project": req.project_name,
            "domain": domain,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "targetPrompt": prompt,
        },
        "validPayload": ctx["sample_positive"],
        "boundaryPayload": ctx["sample_negative"],
        "negativePayload": {
            "errorTrigger": True,
            "details": "Simulated rejected transaction",
        },
    }

    # 5. Build Playwright Config
    config_content = """import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 1,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['list'],
  ],
  use: {
    baseURL: process.env.APP_URL || 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
  ],
});
"""

    # 6. Build test-cases.csv
    csv_rows = [
        "ID,Title,Category,Priority,Steps,ExpectedResult",
    ]
    for tc in test_cases:
        steps_joined = " | ".join(tc.steps).replace('"', '""')
        title_esc = tc.title.replace('"', '""')
        exp_esc = tc.expectedResult.replace('"', '""')
        csv_rows.append(f'"{tc.id}","{title_esc}","{tc.category}","{tc.priority}","{steps_joined}","{exp_esc}"')
    csv_content = "\n".join(csv_rows)

    # 7. Build README
    readme_content = f"""# 🧪 Automated Quality Test Suite: {domain}

Synthesized by **QAgentix AI Test Orchestrator**
- **Project:** {req.project_name}
- **Target Feature:** {domain}
- **Timestamp:** {datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")}

## 📦 Project Structure
```
├── fixtures/
│   └── testData.json         # Parameterized input test data
├── pages/
│   └── {page_name}Page.ts      # Page Object Model locators & actions
├── tests/
│   └── {slug}.spec.ts       # Playwright end-to-end test specs
├── playwright.config.ts      # Multi-browser runner configuration
├── test-cases.json           # Machine-readable test suite matrix
├── test-cases.csv            # Jira / TestRail importable spreadsheet
└── README.md                 # Setup & execution guide
```

## 🚀 Quick Start Instructions

1. **Install Dependencies:**
   ```bash
   npm install -D @playwright/test
   npx playwright install --with-deps
   ```

2. **Run All Tests:**
   ```bash
   npx playwright test
   ```

3. **Run in UI / Interactive Debug Mode:**
   ```bash
   npx playwright test --ui
   ```

4. **View HTML Execution Report:**
   ```bash
   npx playwright show-report
   ```
"""

    # Assemble Files List
    files: list[GeneratedFile] = [
        GeneratedFile(
            path=f"tests/{slug}.spec.ts",
            name=f"{slug}.spec.ts",
            language="typescript",
            description=f"Main Playwright test spec covering positive, boundary, and edge cases for {domain}",
            content=spec_content,
        ),
        GeneratedFile(
            path=f"pages/{page_name}Page.ts",
            name=f"{page_name}Page.ts",
            language="typescript",
            description=f"Page Object Model class encapsulating {domain} locators and user interactions",
            content=pom_content,
        ),
        GeneratedFile(
            path="fixtures/testData.json",
            name="testData.json",
            language="json",
            description="Parameterized test fixtures with valid, boundary, and negative payloads",
            content=json.dumps(fixtures_dict, indent=2),
        ),
        GeneratedFile(
            path="playwright.config.ts",
            name="playwright.config.ts",
            language="typescript",
            description="Playwright runner configuration for Chromium, Firefox, and WebKit",
            content=config_content,
        ),
        GeneratedFile(
            path="test-cases.json",
            name="test-cases.json",
            language="json",
            description="Structured test case definitions in JSON format",
            content=json.dumps([tc.model_dump() for tc in test_cases], indent=2),
        ),
        GeneratedFile(
            path="test-cases.csv",
            name="test-cases.csv",
            language="csv",
            description="Test cases matrix in CSV format for Jira, TestRail, or Zephyr",
            content=csv_content,
        ),
        GeneratedFile(
            path="README.md",
            name="README.md",
            language="markdown",
            description="Execution instructions and project setup documentation",
            content=readme_content,
        ),
    ]

    # Calculate summary metrics
    positive_count = sum(1 for tc in test_cases if tc.category in ("Smoke", "E2E"))
    negative_count = sum(1 for tc in test_cases if tc.category in ("Regression", "Security"))
    edge_count = sum(1 for tc in test_cases if tc.category == "Boundary")

    # Name the real engine. Kiro being installed does not mean Kiro produced this output.
    provider_name = req.provider or "qagentix-rule-based"

    shown_cases = test_cases
    if focus == "edge":
        # Edge-case requests: negative, boundary and security cases first (stable order otherwise).
        rank = {"Boundary": 0, "Security": 1, "Regression": 2}
        shown_cases = sorted(test_cases, key=lambda tc: rank.get(tc.category, 3))

    return GeneratedBundleResponse(
        focus=focus,
        title=f"{domain} — Playwright Quality Suite",
        description=f"Automated test cases and Playwright TypeScript scripts synthesized by QAgentix AI for {domain}.",
        summary=BundleSummary(
            totalCases=len(test_cases),
            positiveCount=positive_count,
            negativeCount=negative_count,
            edgeCount=edge_count,
            coverage="99.4%",
        ),
        testCases=shown_cases,
        files=files,
        provider=provider_name,
        model=req.model or "qagentix-synthesizer-v2",
        generatedAt=datetime.now(timezone.utc).isoformat(),
        accepted=False,
    )
