# QAgentix Kiro Agent Failure Modes & Recovery Documentation

This document defines, documents, and provides reproducible steps for all critical failure modes in the QAgentix Kiro IDE / Agent architecture:
1. **Missing CLI & Missing Auth**
2. **Invalid Request**
3. **Execution Timeout**
4. **Malformed Output & Corrupted JSON**

---

## 1. Summary of Failure Modes & Mitigations

| Failure Mode | Trigger Condition | System Behavior & Mitigation | Status Code / Result |
| :--- | :--- | :--- | :--- |
| **Missing Auth** | Request to `/api/agent/kiro/*` with missing or invalid `Authorization` header | Fast-fails at JWT middleware before dispatching agent workload | `401 Unauthorized` / `403 Forbidden` |
| **Missing CLI Binary** | `kiro-cli` binary is not found on PATH or standard directories | Gracefully degrades to internal multi-agent synthesizer; marks surface as fallback | `200 OK` (fallback agent activated) |
| **Invalid Prompt** | Empty prompt or prompt lacking QA/test engineering intent | Rejection with clear actionable error message; prevents wasted token spend | `400 Bad Request` |
| **Path Traversal** | Relative path contains directory escape sequences (`../`) | Strict path containment verification using `os.path.commonpath` | `400 Bad Request` |
| **CLI Timeout** | Subprocess exceeds configured `timeout_seconds` | Subprocess terminated via `proc.kill()`; execution logged and gracefully recovered | `TimeoutError` trapped; error recorded |
| **Malformed Output** | CLI/LLM returns non-zero exit code or garbled/invalid JSON | Strict regex JSON block extraction with safe empty dictionary / fallback schema defaults | Non-crashing recovery; schema default fallback |

---

## 2. Failure Mode Details & Reproducibility

### A. Missing Auth & Missing CLI

#### 1. Missing or Invalid Auth Token
- **Location**: `Backend/app/api/deps.py` (`get_current_user`)
- **Reproduction**:
  ```bash
  # cURL (missing header)
  curl -X POST http://localhost:8000/api/agent/kiro/execute \
    -H "Content-Type: application/json" \
    -d '{"prompt": "Verify login flow"}'
  ```
- **Expected Response**:
  ```json
  HTTP/1.1 401 Unauthorized
  {"detail": "Not authenticated"}
  ```

#### 2. Missing Kiro CLI Binary
- **Location**: `Backend/app/agent/kiro_agent.py` (`find_kiro_binary`, `get_kiro_status`)
- **Behavior**: When `kiro-cli.exe` is absent from PATH and common installation directories:
  - Status endpoint returns `installed: false`, `version: null`.
  - Execution automatically delegates to the internal Python Multi-Agent orchestrator without failing the user request.
- **Python Reproduction**:
  ```python
  from unittest.mock import patch
  from app.agent.kiro_agent import find_kiro_binary, get_kiro_status

  with patch("app.agent.kiro_agent.find_kiro_binary", return_value=None):
      status = get_kiro_status()
      assert status.installed is False
      assert "not found" in status.message.lower()
  ```

---

### B. Invalid Request

#### 1. Empty or Non-QA Prompts
- **Location**: `Backend/app/agent/kiro_agent.py` (`validate_requirements_prompt`) & `Backend/app/api/routes/kiro.py`
- **Behavior**: Ensures the model only processes actionable QA, testing, and test automation tasks. Prompts like `"hello"`, `"tell me a recipe"`, or `""` are rejected.
- **Reproduction**:
  ```bash
  curl -X POST http://localhost:8000/api/agent/kiro/execute \
    -H "Authorization: Bearer <TOKEN>" \
    -H "Content-Type: application/json" \
    -d '{"prompt": "what is the capital of France?"}'
  ```
- **Expected Response**:
  ```json
  HTTP/1.1 400 Bad Request
  {
    "detail": "Requirements prompt must contain test engineering intent (e.g. login, api, test, playwright, checkout, assert, verify)."
  }
  ```

#### 2. Path Traversal Attempts
- **Location**: `Backend/app/api/routes/kiro.py` (`read_file_content`) & `Backend/app/agent/common.py` (`_safe_workspace_write`)
- **Behavior**: Rejects any relative path with `..` or path escaping patterns.
- **Reproduction**:
  ```bash
  curl -X POST http://localhost:8000/api/agent/kiro/read-file \
    -H "Authorization: Bearer <TOKEN>" \
    -H "Content-Type: application/json" \
    -d '{"relative_path": "../../windows/win.ini"}'
  ```
- **Expected Response**:
  ```json
  HTTP/1.1 400 Bad Request
  {"detail": "Invalid relative path traversal."}
  ```

---

### C. Execution Timeout

- **Location**: `Backend/app/agent/kiro_agent.py` (`execute_with_kiro_cli`, `run_kiro_agent`)
- **Behavior**:
  - The subprocess runs with `asyncio.wait_for(proc.communicate(), timeout=timeout_seconds)`.
  - When the timeout expires, `proc.kill()` terminates the orphaned subprocess.
  - In `run_kiro_agent`, the `TimeoutError` is logged as a warning (`Kiro CLI execution failed: ... Using Agent Orchestrator`), and the agent synthesizes the test artifacts via fallback without dropping the user's session.
- **Python Reproduction**:
  ```python
  import asyncio
  from app.agent.kiro_agent import run_kiro_agent
  from app.schemas.kiro import KiroExecuteRequest
  from unittest.mock import patch

  req = KiroExecuteRequest(prompt="Verify payment gateway flow", timeout_seconds=1)
  with patch("app.agent.kiro_agent.find_kiro_binary", return_value="kiro.exe"), \
       patch("app.agent.kiro_agent.execute_with_kiro_cli", side_effect=TimeoutError("Timed out")), \
       patch("app.agent.kiro_agent.settings.kiro_mode", "cli"):

      response = asyncio.run(run_kiro_agent(req))
      assert response.status == "SUCCESS"
      assert "Timed out" in response.error
      assert len(response.artifacts) > 0  # Fallback successfully created artifacts
  ```

---

### D. Malformed Output & JSON Recovery

- **Location**: `Backend/app/agent/common.py` (`extract_json_payload`) & `Backend/app/agent/kiro_agent.py`
- **Behavior**:
  - Non-zero exit code: If CLI exits with error code != 0, a descriptive `RuntimeError(f"Kiro CLI exited with code {code}: {stderr}")` is raised.
  - Corrupted JSON / Markdown formatting: LLMs frequently wrap JSON in markdown blocks (` ```json {...} ``` `) or append conversational commentary. `extract_json_payload` uses progressive extraction:
    1. Direct JSON parse
    2. Markdown code fence regex extraction
    3. Outermost curly brace regex matching
    4. Safe empty dictionary fallback `{}` (prevents uncaught JSONDecodeError crashes)
- **Python Reproduction**:
  ```python
  from app.agent.common import extract_json_payload

  # Case 1: Markdown-wrapped JSON with commentary
  raw = "Here is the result:\n```json\n{\"plan_path\": \".qagentix/plan.md\"}\n```\nDone!"
  assert extract_json_payload(raw) == {"plan_path": ".qagentix/plan.md"}

  # Case 2: Completely corrupt text
  corrupt = "Error 500: Server crashed <html unparseable"
  assert extract_json_payload(corrupt) == {}  # Returns clean empty dict without throwing
  ```

---

### E. Workspace Allowlist, Symlinks, and Input Size Limits

- **Location**: `Backend/app/agent/common.py` (`validate_workspace_path`, `validate_safe_path`, `validate_input_size`, `_safe_workspace_write`, `_safe_workspace_read`), `Backend/app/core/config.py`, & `Backend/app/api/routes/kiro.py`
- **Behavior**:
  - **Workspace Allowlist**: Only paths under approved workspace roots (`settings.workspace_allowlist`) are accepted. Arbitrary paths (e.g. system directories or unauthorized folders) raise `PermissionError` and return `403 Forbidden`.
  - **Path Traversal & Symlinks**: Relative path components with `..`, null bytes (`\0`), or symlinks resolving outside the workspace boundary raise `PermissionError` and return `400 Bad Request`.
  - **Input & File Size Limits**:
    - Prompt length capped at `settings.max_input_prompt_chars` (default 50,000 characters). Exceeding requests return `400 Bad Request` or `422 Unprocessable Entity`.
    - File writes capped at `settings.max_file_write_bytes` (default 5 MB). Exceeding writes raise `ValueError`.
    - File reads capped at `settings.max_file_read_bytes` (default 10 MB). Exceeding reads return `413 Request Entity Too Large`.

---

### F. Testcase/Script Schema Validation & Static Safety Checks

- **Location**: `Backend/app/agent/safety.py` (`run_static_safety_checks`, `validate_testcase_schema`, `validate_script_contract`, `validate_pre_execution_safety`) & `Backend/app/agent/execute_agent.py`
- **Behavior**:
  - **Testcase Schema Validation**: Validates testcases against `TestCase` and `TestCaseItem` schemas. Rejects missing steps, illegal categories, invalid priorities, and empty expected results.
  - **Script Contract Validation**: Enforces scripts to reside strictly under `Scripts/` with valid test extensions (`.spec.ts`, `.spec.js`) and Playwright test block structures.
  - **Static AST/Regex Safety Checks**: Scans script code before runner invocation and blocks dangerous patterns:
    - Subprocess / shell execution (`child_process`, `execSync`, `spawnSync`, `execFile`, `exec`)
    - Dynamic code evaluation (`eval(`, `new Function(`, `vm.runInContext`)
    - Destructive filesystem operations (`fs.rmSync`, `fs.unlinkSync`, `rm -rf`, `del /f`)
    - Process tampering (`process.exit`, `process.kill`, `delete process.env`)
    - Cloud metadata SSRF & exfiltration (`169.254.169.254`, `metadata.google.internal`, `file://`, `javascript:`)
  - **Pre-execution Gate**: `ExecuteAgent` validates testcase schemas and script safety before dispatching to the runner. If any violation is found, execution is blocked immediately, returning `status="ERROR"` with detailed audit logs in `Reports/logs/execution.log` and `Reports/results.json`.

---

## 3. Running the Test Suite

All 54 automated unit, security boundary, schema validation, and safety tests can be run via Python unittest:

```powershell
cd Backend
.\venv\Scripts\python.exe -m unittest discover -s tests -p "test_*.py" -v
```

### Verified Test Suite Output:
```text
Ran 54 tests in 7.859s

OK
```


