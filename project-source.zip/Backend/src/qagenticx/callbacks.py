"""Token usage and cost tracking callback for LangChain LLM calls."""

from __future__ import annotations

from typing import Any
from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.outputs import LLMResult


class TokenUsageCallback(BaseCallbackHandler):
    """Callback handler that tracks prompt, completion, total tokens, and estimated cost."""

    def __init__(self) -> None:
        super().__init__()
        self.prompt_tokens: int = 0
        self.completion_tokens: int = 0
        self.total_tokens: int = 0
        self.total_cost: float = 0.0
        self.call_count: int = 0
        self.history: list[dict[str, Any]] = []

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        """Capture usage metrics when an LLM call completes."""
        self.call_count += 1
        prompt = 0
        completion = 0
        total = 0
        cost = 0.0

        # 1. Check llm_output dict (standard in ChatOpenAI, ChatAnthropic, etc.)
        llm_output = response.llm_output or {}
        usage = (
            llm_output.get("token_usage")
            or llm_output.get("usage")
            or llm_output.get("estimated_tokens")
            or {}
        )

        if usage:
            prompt = usage.get("prompt_tokens") or usage.get("input_tokens") or 0
            completion = usage.get("completion_tokens") or usage.get("output_tokens") or 0
            total = usage.get("total_tokens") or (prompt + completion)
            cost = float(usage.get("total_cost") or usage.get("cost") or 0.0)

        # 2. Check generation metadata (e.g., usage_metadata on AIMessage)
        if total == 0 and response.generations:
            for gen_list in response.generations:
                for gen in gen_list:
                    # message attribute on ChatGeneration
                    msg = getattr(gen, "message", None)
                    if msg is not None:
                        usage_meta = getattr(msg, "usage_metadata", None)
                        if isinstance(usage_meta, dict):
                            p = usage_meta.get("input_tokens", 0)
                            c = usage_meta.get("output_tokens", 0)
                            t = usage_meta.get("total_tokens", p + c)
                            prompt += p
                            completion += c
                            total += t

                    gen_info = getattr(gen, "generation_info", None) or {}
                    usage_gen = gen_info.get("usage_metadata") or gen_info.get("token_usage") or {}
                    if isinstance(usage_gen, dict):
                        p = usage_gen.get("prompt_tokens", 0) or usage_gen.get("input_tokens", 0)
                        c = usage_gen.get("completion_tokens", 0) or usage_gen.get("output_tokens", 0)
                        prompt += p
                        completion += c
                        total += (usage_gen.get("total_tokens") or (p + c))

        if total == 0 and (prompt > 0 or completion > 0):
            total = prompt + completion

        self.prompt_tokens += prompt
        self.completion_tokens += completion
        self.total_tokens += total
        self.total_cost += cost

        record = {
            "prompt_tokens": prompt,
            "completion_tokens": completion,
            "total_tokens": total,
            "cost": cost,
        }
        self.history.append(record)

    def get_summary(self) -> dict[str, Any]:
        """Return a snapshot dictionary of token usage and cost metrics."""
        return {
            "call_count": self.call_count,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "total_cost": self.total_cost,
        }

    def reset(self) -> None:
        """Reset all counters to zero."""
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.total_tokens = 0
        self.total_cost = 0.0
        self.call_count = 0
        self.history.clear()
