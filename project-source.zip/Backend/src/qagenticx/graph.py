"""LangGraph foundation graph for QAgenticx."""

from __future__ import annotations

from typing import TypedDict
from langgraph.graph import StateGraph, START, END

from qagenticx.config import ProjectConfig


class AgentState(TypedDict):
    project_id: str
    target_url: str
    steps: list[str]
    message: str


def plan_node(state: AgentState) -> dict:
    """Plan node: records the 'plan' execution step."""
    steps = list(state.get("steps", []))
    steps.append("plan")
    return {"steps": steps}


def greet_node(state: AgentState) -> dict:
    """Greet node: records the 'greet' execution step and generates the greeting message."""
    steps = list(state.get("steps", []))
    steps.append("greet")
    project_id = state.get("project_id", "unknown")
    target_url = state.get("target_url", "unknown")
    message = f"Hello from QAgenticx! Project: {project_id}, Target: {target_url}"
    return {"steps": steps, "message": message}


def build_graph():
    """Build and compile the 2-node hello-world LangGraph: START -> plan -> greet -> END."""
    builder = StateGraph(AgentState)
    builder.add_node("plan", plan_node)
    builder.add_node("greet", greet_node)
    builder.add_edge(START, "plan")
    builder.add_edge("plan", "greet")
    builder.add_edge("greet", END)
    return builder.compile()


def run_project(config: ProjectConfig) -> dict:
    """Seed state from ProjectConfig and execute the LangGraph."""
    graph = build_graph()
    initial_state: AgentState = {
        "project_id": config.id,
        "target_url": config.target_url,
        "steps": [],
        "message": "",
    }
    return graph.invoke(initial_state)
