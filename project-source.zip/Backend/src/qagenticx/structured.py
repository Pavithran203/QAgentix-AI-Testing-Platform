"""Pydantic structured output helper with fallback support."""

from __future__ import annotations

import json
import re
from typing import Any, Type, TypeVar
from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound=BaseModel)


def extract_json_from_text(text: str) -> dict[str, Any]:
    """Extract a JSON object from text, handling markdown codeblocks if present."""
    text = text.strip()
    match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text)
    if match:
        text = match.group(1).strip()
    return json.loads(text)


def structured_call(model: Any, schema: Type[T], messages: Any) -> T:
    """Invoke an LLM with structured output, validating the response against a Pydantic schema.
    
    1. Attempts native model.with_structured_output(schema).
    2. Falls back to JSON prompt instruction + JSON extraction + Pydantic validation
       for models or local providers without native function-calling/structured output.
    """
    # 1. Try native structured output
    if hasattr(model, "with_structured_output"):
        try:
            runnable = model.with_structured_output(schema)
            result = runnable.invoke(messages)
            if isinstance(result, schema):
                return result
            if isinstance(result, dict):
                return schema.model_validate(result)
        except Exception:
            # Fall back to prompt-guided JSON extraction
            pass

    # 2. Fallback: prompt instructions + JSON parse
    schema_json = json.dumps(schema.model_json_schema(), indent=2)
    instruction = (
        f"\n\nRespond ONLY with a valid JSON object matching this schema:\n{schema_json}\n"
        "Do not include any other markdown text or explanation outside the JSON."
    )

    if isinstance(messages, str):
        augmented_input = messages + instruction
    elif isinstance(messages, list):
        from langchain_core.messages import BaseMessage, HumanMessage
        augmented_input = list(messages)
        if augmented_input and isinstance(augmented_input[-1], BaseMessage):
            last = augmented_input[-1]
            augmented_input[-1] = type(last)(content=str(last.content) + instruction)
        else:
            augmented_input.append(HumanMessage(content=instruction))
    else:
        augmented_input = messages

    response = model.invoke(augmented_input)
    content = getattr(response, "content", response)
    if not isinstance(content, str):
        content = str(content)

    parsed_json = extract_json_from_text(content)
    return schema.model_validate(parsed_json)
