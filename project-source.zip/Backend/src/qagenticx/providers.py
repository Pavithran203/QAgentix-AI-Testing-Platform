"""LLM Provider factory and resilience execution for QAgenticx."""

from __future__ import annotations

import os
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from tenacity import (
    Retrying,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from qagenticx.settings import LLMSettings, ProviderSettings, SettingsError


class ProviderError(Exception):
    """Base exception for provider errors."""
    pass


class AuthenticationError(ProviderError):
    """Raised when an API key is missing or invalid."""
    pass


class ProviderTimeoutError(ProviderError):
    """Raised when an LLM call exceeds configured timeout."""
    pass


def is_transient_error(exc: BaseException) -> bool:
    """Determine whether an exception is transient (network/rate limit/5xx) or non-retryable (auth/400)."""
    # Non-retryable
    if isinstance(exc, (AuthenticationError, SettingsError)):
        return False

    exc_name = type(exc).__name__.lower()
    if any(k in exc_name for k in ["auth", "permission", "badrequest", "notfound", "invalidrequest"]):
        return False

    status = getattr(exc, "status_code", None) or getattr(exc, "code", None)
    if status in (400, 401, 403, 404):
        return False
    if status in (429, 500, 502, 503, 504):
        return True

    # Retry network, connection, timeout, or rate-limit messages
    if isinstance(exc, (TimeoutError, ConnectionError, OSError)):
        return True

    msg = str(exc).lower()
    if any(term in msg for term in ["rate limit", "timeout", "timed out", "connection error", "503", "502", "overloaded"]):
        return True

    return True


def invoke_with_retry(
    model: Any,
    messages: Any,
    max_retries: int = 3,
    backoff_base: float = 1.0,
    backoff_max: float = 10.0,
    **kwargs: Any,
) -> Any:
    """Invoke an LLM model with exponential backoff retry for transient errors."""
    retryer = Retrying(
        stop=stop_after_attempt(max(1, max_retries + 1)),
        wait=wait_exponential(multiplier=backoff_base, max=backoff_max),
        retry=retry_if_exception(is_transient_error),
        reraise=True,
    )
    for attempt in retryer:
        with attempt:
            return model.invoke(messages, **kwargs)


def get_chat_model(
    settings: LLMSettings,
    provider: str | None = None,
    model: str | None = None,
    temperature: float | None = None,
    with_retry: bool = False,
) -> BaseChatModel:
    """Factory creating a configured LangChain ChatModel with uniform parameters and API key checks.
    
    Supported providers:
      - openai -> ChatOpenAI
      - claude (or anthropic) -> ChatAnthropic
      - gemini (or google) -> ChatGoogleGenerativeAI
      - ollama -> ChatOllama (local)
    """
    prov_name, p_settings = settings.get_provider_settings(provider)
    chosen_model = model or p_settings.default_model
    chosen_temp = temperature if temperature is not None else p_settings.temperature
    timeout = p_settings.timeout_seconds

    if prov_name in ("openai", "claude", "gemini"):
        api_key = settings.get_api_key(prov_name)
        if not api_key or not api_key.strip():
            env_var = p_settings.api_key_env or "API_KEY"
            raise AuthenticationError(
                f"Missing API key for provider '{prov_name}'. Please set the '{env_var}' environment variable."
            )

    if prov_name == "openai":
        from langchain_openai import ChatOpenAI
        chat_model = ChatOpenAI(
            model=chosen_model,
            api_key=api_key,
            temperature=chosen_temp,
            timeout=timeout,
        )

    elif prov_name == "claude":
        from langchain_anthropic import ChatAnthropic
        chat_model = ChatAnthropic(
            model=chosen_model,
            api_key=api_key,
            temperature=chosen_temp,
            timeout=timeout,
        )

    elif prov_name == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI
        chat_model = ChatGoogleGenerativeAI(
            model=chosen_model,
            google_api_key=api_key,
            temperature=chosen_temp,
            timeout=timeout,
        )

    elif prov_name == "ollama":
        from langchain_ollama import ChatOllama
        base_url = p_settings.base_url or "http://localhost:11434"
        chat_model = ChatOllama(
            model=chosen_model,
            base_url=base_url,
            temperature=chosen_temp,
            timeout=timeout,
        )

    else:
        raise ProviderError(f"Unsupported provider: '{prov_name}'")

    if with_retry and hasattr(chat_model, "with_retry") and p_settings.max_retries > 0:
        return chat_model.with_retry(
            stop_after_attempt=p_settings.max_retries + 1,
            wait_exponential_jitter=True,
            retry_if_exception_type=(ConnectionError, TimeoutError),
        )

    return chat_model
