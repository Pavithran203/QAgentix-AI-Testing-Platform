"""CLI entrypoint for QAgenticx."""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from qagenticx.config import ProjectConfigError, list_projects, load_project
from qagenticx.graph import run_project


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="qagenticx",
        description="QAgenticx - Agentic QA automation tool",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # list
    subparsers.add_parser("list", help="List available QA projects")

    # run
    run_parser = subparsers.add_parser("run", help="Run a QA project")
    run_parser.add_argument("project", help="Project ID to run")

    args = parser.parse_args(argv)

    if args.command == "list":
        projects = list_projects()
        if not projects:
            print("No projects found.")
        else:
            for project in projects:
                print(project)
        return 0

    elif args.command == "run":
        try:
            config = load_project(args.project)
        except ProjectConfigError as exc:
            print(f"Error loading project '{args.project}': {exc}", file=sys.stderr)
            return 1

        result = run_project(config)
        steps = " -> ".join(result.get("steps", []))
        print(f"steps: {steps}")
        message = result.get("message", "")
        if message:
            print(message)
        return 0

    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
