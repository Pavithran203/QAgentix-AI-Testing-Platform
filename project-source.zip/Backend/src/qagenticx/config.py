"""Project configuration schema and loader for QAgenticx."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError


class ProjectConfigError(Exception):
    """Raised when a project configuration cannot be loaded or fails validation."""
    pass


class BrowserConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    engine: Literal["chromium", "firefox", "webkit"] = "chromium"
    headless: bool = True
    timeout_ms: int = 30000
    viewport_width: int = 1280
    viewport_height: int = 720


class LLMConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provider: str = "openai"
    model: str = "gpt-4o"
    temperature: float = 0.0


class ProjectConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    description: str = ""
    target_url: str
    browser: BrowserConfig = Field(default_factory=BrowserConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    goals: list[str] = Field(default_factory=list)


def get_default_projects_dir() -> Path:
    """Resolve the default directory where projects are stored."""
    env_dir = os.environ.get("QAGENTICX_PROJECTS_DIR")
    if env_dir:
        return Path(env_dir).resolve()

    cwd_projects = Path.cwd() / "projects"
    if cwd_projects.is_dir():
        return cwd_projects.resolve()

    parent_projects = Path.cwd().parent / "projects"
    if parent_projects.is_dir():
        return parent_projects.resolve()

    # Relative to this source file: src/qagenticx/config.py -> backend/src/qagenticx -> repo root
    # __file__ is in backend/src/qagenticx/
    # parents: [0]=qagenticx, [1]=src, [2]=backend, [3]=repo root
    try:
        repo_projects = Path(__file__).resolve().parents[3] / "projects"
        if repo_projects.is_dir():
            return repo_projects.resolve()
    except IndexError:
        pass

    return cwd_projects.resolve()


def list_projects(projects_dir: Path | str | None = None) -> list[str]:
    """Return a sorted list of project IDs that have a project.yaml in projects_dir."""
    base_dir = Path(projects_dir).resolve() if projects_dir is not None else get_default_projects_dir()
    if not base_dir.exists() or not base_dir.is_dir():
        return []

    projects: list[str] = []
    for item in base_dir.iterdir():
        if item.is_dir() and (item / "project.yaml").is_file():
            projects.append(item.name)

    return sorted(projects)


def load_project(project_id: str, projects_dir: Path | str | None = None) -> ProjectConfig:
    """Load and validate a project.yaml file from projects/<project_id>/."""
    if not project_id or not isinstance(project_id, str):
        raise ProjectConfigError("A non-empty project_id string must be provided.")

    base_dir = Path(projects_dir).resolve() if projects_dir is not None else get_default_projects_dir()
    project_folder = base_dir / project_id

    if not project_folder.exists() or not project_folder.is_dir():
        raise ProjectConfigError(f"Project directory does not exist: {project_folder}")

    yaml_file = project_folder / "project.yaml"
    if not yaml_file.exists() or not yaml_file.is_file():
        raise ProjectConfigError(f"Missing project.yaml in directory: {project_folder}")

    try:
        content = yaml_file.read_text(encoding="utf-8")
        data = yaml.safe_load(content)
    except yaml.YAMLError as exc:
        raise ProjectConfigError(f"Malformed YAML in {yaml_file}: {exc}") from exc
    except Exception as exc:
        raise ProjectConfigError(f"Failed to read {yaml_file}: {exc}") from exc

    if data is None:
        data = {}
    elif not isinstance(data, dict):
        raise ProjectConfigError(
            f"project.yaml in {project_folder} must define a mapping/dictionary, got {type(data).__name__}."
        )

    # Hard constraint: The folder name IS the project id (do not read id from YAML; folder name wins)
    data["id"] = project_id

    try:
        return ProjectConfig.model_validate(data)
    except ValidationError as exc:
        raise ProjectConfigError(f"Schema validation error in {yaml_file}:\n{exc}") from exc
