"""LLM settings and config.yaml loader for QAgenticx."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict, Field, ValidationError


class SettingsError(Exception):
    """Raised when settings fail to load or validate."""
    pass


class ProviderSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    default_model: str
    temperature: float = 0.0
    timeout_seconds: float = 30.0
    max_retries: int = 3
    backoff_base_seconds: float = 1.0
    backoff_max_seconds: float = 10.0
    api_key_env: str | None = None
    base_url: str | None = None


class LLMSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    default_provider: str = "openai"
    providers: dict[str, ProviderSettings] = Field(default_factory=dict)

    def get_provider_name(self, provider: str | None = None) -> str:
        """Resolve the provider name (lowercased) or default provider."""
        resolved = (provider or self.default_provider).strip().lower()
        # Aliases
        if resolved == "anthropic":
            resolved = "claude"
        elif resolved in ("google", "google-genai"):
            resolved = "gemini"
        return resolved

    def get_provider_settings(self, provider: str | None = None) -> tuple[str, ProviderSettings]:
        """Return (resolved_provider_name, ProviderSettings) or raise SettingsError."""
        name = self.get_provider_name(provider)
        if name not in self.providers:
            available = ", ".join(sorted(self.providers.keys()))
            raise SettingsError(
                f"Unknown LLM provider '{provider}'. Available providers in config: {available}"
            )
        return name, self.providers[name]

    def get_api_key(self, provider: str | None = None) -> str | None:
        """Resolve and read the API key from environment for the given provider."""
        _, settings = self.get_provider_settings(provider)
        if not settings.api_key_env:
            return None
        return os.environ.get(settings.api_key_env)


def get_default_config_path() -> Path:
    """Resolve the default path to config.yaml."""
    env_path = os.environ.get("QAGENTICX_CONFIG_PATH")
    if env_path:
        return Path(env_path).resolve()

    cwd_config = Path.cwd() / "config.yaml"
    if cwd_config.is_file():
        return cwd_config.resolve()

    parent_config = Path.cwd().parent / "config.yaml"
    if parent_config.is_file():
        return parent_config.resolve()

    try:
        # backend/src/qagenticx/settings.py -> parents[3] = repo root
        repo_config = Path(__file__).resolve().parents[3] / "config.yaml"
        if repo_config.is_file():
            return repo_config.resolve()
    except IndexError:
        pass

    return cwd_config.resolve()


def load_settings(config_path: Path | str | None = None) -> LLMSettings:
    """Load, parse, and validate config.yaml into LLMSettings."""
    # Ensure .env is loaded
    load_dotenv()

    target_path = Path(config_path).resolve() if config_path is not None else get_default_config_path()

    if not target_path.exists() or not target_path.is_file():
        raise SettingsError(f"Configuration file not found: {target_path}")

    try:
        content = target_path.read_text(encoding="utf-8")
        data = yaml.safe_load(content)
    except yaml.YAMLError as exc:
        raise SettingsError(f"Malformed YAML in {target_path}: {exc}") from exc
    except Exception as exc:
        raise SettingsError(f"Failed to read {target_path}: {exc}") from exc

    if not isinstance(data, dict):
        raise SettingsError(f"Configuration in {target_path} must be a dictionary/mapping.")

    try:
        settings = LLMSettings.model_validate(data)
    except ValidationError as exc:
        raise SettingsError(f"Settings schema validation error in {target_path}:\n{exc}") from exc

    # Validate that default_provider exists in providers mapping
    canonical_default = settings.get_provider_name(settings.default_provider)
    if canonical_default not in settings.providers:
        raise SettingsError(
            f"default_provider '{settings.default_provider}' is not configured under 'providers'."
        )

    return settings
