"""Executable module entrypoint: python -m qagenticx."""

from __future__ import annotations

import sys
from qagenticx.cli import main

if __name__ == "__main__":
    sys.exit(main())
