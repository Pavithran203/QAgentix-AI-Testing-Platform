# QAgenticx Backend & Agent Framework

The backend for **QAgenticx**, featuring an agentic QA automation tool (LangGraph + Playwright + Multi-LLM provider layer) along with a FastAPI governance platform with RBAC, Project Membership, Audit Logging, and User Management.

---

## 1. Quickstart & Installation (Python 3.12)

> **Important:** Python 3.12 is required (`>=3.12,<3.13`).

```powershell
# Navigate to the backend directory
cd Backend

# Create a virtual environment using Python 3.12
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1

# Install the qagenticx package in editable mode with dev dependencies
pip install -e ".[dev]"

# (Optional) Install FastAPI auth & db server dependencies
pip install -r requirements.txt

# Install Playwright browser drivers
playwright install chromium
```

---

## 2. Configuration & Environment Variables

### A. Environment Keys (`.env`)
Copy `.env.example` from repository root:
```powershell
Copy-Item ..\.env.example ..\.env
```
Populate API keys for the providers you plan to use:
```ini
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=AI...
# OLLAMA_BASE_URL=http://localhost:11434
```
> Note: `.env` is git-ignored and credentials are never checked into version control.

### B. Global LLM Configuration (`config.yaml`)
Located at repo root (`config.yaml`), defining default provider, models, timeouts, retries, and backoff settings:
```yaml
default_provider: openai
providers:
  openai:
    default_model: gpt-4o
    temperature: 0.0
    timeout_seconds: 30.0
    max_retries: 3
    api_key_env: OPENAI_API_KEY
  claude:
    default_model: claude-3-5-sonnet-20241022
    ...
```

### C. QA Projects (`projects/<name>/project.yaml`)
Each project folder under `projects/` defines target URLs, browser parameters, and optional LLM overrides:
```yaml
name: "Example QA Project"
target_url: "https://example.com"
browser:
  engine: "chromium"
  headless: true
llm:
  provider: "openai"
  model: "gpt-4o"
goals:
  - "Open target URL"
  - "Verify page title"
```

---

## 3. CLI Usage

```powershell
# List all QA projects
qagenticx list

# Run a project through the 2-node LangGraph
qagenticx run example
```

---

## 4. Running Tests

Run the full automated test suite:
```powershell
pytest -v
```

---

## 5. How to Select a Provider

1. **Globally via `config.yaml`**:
   Change `default_provider: claude` (or `openai`, `gemini`, `ollama`).
2. **Per-Project via `project.yaml`**:
   Specify `llm.provider` and `llm.model` inside your project's `project.yaml`.
3. **In Code via Provider Factory**:
   ```python
   from qagenticx.settings import load_settings
   from qagenticx.providers import get_chat_model

   settings = load_settings()
   model = get_chat_model(settings, provider="claude", model="claude-3-5-sonnet-20241022")
   response = model.invoke("Hello QA Agent!")
   ```

---

## 6. RBAC, Project Membership & Audit Logging (FastAPI)

### Roles & Hierarchy
- **Admin**: Full system management, user CRUD, role assignments, audit logs.
- **Test Lead**: Manage project members, trigger test suites, view audit logs.
- **Tester**: Execute tests, manage test cases, view results.
- **Viewer**: Read-only access to projects and test run results.

### API Routes
- `POST /api/auth/register` & `/api/auth/login`
- `GET /api/users` (Admin: filter by role/search)
- `POST /api/users` (Admin: create user directly)
- `PATCH /api/users/{id}/role` (Admin: promote/demote role)
- `GET /api/projects/{project_id}/members` (List project members)
- `POST /api/projects/{project_id}/members` (Add member to project)
- `GET /api/audit-logs` (Inspect audit trail with filters)

---

## 7. Prompt-Injection-Safe Page Handling (`qagenticx.security`)

All text harvested from external web pages during Playwright browsing is treated as untrusted data before being passed to LLM calls:

```python
from qagenticx.security import sanitize_page_text

# Harvested DOM text from web page
raw_dom = page.inner_text("body")

# Full sanitization pipeline:
# 1. Redacts credentials (OpenAI/Anthropic/Google keys, Bearer/JWTs, AWS keys, passwords, credit cards)
# 2. Neutralizes prompt injection commands (ignore previous instructions, role hijacking)
# 3. Strips raw chat template delimiters (<|im_start|>, [INST], etc.)
# 4. Enforces character cap (default 15,000 chars)
# 5. Encloses content within <untrusted_harvested_page url="..."> data boundaries
safe_prompt_content = sanitize_page_text(raw_dom, max_chars=15000, url=page.url)
```

Run automated tests:
```powershell
pytest -v
# Output: 50 passed
```

